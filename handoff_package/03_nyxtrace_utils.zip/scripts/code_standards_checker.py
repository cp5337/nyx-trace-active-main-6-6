"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-CODE-STANDARDS-CHECKER-0001         │
// │ 📁 domain       : Analysis, Code Quality                    │
// │ 🧠 description  : Analysis tool for code style standards    │
// │                  to enforce line length and module size     │
// │ 🕸️ hash_type    : UUID → CUID-linked module                │
// │ 🔄 parent_node  : NODE_ANALYSIS                            │
// │ 🧩 dependencies : os, sys, ast                             │
// │ 🔧 tool_usage   : Analysis, CLI                            │
// │ 📡 input_type   : Python source files                       │
// │ 🧪 test_status  : experimental                             │
// │ 🧠 cognitive_fn : style analysis, standards enforcement     │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

Code Standards Checker
--------------------
This tool analyzes Python files to check adherence to code style standards:
- Line length <= 80 characters
- Module size <= 30 lines (excluding comments and docstrings)
- Comment density >= 15% (comments to code ratio)
"""

import os
import sys
import ast
import re
import csv
from typing import Dict, List, Tuple, Any, Set
from pathlib import Path
import time

# Define standards
MAX_LINE_LENGTH = 80
MAX_MODULE_SIZE = 30  # Lines per module/component
MIN_COMMENT_RATIO = 0.15  # 15% of code should be comments

# Track global stats
total_files = 0
files_exceeding_line_length = 0
files_exceeding_module_size = 0
files_below_comment_ratio = 0


def analyze_line_length(file_path: str) -> Tuple[int, List[Tuple[int, int]]]:
    """
    Analyze line length in a file and report violations.
    
    Args:
        file_path: Path to the file to analyze
        
    Returns:
        Tuple containing:
            - Number of lines exceeding max length
            - List of (line_number, line_length) tuples for lines exceeding max length
    """
    violations = []
    
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f, 1):
                line_length = len(line.rstrip('\n'))
                if line_length > MAX_LINE_LENGTH:
                    violations.append((i, line_length))
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
    
    return len(violations), violations


def count_comment_lines(source_code: str) -> int:
    """
    Count the number of comment lines in the source code.
    
    Args:
        source_code: Source code string
        
    Returns:
        Number of comment lines
    """
    comment_count = 0
    lines = source_code.split('\n')
    
    for line in lines:
        stripped = line.strip()
        if stripped.startswith('#'):
            comment_count += 1
        elif '#' in stripped and not (
            "'" in stripped.split('#')[0] and "'" in stripped.split('#')[1]
        ) and not (
            '"' in stripped.split('#')[0] and '"' in stripped.split('#')[1]
        ):
            # Count inline comments, but avoid counting # in strings
            comment_count += 1
    
    return comment_count


def analyze_comment_density(file_path: str) -> Tuple[float, int, int]:
    """
    Analyze the comment density in a file.
    
    Args:
        file_path: Path to the file to analyze
        
    Returns:
        Tuple containing:
            - Comment ratio (comments / total lines)
            - Number of comment lines
            - Total number of non-blank lines
    """
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            source_code = f.read()
            
        # Count comment lines
        comment_lines = count_comment_lines(source_code)
        
        # Count total non-blank lines
        total_lines = sum(1 for line in source_code.split('\n') 
                          if line.strip() != '')
        
        if total_lines == 0:
            return 0.0, 0, 0
            
        # Calculate ratio
        ratio = comment_lines / total_lines
        
        return ratio, comment_lines, total_lines
    except Exception as e:
        print(f"Error analyzing comments in {file_path}: {e}")
        return 0.0, 0, 0


def extract_modules(tree: ast.AST) -> List[Tuple[str, int, int, int]]:
    """
    Extract modules (functions, classes, methods) from AST.
    
    Args:
        tree: AST tree of a Python file
        
    Returns:
        List of (name, start_line, end_line, line_count) tuples for each module
    """
    modules = []
    
    # Extract functions
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            line_count = node.end_lineno - node.lineno + 1
            modules.append((node.name, node.lineno, node.end_lineno, line_count))
        elif isinstance(node, ast.ClassDef):
            # Class itself
            line_count = node.end_lineno - node.lineno + 1
            modules.append((node.name, node.lineno, node.end_lineno, line_count))
            
            # Methods within the class
            for item in node.body:
                if isinstance(item, ast.FunctionDef):
                    method_line_count = item.end_lineno - item.lineno + 1
                    modules.append((
                        f"{node.name}.{item.name}", 
                        item.lineno, 
                        item.end_lineno, 
                        method_line_count
                    ))
    
    return modules


def analyze_module_size(file_path: str) -> Tuple[List[Tuple[str, int]], int]:
    """
    Analyze module sizes in a file and report violations.
    
    Args:
        file_path: Path to the file to analyze
        
    Returns:
        Tuple containing:
            - List of (module_name, line_count) tuples for modules exceeding max size
            - Number of modules exceeding max size
    """
    violations = []
    
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            source_code = f.read()
            
        # Parse the AST
        tree = ast.parse(source_code, filename=file_path)
        
        # Extract modules
        modules = extract_modules(tree)
        
        # Find violations
        for name, start_line, end_line, line_count in modules:
            if line_count > MAX_MODULE_SIZE:
                violations.append((name, line_count))
    except SyntaxError:
        print(f"Syntax error in {file_path}, skipping module size analysis")
    except Exception as e:
        print(f"Error analyzing module size in {file_path}: {e}")
    
    return violations, len(violations)


def analyze_file(file_path: str) -> Dict[str, Any]:
    """
    Perform a comprehensive analysis of a file.
    
    Args:
        file_path: Path to the file to analyze
        
    Returns:
        Dictionary containing analysis results
    """
    global total_files, files_exceeding_line_length
    global files_exceeding_module_size, files_below_comment_ratio
    
    total_files += 1
    results = {
        'file_path': file_path,
        'line_length': {
            'violations_count': 0,
            'violations': []
        },
        'module_size': {
            'violations_count': 0,
            'violations': []
        },
        'comment_density': {
            'ratio': 0.0,
            'comment_lines': 0,
            'total_lines': 0
        }
    }
    
    # Analyze line length
    violations_count, violations = analyze_line_length(file_path)
    results['line_length']['violations_count'] = violations_count
    results['line_length']['violations'] = violations
    
    if violations_count > 0:
        files_exceeding_line_length += 1
    
    # Analyze module size
    module_violations, module_count = analyze_module_size(file_path)
    results['module_size']['violations_count'] = module_count
    results['module_size']['violations'] = module_violations
    
    if module_count > 0:
        files_exceeding_module_size += 1
    
    # Analyze comment density
    ratio, comment_lines, total_lines = analyze_comment_density(file_path)
    results['comment_density']['ratio'] = ratio
    results['comment_density']['comment_lines'] = comment_lines
    results['comment_density']['total_lines'] = total_lines
    
    if ratio < MIN_COMMENT_RATIO and total_lines > 0:
        files_below_comment_ratio += 1
    
    return results


def scan_directory(path: str = '.', extensions: List[str] = None, 
                  exclude_dirs: List[str] = None) -> List[Dict[str, Any]]:
    """
    Scan a directory for files to analyze.
    
    Args:
        path: Directory path to scan
        extensions: File extensions to include
        exclude_dirs: Directories to exclude
        
    Returns:
        List of analysis results for each file
    """
    if extensions is None:
        extensions = ['.py']
    
    if exclude_dirs is None:
        exclude_dirs = ['__pycache__', 'venv', 'env', '.git', '.vscode', 
                       'node_modules', 'attached_assets', '.pythonlibs']
    
    results = []
    
    for root, dirs, files in os.walk(path):
        # Skip excluded directories
        dirs[:] = [d for d in dirs if d not in exclude_dirs 
                  and not d.startswith('.')]
        
        for file in files:
            if any(file.endswith(ext) for ext in extensions):
                file_path = os.path.join(root, file)
                
                # Skip files in excluded directories
                if any(exclude in file_path for exclude in exclude_dirs):
                    continue
                
                # Analyze the file
                result = analyze_file(file_path)
                results.append(result)
    
    return results


def generate_report(results: List[Dict[str, Any]], 
                   output_file: str = "code_standards_report.md") -> None:
    """
    Generate a markdown report with analysis results.
    
    Args:
        results: List of file analysis results
        output_file: Path to output markdown file
    """
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("# CTAS Code Standards Analysis Report\n\n")
        f.write(f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        # Write summary
        f.write("## Summary\n\n")
        f.write(f"- Total Python files analyzed: {total_files}\n")
        
        if total_files > 0:
            line_length_pct = (files_exceeding_line_length / total_files) * 100
            module_size_pct = (files_exceeding_module_size / total_files) * 100
            comment_pct = (files_below_comment_ratio / total_files) * 100
            
            f.write(f"- Files with lines exceeding {MAX_LINE_LENGTH} characters: "
                   f"{files_exceeding_line_length} ({line_length_pct:.1f}%)\n")
            f.write(f"- Files with modules exceeding {MAX_MODULE_SIZE} lines: "
                   f"{files_exceeding_module_size} ({module_size_pct:.1f}%)\n")
            f.write(f"- Files below {MIN_COMMENT_RATIO*100:.1f}% comment density: "
                   f"{files_below_comment_ratio} ({comment_pct:.1f}%)\n")
        
        # Line Length Violations
        f.write("\n## Line Length Violations\n\n")
        f.write("Files with the most line length violations:\n\n")
        f.write("| File | Violations | Longest Line |\n")
        f.write("|------|------------|-------------|\n")
        
        # Sort by number of violations
        sorted_by_line_violations = sorted(
            results, 
            key=lambda x: x['line_length']['violations_count'],
            reverse=True
        )
        
        for result in sorted_by_line_violations[:20]:  # Top 20
            violations = result['line_length']['violations_count']
            if violations > 0:
                file_path = result['file_path']
                # Find the longest line
                longest = max(result['line_length']['violations'], 
                             key=lambda x: x[1]) if result['line_length']['violations'] else (0, 0)
                f.write(f"| {file_path} | {violations} | Line {longest[0]}: {longest[1]} chars |\n")
        
        # Module Size Violations
        f.write("\n## Module Size Violations\n\n")
        f.write("Files with the most oversized modules:\n\n")
        f.write("| File | Oversized Modules | Largest Module |\n")
        f.write("|------|------------------|----------------|\n")
        
        # Sort by number of module violations
        sorted_by_module_violations = sorted(
            results, 
            key=lambda x: x['module_size']['violations_count'],
            reverse=True
        )
        
        for result in sorted_by_module_violations[:20]:  # Top 20
            violations = result['module_size']['violations_count']
            if violations > 0:
                file_path = result['file_path']
                # Find the largest module
                largest = max(result['module_size']['violations'], 
                             key=lambda x: x[1]) if result['module_size']['violations'] else ('', 0)
                f.write(f"| {file_path} | {violations} | {largest[0]}: {largest[1]} lines |\n")
        
        # Comment Density
        f.write("\n## Comment Density Analysis\n\n")
        f.write("Files with the lowest comment density:\n\n")
        f.write("| File | Comment Ratio | Comment Lines | Total Lines |\n")
        f.write("|------|---------------|--------------|-------------|\n")
        
        # Sort by comment ratio (ascending)
        sorted_by_comment_ratio = sorted(
            [r for r in results if r['comment_density']['total_lines'] > 30],  # Only substantial files
            key=lambda x: x['comment_density']['ratio']
        )
        
        for result in sorted_by_comment_ratio[:20]:  # Top 20
            ratio = result['comment_density']['ratio']
            comment_lines = result['comment_density']['comment_lines']
            total_lines = result['comment_density']['total_lines']
            file_path = result['file_path']
            f.write(f"| {file_path} | {ratio:.1%} | {comment_lines} | {total_lines} |\n")
        
        # Recommendations
        f.write("\n## Recommendations\n\n")
        f.write("1. **Line Length**: Refactor long lines by:\n")
        f.write("   - Breaking up long string literals\n")
        f.write("   - Using line continuation with parentheses\n")
        f.write("   - Moving complex expressions to multiple lines\n\n")
        
        f.write("2. **Module Size**: Break down large modules by:\n")
        f.write("   - Extracting helper functions\n")
        f.write("   - Creating specialized classes\n")
        f.write("   - Moving functionality to new modules\n\n")
        
        f.write("3. **Comment Density**: Improve documentation by:\n")
        f.write("   - Adding descriptive docstrings\n")
        f.write("   - Documenting complex logic\n")
        f.write("   - Explaining 'why' rather than 'what'\n")
    
    print(f"Report generated: {output_file}")


def generate_csv_report(results: List[Dict[str, Any]], 
                       output_file: str = "code_standards_data.csv") -> None:
    """
    Generate a CSV file with analysis results for further processing.
    
    Args:
        results: List of file analysis results
        output_file: Path to output CSV file
    """
    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        
        # Write header
        writer.writerow([
            'File Path', 
            'Line Length Violations', 
            'Max Line Length',
            'Module Size Violations',
            'Max Module Size',
            'Comment Ratio',
            'Comment Lines',
            'Total Lines'
        ])
        
        # Write data
        for result in results:
            file_path = result['file_path']
            
            line_violations = result['line_length']['violations_count']
            max_line_length = max([v[1] for v in result['line_length']['violations']] or [0])
            
            module_violations = result['module_size']['violations_count']
            max_module_size = max([v[1] for v in result['module_size']['violations']] or [0])
            
            comment_ratio = result['comment_density']['ratio']
            comment_lines = result['comment_density']['comment_lines']
            total_lines = result['comment_density']['total_lines']
            
            writer.writerow([
                file_path,
                line_violations,
                max_line_length,
                module_violations,
                max_module_size,
                comment_ratio,
                comment_lines,
                total_lines
            ])
    
    print(f"CSV data generated: {output_file}")


def main():
    """Main entry point for the script."""
    print("Analyzing code standards...")
    
    start_time = time.time()
    
    # Scan the codebase
    results = scan_directory()
    
    # Generate reports
    generate_report(results)
    generate_csv_report(results)
    
    end_time = time.time()
    
    print(f"Analysis complete in {end_time - start_time:.2f} seconds.")
    print(f"Processed {total_files} files.")
    print(f"Files with line length violations: {files_exceeding_line_length}")
    print(f"Files with module size violations: {files_exceeding_module_size}")
    print(f"Files with low comment density: {files_below_comment_ratio}")


if __name__ == "__main__":
    main()