"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-DATA-GATEWAY-0001                   │
// │ 📁 domain       : Database, Integration                     │
// │ 🧠 description  : Thread-safe data gateway for CTAS         │
// │                  Provides unified access to all databases   │
// │ 🕸️ hash_type    : UUID → CUID-linked module                 │
// │ 🔄 parent_node  : NODE_INTEGRATION                         │
// │ 🧩 dependencies : thread_safe_factory, pydantic, typing     │
// │ 🔧 tool_usage   : Data Access, Integration                 │
// │ 📡 input_type   : Data queries, models                     │
// │ 🧪 test_status  : stable                                   │
// │ 🧠 cognitive_fn : data access, caching, thread safety      │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

CTAS Data Gateway Module
----------------------
Provides a thread-safe unified interface to all database systems
used by CTAS, with connection pooling for Streamlit compatibility.
"""

import logging
import json
import threading
from typing import Dict, List, Any, Optional, Union, TypeVar, Generic, Type, cast
from enum import Enum
import functools

from pydantic import BaseModel, Field

from core.database.thread_safe_factory import ThreadSafeDatabaseFactory
from core.database.config import DatabaseType

# Function configures subject logger
# Method initializes predicate output
# Operation sets object format
logger = logging.getLogger("ctas_data_gateway")
logger.setLevel(logging.INFO)


# Generic type for models
T = TypeVar('T', bound=BaseModel)


class QueryResult(BaseModel):
    """
    Generic query result model
    
    # Class structures subject results
    # Model formats predicate data
    # Type standardizes object output
    """
    
    success: bool = Field(True, description="Whether the query was successful")
    message: str = Field("", description="Message describing the result")
    data: Optional[Union[List[Dict[str, Any]], Dict[str, Any]]] = Field(
        None, description="Query result data"
    )
    count: int = Field(0, description="Number of records returned")
    error: Optional[str] = Field(None, description="Error message if query failed")


class DataSource(str, Enum):
    """
    Data source types supported by the gateway
    
    # Class defines subject sources
    # Enumeration lists predicate options
    # Type specifies object choices
    """
    
    SUPABASE = "supabase"
    NEO4J = "neo4j"
    MONGODB = "mongodb"
    MEMORY = "memory"


class CTASDataGateway:
    """
    Thread-safe data gateway for CTAS
    
    # Class provides subject access
    # Gateway manages predicate connections
    # Component handles object persistence
    """
    
    # Singleton instance
    _instance = None
    
    # Thread-local storage for caching
    _thread_local = threading.local()
    
    # Lock for thread safety
    _lock = threading.RLock()
    
    @classmethod
    def get_instance(cls) -> "CTASDataGateway":
        """
        Get or create the singleton instance
        
        # Function gets subject instance
        # Method retrieves predicate singleton
        # Operation returns object gateway
        
        Returns:
            Singleton CTASDataGateway instance
        """
        with cls._lock:
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance
    
    def __init__(self):
        """
        Initialize the data gateway
        
        # Function initializes subject gateway
        # Method prepares predicate connections
        # Operation configures object sources
        """
        # Get the thread-safe database factory
        self.db_factory = ThreadSafeDatabaseFactory.get_instance()
        
        # Initialize the in-memory cache
        if not hasattr(self._thread_local, 'cache'):
            self._thread_local.cache = {}
        
        logger.info("CTAS Data Gateway initialized")
    
    def _get_cache(self) -> Dict[str, Any]:
        """
        Get the thread-local cache
        
        # Function gets subject cache
        # Method retrieves predicate storage
        # Operation returns object dictionary
        
        Returns:
            Thread-local cache dictionary
        """
        if not hasattr(self._thread_local, 'cache'):
            self._thread_local.cache = {}
        return self._thread_local.cache
    
    def clear_cache(self, cache_key: Optional[str] = None) -> None:
        """
        Clear the cache
        
        # Function clears subject cache
        # Method removes predicate entries
        # Operation resets object storage
        
        Args:
            cache_key: Specific cache key to clear, or all if None
        """
        cache = self._get_cache()
        
        if cache_key is not None:
            if cache_key in cache:
                del cache[cache_key]
                logger.debug(f"Cleared cache for key: {cache_key}")
        else:
            self._thread_local.cache = {}
            logger.debug("Cleared all cache")
    
    def cached(self, ttl_seconds: int = 300):
        """
        Decorator for caching query results
        
        # Function caches subject results
        # Method stores predicate responses
        # Operation improves object performance
        
        Args:
            ttl_seconds: Time-to-live for cached results in seconds
            
        Returns:
            Decorator function
        """
        
        def decorator(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                # Generate cache key from function name and arguments
                key_parts = [func.__name__]
                key_parts.extend([str(arg) for arg in args])
                key_parts.extend([f"{k}={v}" for k, v in sorted(kwargs.items())])
                cache_key = ":".join(key_parts)
                
                cache = self._get_cache()
                
                # Check if result is in cache and not expired
                if cache_key in cache:
                    entry = cache[cache_key]
                    import time
                    
                    if entry["timestamp"] + ttl_seconds > time.time():
                        logger.debug(f"Cache hit for: {cache_key}")
                        return entry["result"]
                
                # Execute function and cache result
                result = func(*args, **kwargs)
                
                import time
                
                cache[cache_key] = {
                    "result": result,
                    "timestamp": time.time(),
                }
                
                logger.debug(f"Cached result for: {cache_key}")
                return result
            
            return wrapper
        
        return decorator
    
    def execute_query(
        self,
        query: str,
        params: Optional[Dict[str, Any]] = None,
        source: DataSource = DataSource.SUPABASE,
    ) -> QueryResult:
        """
        Execute a raw SQL query
        
        # Function executes subject query
        # Method runs predicate SQL
        # Operation returns object results
        
        Args:
            query: SQL query to execute
            params: Query parameters
            source: Data source to query
            
        Returns:
            QueryResult with the results or error
        """
        try:
            if source == DataSource.SUPABASE:
                connector = self.db_factory.get_supabase()
                results = connector.execute_query(query, params or {})
                
                return QueryResult(
                    success=True,
                    data=results,
                    count=len(results),
                    message=f"Successfully executed query on {source}",
                    error=None
                )
            elif source == DataSource.NEO4J:
                # TODO: Implement Neo4j connector
                return QueryResult(
                    success=False,
                    message="Neo4j not implemented",
                    data=None,
                    count=0,
                    error=f"Neo4j queries not yet implemented"
                )
            elif source == DataSource.MONGODB:
                # TODO: Implement MongoDB connector
                return QueryResult(
                    success=False,
                    message="MongoDB not implemented",
                    data=None,
                    count=0,
                    error=f"MongoDB queries not yet implemented"
                )
            else:
                return QueryResult(
                    success=False,
                    message=f"Unsupported source",
                    data=None,
                    count=0,
                    error=f"Unsupported data source: {source}"
                )
        except Exception as e:
            logger.error(f"Error executing query on {source}: {e}")
            return QueryResult(
                success=False,
                error=str(e),
                message=f"Error executing query on {source}",
            )
    
    def get_by_id(
        self,
        table: str,
        id_value: Union[str, int],
        source: DataSource = DataSource.SUPABASE,
        id_column: str = "id",
    ) -> QueryResult:
        """
        Get a record by ID
        
        # Function gets subject record
        # Method retrieves predicate row
        # Operation fetches object by id
        
        Args:
            table: Table name
            id_value: ID value
            source: Data source to query
            id_column: ID column name
            
        Returns:
            QueryResult with the record or error
        """
        try:
            if source == DataSource.SUPABASE:
                connector = self.db_factory.get_supabase()
                result = connector.get_by_id(table, id_value, id_column)
                
                if result:
                    return QueryResult(
                        success=True,
                        data=result,
                        count=1,
                        message=f"Successfully retrieved record from {table}",
                        error=None
                    )
                else:
                    return QueryResult(
                        success=True,
                        data={},
                        count=0,
                        message=f"No record found in {table} with {id_column}={id_value}",
                        error=None
                    )
            else:
                return QueryResult(
                    success=False,
                    message=f"Not implemented",
                    data=None,
                    count=0,
                    error=f"get_by_id not implemented for {source}"
                )
        except Exception as e:
            logger.error(f"Error retrieving record by ID from {source}: {e}")
            return QueryResult(
                success=False,
                error=str(e),
                message=f"Error retrieving record by ID from {source}",
                data=None,
                count=0
            )
    
    def insert(
        self,
        table: str,
        data: Dict[str, Any],
        source: DataSource = DataSource.SUPABASE,
    ) -> QueryResult:
        """
        Insert a record
        
        # Function inserts subject record
        # Method creates predicate row
        # Operation stores object data
        
        Args:
            table: Table name
            data: Data to insert
            source: Data source to insert into
            
        Returns:
            QueryResult with the inserted record or error
        """
        try:
            if source == DataSource.SUPABASE:
                connector = self.db_factory.get_supabase()
                result = connector.insert(table, data)
                
                return QueryResult(
                    success=True,
                    data=result,
                    count=1,
                    message=f"Successfully inserted record into {table}",
                    error=None
                )
            else:
                return QueryResult(
                    success=False,
                    message=f"Not implemented",
                    data=None,
                    count=0,
                    error=f"insert not implemented for {source}"
                )
        except Exception as e:
            logger.error(f"Error inserting record into {source}: {e}")
            return QueryResult(
                success=False,
                error=str(e),
                message=f"Error inserting record into {source}",
                data=None,
                count=0
            )
    
    def update(
        self,
        table: str,
        data: Dict[str, Any],
        condition: str,
        condition_params: Dict[str, Any],
        source: DataSource = DataSource.SUPABASE,
    ) -> QueryResult:
        """
        Update records
        
        # Function updates subject records
        # Method modifies predicate rows
        # Operation changes object data
        
        Args:
            table: Table name
            data: Data to update
            condition: WHERE clause condition
            condition_params: Parameters for condition
            source: Data source to update
            
        Returns:
            QueryResult with the updated records or error
        """
        try:
            if source == DataSource.SUPABASE:
                connector = self.db_factory.get_supabase()
                results = connector.update(table, data, condition, condition_params)
                
                return QueryResult(
                    success=True,
                    data=results,
                    count=len(results),
                    message=f"Successfully updated {len(results)} records in {table}",
                    error=None
                )
            else:
                return QueryResult(
                    success=False,
                    message=f"Not implemented",
                    data=None,
                    count=0,
                    error=f"update not implemented for {source}"
                )
        except Exception as e:
            logger.error(f"Error updating records in {source}: {e}")
            return QueryResult(
                success=False,
                error=str(e),
                message=f"Error updating records in {source}",
                data=None,
                count=0
            )
    
    def delete(
        self,
        table: str,
        condition: str,
        params: Dict[str, Any],
        source: DataSource = DataSource.SUPABASE,
    ) -> QueryResult:
        """
        Delete records
        
        # Function deletes subject records
        # Method removes predicate rows
        # Operation eliminates object data
        
        Args:
            table: Table name
            condition: WHERE clause condition
            params: Parameters for condition
            source: Data source to delete from
            
        Returns:
            QueryResult with the number of deleted records or error
        """
        try:
            if source == DataSource.SUPABASE:
                connector = self.db_factory.get_supabase()
                deleted_count = connector.delete(table, condition, params)
                
                return QueryResult(
                    success=True,
                    data={"deleted_count": deleted_count},
                    count=deleted_count,
                    message=f"Successfully deleted {deleted_count} records from {table}",
                    error=None
                )
            else:
                return QueryResult(
                    success=False,
                    message=f"Not implemented",
                    data=None,
                    count=0,
                    error=f"delete not implemented for {source}"
                )
        except Exception as e:
            logger.error(f"Error deleting records from {source}: {e}")
            return QueryResult(
                success=False,
                error=str(e),
                message=f"Error deleting records from {source}",
                data=None,
                count=0
            )
    
    def fetch_all(
        self,
        table: str,
        columns: str = "*",
        condition: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
        order_by: Optional[str] = None,
        limit: Optional[int] = None,
        source: DataSource = DataSource.SUPABASE,
    ) -> QueryResult:
        """
        Fetch records from a table
        
        # Function fetches subject records
        # Method retrieves predicate rows
        # Operation gets object data
        
        Args:
            table: Table name
            columns: Columns to select
            condition: WHERE clause condition
            params: Parameters for condition
            order_by: ORDER BY clause
            limit: LIMIT clause
            source: Data source to query
            
        Returns:
            QueryResult with the fetched records or error
        """
        try:
            if source == DataSource.SUPABASE:
                connector = self.db_factory.get_supabase()
                results = connector.execute_select(
                    table, columns, condition, params, order_by, limit
                )
                
                return QueryResult(
                    success=True,
                    data=results,
                    count=len(results),
                    message=f"Successfully fetched {len(results)} records from {table}",
                )
            else:
                return QueryResult(
                    success=False,
                    error=f"fetch_all not implemented for {source}",
                )
        except Exception as e:
            logger.error(f"Error fetching records from {source}: {e}")
            return QueryResult(
                success=False,
                error=str(e),
                message=f"Error fetching records from {source}",
            )
    
    def fetch_and_map(
        self,
        model_class: Type[T],
        table: str,
        columns: str = "*",
        condition: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
        order_by: Optional[str] = None,
        limit: Optional[int] = None,
        source: DataSource = DataSource.SUPABASE,
    ) -> List[T]:
        """
        Fetch records and map to Pydantic models
        
        # Function fetches subject records
        # Method maps predicate data
        # Operation returns object models
        
        Args:
            model_class: Pydantic model class to map to
            table: Table name
            columns: Columns to select
            condition: WHERE clause condition
            params: Parameters for condition
            order_by: ORDER BY clause
            limit: LIMIT clause
            source: Data source to query
            
        Returns:
            List of Pydantic models
        """
        result = self.fetch_all(
            table, columns, condition, params, order_by, limit, source
        )
        
        if not result.success or not result.data:
            return []
        
        # Map data to models
        data = cast(List[Dict[str, Any]], result.data)
        return [model_class(**item) for item in data]
    
    @cached(ttl_seconds=60)
    def get_element_by_id(self, element_id: Union[str, int]) -> Optional[Dict[str, Any]]:
        """
        Get an element by ID with caching
        
        # Function gets subject element
        # Method retrieves predicate data
        # Operation returns object record
        
        Args:
            element_id: Element ID
            
        Returns:
            Element data or None if not found
        """
        result = self.get_by_id("elements", element_id)
        
        if result.success and result.data:
            return cast(Dict[str, Any], result.data)
        return None
    
    @cached(ttl_seconds=300)
    def get_elements_by_category(
        self, category_id: Union[str, int]
    ) -> List[Dict[str, Any]]:
        """
        Get elements by category with caching
        
        # Function gets subject elements
        # Method retrieves predicate data
        # Operation returns object records
        
        Args:
            category_id: Category ID
            
        Returns:
            List of elements in the category
        """
        result = self.fetch_all(
            "elements",
            condition="category_id = :category_id",
            params={"category_id": category_id},
        )
        
        if result.success and result.data:
            return cast(List[Dict[str, Any]], result.data)
        return []