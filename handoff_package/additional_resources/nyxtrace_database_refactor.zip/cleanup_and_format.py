import os
import shutil
import subprocess
import json

# Load the refactor plan (if provided as a separate file)
PLAN_PATH = "refactor_directives.json"

if os.path.exists(PLAN_PATH):
    with open(PLAN_PATH) as f:
        config = json.load(f)
else:
    # Fallback inline config
    config = {
        "cleanup": {
            "remove": [".replit", ".mypy_cache/", "__pycache__/", "*.bak", "*.old"]
        },
        "enforce": ["black", "pydantic", "mypy"],
        "export": {
            "zip_command": 'zip -r nyx_trace_refactored_v1.zip . -x "*.venv*" "*.replit*" "__pycache__/*" "*.bak" "*.old" "core/mcp_server.py"'
        }
    }

# --- Clean unwanted files ---
print("🧹 Cleaning up...")
for pattern in config["cleanup"]["remove"]:
    subprocess.call(['find', '.', '-name', pattern, '-exec', 'rm', '-rf', '{}', ';'])

# --- Enforce standards ---
print("🎨 Running black...")
subprocess.run(["black", "."])

print("🔍 Running mypy...")
subprocess.run(["mypy", ".", "--ignore-missing-imports"])

# --- Zip final output ---
print("📦 Creating ZIP archive...")
os.system(config["export"]["zip_command"])

print("✅ Refactor pass complete.")