import pandas as pd
import openpyxl
import json

def inspect_excel_file(file_path):
    """
    Inspect an Excel file and return information about its structure
    """
    # Try to load with pandas first
    print(f"Inspecting Excel file: {file_path}")
    
    try:
        # Read with pandas
        df = pd.read_excel(file_path)
        print("\nDataFrame Info:")
        print(f"Shape: {df.shape} (rows, columns)")
        print("\nColumns:")
        for col in df.columns:
            print(f"  - {col}")
        
        print("\nFirst 5 rows:")
        print(df.head(5).to_string())
        
        print("\nData types:")
        print(df.dtypes)
        
        return df
    except Exception as e:
        print(f"Error reading with pandas: {str(e)}")
        
        # Try with openpyxl directly
        try:
            wb = openpyxl.load_workbook(file_path)
            print("\nWorkbook loaded with openpyxl")
            print(f"Sheets: {wb.sheetnames}")
            
            # Get the first sheet
            sheet = wb.active
            print(f"Active sheet: {sheet.title}")
            print(f"Dimensions: {sheet.dimensions}")
            
            # Get headers (first row)
            headers = []
            for cell in sheet[1]:
                headers.append(cell.value)
            
            print("\nHeaders:")
            for header in headers:
                print(f"  - {header}")
                
            # Get sample data (first 5 rows)
            print("\nSample data (first 5 rows):")
            for row_idx, row in enumerate(sheet.iter_rows(min_row=2, max_row=6, values_only=True)):
                print(f"Row {row_idx+1}: {row}")
                
            return None
        except Exception as e2:
            print(f"Error reading with openpyxl: {str(e2)}")
            return None

if __name__ == "__main__":
    file_path = "attached_assets/sample_osint.xlsx"
    df = inspect_excel_file(file_path)