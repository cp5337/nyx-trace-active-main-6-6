"""
Criminal Network Analysis Module
-------------------------------
This module specifically focuses on identifying and analyzing criminal networks,
including cartels, gangs, and trafficking organizations. It builds on the core
network analysis framework to provide specialized capabilities for identifying
hotspots, routes, and patterns in criminal activity data.

Key capabilities:
1. Cartel and gang network identification
2. Trafficking route analysis using Bayesian methods
3. Criminal hotspot detection with geospatial analysis
4. Temporal pattern analysis in criminal activities
5. Hidden Markov Model analysis for predicting movement patterns
6. Cross-border activity correlation
"""

import os
import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Set, Union
import logging
import math
from collections import defaultdict, Counter
import random
from scipy import stats
import pickle
import re

# Import core network analysis components
from .network_analysis_core import (
    Node, Edge, NetworkGraph, RouteAnalyzer,
    BayesianNetworkAnalyzer, HiddenMarkovModelAnalyzer
)

# Try specialized libraries
try:
    import networkx as nx
    NX_AVAILABLE = True
except ImportError:
    NX_AVAILABLE = False

try:
    from geopy.distance import geodesic
    GEOPY_AVAILABLE = True
except ImportError:
    GEOPY_AVAILABLE = False

try:
    from shapely.geometry import Point, Polygon
    SHAPELY_AVAILABLE = True
except ImportError:
    SHAPELY_AVAILABLE = False

try:
    from sklearn.cluster import DBSCAN
    from sklearn.preprocessing import StandardScaler
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('criminal_network_analyzer')


class CriminalEntity:
    """
    Represents a criminal organization entity with its attributes and activities.
    """
    def __init__(self, entity_id: str, name: str, entity_type: str, attributes: Dict = None):
        self.id = entity_id
        self.name = name
        self.type = entity_type  # cartel, gang, cell, etc.
        self.attributes = attributes or {}
        self.locations = set()  # Locations associated with this entity
        self.activities = []  # Activities associated with this entity
        self.members = set()  # Known members
        self.connections = {}  # Connections to other entities
        self.timeline = []  # Timeline of events
        
    def add_location(self, location_id: str, attributes: Dict = None):
        """Add an associated location"""
        self.locations.add(location_id)
        
    def add_activity(self, activity: Dict):
        """Add an activity record"""
        self.activities.append(activity)
        # Also update timeline
        if "date" in activity:
            self.timeline.append({
                "date": activity["date"],
                "type": "activity",
                "details": activity
            })
        
    def add_member(self, member_id: str, attributes: Dict = None):
        """Add a member"""
        self.members.add(member_id)
        
    def add_connection(self, target_entity_id: str, connection_type: str, attributes: Dict = None):
        """Add a connection to another entity"""
        if target_entity_id not in self.connections:
            self.connections[target_entity_id] = []
            
        connection = {
            "type": connection_type,
            "attributes": attributes or {}
        }
        self.connections[target_entity_id].append(connection)
        
    def get_primary_territory(self) -> Optional[str]:
        """Get the primary territory (most common location)"""
        if not self.locations:
            return None
            
        # Return the most common location if we have activity data
        loc_activities = defaultdict(int)
        for activity in self.activities:
            if "location_id" in activity:
                loc_activities[activity["location_id"]] += 1
                
        if loc_activities:
            return max(loc_activities.items(), key=lambda x: x[1])[0]
            
        # Otherwise just return the first location
        return next(iter(self.locations))
        
    def get_activity_timeline(self) -> List[Dict]:
        """Get timeline of activities sorted by date"""
        sorted_timeline = sorted(self.timeline, key=lambda x: x["date"])
        return sorted_timeline
        
    def to_dict(self) -> Dict:
        """Convert to dictionary representation"""
        return {
            "id": self.id,
            "name": self.name,
            "type": self.type,
            "attributes": self.attributes,
            "locations": list(self.locations),
            "activities": self.activities,
            "members": list(self.members),
            "connections": self.connections,
            "timeline": self.timeline
        }
        
    @classmethod
    def from_dict(cls, data: Dict) -> 'CriminalEntity':
        """Create a CriminalEntity from a dictionary"""
        entity = cls(data["id"], data["name"], data["type"], data.get("attributes", {}))
        
        # Add locations
        for location_id in data.get("locations", []):
            entity.add_location(location_id)
            
        # Add activities
        for activity in data.get("activities", []):
            entity.add_activity(activity)
            
        # Add members
        for member_id in data.get("members", []):
            entity.add_member(member_id)
            
        # Add connections
        for target_id, connections in data.get("connections", {}).items():
            for connection in connections:
                entity.add_connection(target_id, connection["type"], connection.get("attributes"))
                
        # Add timeline items
        for item in data.get("timeline", []):
            if item not in entity.timeline:  # Avoid duplicates from activities
                entity.timeline.append(item)
                
        return entity


class CriminalNetworkAnalyzer:
    """
    Analyzer for criminal networks including cartels, gangs, and trafficking organizations.
    """
    def __init__(self):
        self.network_graph = NetworkGraph("Criminal Network")
        self.criminal_entities = {}  # {entity_id: CriminalEntity}
        self.bayesian_analyzer = BayesianNetworkAnalyzer()
        self.hmm_analyzer = HiddenMarkovModelAnalyzer()
        self.route_analyzer = RouteAnalyzer()
        
        # Criminal organization types and their attributes
        self.criminal_types = self._initialize_criminal_types()
        
    def _initialize_criminal_types(self) -> Dict:
        """Initialize the criminal organization types database"""
        return {
            "cartel": {
                "name": "Drug Cartel",
                "description": "Organized crime syndicate primarily focused on drug trafficking",
                "indicators": ["drug trafficking", "violence", "corruption", "territory control"],
                "activities": ["drug production", "drug distribution", "money laundering", "extortion"],
                "typical_routes": [
                    "South America to North America", 
                    "Mexico to USA",
                    "Golden Triangle to East Asia",
                    "Afghanistan to Europe"
                ],
                "commodities": ["cocaine", "heroin", "methamphetamine", "marijuana", "fentanyl"]
            },
            "gang": {
                "name": "Street Gang",
                "description": "Urban criminal organization with territorial focus",
                "indicators": ["territorial markings", "violence", "street crimes", "recruitment"],
                "activities": ["drug dealing", "extortion", "robbery", "assault"],
                "typical_routes": ["urban centers", "city to city", "prison to street"],
                "commodities": ["drugs", "weapons", "stolen goods"]
            },
            "human_trafficking": {
                "name": "Human Trafficking Network",
                "description": "Criminal network involved in exploitation of humans",
                "indicators": ["exploitation", "forced labor", "sexual exploitation", "debt bondage"],
                "activities": ["recruitment", "transportation", "harboring", "exploitation"],
                "typical_routes": [
                    "Southeast Asia to Western countries",
                    "Eastern Europe to Western Europe",
                    "Africa to Europe", 
                    "Central/South America to North America"
                ],
                "commodities": ["labor", "sexual services", "domestic servitude"]
            },
            "arms_trafficking": {
                "name": "Arms Trafficking Network",
                "description": "Criminal network involved in illegal weapons trade",
                "indicators": ["weapons cache", "cross-border movement", "conflict zones"],
                "activities": ["sourcing", "smuggling", "distribution", "sales"],
                "typical_routes": [
                    "Conflict zones to embargoed nations", 
                    "Eastern Europe to Africa",
                    "Southeast Asia routes", 
                    "Balkan route"
                ],
                "commodities": ["small arms", "assault rifles", "ammunition", "explosives"]
            }
        }
        
    def add_criminal_entity(self, 
                           name: str, 
                           entity_type: str, 
                           attributes: Dict = None) -> CriminalEntity:
        """
        Add a criminal entity to the analysis
        
        Args:
            name: Name of the criminal entity
            entity_type: Type of entity (cartel, gang, etc.)
            attributes: Optional additional attributes
            
        Returns:
            Created CriminalEntity object
        """
        # Generate a unique ID
        entity_id = f"entity_{len(self.criminal_entities) + 1}_{entity_type}"
        
        # Add type-specific attributes
        if entity_type in self.criminal_types:
            if attributes is None:
                attributes = {}
                
            # Add type information
            type_info = self.criminal_types[entity_type]
            attributes["criminal_type_info"] = {
                "description": type_info["description"],
                "indicators": type_info["indicators"],
                "typical_activities": type_info["activities"],
                "typical_commodities": type_info["commodities"]
            }
            
        # Create the entity
        entity = CriminalEntity(entity_id, name, entity_type, attributes)
        self.criminal_entities[entity_id] = entity
        
        # Also add as a node in the network graph
        node = Node(entity_id, entity_type, {
            "name": name,
            "criminal_entity": True,
            **attributes or {}
        })
        self.network_graph.add_node(node)
        
        return entity
        
    def add_activity(self, 
                   entity_id: str, 
                   activity_type: str, 
                   location_id: str, 
                   date: datetime = None,
                   details: Dict = None) -> bool:
        """
        Add a criminal activity to an entity
        
        Args:
            entity_id: ID of the criminal entity
            activity_type: Type of activity
            location_id: Location where activity occurred
            date: Date of activity
            details: Additional details about the activity
            
        Returns:
            Boolean indicating success
        """
        if entity_id not in self.criminal_entities:
            logger.warning(f"Entity {entity_id} not found")
            return False
            
        entity = self.criminal_entities[entity_id]
        
        # Create activity record
        activity = {
            "type": activity_type,
            "location_id": location_id,
            "date": date or datetime.now(),
            "details": details or {}
        }
        
        # Add to entity
        entity.add_activity(activity)
        
        # Add location to entity's territories
        entity.add_location(location_id)
        
        # Create or update location node in graph if needed
        if location_id not in self.network_graph.nodes:
            location_node = Node(location_id, "location", {
                "activities": [activity_type]
            })
            self.network_graph.add_node(location_node)
        else:
            # Update existing location
            location_node = self.network_graph.get_node(location_id)
            if "activities" not in location_node.attributes:
                location_node.attributes["activities"] = []
            if activity_type not in location_node.attributes["activities"]:
                location_node.attributes["activities"].append(activity_type)
                
        # Add edge for this activity
        edge_attributes = {
            "activity_type": activity_type,
            "date": date.isoformat() if date else datetime.now().isoformat(),
            "details": details or {}
        }
        
        activity_edge = Edge(
            entity_id, 
            location_id, 
            "criminal_activity",
            weight=1.0,
            attributes=edge_attributes,
            timestamp=date or datetime.now()
        )
        self.network_graph.add_edge(activity_edge)
        
        return True
        
    def add_entity_connection(self, 
                            source_id: str, 
                            target_id: str, 
                            connection_type: str,
                            attributes: Dict = None) -> bool:
        """
        Add a connection between criminal entities
        
        Args:
            source_id: Source entity ID
            target_id: Target entity ID
            connection_type: Type of connection
            attributes: Additional attributes
            
        Returns:
            Boolean indicating success
        """
        if source_id not in self.criminal_entities or target_id not in self.criminal_entities:
            logger.warning(f"Entity {source_id} or {target_id} not found")
            return False
            
        # Add connection to entity object
        self.criminal_entities[source_id].add_connection(
            target_id, connection_type, attributes
        )
        
        # Add edge to network graph
        edge_attributes = {
            "connection_type": connection_type,
            **(attributes or {})
        }
        
        connection_edge = Edge(
            source_id,
            target_id,
            "entity_connection",
            weight=1.0,
            attributes=edge_attributes,
            timestamp=datetime.now()
        )
        self.network_graph.add_edge(connection_edge)
        
        return True
        
    def load_incident_data(self, 
                         data: pd.DataFrame,
                         entity_col: str = None,
                         entity_type_col: str = None,
                         location_cols: List[str] = None,
                         date_col: str = None,
                         lat_col: str = None,
                         lon_col: str = None,
                         activity_col: str = None,
                         details_cols: List[str] = None) -> Dict:
        """
        Load incident data from a DataFrame
        
        Args:
            data: DataFrame containing incident data
            entity_col: Column with entity names
            entity_type_col: Column with entity types
            location_cols: Columns with location information
            date_col: Column with date information
            lat_col: Column with latitude
            lon_col: Column with longitude
            activity_col: Column with activity type
            details_cols: Columns with additional details
            
        Returns:
            Dictionary with loading statistics
        """
        if data.empty:
            return {"error": "Empty DataFrame provided", "records_processed": 0}
            
        # Initialize statistics
        stats = {
            "total_records": len(data),
            "records_processed": 0,
            "entities_created": 0,
            "locations_created": 0,
            "activities_added": 0,
            "errors": []
        }
        
        # Process each row
        for _, row in data.iterrows():
            try:
                # Extract entity information
                entity_name = row[entity_col] if entity_col and entity_col in row else "Unknown Entity"
                entity_type = row[entity_type_col] if entity_type_col and entity_type_col in row else "unknown"
                
                # Normalize entity type
                entity_type = self._normalize_entity_type(entity_type)
                
                # Find or create entity
                entity_id = None
                for eid, entity in self.criminal_entities.items():
                    if entity.name.lower() == entity_name.lower():
                        entity_id = eid
                        break
                        
                if not entity_id:
                    # Create new entity
                    entity = self.add_criminal_entity(entity_name, entity_type)
                    entity_id = entity.id
                    stats["entities_created"] += 1
                    
                # Extract location information
                location_id = self._extract_location_id(row, location_cols, lat_col, lon_col)
                
                if not location_id:
                    # Create generic location
                    location_id = f"loc_{stats['locations_created'] + 1}"
                    stats["locations_created"] += 1
                    
                # Extract date
                activity_date = None
                if date_col and date_col in row and pd.notna(row[date_col]):
                    try:
                        activity_date = pd.to_datetime(row[date_col])
                    except:
                        activity_date = datetime.now()
                else:
                    activity_date = datetime.now()
                    
                # Extract activity type
                activity_type = "unknown"
                if activity_col and activity_col in row and pd.notna(row[activity_col]):
                    activity_type = str(row[activity_col])
                    
                # Extract details
                details = {}
                if details_cols:
                    for col in details_cols:
                        if col in row and pd.notna(row[col]):
                            details[col] = row[col]
                            
                # Add activity
                if self.add_activity(entity_id, activity_type, location_id, activity_date, details):
                    stats["activities_added"] += 1
                    
                stats["records_processed"] += 1
                
            except Exception as e:
                stats["errors"].append(f"Error processing row: {str(e)}")
                
        return stats
        
    def _normalize_entity_type(self, entity_type: str) -> str:
        """Normalize entity type to match our defined types"""
        entity_type_lower = entity_type.lower()
        
        # Check for cartel
        if any(term in entity_type_lower for term in 
              ["cartel", "syndicate", "drug", "narco", "trafficking organization"]):
            return "cartel"
            
        # Check for gang
        if any(term in entity_type_lower for term in 
              ["gang", "crew", "street", "prison gang", "clique"]):
            return "gang"
            
        # Check for human trafficking
        if any(term in entity_type_lower for term in 
              ["human trafficking", "trafficking network", "smuggling", "exploitation"]):
            return "human_trafficking"
            
        # Check for arms trafficking
        if any(term in entity_type_lower for term in 
              ["arms", "weapons", "gun running", "arms dealer"]):
            return "arms_trafficking"
            
        # Default
        return "criminal_group"
        
    def _extract_location_id(self, row, location_cols, lat_col, lon_col):
        """Extract a unique location identifier from row data"""
        # If latitude and longitude are available, use them
        if lat_col and lon_col and lat_col in row and lon_col in row:
            if pd.notna(row[lat_col]) and pd.notna(row[lon_col]):
                # Round to 3 decimal places for stable IDs (approx 100m precision)
                lat = round(float(row[lat_col]), 3)
                lon = round(float(row[lon_col]), 3)
                return f"loc_{lat}_{lon}"
                
        # Otherwise use location name columns
        if location_cols:
            loc_parts = []
            for col in location_cols:
                if col in row and pd.notna(row[col]):
                    loc_parts.append(str(row[col]))
                    
            if loc_parts:
                return f"loc_{'_'.join(loc_parts).lower().replace(' ', '_')}"
                
        return None
        
    def identify_criminal_hotspots(self, 
                                min_activities: int = 3,
                                time_window_days: int = 90,
                                radius_km: float = 10.0) -> List[Dict]:
        """
        Identify hotspots of criminal activity
        
        Args:
            min_activities: Minimum number of activities to consider a hotspot
            time_window_days: Time window for recent activities
            radius_km: Radius for clustering activities in kilometers
            
        Returns:
            List of identified hotspots
        """
        # Get all criminal activity edges
        activity_edges = self.network_graph.get_edges_by_type("criminal_activity")
        
        # Filter for recent activities
        cutoff_date = datetime.now() - timedelta(days=time_window_days)
        recent_activities = [edge for edge in activity_edges 
                           if edge.timestamp >= cutoff_date]
        
        if not recent_activities:
            return []
            
        # Group by location
        location_activities = defaultdict(list)
        for edge in recent_activities:
            location_activities[edge.target_id].append(edge)
            
        # Find potential hotspots (locations with multiple activities)
        potential_hotspots = {}
        for location_id, activities in location_activities.items():
            if len(activities) >= min_activities:
                location_node = self.network_graph.get_node(location_id)
                if location_node:
                    potential_hotspots[location_id] = {
                        "location_id": location_id,
                        "location_name": location_node.attributes.get("name", location_id),
                        "activity_count": len(activities),
                        "last_activity": max(edge.timestamp for edge in activities),
                        "activities": activities,
                        "entities": list(set(edge.source_id for edge in activities)),
                        "location_attributes": location_node.attributes,
                        "activity_types": list(set(edge.attributes.get("activity_type", "unknown") 
                                               for edge in activities))
                    }
                    
        if not potential_hotspots:
            return []
            
        # If geospatial capabilities are available, perform spatial clustering
        if GEOPY_AVAILABLE and SKLEARN_AVAILABLE:
            # Extract locations with coordinates
            locations_with_coords = []
            for location_id, hotspot in potential_hotspots.items():
                attrs = hotspot["location_attributes"]
                if "latitude" in attrs and "longitude" in attrs:
                    locations_with_coords.append({
                        "location_id": location_id,
                        "lat": attrs["latitude"],
                        "lon": attrs["longitude"],
                        "activity_count": hotspot["activity_count"]
                    })
                    
            # If we have enough locations with coordinates, cluster them
            if len(locations_with_coords) >= min_activities:
                return self._cluster_hotspots(locations_with_coords, potential_hotspots, radius_km)
                
        # Otherwise just return the locations with most activity
        return [hs for hs in sorted(
            potential_hotspots.values(), 
            key=lambda x: x["activity_count"], 
            reverse=True
        )]
        
    def _cluster_hotspots(self, locations_with_coords, potential_hotspots, radius_km):
        """
        Cluster locations into hotspots using DBSCAN
        
        Args:
            locations_with_coords: List of locations with coordinates
            potential_hotspots: Dictionary of potential hotspots
            radius_km: Radius for clustering in kilometers
            
        Returns:
            List of clustered hotspots
        """
        # Create NumPy array of coordinates
        coords = np.array([[loc["lat"], loc["lon"]] for loc in locations_with_coords])
        
        # Convert radius to degrees (approx)
        radius_degrees = radius_km / 111.0  # 1 degree ~= 111 km
        
        # Perform DBSCAN clustering
        clustering = DBSCAN(
            eps=radius_degrees,
            min_samples=1,
            metric='euclidean'
        ).fit(coords)
        
        # Get cluster labels
        labels = clustering.labels_
        
        # Group by cluster
        clusters = defaultdict(list)
        for i, label in enumerate(labels):
            if label != -1:  # -1 is noise
                clusters[label].append(locations_with_coords[i])
                
        # Create hotspot for each cluster
        hotspots = []
        for cluster_id, cluster_locs in clusters.items():
            if len(cluster_locs) >= 1:
                # Calculate cluster center (weighted by activity)
                total_weight = sum(loc["activity_count"] for loc in cluster_locs)
                center_lat = sum(loc["lat"] * loc["activity_count"] for loc in cluster_locs) / total_weight
                center_lon = sum(loc["lon"] * loc["activity_count"] for loc in cluster_locs) / total_weight
                
                # Collect all activities and entities in this cluster
                cluster_activities = []
                cluster_entities = set()
                activity_types = set()
                location_ids = []
                
                for loc in cluster_locs:
                    loc_id = loc["location_id"]
                    location_ids.append(loc_id)
                    
                    if loc_id in potential_hotspots:
                        hs = potential_hotspots[loc_id]
                        cluster_activities.extend(hs["activities"])
                        cluster_entities.update(hs["entities"])
                        activity_types.update(hs["activity_types"])
                
                # Create hotspot record
                hotspot = {
                    "cluster_id": f"cluster_{cluster_id}",
                    "center": {
                        "latitude": center_lat,
                        "longitude": center_lon
                    },
                    "radius_km": radius_km,
                    "location_count": len(cluster_locs),
                    "locations": location_ids,
                    "activity_count": len(cluster_activities),
                    "last_activity": max(edge.timestamp for edge in cluster_activities) if cluster_activities else None,
                    "entities": list(cluster_entities),
                    "activity_types": list(activity_types)
                }
                
                # Add entity details
                entity_details = []
                for entity_id in cluster_entities:
                    if entity_id in self.criminal_entities:
                        entity = self.criminal_entities[entity_id]
                        entity_details.append({
                            "id": entity_id,
                            "name": entity.name,
                            "type": entity.type,
                            "activity_count": sum(1 for edge in cluster_activities if edge.source_id == entity_id)
                        })
                        
                hotspot["entity_details"] = sorted(
                    entity_details, 
                    key=lambda x: x["activity_count"], 
                    reverse=True
                )
                
                hotspots.append(hotspot)
                
        # Sort by activity count
        return sorted(hotspots, key=lambda x: x["activity_count"], reverse=True)
        
    def analyze_trafficking_routes(self, 
                                 entity_type: str = None, 
                                 time_window_days: int = 90) -> Dict:
        """
        Analyze trafficking routes using Bayesian analysis
        
        Args:
            entity_type: Type of criminal entity to focus on
            time_window_days: Time window for recent activities
            
        Returns:
            Dictionary with route analysis results
        """
        # Update route analyzer with current network
        self.route_analyzer.fit(self.network_graph)
        
        # Get relevant criminal entities
        if entity_type:
            relevant_entities = [
                entity for entity in self.criminal_entities.values()
                if entity.type == entity_type
            ]
        else:
            # Default to cartels and trafficking networks
            relevant_entities = [
                entity for entity in self.criminal_entities.values()
                if entity.type in ["cartel", "human_trafficking", "arms_trafficking"]
            ]
            
        if not relevant_entities:
            return {"error": "No relevant criminal entities found", "routes": []}
            
        # Get recent activity edges
        cutoff_date = datetime.now() - timedelta(days=time_window_days)
        recent_activities = [edge for edge in self.network_graph.get_edges_by_type("criminal_activity") 
                           if edge.timestamp >= cutoff_date]
        
        # Filter to relevant entities
        relevant_entity_ids = [entity.id for entity in relevant_entities]
        entity_activities = [edge for edge in recent_activities 
                           if edge.source_id in relevant_entity_ids]
        
        if not entity_activities:
            return {"error": "No recent activities for specified entities", "routes": []}
            
        # Group activities by entity and sort by timestamp
        entity_routes = defaultdict(list)
        for edge in entity_activities:
            entity_routes[edge.source_id].append((edge.timestamp, edge.target_id))
            
        # For each entity, create sequential paths
        routes = []
        for entity_id, activities in entity_routes.items():
            if len(activities) < 2:
                continue
                
            # Sort by timestamp
            sorted_activities = sorted(activities, key=lambda x: x[0])
            
            # Create path sequence
            path = []
            for _, location_id in sorted_activities:
                if not path or path[-1] != location_id:
                    path.append(location_id)
                    
            if len(path) >= 2:
                # Use route analyzer to get detailed routes
                try:
                    predicted_routes = self.route_analyzer.predict_routes(
                        path[0], path[-1], n_routes=2
                    )
                    
                    if predicted_routes:
                        entity = self.criminal_entities[entity_id]
                        
                        for i, route in enumerate(predicted_routes):
                            route_data = {
                                "entity_id": entity_id,
                                "entity_name": entity.name,
                                "entity_type": entity.type,
                                "origin": path[0],
                                "destination": path[-1],
                                "path": route["path"],
                                "probability": route["probability"],
                                "actual_path": path,
                                "route_number": i + 1
                            }
                            
                            # Add location details
                            route_data["waypoints"] = []
                            for location_id in route["path"]:
                                location_node = self.network_graph.get_node(location_id)
                                if location_node:
                                    waypoint = {
                                        "id": location_id,
                                        "name": location_node.attributes.get("name", location_id)
                                    }
                                    
                                    if "latitude" in location_node.attributes and "longitude" in location_node.attributes:
                                        waypoint["coordinates"] = {
                                            "latitude": location_node.attributes["latitude"],
                                            "longitude": location_node.attributes["longitude"]
                                        }
                                    
                                    route_data["waypoints"].append(waypoint)
                                    
                            routes.append(route_data)
                            
                except Exception as e:
                    logger.error(f"Error predicting routes for {entity_id}: {str(e)}")
                    
        # Sort routes by probability
        routes.sort(key=lambda x: x["probability"], reverse=True)
        
        # Get top routes for visualization
        top_routes = routes[:10] if len(routes) > 10 else routes
        
        # Generate cross-border analysis
        cross_border_routes = self._analyze_cross_border_routes(routes)
        
        return {
            "routes": top_routes,
            "total_routes": len(routes),
            "entities_analyzed": len(entity_routes),
            "cross_border_analysis": cross_border_routes
        }
        
    def _analyze_cross_border_routes(self, routes):
        """
        Analyze cross-border trafficking routes
        
        Args:
            routes: List of route dictionaries
            
        Returns:
            Dictionary with cross-border analysis
        """
        # Need waypoints with country information
        cross_border_routes = []
        border_crossings = defaultdict(int)
        
        for route in routes:
            countries = []
            
            for waypoint in route.get("waypoints", []):
                location_id = waypoint["id"]
                location_node = self.network_graph.get_node(location_id)
                
                if location_node and "country" in location_node.attributes:
                    country = location_node.attributes["country"]
                    countries.append(country)
                    
            # If we found multiple countries, this is a cross-border route
            if len(set(countries)) > 1:
                cross_border_route = route.copy()
                cross_border_route["countries"] = countries
                
                # Identify border crossings
                for i in range(len(countries) - 1):
                    if countries[i] != countries[i+1]:
                        crossing = f"{countries[i]}-{countries[i+1]}"
                        border_crossings[crossing] += 1
                        
                cross_border_routes.append(cross_border_route)
                
        # Get top border crossings
        top_crossings = sorted(
            [{"crossing": k, "count": v} for k, v in border_crossings.items()],
            key=lambda x: x["count"],
            reverse=True
        )
        
        return {
            "cross_border_routes": cross_border_routes[:5],  # Top 5 for brevity
            "border_crossings": top_crossings[:10],  # Top 10 crossings
            "total_cross_border_routes": len(cross_border_routes)
        }
        
    def predict_future_movements(self, 
                              entity_id: str = None, 
                              time_horizon_days: int = 30) -> Dict:
        """
        Predict future movements using Hidden Markov Models
        
        Args:
            entity_id: ID of specific entity to predict (or None for all)
            time_horizon_days: Time horizon for predictions
            
        Returns:
            Dictionary with movement predictions
        """
        # Train HMM on movement sequences
        self.hmm_analyzer.fit(self.network_graph)
        
        # Determine which entities to analyze
        entities_to_analyze = []
        if entity_id:
            if entity_id in self.criminal_entities:
                entities_to_analyze = [self.criminal_entities[entity_id]]
            else:
                return {"error": f"Entity {entity_id} not found", "predictions": []}
        else:
            # Focus on entities with multiple activities
            for entity in self.criminal_entities.values():
                if len(entity.activities) >= 3:
                    entities_to_analyze.append(entity)
                    
        if not entities_to_analyze:
            return {"error": "No entities with sufficient activities for prediction", "predictions": []}
            
        # Generate predictions for each entity
        predictions = []
        for entity in entities_to_analyze:
            # Extract recent locations
            activities = sorted(entity.activities, key=lambda a: a["date"])
            recent_locations = []
            
            for activity in activities[-5:]:  # Last 5 activities
                location_id = activity["location_id"]
                if not recent_locations or recent_locations[-1] != location_id:
                    recent_locations.append(location_id)
                    
            if len(recent_locations) < 2:
                continue  # Need at least 2 locations for prediction
                
            # Predict next locations
            try:
                next_locations = self.hmm_analyzer.predict_next_locations(
                    recent_locations, n_predictions=3
                )
                
                if next_locations:
                    prediction = {
                        "entity_id": entity.id,
                        "entity_name": entity.name,
                        "entity_type": entity.type,
                        "recent_locations": recent_locations,
                        "predicted_next_locations": []
                    }
                    
                    # Add details for each predicted location
                    for location_id, probability in next_locations:
                        location_node = self.network_graph.get_node(location_id)
                        
                        if location_node:
                            loc_prediction = {
                                "location_id": location_id,
                                "probability": probability,
                                "name": location_node.attributes.get("name", location_id)
                            }
                            
                            if "latitude" in location_node.attributes and "longitude" in location_node.attributes:
                                loc_prediction["coordinates"] = {
                                    "latitude": location_node.attributes["latitude"],
                                    "longitude": location_node.attributes["longitude"]
                                }
                                
                            prediction["predicted_next_locations"].append(loc_prediction)
                            
                    predictions.append(prediction)
                    
            except Exception as e:
                logger.error(f"Error predicting movements for {entity.id}: {str(e)}")
                
        # Sort predictions by highest probability
        for prediction in predictions:
            prediction["predicted_next_locations"].sort(
                key=lambda x: x["probability"], 
                reverse=True
            )
            
        # Sort overall predictions by entity with highest confidence prediction
        predictions.sort(
            key=lambda x: max([loc["probability"] for loc in x["predicted_next_locations"]])
            if x["predicted_next_locations"] else 0,
            reverse=True
        )
        
        return {
            "predictions": predictions,
            "time_horizon_days": time_horizon_days,
            "timestamp": datetime.now().isoformat()
        }
        
    def analyze_temporal_patterns(self) -> Dict:
        """
        Analyze temporal patterns in criminal activities
        
        Returns:
            Dictionary with temporal pattern analysis
        """
        # Get all criminal activity edges with timestamps
        activity_edges = [edge for edge in self.network_graph.get_edges_by_type("criminal_activity")
                         if edge.timestamp is not None]
        
        if not activity_edges:
            return {"error": "No timestamped activities available for analysis"}
            
        # Group by various time dimensions
        hourly_counts = defaultdict(int)
        daily_counts = defaultdict(int)
        monthly_counts = defaultdict(int)
        
        for edge in activity_edges:
            time = edge.timestamp
            hourly_counts[time.hour] += 1
            daily_counts[time.weekday()] += 1
            monthly_counts[time.month] += 1
            
        # Calculate peak times
        peak_hour = max(hourly_counts.items(), key=lambda x: x[1])[0]
        peak_day = max(daily_counts.items(), key=lambda x: x[1])[0]
        peak_month = max(monthly_counts.items(), key=lambda x: x[1])[0]
        
        # Format the results
        day_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        month_names = ["January", "February", "March", "April", "May", "June", 
                      "July", "August", "September", "October", "November", "December"]
        
        # Format time as 12-hour with AM/PM
        hour_format = f"{peak_hour % 12 or 12} {'AM' if peak_hour < 12 else 'PM'}"
        
        # Create time series analysis
        time_series = self._analyze_activity_time_series(activity_edges)
        
        # Create entity-specific temporal patterns
        entity_patterns = self._analyze_entity_temporal_patterns(activity_edges)
        
        return {
            "peak_times": {
                "hour": {
                    "value": peak_hour,
                    "formatted": hour_format,
                    "count": hourly_counts[peak_hour]
                },
                "day": {
                    "value": peak_day,
                    "formatted": day_names[peak_day],
                    "count": daily_counts[peak_day]
                },
                "month": {
                    "value": peak_month,
                    "formatted": month_names[peak_month - 1],
                    "count": monthly_counts[peak_month]
                }
            },
            "distribution": {
                "hourly": [{"hour": h, "count": hourly_counts[h]} for h in range(24)],
                "daily": [{"day": d, "name": day_names[d], "count": daily_counts[d]} for d in range(7)],
                "monthly": [{"month": m, "name": month_names[m-1], "count": monthly_counts[m]} for m in range(1, 13)]
            },
            "time_series_analysis": time_series,
            "entity_patterns": entity_patterns
        }
        
    def _analyze_activity_time_series(self, activity_edges):
        """
        Analyze time series patterns in activities
        
        Args:
            activity_edges: List of activity edges with timestamps
            
        Returns:
            Dictionary with time series analysis
        """
        if not activity_edges:
            return {"error": "No data available for time series analysis"}
            
        # Sort by timestamp
        sorted_edges = sorted(activity_edges, key=lambda e: e.timestamp)
        
        # Group by week
        weekly_data = defaultdict(int)
        for edge in sorted_edges:
            # Format as ISO year and week
            year_week = edge.timestamp.strftime("%Y-%W")
            weekly_data[year_week] += 1
            
        # Convert to time series
        time_series = [
            {"period": period, "count": count}
            for period, count in sorted(weekly_data.items())
        ]
        
        # Get trend information
        trend = "stable"
        if len(time_series) >= 2:
            first_half = sum(item["count"] for item in time_series[:len(time_series)//2])
            second_half = sum(item["count"] for item in time_series[len(time_series)//2:])
            
            if second_half > first_half * 1.2:
                trend = "increasing"
            elif second_half < first_half * 0.8:
                trend = "decreasing"
                
        # Calculate seasonality if enough data
        seasonality = "none"
        if len(time_series) >= 12:  # Need at least 12 weeks
            try:
                counts = np.array([item["count"] for item in time_series])
                
                # Simple autocorrelation approach
                autocorr = np.correlate(counts, counts, mode='full')
                autocorr = autocorr[len(autocorr)//2:]
                
                # Find peaks
                from scipy.signal import find_peaks
                peaks, _ = find_peaks(autocorr)
                
                if len(peaks) > 1:
                    # Use the first significant peak after lag 0
                    period = peaks[1] if len(peaks) > 1 else 0
                    
                    if period == 4 or period == 5:
                        seasonality = "monthly"
                    elif period == 12 or period == 13:
                        seasonality = "quarterly"
                    elif period >= 50 and period <= 54:
                        seasonality = "yearly"
            except:
                pass
                
        return {
            "time_series": time_series,
            "trend": trend,
            "seasonality": seasonality,
            "total_periods": len(time_series),
            "first_activity": sorted_edges[0].timestamp.isoformat(),
            "last_activity": sorted_edges[-1].timestamp.isoformat()
        }
        
    def _analyze_entity_temporal_patterns(self, activity_edges):
        """
        Analyze temporal patterns specific to each entity
        
        Args:
            activity_edges: List of activity edges with timestamps
            
        Returns:
            Dictionary with entity-specific pattern analysis
        """
        # Group edges by entity
        entity_edges = defaultdict(list)
        for edge in activity_edges:
            entity_edges[edge.source_id].append(edge)
            
        # Analyze each entity with sufficient data
        entity_patterns = {}
        for entity_id, edges in entity_edges.items():
            if len(edges) < 3:
                continue
                
            entity = self.criminal_entities.get(entity_id)
            if not entity:
                continue
                
            # Sort by timestamp
            sorted_edges = sorted(edges, key=lambda e: e.timestamp)
            
            # Calculate activity intervals
            intervals = []
            for i in range(len(sorted_edges) - 1):
                interval = (sorted_edges[i+1].timestamp - sorted_edges[i].timestamp).total_seconds() / 86400  # days
                intervals.append(interval)
                
            if not intervals:
                continue
                
            # Calculate statistics
            avg_interval = sum(intervals) / len(intervals)
            std_interval = (sum((x - avg_interval)**2 for x in intervals) / len(intervals))**0.5
            
            # Identify regular or irregular patterns
            regularity = "irregular"
            if std_interval < avg_interval * 0.5:  # Low variation = regular
                regularity = "regular"
                
            # Group by time of day
            time_of_day = defaultdict(int)
            for edge in sorted_edges:
                hour = edge.timestamp.hour
                if hour < 6:
                    period = "night"
                elif hour < 12:
                    period = "morning"
                elif hour < 18:
                    period = "afternoon"
                else:
                    period = "evening"
                    
                time_of_day[period] += 1
                
            # Determine the preferred time of day
            preferred_time = max(time_of_day.items(), key=lambda x: x[1])[0]
            
            entity_patterns[entity_id] = {
                "entity_name": entity.name,
                "entity_type": entity.type,
                "activity_count": len(edges),
                "avg_interval_days": avg_interval,
                "interval_variability": std_interval,
                "pattern_regularity": regularity,
                "preferred_time_of_day": preferred_time,
                "first_activity": sorted_edges[0].timestamp.isoformat(),
                "last_activity": sorted_edges[-1].timestamp.isoformat()
            }
            
        return entity_patterns
        
    def detect_interaction_patterns(self) -> Dict:
        """
        Detect patterns of interaction between criminal entities
        
        Returns:
            Dictionary with interaction pattern analysis
        """
        # Get all entity connection edges
        connection_edges = self.network_graph.get_edges_by_type("entity_connection")
        
        if not connection_edges:
            return {"error": "No entity connections available for analysis"}
            
        # Create a graph of entity connections
        entity_graph = nx.DiGraph()
        
        for edge in connection_edges:
            # Skip if entities don't exist
            if (edge.source_id not in self.criminal_entities or 
                edge.target_id not in self.criminal_entities):
                continue
                
            # Add edge with connection type as attribute
            entity_graph.add_edge(
                edge.source_id, 
                edge.target_id, 
                connection_type=edge.attributes.get("connection_type", "unknown"),
                weight=edge.weight
            )
            
        # Identify strongly connected components (potential alliances)
        alliances = []
        if entity_graph.number_of_edges() > 0:
            try:
                # Find strongly connected components
                components = list(nx.strongly_connected_components(entity_graph))
                
                for i, component in enumerate(components):
                    if len(component) >= 2:  # Need at least 2 entities for an alliance
                        alliance = {
                            "id": f"alliance_{i+1}",
                            "entities": [],
                            "size": len(component)
                        }
                        
                        # Add entity details
                        for entity_id in component:
                            entity = self.criminal_entities[entity_id]
                            alliance["entities"].append({
                                "id": entity_id,
                                "name": entity.name,
                                "type": entity.type
                            })
                            
                        alliances.append(alliance)
            except Exception as e:
                logger.error(f"Error detecting alliances: {str(e)}")
                
        # Identify rivalries (entities with negative connections)
        rivalries = []
        for edge in connection_edges:
            if (edge.source_id in self.criminal_entities and 
                edge.target_id in self.criminal_entities):
                
                connection_type = edge.attributes.get("connection_type", "")
                
                if any(term in connection_type.lower() for term in 
                      ["rival", "conflict", "enemy", "dispute", "hostile"]):
                    
                    source = self.criminal_entities[edge.source_id]
                    target = self.criminal_entities[edge.target_id]
                    
                    rivalry = {
                        "entities": [
                            {"id": source.id, "name": source.name, "type": source.type},
                            {"id": target.id, "name": target.name, "type": target.type}
                        ],
                        "connection_type": connection_type,
                        "details": edge.attributes
                    }
                    
                    rivalries.append(rivalry)
                    
        # Calculate centrality measures if we have enough entities
        influential_entities = []
        if entity_graph.number_of_nodes() >= 3:
            try:
                # Calculate different centrality measures
                degree = nx.degree_centrality(entity_graph)
                betweenness = nx.betweenness_centrality(entity_graph)
                
                try:
                    eigenvector = nx.eigenvector_centrality(entity_graph)
                except:
                    eigenvector = {node: 0.0 for node in entity_graph.nodes()}
                    
                # Combine measures for influence score
                influence_scores = {}
                for entity_id in entity_graph.nodes():
                    score = (
                        0.3 * degree.get(entity_id, 0) +
                        0.4 * betweenness.get(entity_id, 0) +
                        0.3 * eigenvector.get(entity_id, 0)
                    )
                    influence_scores[entity_id] = score
                    
                # Get top influential entities
                top_entities = sorted(
                    influence_scores.items(), 
                    key=lambda x: x[1], 
                    reverse=True
                )[:10]
                
                for entity_id, score in top_entities:
                    if entity_id in self.criminal_entities:
                        entity = self.criminal_entities[entity_id]
                        influential_entities.append({
                            "id": entity_id,
                            "name": entity.name,
                            "type": entity.type,
                            "influence_score": score,
                            "degree_centrality": degree.get(entity_id, 0),
                            "betweenness_centrality": betweenness.get(entity_id, 0),
                            "eigenvector_centrality": eigenvector.get(entity_id, 0)
                        })
            except Exception as e:
                logger.error(f"Error calculating centrality: {str(e)}")
                
        return {
            "alliances": alliances,
            "rivalries": rivalries,
            "influential_entities": influential_entities,
            "total_connections": len(connection_edges),
            "total_entities": len(entity_graph.nodes())
        }
        
    def identify_emerging_threats(self) -> Dict:
        """
        Identify emerging threats based on recent patterns and anomalies
        
        Returns:
            Dictionary with emerging threat analysis
        """
        # This is a comprehensive analysis that combines various factors
        threats = []
        
        # 1. Rapid activity increase for entities
        activity_trends = self._analyze_entity_activity_trends()
        for entity_id, trend in activity_trends.items():
            if trend["growth_rate"] > 0.5:  # 50% growth rate
                if entity_id in self.criminal_entities:
                    entity = self.criminal_entities[entity_id]
                    threats.append({
                        "threat_type": "activity_surge",
                        "entity": {
                            "id": entity_id,
                            "name": entity.name,
                            "type": entity.type
                        },
                        "severity": "high" if trend["growth_rate"] > 1.0 else "medium",
                        "details": {
                            "growth_rate": trend["growth_rate"],
                            "recent_count": trend["recent_count"],
                            "previous_count": trend["previous_count"],
                            "locations": trend["locations"]
                        }
                    })
                    
        # 2. New territory expansion
        territory_changes = self._analyze_territory_changes()
        for entity_id, change in territory_changes.items():
            if change["expansion_rate"] > 0.3:  # 30% territory expansion
                if entity_id in self.criminal_entities:
                    entity = self.criminal_entities[entity_id]
                    threats.append({
                        "threat_type": "territory_expansion",
                        "entity": {
                            "id": entity_id,
                            "name": entity.name,
                            "type": entity.type
                        },
                        "severity": "high" if change["expansion_rate"] > 0.5 else "medium",
                        "details": {
                            "expansion_rate": change["expansion_rate"],
                            "new_locations": change["new_locations"],
                            "old_territory": change["old_territory"]
                        }
                    })
                    
        # 3. New connections between previously unconnected entities
        new_connections = self._identify_new_entity_connections()
        for connection in new_connections:
            threats.append({
                "threat_type": "new_alliance",
                "entities": connection["entities"],
                "severity": connection["significance"],
                "details": {
                    "connection_type": connection["connection_type"],
                    "first_seen": connection["first_seen"]
                }
            })
            
        # 4. Geographic anomalies
        geo_anomalies = self._detect_geographic_anomalies()
        for anomaly in geo_anomalies:
            threats.append({
                "threat_type": "geographic_anomaly",
                "severity": anomaly["severity"],
                "location": anomaly["location"],
                "details": {
                    "anomaly_type": anomaly["anomaly_type"],
                    "deviation": anomaly["deviation"],
                    "entities": anomaly["entities"]
                }
            })
            
        # Sort threats by severity
        severity_rank = {"high": 3, "medium": 2, "low": 1}
        threats.sort(key=lambda x: severity_rank.get(x["severity"], 0), reverse=True)
        
        return {
            "threats": threats,
            "timestamp": datetime.now().isoformat(),
            "total_threats": len(threats)
        }
        
    def _analyze_entity_activity_trends(self):
        """
        Analyze activity trends for entities to identify unusual increases
        
        Returns:
            Dictionary mapping entity IDs to trend information
        """
        trends = {}
        
        # Get all activity edges
        activity_edges = self.network_graph.get_edges_by_type("criminal_activity")
        
        # Group by entity
        entity_edges = defaultdict(list)
        for edge in activity_edges:
            entity_edges[edge.source_id].append(edge)
            
        # Calculate trends
        for entity_id, edges in entity_edges.items():
            if len(edges) < 5:  # Need sufficient data
                continue
                
            # Sort by timestamp
            sorted_edges = sorted(edges, key=lambda e: e.timestamp)
            
            # Calculate midpoint
            midpoint = len(sorted_edges) // 2
            
            # Compare recent vs. previous activity
            previous_edges = sorted_edges[:midpoint]
            recent_edges = sorted_edges[midpoint:]
            
            previous_count = len(previous_edges)
            recent_count = len(recent_edges)
            
            if previous_count == 0:
                growth_rate = float('inf')
            else:
                growth_rate = (recent_count - previous_count) / previous_count
                
            # Get locations in recent period
            recent_locations = list(set(edge.target_id for edge in recent_edges))
            
            trends[entity_id] = {
                "previous_count": previous_count,
                "recent_count": recent_count,
                "growth_rate": growth_rate,
                "locations": recent_locations
            }
            
        return trends
        
    def _analyze_territory_changes(self):
        """
        Analyze territory changes for entities
        
        Returns:
            Dictionary mapping entity IDs to territory change information
        """
        changes = {}
        
        # Get all activity edges with timestamps
        activity_edges = [edge for edge in self.network_graph.get_edges_by_type("criminal_activity")
                         if edge.timestamp is not None]
        
        # Group by entity
        entity_edges = defaultdict(list)
        for edge in activity_edges:
            entity_edges[edge.source_id].append(edge)
            
        # Calculate territory changes
        for entity_id, edges in entity_edges.items():
            if len(edges) < 5:  # Need sufficient data
                continue
                
            # Sort by timestamp
            sorted_edges = sorted(edges, key=lambda e: e.timestamp)
            
            # Calculate midpoint
            midpoint_time = sorted_edges[len(sorted_edges) // 2].timestamp
            
            # Get old and new territories
            old_territory = set(edge.target_id for edge in sorted_edges 
                              if edge.timestamp < midpoint_time)
            all_territory = set(edge.target_id for edge in sorted_edges)
            
            # New locations are those not in old territory
            new_locations = all_territory - old_territory
            
            # Calculate expansion rate
            expansion_rate = len(new_locations) / max(1, len(old_territory))
            
            changes[entity_id] = {
                "old_territory": list(old_territory),
                "all_territory": list(all_territory),
                "new_locations": list(new_locations),
                "expansion_rate": expansion_rate
            }
            
        return changes
        
    def _identify_new_entity_connections(self):
        """
        Identify new connections between previously unconnected entities
        
        Returns:
            List of new connection dictionaries
        """
        new_connections = []
        
        # Get all entity connection edges with timestamps
        connection_edges = [edge for edge in self.network_graph.get_edges_by_type("entity_connection")
                          if edge.timestamp is not None]
        
        # Sort by timestamp
        sorted_edges = sorted(connection_edges, key=lambda e: e.timestamp)
        
        # Skip if not enough data
        if len(sorted_edges) < 3:
            return []
            
        # Recent connections are those in the last third of the timeline
        cutoff_index = len(sorted_edges) * 2 // 3
        cutoff_time = sorted_edges[cutoff_index].timestamp
        
        # Check all recent connections
        for edge in sorted_edges[cutoff_index:]:
            if (edge.source_id in self.criminal_entities and 
                edge.target_id in self.criminal_entities):
                
                source = self.criminal_entities[edge.source_id]
                target = self.criminal_entities[edge.target_id]
                
                # Skip if same entity type (not as significant)
                if source.type == target.type:
                    continue
                    
                # Different types of entities connecting is more significant
                significance = "high" if (
                    (source.type in ["cartel", "human_trafficking"] and 
                     target.type in ["cartel", "human_trafficking"]) or
                    (source.type in ["gang", "arms_trafficking"] and 
                     target.type in ["cartel", "human_trafficking"])
                ) else "medium"
                
                new_connections.append({
                    "entities": [
                        {"id": source.id, "name": source.name, "type": source.type},
                        {"id": target.id, "name": target.name, "type": target.type}
                    ],
                    "connection_type": edge.attributes.get("connection_type", "unknown"),
                    "first_seen": edge.timestamp.isoformat(),
                    "significance": significance
                })
                
        return new_connections
        
    def _detect_geographic_anomalies(self):
        """
        Detect geographic anomalies in activity patterns
        
        Returns:
            List of geographic anomaly dictionaries
        """
        anomalies = []
        
        # Skip if no geospatial capabilities
        if not GEOPY_AVAILABLE or not SHAPELY_AVAILABLE:
            return []
            
        # Get all activity edges
        activity_edges = self.network_graph.get_edges_by_type("criminal_activity")
        
        # Group by location
        location_activities = defaultdict(list)
        for edge in activity_edges:
            location_activities[edge.target_id].append(edge)
            
        # Check for locations with unusual entity combinations
        for location_id, edges in location_activities.items():
            if len(edges) < 3:
                continue
                
            location_node = self.network_graph.get_node(location_id)
            if not location_node:
                continue
                
            # Get entities at this location
            entities = list(set(edge.source_id for edge in edges))
            entity_types = {}
            
            for entity_id in entities:
                if entity_id in self.criminal_entities:
                    entity = self.criminal_entities[entity_id]
                    if entity.type not in entity_types:
                        entity_types[entity.type] = 0
                    entity_types[entity.type] += 1
                    
            # Check for unusual combinations
            unusual_mix = False
            if "cartel" in entity_types and "arms_trafficking" in entity_types:
                unusual_mix = True
            if "human_trafficking" in entity_types and "arms_trafficking" in entity_types:
                unusual_mix = True
                
            if unusual_mix:
                entity_details = []
                for entity_id in entities:
                    if entity_id in self.criminal_entities:
                        entity = self.criminal_entities[entity_id]
                        entity_details.append({
                            "id": entity_id,
                            "name": entity.name,
                            "type": entity.type
                        })
                
                anomalies.append({
                    "location": {
                        "id": location_id,
                        "name": location_node.attributes.get("name", location_id)
                    },
                    "anomaly_type": "unusual_entity_combination",
                    "severity": "high",
                    "deviation": "Multiple criminal organization types in same location",
                    "entities": entity_details
                })
                
        # Check for geographic outliers
        if SKLEARN_AVAILABLE and len(location_activities) >= 5:
            try:
                # Get locations with coordinates
                locations = []
                for location_id in location_activities:
                    location_node = self.network_graph.get_node(location_id)
                    if location_node and "latitude" in location_node.attributes and "longitude" in location_node.attributes:
                        locations.append({
                            "id": location_id,
                            "lat": location_node.attributes["latitude"],
                            "lon": location_node.attributes["longitude"],
                            "activity_count": len(location_activities[location_id])
                        })
                        
                if len(locations) >= 5:  # Need enough data points
                    # Create numpy array of coordinates
                    coords = np.array([[loc["lat"], loc["lon"]] for loc in locations])
                    
                    # Standardize coordinates
                    scaler = StandardScaler()
                    scaled_coords = scaler.fit_transform(coords)
                    
                    # Calculate Mahalanobis distance to find outliers
                    from scipy.spatial.distance import mahalanobis
                    cov = np.cov(scaled_coords.T)
                    
                    # Handle singular matrix
                    if np.linalg.det(cov) < 1e-10:
                        cov = cov + np.eye(cov.shape[0]) * 0.01
                        
                    inv_cov = np.linalg.inv(cov)
                    mean_coords = np.mean(scaled_coords, axis=0)
                    
                    for i, loc in enumerate(locations):
                        dist = mahalanobis(scaled_coords[i], mean_coords, inv_cov)
                        
                        # If distance is large, this is an outlier
                        if dist > 3.0:  # Threshold for outlier
                            location_id = loc["id"]
                            location_node = self.network_graph.get_node(location_id)
                            
                            # Get entities at this location
                            edges = location_activities[location_id]
                            entities = list(set(edge.source_id for edge in edges))
                            
                            entity_details = []
                            for entity_id in entities:
                                if entity_id in self.criminal_entities:
                                    entity = self.criminal_entities[entity_id]
                                    entity_details.append({
                                        "id": entity_id,
                                        "name": entity.name,
                                        "type": entity.type
                                    })
                            
                            anomalies.append({
                                "location": {
                                    "id": location_id,
                                    "name": location_node.attributes.get("name", location_id),
                                    "coordinates": {
                                        "latitude": location_node.attributes["latitude"],
                                        "longitude": location_node.attributes["longitude"]
                                    }
                                },
                                "anomaly_type": "geographic_outlier",
                                "severity": "medium",
                                "deviation": round(dist, 2),
                                "entities": entity_details
                            })
            except Exception as e:
                logger.error(f"Error detecting geographic outliers: {str(e)}")
                
        return anomalies
        
    def generate_intelligence_report(self) -> Dict:
        """
        Generate a comprehensive intelligence report on criminal networks
        
        Returns:
            Dictionary with intelligence report
        """
        report = {
            "title": "Criminal Network Intelligence Report",
            "timestamp": datetime.now().isoformat(),
            "summary": {},
            "entity_analysis": [],
            "hotspots": [],
            "trafficking_routes": {},
            "temporal_patterns": {},
            "interaction_analysis": {},
            "emerging_threats": {},
            "predictions": {}
        }
        
        # Generate summary statistics
        entity_counts = defaultdict(int)
        for entity in self.criminal_entities.values():
            entity_counts[entity.type] += 1
            
        total_activities = len(self.network_graph.get_edges_by_type("criminal_activity"))
        total_locations = len(set(edge.target_id for edge in self.network_graph.get_edges_by_type("criminal_activity")))
        
        report["summary"] = {
            "total_entities": len(self.criminal_entities),
            "entity_counts": dict(entity_counts),
            "total_activities": total_activities,
            "total_locations": total_locations
        }
        
        # Add entity analysis
        for entity in self.criminal_entities.values():
            # Skip entities with minimal data
            if len(entity.activities) < 2:
                continue
                
            # Get primary territory
            primary_loc = entity.get_primary_territory()
            primary_location = {}
            
            if primary_loc:
                location_node = self.network_graph.get_node(primary_loc)
                if location_node:
                    primary_location = {
                        "id": primary_loc,
                        "name": location_node.attributes.get("name", primary_loc)
                    }
                    
                    if "latitude" in location_node.attributes and "longitude" in location_node.attributes:
                        primary_location["coordinates"] = {
                            "latitude": location_node.attributes["latitude"],
                            "longitude": location_node.attributes["longitude"]
                        }
            
            # Create entity analysis
            entity_analysis = {
                "id": entity.id,
                "name": entity.name,
                "type": entity.type,
                "activities": len(entity.activities),
                "locations": len(entity.locations),
                "primary_location": primary_location,
                "connections": len(entity.connections)
            }
            
            report["entity_analysis"].append(entity_analysis)
            
        # Sort entities by activity count
        report["entity_analysis"].sort(key=lambda x: x["activities"], reverse=True)
        
        # Limit to top 10 entities
        report["entity_analysis"] = report["entity_analysis"][:10]
        
        # Add hotspot analysis
        hotspots = self.identify_criminal_hotspots()
        report["hotspots"] = hotspots[:5] if len(hotspots) > 5 else hotspots
        
        # Add trafficking route analysis
        trafficking = self.analyze_trafficking_routes()
        report["trafficking_routes"] = trafficking
        
        # Add temporal pattern analysis
        temporal = self.analyze_temporal_patterns()
        report["temporal_patterns"] = temporal
        
        # Add interaction analysis
        interaction = self.detect_interaction_patterns()
        report["interaction_analysis"] = interaction
        
        # Add emerging threats
        threats = self.identify_emerging_threats()
        report["emerging_threats"] = threats
        
        # Add predictions
        predictions = self.predict_future_movements()
        report["predictions"] = predictions
        
        return report