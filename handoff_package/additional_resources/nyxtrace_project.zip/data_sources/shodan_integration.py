"""
Shodan API Integration
---------------------
This module integrates Shodan API for enhanced OSINT capabilities
related to internet infrastructure and exposed devices.
"""

import shodan
import pandas as pd
import streamlit as st
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional

class ShodanIntegration:
    """Shodan API integration for OSINT analysis"""
    
    def __init__(self):
        """Initialize the Shodan integration"""
        self.api = None
        self.api_key = None
        self.initialized = False
    
    def configure(self, api_key: str) -> bool:
        """
        Configure the Shodan API client
        
        Args:
            api_key: Shodan API key
            
        Returns:
            bool: True if configuration successful
        """
        try:
            self.api = shodan.Shodan(api_key)
            self.api_key = api_key
            self.initialized = True
            # Test with a basic API call
            self.api.info()
            return True
        except Exception as e:
            st.error(f"Error configuring Shodan API: {str(e)}")
            self.initialized = False
            return False
    
    def search_location(self, city: str, state: Optional[str] = None, country: str = "US", 
                        limit: int = 100) -> pd.DataFrame:
        """
        Search for devices in a specific location
        
        Args:
            city: City name
            state: State name/code (optional)
            country: Country code (default: US)
            limit: Maximum number of results to return
            
        Returns:
            DataFrame with search results
        """
        if not self.initialized:
            st.error("Shodan API not initialized. Please configure it first.")
            return pd.DataFrame()
        
        try:
            # Build query
            location_query = f"city:\"{city}\""
            if state:
                location_query += f" state:\"{state}\""
            if country:
                location_query += f" country:\"{country}\""
            
            # Execute search
            results = self.api.search(location_query, limit=limit)
            
            # Process results
            processed_data = []
            for result in results.get('matches', []):
                processed_data.append({
                    'IP': result.get('ip_str', 'Unknown'),
                    'Port': result.get('port', 0),
                    'Organization': result.get('org', 'Unknown'),
                    'Hostnames': ', '.join(result.get('hostnames', [])),
                    'Last Update': result.get('timestamp', ''),
                    'ISP': result.get('isp', 'Unknown'),
                    'OS': result.get('os', 'Unknown'),
                    'Product': result.get('product', 'Unknown'),
                    'Transport': result.get('transport', 'Unknown'),
                    'Latitude': result.get('location', {}).get('latitude', 0),
                    'Longitude': result.get('location', {}).get('longitude', 0),
                })
            
            # Create DataFrame
            return pd.DataFrame(processed_data)
            
        except Exception as e:
            st.error(f"Error searching Shodan: {str(e)}")
            return pd.DataFrame()
    
    def get_host_details(self, ip: str) -> Dict[str, Any]:
        """
        Get detailed information about a specific IP
        
        Args:
            ip: IP address to look up
            
        Returns:
            Dictionary with host details
        """
        if not self.initialized:
            st.error("Shodan API not initialized. Please configure it first.")
            return {}
        
        try:
            # Get host information
            host = self.api.host(ip)
            
            # Extract relevant details
            details = {
                'IP': host.get('ip_str', 'Unknown'),
                'Organization': host.get('org', 'Unknown'),
                'Hostnames': host.get('hostnames', []),
                'Country': host.get('country_name', 'Unknown'),
                'City': host.get('city', 'Unknown'),
                'ISP': host.get('isp', 'Unknown'),
                'Last Update': host.get('last_update', ''),
                'Open Ports': host.get('ports', []),
                'Vulnerabilities': host.get('vulns', []),
                'Tags': host.get('tags', []),
                'Services': []
            }
            
            # Extract service information
            for service in host.get('data', []):
                details['Services'].append({
                    'Port': service.get('port', 0),
                    'Transport': service.get('transport', 'Unknown'),
                    'Product': service.get('product', 'Unknown'),
                    'Banner': service.get('data', '').strip()[:100] + '...',
                })
            
            return details
            
        except Exception as e:
            st.error(f"Error getting host details: {str(e)}")
            return {}
    
    def analyze_infrastructure(self, city: str, state: Optional[str] = None, country: str = "US") -> Dict[str, Any]:
        """
        Analyze infrastructure for a specific location
        
        Args:
            city: City name
            state: State name/code (optional)
            country: Country code (default: US)
            
        Returns:
            Dictionary with infrastructure analysis
        """
        if not self.initialized:
            st.error("Shodan API not initialized. Please configure it first.")
            return {}
        
        try:
            # Get devices in location
            devices_df = self.search_location(city, state, country)
            
            if devices_df.empty:
                return {'success': False, 'message': 'No infrastructure data found for this location'}
            
            # Analyze the data
            analysis = {
                'success': True,
                'total_devices': len(devices_df),
                'organizations': devices_df['Organization'].value_counts().head(10).to_dict(),
                'ports': devices_df['Port'].value_counts().head(10).to_dict(),
                'transports': devices_df['Transport'].value_counts().to_dict(),
                'operating_systems': devices_df['OS'].value_counts().to_dict(),
                'coordinates': devices_df[['Latitude', 'Longitude']].to_dict('records'),
                'top_isps': devices_df['ISP'].value_counts().head(5).to_dict()
            }
            
            return analysis
            
        except Exception as e:
            st.error(f"Error analyzing infrastructure: {str(e)}")
            return {'success': False, 'message': f'Error: {str(e)}'}


def create_shodan_visualization(analysis: Dict[str, Any], city: str):
    """
    Create visualization for Shodan OSINT data
    
    Args:
        analysis: Infrastructure analysis from Shodan
        city: City name for the title
    
    Returns:
        Dictionary of Plotly figures
    """
    import plotly.express as px
    import plotly.graph_objects as go
    from utils import get_theme_settings
    
    if not analysis.get('success', False):
        return {}
    
    theme = get_theme_settings()
    
    # Create figures dict
    figures = {}
    
    # Organizations bar chart
    if analysis.get('organizations'):
        org_df = pd.DataFrame({
            'Organization': list(analysis['organizations'].keys()),
            'Count': list(analysis['organizations'].values())
        })
        
        figures['organizations'] = px.bar(
            org_df, 
            x='Count', 
            y='Organization',
            orientation='h',
            title=f"Top Organizations in {city}",
            template=theme['template']
        )
    
    # Ports pie chart
    if analysis.get('ports'):
        port_df = pd.DataFrame({
            'Port': list(analysis['ports'].keys()),
            'Count': list(analysis['ports'].values())
        })
        
        figures['ports'] = px.pie(
            port_df,
            values='Count',
            names='Port',
            title=f"Common Open Ports in {city}",
            template=theme['template']
        )
    
    # Transport protocols bar chart
    if analysis.get('transports'):
        transport_df = pd.DataFrame({
            'Protocol': list(analysis['transports'].keys()),
            'Count': list(analysis['transports'].values())
        })
        
        figures['transports'] = px.bar(
            transport_df,
            x='Protocol',
            y='Count',
            title=f"Transport Protocols in {city}",
            template=theme['template']
        )
    
    # OS distribution pie chart
    if analysis.get('operating_systems'):
        # Filter out None/empty values
        os_dict = {k: v for k, v in analysis['operating_systems'].items() if k}
        
        if os_dict:
            os_df = pd.DataFrame({
                'OS': list(os_dict.keys()),
                'Count': list(os_dict.values())
            })
            
            figures['operating_systems'] = px.pie(
                os_df,
                values='Count',
                names='OS',
                title=f"Operating Systems in {city}",
                template=theme['template']
            )
    
    # Geographical visualization of devices
    if analysis.get('coordinates'):
        coord_df = pd.DataFrame(analysis['coordinates'])
        
        if not coord_df.empty and 'Latitude' in coord_df.columns:
            # Remove any rows with invalid coordinates
            coord_df = coord_df[(coord_df['Latitude'] != 0) & (coord_df['Longitude'] != 0)]
            
            if not coord_df.empty:
                figures['geo_distribution'] = px.scatter_mapbox(
                    coord_df,
                    lat="Latitude",
                    lon="Longitude",
                    size=[10] * len(coord_df),
                    zoom=10,
                    height=400,
                    mapbox_style=theme['mapbox_style']
                )
                
                # Update mapbox configuration with token if available
                mapbox_config = {}
                if theme['mapbox_token'] and theme['map_provider'] == 'mapbox':
                    mapbox_config['accesstoken'] = theme['mapbox_token']
                
                figures['geo_distribution'].update_layout(
                    margin={"r":0,"t":30,"l":0,"b":0},
                    title=f"Device Distribution in {city}",
                    template=theme['template'],
                    mapbox=mapbox_config
                )
    
    return figures