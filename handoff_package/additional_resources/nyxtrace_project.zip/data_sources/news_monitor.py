"""
News Source Monitoring Module
----------------------------
This module provides specialized functionality for monitoring news sources
for incidents involving bomb threats, cyber attacks, and other incident types
defined in the OSINT dataset.

Key capabilities:
1. Extracts URLs and incident patterns from existing OSINT data
2. Monitors news sources for new incidents matching defined patterns
3. Classifies content into incident types (bomb threats, cyber attacks, etc.)
4. Updates the dataset with newly discovered incidents
5. Extracts key entities (people, organizations) from articles
6. Uses advanced browser automation with Playwright for dynamic content
7. Performs semantic keyword extraction for better content understanding
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import trafilatura
import requests
import re
import time
import os
import concurrent.futures
import urllib.parse
from typing import Dict, List, Any, Optional, Tuple, Set
from urllib3.exceptions import InsecureRequestWarning
from .web_scraper import WebScraperDataSource

# Suppress insecure request warnings
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class NewsMonitor:
    """
    Monitor news sources for incidents and threats based on patterns
    identified in existing OSINT data
    """
    
    def __init__(self):
        # Initialize with default settings
        self.source_urls = []
        self.incident_keywords = {}
        self.monitored_sources = {}
        self.last_check_time = {}
        self.web_scraper = WebScraperDataSource()
        self.web_scraper.is_configured = True  # Skip configuration requirement
        self.excel_path = "attached_assets/sample_osint.xlsx"
        self.monitoring_interval = 3600  # Default to hourly checks
        self.initialized = False
        
        # Default patterns for different incident types
        self.incident_patterns = {
            "Bomb Threat": [
                r"bomb\s+threat", 
                r"explosive\s+device", 
                r"evacuated\s+due\s+to\s+threat",
                r"suspicious\s+package",
                r"threat\s+to\s+(school|building|airport)"
            ],
            "Device Discovered": [
                r"suspicious\s+device", 
                r"found\s+explosive", 
                r"discovered\s+(bomb|explosive|device)",
                r"explosive\s+material",
                r"IED\s+found"
            ],
            "Device Emplaced": [
                r"planted\s+(bomb|explosive|device)", 
                r"placed\s+(bomb|explosive|device)", 
                r"detonated",
                r"explosion\s+at",
                r"set\s+off\s+(bomb|explosive|device)"
            ],
            "Cyber Attack": [
                r"cyber\s+attack", 
                r"hacked", 
                r"data\s+breach",
                r"ransomware",
                r"phishing",
                r"ddos",
                r"malware"
            ]
        }
        
        # Communication method patterns
        self.communication_patterns = {
            "Social Media": [r"social\s+media", r"facebook", r"twitter", r"instagram", r"tiktok"],
            "Email": [r"email", r"e-mail"],
            "Phone": [r"phone\s+call", r"called", r"telephone"],
            "Written": [r"letter", r"note", r"written"],
            "Verbal": [r"verbal", r"verbally", r"said", r"told"],
            "Automated Phone": [r"automated", r"robocall", r"recorded"]
        }
    
    def initialize_from_excel(self):
        """
        Initialize the monitor using data from the Excel file
        - Extract URLs to monitor
        - Learn incident patterns from existing data
        """
        try:
            # Load the Excel file
            df = pd.read_excel(self.excel_path)
            
            # Extract source URLs
            if 'Source' in df.columns:
                for source in df['Source'].dropna():
                    # Some entries may have multiple URLs separated by commas
                    urls = [url.strip() for url in str(source).split(',')]
                    for url in urls:
                        if url.startswith('http'):
                            # Extract base domain for monitoring
                            parsed_url = urllib.parse.urlparse(url)
                            base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
                            
                            if base_url not in self.source_urls:
                                self.source_urls.append(base_url)
                                # Initialize last check time
                                self.last_check_time[base_url] = datetime.now() - timedelta(days=1)
            
            # Extract incident types
            if 'Incident Type' in df.columns:
                for incident_type in df['Incident Type'].dropna().unique():
                    # Store incident type and related data
                    type_data = df[df['Incident Type'] == incident_type]
                    self.incident_keywords[incident_type] = self._extract_keywords(type_data)
            
            # Extract communications methods
            for comm_method in ["Social Media", "Email", "Phone", "Written", "Verbal", "Automated Phone"]:
                if comm_method in df.columns:
                    # Extract examples of this communication method
                    examples = df[df[comm_method] == True]
                    if not examples.empty:
                        if comm_method not in self.communication_patterns:
                            self.communication_patterns[comm_method] = []
                        # Could extract more patterns here if needed
            
            self.initialized = True
            print(f"Initialized NewsMonitor with {len(self.source_urls)} source URLs")
            return True
            
        except Exception as e:
            print(f"Error initializing from Excel: {str(e)}")
            return False
    
    def _extract_keywords(self, df_subset):
        """
        Extract keywords from a subset of data related to a specific incident type
        """
        keywords = set()
        
        # Extract keywords from description fields if available
        if 'Description' in df_subset.columns:
            for desc in df_subset['Description'].dropna():
                # Extract key terms from description
                words = re.findall(r'\b\w+\b', str(desc).lower())
                for word in words:
                    if len(word) > 4 and word not in ['threat', 'there', 'their', 'about', 'would', 'could']:
                        keywords.add(word)
        
        return list(keywords)
    
    def start_monitoring(self):
        """
        Start monitoring the identified news sources for incidents
        Returns initial dataset of current articles matching patterns
        """
        if not self.initialized:
            if not self.initialize_from_excel():
                raise ValueError("Failed to initialize from Excel data")
        
        # Initial scan of all sources
        results = self.check_all_sources()
        
        print(f"Initial monitoring scan complete. Found {len(results)} matching articles")
        return results
    
    def check_all_sources(self):
        """
        Check all monitored sources for new incidents
        """
        all_results = []
        
        # Process sources in parallel for efficiency
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            future_to_url = {executor.submit(self.check_source, url): url for url in self.source_urls}
            
            for future in concurrent.futures.as_completed(future_to_url):
                url = future_to_url[future]
                try:
                    # Collect results from this source
                    source_results = future.result()
                    all_results.extend(source_results)
                except Exception as e:
                    print(f"Error checking source {url}: {str(e)}")
        
        return all_results
    
    def check_source(self, source_url):
        """
        Check a specific news source for new incidents
        """
        print(f"Checking source: {source_url}")
        results = []
        
        try:
            # Use the web scraper to get content from this source
            # We'll use get_website_text_content directly to get both main content and linked content
            main_content, additional_contents = self.web_scraper.get_website_text_content(source_url)
            
            # Check the main content for incidents
            main_incidents = self._check_content_for_incidents(main_content, source_url)
            if main_incidents:
                results.extend(main_incidents)
            
            # Also check linked content
            for linked in additional_contents:
                linked_incidents = self._check_content_for_incidents(
                    linked['content'], 
                    linked['url']
                )
                if linked_incidents:
                    results.extend(linked_incidents)
            
            # Update last check time
            self.last_check_time[source_url] = datetime.now()
            
        except Exception as e:
            print(f"Error scanning source {source_url}: {str(e)}")
        
        return results
    
    def _check_content_for_incidents(self, content, url):
        """
        Check a specific piece of content for incidents matching our patterns
        Returns a list of incident dictionaries if any are found
        """
        if not content or len(content) < 100:
            return []
            
        results = []
        content_lower = content.lower()
        
        # Check for each incident type
        for incident_type, patterns in self.incident_patterns.items():
            for pattern in patterns:
                if re.search(pattern, content_lower):
                    # Found a match, extract incident details
                    incident = self._extract_incident_details(content, url, incident_type)
                    if incident:
                        results.append(incident)
                    break  # Move to next incident type once we find a match
        
        return results
    
    def _extract_incident_details(self, content, url, incident_type):
        """
        Extract detailed information about an incident from the content
        """
        content_lower = content.lower()
        
        # Create incident object with known details
        incident = {
            'Event Date': datetime.now(),
            'Source': url,
            'Incident Type': incident_type,
            'Description': content[:1000] + "..." if len(content) > 1000 else content
        }
        
        # Try to extract location information
        location_match = re.search(r'in ([A-Z][a-z]+(?:[ -][A-Z][a-z]+)*),\s+([A-Z]{2})', content)
        if location_match:
            incident['City'] = location_match.group(1)
            incident['State'] = location_match.group(2)
            incident['Country'] = 'United States'  # Default for now, could be improved
        
        # Check for communication methods
        for method, patterns in self.communication_patterns.items():
            for pattern in patterns:
                if re.search(pattern, content_lower):
                    incident[method] = True
                    break
            if method not in incident:
                incident[method] = False
        
        # Check for arrests
        if re.search(r'arrest|apprehend|custody|detained', content_lower):
            incident['Arrested'] = 1
        else:
            incident['Arrested'] = 0
            
        # Check for casualties
        if re.search(r'killed|dead|death|fatality', content_lower):
            incident['Dead'] = 1  # Would need more sophisticated extraction for counts
        else:
            incident['Dead'] = 0
            
        if re.search(r'injured|hurt|wound', content_lower):
            incident['Injured'] = 1  # Would need more sophisticated extraction for counts
        else:
            incident['Injured'] = 0
        
        return incident
    
    def update_excel_with_incidents(self, incidents):
        """
        Update the Excel file with newly discovered incidents
        """
        if not incidents:
            return False
            
        try:
            # Load existing data
            existing_df = pd.read_excel(self.excel_path)
            
            # Create DataFrame from new incidents
            new_df = pd.DataFrame(incidents)
            
            # Ensure all columns from existing df are present in new df
            for col in existing_df.columns:
                if col not in new_df.columns:
                    new_df[col] = None
            
            # Reorder columns to match existing df
            new_df = new_df[existing_df.columns]
            
            # Append new data
            combined_df = pd.concat([existing_df, new_df], ignore_index=True)
            
            # Create backup of original file
            backup_path = self.excel_path + '.backup'
            existing_df.to_excel(backup_path, index=False)
            
            # Save updated file
            combined_df.to_excel(self.excel_path, index=False)
            
            print(f"Updated Excel file with {len(incidents)} new incidents")
            return True
            
        except Exception as e:
            print(f"Error updating Excel file: {str(e)}")
            return False
    
    def get_monitored_sources(self):
        """
        Get a list of currently monitored sources with last check time
        """
        return [
            {"url": url, "last_checked": self.last_check_time.get(url, "Never")}
            for url in self.source_urls
        ]
    
    def add_source(self, url):
        """
        Add a new source URL to monitor
        """
        if not url.startswith('http'):
            url = 'https://' + url
        
        parsed_url = urllib.parse.urlparse(url)
        base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
        
        if base_url not in self.source_urls:
            self.source_urls.append(base_url)
            self.last_check_time[base_url] = datetime.now()
            return True
        return False
    
    def add_incident_pattern(self, incident_type, pattern):
        """
        Add a new pattern for a specific incident type
        """
        if incident_type not in self.incident_patterns:
            self.incident_patterns[incident_type] = []
        
        if pattern not in self.incident_patterns[incident_type]:
            self.incident_patterns[incident_type].append(pattern)
            return True
        return False

    def parse_cyber_threat_indicators(self, content):
        """
        Parse content specifically for cyber threat indicators
        Returns a dictionary of identified indicators
        """
        indicators = {
            'ip_addresses': [],
            'domains': [],
            'hashes': [],
            'attack_vectors': [],
            'malware_types': []
        }
        
        # Extract IP addresses (both IPv4 and simplified IPv6)
        ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b|[0-9a-fA-F:]{1,4}(?::[0-9a-fA-F]{1,4}){7}'
        indicators['ip_addresses'] = re.findall(ip_pattern, content)
        
        # Extract domains
        domain_pattern = r'\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}\b'
        indicators['domains'] = re.findall(domain_pattern, content)
        
        # Extract file hashes (MD5, SHA1, SHA256)
        hash_patterns = {
            'md5': r'\b[a-fA-F0-9]{32}\b',
            'sha1': r'\b[a-fA-F0-9]{40}\b',
            'sha256': r'\b[a-fA-F0-9]{64}\b'
        }
        for hash_type, pattern in hash_patterns.items():
            indicators[f'{hash_type}_hashes'] = re.findall(pattern, content)
        
        # Check for common attack vectors
        attack_vectors = [
            'phishing', 'spear-phishing', 'ddos', 'ransomware', 
            'supply chain', 'zero-day', 'credential stuffing', 'brute force'
        ]
        for vector in attack_vectors:
            if re.search(r'\b' + re.escape(vector) + r'\b', content.lower()):
                indicators['attack_vectors'].append(vector)
        
        # Check for malware types
        malware_types = [
            'trojan', 'worm', 'virus', 'backdoor', 'rootkit', 'keylogger',
            'spyware', 'adware', 'ransomware', 'bot', 'cryptominer'
        ]
        for malware in malware_types:
            if re.search(r'\b' + re.escape(malware) + r'\b', content.lower()):
                indicators['malware_types'].append(malware)
        
        return indicators