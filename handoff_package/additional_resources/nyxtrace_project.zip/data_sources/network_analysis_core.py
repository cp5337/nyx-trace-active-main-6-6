"""
Network Analysis Core Module
--------------------------
This module provides a domain-agnostic framework for analyzing network-based 
patterns using advanced probabilistic models including Bayesian networks and 
Hidden Markov Models. It is designed to be extensible for multiple applications:

- Criminal network analysis (cartels, gangs, trafficking)
- Commercial shipping and supply chain analytics
- Security threat modeling
- Transportation and logistics optimization
- Migration pattern analysis

The core abstractions are built to be portable to other languages (like Rust)
and provide foundational algorithms that can be used across domains.
"""

import os
import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
from typing import Dict, List, Any, Optional, Tuple, Set, Union, Callable
import logging
import math
import networkx as nx
from collections import defaultdict, Counter
import random
from scipy import stats
import pickle

# Try to import specialized analysis libraries
try:
    from hmmlearn import hmm
    HMM_AVAILABLE = True
except ImportError:
    HMM_AVAILABLE = False

try:
    from pomegranate import BayesianNetwork, DiscreteDistribution, ConditionalProbabilityTable
    BAYESIAN_AVAILABLE = True
except ImportError:
    BAYESIAN_AVAILABLE = False

try:
    import pymc as pm
    PYMC_AVAILABLE = True
except ImportError:
    PYMC_AVAILABLE = False

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('network_analysis_core')


# =============================================================================
# Core Data Structures
# =============================================================================

class Node:
    """
    A generic node in a network, representing an entity like a location,
    organization, or individual. Designed to be domain-agnostic.
    """
    def __init__(self, node_id: str, node_type: str, attributes: Dict = None):
        self.id = node_id
        self.type = node_type
        self.attributes = attributes or {}
        self.weight = 1.0
        self.connections = {}  # {node_id: Edge}
        self.metadata = {}  # For extensibility

    def add_attribute(self, key: str, value: Any) -> None:
        """Add or update an attribute"""
        self.attributes[key] = value

    def add_connection(self, target_node_id: str, edge: 'Edge') -> None:
        """Add a connection to another node"""
        self.connections[target_node_id] = edge

    def get_connected_nodes(self) -> List[str]:
        """Get IDs of all connected nodes"""
        return list(self.connections.keys())

    def to_dict(self) -> Dict:
        """Convert to dictionary representation"""
        return {
            "id": self.id,
            "type": self.type,
            "attributes": self.attributes,
            "weight": self.weight,
            "metadata": self.metadata
        }

    @classmethod
    def from_dict(cls, data: Dict) -> 'Node':
        """Create a Node from a dictionary"""
        node = cls(data["id"], data["type"], data.get("attributes", {}))
        node.weight = data.get("weight", 1.0)
        node.metadata = data.get("metadata", {})
        return node


class Edge:
    """
    A connection between two nodes in a network, representing a relationship,
    transaction, movement, or communication.
    """
    def __init__(self, 
                source_id: str, 
                target_id: str, 
                edge_type: str, 
                weight: float = 1.0, 
                attributes: Dict = None,
                directed: bool = True,
                timestamp: Optional[datetime] = None):
        self.source_id = source_id
        self.target_id = target_id
        self.type = edge_type
        self.weight = weight
        self.attributes = attributes or {}
        self.directed = directed
        self.timestamp = timestamp or datetime.now()
        self.metadata = {}

    def to_dict(self) -> Dict:
        """Convert to dictionary representation"""
        return {
            "source_id": self.source_id,
            "target_id": self.target_id,
            "type": self.type,
            "weight": self.weight,
            "attributes": self.attributes,
            "directed": self.directed,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata
        }

    @classmethod
    def from_dict(cls, data: Dict) -> 'Edge':
        """Create an Edge from a dictionary"""
        timestamp = datetime.fromisoformat(data["timestamp"]) if "timestamp" in data else None
        edge = cls(
            data["source_id"],
            data["target_id"],
            data["type"],
            data.get("weight", 1.0),
            data.get("attributes", {}),
            data.get("directed", True),
            timestamp
        )
        edge.metadata = data.get("metadata", {})
        return edge


class NetworkGraph:
    """
    A graph representing a network of nodes and edges, optimized for
    analysis across different domains.
    """
    def __init__(self, name: str = "Network", attributes: Dict = None):
        self.name = name
        self.attributes = attributes or {}
        self.nodes = {}  # {node_id: Node}
        self.edges = []  # List of Edge objects
        self.node_index = defaultdict(list)  # {node_type: [node_ids]}
        self.edge_index = defaultdict(list)  # {edge_type: [edge_indices]}
        self.timestamp_index = defaultdict(list)  # {date_str: [edge_indices]}
        self.metadata = {}
        
        # Analysis results cache
        self.analysis_cache = {}

    def add_node(self, node: Node) -> None:
        """Add a node to the graph"""
        self.nodes[node.id] = node
        self.node_index[node.type].append(node.id)

    def add_edge(self, edge: Edge) -> None:
        """Add an edge to the graph"""
        edge_idx = len(self.edges)
        self.edges.append(edge)
        self.edge_index[edge.type].append(edge_idx)
        
        # Add to timestamp index (by day)
        date_str = edge.timestamp.strftime("%Y-%m-%d")
        self.timestamp_index[date_str].append(edge_idx)
        
        # Update node connections
        if edge.source_id in self.nodes:
            self.nodes[edge.source_id].add_connection(edge.target_id, edge)
        
        if not edge.directed and edge.target_id in self.nodes:
            # For undirected edges, add the reverse connection
            self.nodes[edge.target_id].add_connection(edge.source_id, edge)

    def get_node(self, node_id: str) -> Optional[Node]:
        """Get a node by ID"""
        return self.nodes.get(node_id)

    def get_nodes_by_type(self, node_type: str) -> List[Node]:
        """Get all nodes of a specific type"""
        node_ids = self.node_index.get(node_type, [])
        return [self.nodes[node_id] for node_id in node_ids]

    def get_edges_by_type(self, edge_type: str) -> List[Edge]:
        """Get all edges of a specific type"""
        edge_indices = self.edge_index.get(edge_type, [])
        return [self.edges[idx] for idx in edge_indices]

    def get_edges_by_date_range(self, start_date: datetime, end_date: datetime) -> List[Edge]:
        """Get all edges within a date range"""
        edges = []
        current_date = start_date
        
        while current_date <= end_date:
            date_str = current_date.strftime("%Y-%m-%d")
            edge_indices = self.timestamp_index.get(date_str, [])
            edges.extend([self.edges[idx] for idx in edge_indices])
            current_date += timedelta(days=1)
            
        return edges

    def get_edges_between_nodes(self, source_id: str, target_id: str) -> List[Edge]:
        """Get all edges between two nodes"""
        if source_id not in self.nodes:
            return []
            
        edges = []
        if target_id in self.nodes[source_id].connections:
            edges.append(self.nodes[source_id].connections[target_id])
            
        # Also check reverse direction for completeness
        if target_id in self.nodes and source_id in self.nodes[target_id].connections:
            reverse_edge = self.nodes[target_id].connections[source_id]
            if reverse_edge not in edges:  # Avoid duplicates for undirected edges
                edges.append(reverse_edge)
                
        return edges

    def get_networkx_graph(self, directed: bool = True) -> nx.Graph:
        """
        Convert to NetworkX graph for advanced analysis
        
        Args:
            directed: Whether to create a directed graph
            
        Returns:
            NetworkX graph object
        """
        if directed:
            G = nx.DiGraph(name=self.name)
        else:
            G = nx.Graph(name=self.name)
            
        # Add nodes with attributes
        for node_id, node in self.nodes.items():
            G.add_node(node_id, **node.attributes, weight=node.weight, node_type=node.type)
            
        # Add edges with attributes
        for edge in self.edges:
            # Only add edges where both endpoints exist
            if edge.source_id in self.nodes and edge.target_id in self.nodes:
                G.add_edge(
                    edge.source_id, 
                    edge.target_id, 
                    **edge.attributes,
                    weight=edge.weight,
                    edge_type=edge.type,
                    timestamp=edge.timestamp
                )
                
        return G

    def to_dict(self) -> Dict:
        """Convert to dictionary representation"""
        return {
            "name": self.name,
            "attributes": self.attributes,
            "nodes": [node.to_dict() for node in self.nodes.values()],
            "edges": [edge.to_dict() for edge in self.edges],
            "metadata": self.metadata
        }

    @classmethod
    def from_dict(cls, data: Dict) -> 'NetworkGraph':
        """Create a NetworkGraph from a dictionary"""
        graph = cls(data["name"], data.get("attributes", {}))
        graph.metadata = data.get("metadata", {})
        
        # Add nodes
        for node_data in data["nodes"]:
            node = Node.from_dict(node_data)
            graph.add_node(node)
            
        # Add edges
        for edge_data in data["edges"]:
            edge = Edge.from_dict(edge_data)
            graph.add_edge(edge)
            
        return graph

    def save(self, file_path: str) -> None:
        """Save the graph to a file"""
        data = self.to_dict()
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)

    @classmethod
    def load(cls, file_path: str) -> 'NetworkGraph':
        """Load a graph from a file"""
        with open(file_path, 'r') as f:
            data = json.load(f)
        return cls.from_dict(data)
            
    def get_subgraph(self, node_ids: List[str]) -> 'NetworkGraph':
        """
        Create a subgraph containing only the specified nodes and their interconnections
        
        Args:
            node_ids: List of node IDs to include
            
        Returns:
            NetworkGraph containing only the specified nodes
        """
        subgraph = NetworkGraph(f"{self.name}_subgraph", self.attributes.copy())
        
        # Add selected nodes
        for node_id in node_ids:
            if node_id in self.nodes:
                subgraph.add_node(Node.from_dict(self.nodes[node_id].to_dict()))
        
        # Add edges between these nodes
        for edge in self.edges:
            if edge.source_id in node_ids and edge.target_id in node_ids:
                subgraph.add_edge(Edge.from_dict(edge.to_dict()))
                
        return subgraph


# =============================================================================
# Statistical Models and Analysis
# =============================================================================

class BayesianNetworkAnalyzer:
    """
    Analyzes patterns in network data using Bayesian Networks to 
    estimate conditional probabilities and causal relationships.
    """
    def __init__(self):
        self.model = None
        self.node_mapping = {}  # Maps node IDs to indices
        self.trained = False
        
    def fit(self, graph: NetworkGraph, node_types: List[str] = None, edge_types: List[str] = None):
        """
        Fit a Bayesian Network to the graph data
        
        Args:
            graph: NetworkGraph to analyze
            node_types: Optional filter for node types to include
            edge_types: Optional filter for edge types to include
            
        Returns:
            Self for chaining
        """
        if not BAYESIAN_AVAILABLE:
            logger.warning("pomegranate library not available. Cannot build Bayesian Network.")
            return self
            
        # Extract nodes to include in the model
        include_nodes = set()
        if node_types:
            for node_type in node_types:
                include_nodes.update([node_id for node_id in graph.node_index.get(node_type, [])])
        else:
            include_nodes = set(graph.nodes.keys())
            
        # Extract edges to include in the model
        edge_indices = []
        if edge_types:
            for edge_type in edge_types:
                edge_indices.extend(graph.edge_index.get(edge_type, []))
        else:
            edge_indices = list(range(len(graph.edges)))
            
        # Filter edges to only those connecting included nodes
        filtered_edges = []
        for idx in edge_indices:
            edge = graph.edges[idx]
            if edge.source_id in include_nodes and edge.target_id in include_nodes:
                filtered_edges.append(edge)
                
        # Not enough data
        if len(include_nodes) < 2 or len(filtered_edges) < 1:
            logger.warning("Not enough nodes or edges to build Bayesian Network.")
            return self
            
        # Create node mapping (node_id -> index)
        self.node_mapping = {node_id: i for i, node_id in enumerate(sorted(include_nodes))}
        
        # Build directed graph of connections
        connection_graph = nx.DiGraph()
        for node_id in include_nodes:
            connection_graph.add_node(node_id)
            
        for edge in filtered_edges:
            connection_graph.add_edge(edge.source_id, edge.target_id, weight=edge.weight)
            
        # Remove cycles for Bayesian Network (which must be a DAG)
        while not nx.is_directed_acyclic_graph(connection_graph):
            # Find cycles
            try:
                cycle = nx.find_cycle(connection_graph)
                # Remove the weakest edge in the cycle
                weakest_edge = min(cycle, key=lambda e: connection_graph[e[0]][e[1]].get('weight', 1.0))
                connection_graph.remove_edge(weakest_edge[0], weakest_edge[1])
            except nx.NetworkXNoCycle:
                break
                
        # Build the Bayesian Network structure
        structure = []
        for node_id in include_nodes:
            parents = list(connection_graph.predecessors(node_id))
            structure.append((self.node_mapping[node_id], [self.node_mapping[p] for p in parents]))
            
        # Initialize probability distributions based on edge weights
        # This is a simplified approach - in practice you'd use observed data
        distributions = []
        for node_id in sorted(include_nodes):
            parents = list(connection_graph.predecessors(node_id))
            if not parents:
                # No parents, use a simple discrete distribution
                dist = DiscreteDistribution({0: 0.5, 1: 0.5})
            else:
                # Create conditional probability table based on edge weights
                table = []
                parent_indices = [self.node_mapping[p] for p in parents]
                
                # Generate all possible parent value combinations
                for values in self._generate_value_combinations(len(parents)):
                    # Calculate probability based on incoming edge weights
                    total_weight = sum(connection_graph[parents[i]][node_id].get('weight', 1.0) 
                                      for i in range(len(parents)) if values[i] == 1)
                    
                    # Probability of node being active given parent values
                    p_active = min(0.95, max(0.05, total_weight / (len(parents) + 0.1)))
                    
                    # Add both outcomes to the table (active=1, inactive=0)
                    row = list(values) + [1, p_active]
                    table.append(row)
                    row = list(values) + [0, 1.0 - p_active]
                    table.append(row)
                    
                # Create the CPT
                dist = ConditionalProbabilityTable(table, parent_indices)
            
            distributions.append(dist)
            
        # Create the Bayesian Network
        self.model = BayesianNetwork.from_structure(
            distributions,
            structure
        )
        
        self.trained = True
        return self
        
    def _generate_value_combinations(self, n_parents):
        """Generate all possible combinations of 0/1 values for n parents"""
        if n_parents == 0:
            return []
        return [list(map(int, format(i, f'0{n_parents}b'))) for i in range(2**n_parents)]
        
    def predict_likelihood(self, source_nodes: List[str], target_nodes: List[str]) -> Dict[str, float]:
        """
        Predict the likelihood of connections between source and target nodes
        
        Args:
            source_nodes: List of source node IDs
            target_nodes: List of target node IDs
            
        Returns:
            Dictionary mapping target nodes to likelihood scores
        """
        if not self.trained or not self.model:
            return {target: 0.5 for target in target_nodes}  # Default to 0.5 if not trained
            
        # Check which nodes are in our model
        valid_sources = [n for n in source_nodes if n in self.node_mapping]
        valid_targets = [n for n in target_nodes if n in self.node_mapping]
        
        if not valid_sources or not valid_targets:
            return {target: 0.5 for target in target_nodes}
            
        # Create evidence dictionary from source nodes (assume they're active)
        evidence = {self.node_mapping[source]: 1 for source in valid_sources}
        
        # Predict for each target node
        result = {}
        for target in target_nodes:
            if target in valid_targets:
                # Use Bayesian Network to predict probability
                target_idx = self.node_mapping[target]
                try:
                    # Get marginal probability of target=1 given evidence
                    probability = self.model.predict_proba(evidence)[target_idx].parameters[0][1]
                    result[target] = probability
                except Exception as e:
                    logger.error(f"Error in Bayesian prediction for {target}: {str(e)}")
                    result[target] = 0.5
            else:
                result[target] = 0.5  # Default for nodes not in model
                
        return result
        
    def most_likely_paths(self, 
                         source_node: str, 
                         target_node: str, 
                         graph: NetworkGraph,
                         max_paths: int = 3) -> List[List[str]]:
        """
        Find the most likely paths from source to target node
        
        Args:
            source_node: Source node ID
            target_node: Target node ID
            graph: NetworkGraph containing the nodes
            max_paths: Maximum number of paths to return
            
        Returns:
            List of paths (each path is a list of node IDs)
        """
        if not self.trained or source_node not in self.node_mapping or target_node not in self.node_mapping:
            return []
            
        # Convert to NetworkX for path finding
        nx_graph = graph.get_networkx_graph(directed=True)
        
        # Try to find all simple paths
        try:
            all_paths = list(nx.all_simple_paths(nx_graph, source_node, target_node, cutoff=10))
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            return []
            
        if not all_paths:
            return []
            
        # Calculate likelihood of each path
        path_likelihoods = []
        for path in all_paths:
            # Likelihood is the product of transition probabilities along the path
            likelihood = 1.0
            for i in range(len(path) - 1):
                from_node, to_node = path[i], path[i+1]
                
                # Get probability using our Bayesian model
                prob = self.predict_likelihood([from_node], [to_node])[to_node]
                likelihood *= prob
                
            path_likelihoods.append((path, likelihood))
            
        # Sort by likelihood (descending)
        path_likelihoods.sort(key=lambda x: x[1], reverse=True)
        
        # Return the top paths
        return [path for path, _ in path_likelihoods[:max_paths]]


class HiddenMarkovModelAnalyzer:
    """
    Analyzes sequential patterns in network data using Hidden Markov Models
    to detect hidden states and predict transitions.
    """
    def __init__(self, n_components: int = 3, n_iterations: int = 100):
        self.n_components = n_components  # Number of hidden states
        self.n_iterations = n_iterations
        self.model = None
        self.location_mapping = {}  # Maps locations to indices
        self.reverse_mapping = {}   # Maps indices back to locations
        self.trained = False
        
    def fit(self, graph: NetworkGraph, sequence_extractor: Callable = None):
        """
        Fit a Hidden Markov Model to movement sequences in the graph
        
        Args:
            graph: NetworkGraph to analyze
            sequence_extractor: Optional function to extract sequences from the graph
                               (default extracts sequences based on timestamp-ordered movements)
            
        Returns:
            Self for chaining
        """
        if not HMM_AVAILABLE:
            logger.warning("hmmlearn library not available. Cannot build HMM.")
            return self
            
        # Extract movement sequences
        sequences = self._extract_sequences(graph) if sequence_extractor is None else sequence_extractor(graph)
        
        if not sequences:
            logger.warning("No sequences found in graph. Cannot train HMM.")
            return self
            
        # Create mapping for locations to indices
        unique_locations = set()
        for sequence in sequences:
            unique_locations.update(sequence)
            
        self.location_mapping = {loc: idx for idx, loc in enumerate(sorted(unique_locations))}
        self.reverse_mapping = {idx: loc for loc, idx in self.location_mapping.items()}
        
        # Convert sequences to numerical form
        numerical_sequences = []
        for sequence in sequences:
            numerical_sequences.append([self.location_mapping[loc] for loc in sequence])
            
        # Prepare the data for HMM
        X = np.concatenate([np.array(seq).reshape(-1, 1) for seq in numerical_sequences])
        lengths = [len(seq) for seq in numerical_sequences]
        
        # Initialize and train the HMM
        self.model = hmm.MultinomialHMM(n_components=self.n_components, n_iter=self.n_iterations)
        self.model.fit(X, lengths=lengths)
        
        self.trained = True
        return self
    
    def _extract_sequences(self, graph: NetworkGraph) -> List[List[str]]:
        """
        Extract movement sequences from the graph based on timestamp order
        
        Args:
            graph: NetworkGraph to analyze
            
        Returns:
            List of sequences (each sequence is a list of node IDs representing a path)
        """
        # Find all movement/travel type edges
        movement_edge_types = set()
        for edge_type in graph.edge_index.keys():
            if any(keyword in edge_type.lower() for keyword in 
                   ['movement', 'travel', 'trafficking', 'transport', 'shipment', 'migration']):
                movement_edge_types.add(edge_type)
                
        if not movement_edge_types:
            # No explicit movement edges, look for any edges with timestamp
            edges_with_time = [(i, edge) for i, edge in enumerate(graph.edges) 
                              if edge.timestamp is not None]
        else:
            # Get edges of movement types
            edge_indices = []
            for edge_type in movement_edge_types:
                edge_indices.extend(graph.edge_index.get(edge_type, []))
                
            edges_with_time = [(i, graph.edges[i]) for i in edge_indices
                              if graph.edges[i].timestamp is not None]
            
        if not edges_with_time:
            return []
            
        # Group edges by entities (could be individuals, vehicles, shipments, etc.)
        # We'll use a heuristic approach looking for shared attributes
        entity_sequences = defaultdict(list)
        
        # Try to identify entity identifier attributes
        identifier_attributes = set(['entity_id', 'tracking_id', 'shipment_id', 'individual_id', 'vehicle_id'])
        
        for _, edge in edges_with_time:
            entity_id = None
            
            # Check if the edge has an identifier attribute
            for attr in identifier_attributes:
                if attr in edge.attributes:
                    entity_id = edge.attributes[attr]
                    break
                    
            # If no identifier, use source_id as a fallback
            if entity_id is None:
                entity_id = edge.source_id
                
            # Add to the sequence for this entity
            entity_sequences[entity_id].append((edge.timestamp, edge.source_id, edge.target_id))
            
        # Sort each sequence by timestamp
        sequences = []
        for entity_id, movements in entity_sequences.items():
            if len(movements) <= 1:
                continue  # Need at least 2 movements to form a sequence
                
            # Sort by timestamp
            sorted_movements = sorted(movements, key=lambda x: x[0])
            
            # Extract the path
            path = [sorted_movements[0][1]]  # Start with first source
            for _, _, target in sorted_movements:
                path.append(target)
                
            sequences.append(path)
            
        return sequences
    
    def predict_next_locations(self, 
                              current_sequence: List[str], 
                              n_predictions: int = 3) -> List[Tuple[str, float]]:
        """
        Predict the most likely next locations given a sequence of previous locations
        
        Args:
            current_sequence: Sequence of location IDs
            n_predictions: Number of predictions to return
            
        Returns:
            List of (location_id, probability) tuples, sorted by probability
        """
        if not self.trained or not self.model:
            return []
            
        # Convert sequence to numerical form
        valid_sequence = [loc for loc in current_sequence if loc in self.location_mapping]
        
        if not valid_sequence:
            return []
            
        numerical_sequence = [self.location_mapping[loc] for loc in valid_sequence]
        X = np.array(numerical_sequence).reshape(-1, 1)
        
        # Get the most likely state for the current position
        state_probs = self.model.predict_proba(X)
        current_state_prob = state_probs[-1]
        
        # Get next observation probabilities
        n_locations = len(self.location_mapping)
        next_location_probs = np.zeros(n_locations)
        
        for i in range(self.n_components):
            next_location_probs += current_state_prob[i] * self.model.emissionprob_[i]
            
        # Sort and return the top predictions
        top_indices = np.argsort(next_location_probs)[-n_predictions:][::-1]
        
        predictions = []
        for idx in top_indices:
            if idx in self.reverse_mapping:
                location = self.reverse_mapping[idx]
                probability = next_location_probs[idx]
                predictions.append((location, float(probability)))
                
        return predictions
    
    def decode_hidden_states(self, sequence: List[str]) -> List[int]:
        """
        Decode the most likely sequence of hidden states for a given observation sequence
        
        Args:
            sequence: Sequence of location IDs
            
        Returns:
            List of state indices representing the most likely state sequence
        """
        if not self.trained or not self.model:
            return []
            
        # Convert sequence to numerical form
        valid_sequence = [loc for loc in sequence if loc in self.location_mapping]
        
        if not valid_sequence:
            return []
            
        numerical_sequence = [self.location_mapping[loc] for loc in valid_sequence]
        X = np.array(numerical_sequence).reshape(-1, 1)
        
        # Decode the hidden state sequence
        logprob, state_sequence = self.model.decode(X)
        
        return state_sequence.tolist()
    
    def generate_sequence(self, start_location: str, length: int = 5) -> List[str]:
        """
        Generate a likely sequence starting from a given location
        
        Args:
            start_location: Starting location ID
            length: Length of sequence to generate
            
        Returns:
            List of location IDs representing a likely sequence
        """
        if not self.trained or not self.model or start_location not in self.location_mapping:
            return []
            
        # Start with the given location
        sequence = [start_location]
        current_loc = start_location
        
        # Generate subsequent locations
        for _ in range(length - 1):
            predictions = self.predict_next_locations([current_loc], n_predictions=1)
            
            if not predictions:
                break
                
            next_loc, _ = predictions[0]
            sequence.append(next_loc)
            current_loc = next_loc
            
        return sequence


class RouteAnalyzer:
    """
    Analyzes and predicts routes through networks using statistical
    and graph-based methods.
    """
    def __init__(self):
        self.bayesian_analyzer = BayesianNetworkAnalyzer()
        self.hmm_analyzer = HiddenMarkovModelAnalyzer()
        self.graph = None
        
    def fit(self, graph: NetworkGraph, node_types: List[str] = None, edge_types: List[str] = None):
        """
        Fit the route analyzer to a graph
        
        Args:
            graph: NetworkGraph to analyze
            node_types: Optional filter for node types to include
            edge_types: Optional filter for edge types to include
            
        Returns:
            Self for chaining
        """
        self.graph = graph
        
        # Fit Bayesian Network if available
        if BAYESIAN_AVAILABLE:
            self.bayesian_analyzer.fit(graph, node_types, edge_types)
            
        # Fit Hidden Markov Model if available
        if HMM_AVAILABLE:
            self.hmm_analyzer.fit(graph)
            
        return self
        
    def predict_routes(self, 
                      source: str, 
                      destination: str, 
                      n_routes: int = 3,
                      use_hmm: bool = True,
                      use_bayesian: bool = True) -> List[Dict]:
        """
        Predict likely routes between source and destination
        
        Args:
            source: Source node ID
            destination: Destination node ID
            n_routes: Number of routes to return
            use_hmm: Whether to use HMM for predictions
            use_bayesian: Whether to use Bayesian Network for predictions
            
        Returns:
            List of route dictionaries containing node sequences and probabilities
        """
        if self.graph is None:
            return []
            
        routes = []
        
        # Use Bayesian Network for prediction if available
        if use_bayesian and BAYESIAN_AVAILABLE and self.bayesian_analyzer.trained:
            bayesian_paths = self.bayesian_analyzer.most_likely_paths(
                source, destination, self.graph, max_paths=n_routes
            )
            
            for path in bayesian_paths:
                if path not in [r["path"] for r in routes]:
                    routes.append({
                        "path": path,
                        "method": "bayesian",
                        "probability": 0.0,  # Will calculate below
                        "nodes": []  # Will populate with node objects
                    })
                    
        # Use HMM for sequence prediction if available
        if use_hmm and HMM_AVAILABLE and self.hmm_analyzer.trained:
            # Here we'd implement a more complex approach using HMM to predict paths
            # This is a simplified placeholder - in practice, we'd need to explore
            # the network structure using the HMM predicted transitions
            pass
            
        # If no predictions from models, use shortest paths
        if not routes:
            try:
                nx_graph = self.graph.get_networkx_graph(directed=True)
                shortest_paths = list(nx.shortest_simple_paths(nx_graph, source, destination))[:n_routes]
                
                for path in shortest_paths:
                    routes.append({
                        "path": path,
                        "method": "shortest_path",
                        "probability": 0.0,  # Will calculate below
                        "nodes": []  # Will populate with node objects
                    })
            except (nx.NetworkXNoPath, nx.NodeNotFound):
                return []
                
        # Enrich route information
        for route in routes:
            path = route["path"]
            
            # Enhance with node objects
            route["nodes"] = [self.graph.get_node(node_id) for node_id in path]
            
            # Calculate edge weights/probabilities along path
            total_weight = 0
            edges = []
            
            for i in range(len(path) - 1):
                from_id, to_id = path[i], path[i+1]
                path_edges = self.graph.get_edges_between_nodes(from_id, to_id)
                
                if path_edges:
                    # Use the highest weight edge if multiple exist
                    edge = max(path_edges, key=lambda e: e.weight)
                    edges.append(edge)
                    total_weight += edge.weight
                    
            route["edges"] = edges
            
            # Calculate simple probability based on edge weights
            if len(edges) > 0:
                route["probability"] = total_weight / len(edges)
            
        # Sort by probability
        routes.sort(key=lambda r: r["probability"], reverse=True)
        
        return routes[:n_routes]
    
    def identify_critical_nodes(self, graph: NetworkGraph = None) -> List[Tuple[str, float]]:
        """
        Identify critical nodes in the network using centrality metrics
        
        Args:
            graph: NetworkGraph to analyze, or None to use the fitted graph
            
        Returns:
            List of (node_id, criticality_score) tuples
        """
        if graph is None:
            if self.graph is None:
                return []
            graph = self.graph
            
        nx_graph = graph.get_networkx_graph()
        
        # Calculate betweenness centrality
        betweenness = nx.betweenness_centrality(nx_graph, weight='weight')
        
        # Calculate degree centrality
        degree = nx.degree_centrality(nx_graph)
        
        # Combine metrics for criticality score
        critical_nodes = []
        for node_id in graph.nodes:
            score = 0.7 * betweenness.get(node_id, 0) + 0.3 * degree.get(node_id, 0)
            critical_nodes.append((node_id, score))
            
        # Sort by criticality score
        critical_nodes.sort(key=lambda x: x[1], reverse=True)
        
        return critical_nodes
    
    def detect_communities(self, graph: NetworkGraph = None) -> Dict[str, int]:
        """
        Detect communities or clusters in the network
        
        Args:
            graph: NetworkGraph to analyze, or None to use the fitted graph
            
        Returns:
            Dictionary mapping node_id to community ID
        """
        if graph is None:
            if self.graph is None:
                return {}
            graph = self.graph
            
        nx_graph = graph.get_networkx_graph(directed=False)  # Use undirected for community detection
        
        # Use Louvain algorithm for community detection
        try:
            import community as community_louvain
            partition = community_louvain.best_partition(nx_graph)
            return partition
        except ImportError:
            # Fallback to connected components if python-louvain not available
            components = nx.connected_components(nx_graph)
            mapping = {}
            for i, component in enumerate(components):
                for node in component:
                    mapping[node] = i
            return mapping


# =============================================================================
# Specialized Analysis Modules
# =============================================================================

class CriminalNetworkAnalyzer:
    """
    Specialized module for analyzing criminal networks (cartels, gangs, trafficking)
    built on top of the core network analysis framework.
    """
    def __init__(self):
        self.network_graph = NetworkGraph("Criminal Network")
        self.route_analyzer = RouteAnalyzer()
        self.criminal_types = self._initialize_criminal_types()
        
    def _initialize_criminal_types(self):
        """Initialize the criminal organization types and their attributes"""
        return {
            "cartel": {
                "name": "Drug Cartel",
                "description": "Organized crime syndicate focused on drug trafficking",
                "indicators": ["drug trafficking", "violence", "corruption", "territory control"],
                "activities": ["drug production", "drug distribution", "money laundering", "extortion"],
                "typical_routes": ["South America to North America", "Mexico to USA", 
                                 "Golden Triangle to Asia & Australia"],
                "commodities": ["cocaine", "heroin", "methamphetamine", "marijuana", "fentanyl"]
            },
            "gang": {
                "name": "Street Gang",
                "description": "Urban criminal organization with territorial focus",
                "indicators": ["territorial markings", "violence", "street crimes", "recruitment"],
                "activities": ["drug dealing", "extortion", "robbery", "assault"],
                "typical_routes": ["urban centers", "city to city", "prison to street"],
                "commodities": ["drugs", "weapons", "stolen goods"]
            },
            "human_trafficking": {
                "name": "Human Trafficking Network",
                "description": "Criminal network involved in exploitation of humans",
                "indicators": ["exploitation", "forced labor", "sexual exploitation", "debt bondage"],
                "activities": ["recruitment", "transportation", "harboring", "exploitation"],
                "typical_routes": ["Southeast Asia to West", "Eastern Europe to Western Europe",
                                 "Africa to Europe", "South America to North America"],
                "commodities": ["labor", "sexual services", "domestic servitude"]
            },
            "arms_trafficking": {
                "name": "Arms Trafficking Network",
                "description": "Criminal network involved in illegal weapons trade",
                "indicators": ["weapons cache", "cross-border movement", "conflict zones"],
                "activities": ["sourcing", "smuggling", "distribution", "sales"],
                "typical_routes": ["Conflict zones to embargoed nations", "Eastern Europe to Africa",
                                 "Southeast Asia routes", "Balkan route"],
                "commodities": ["small arms", "assault rifles", "ammunition", "explosives"]
            }
        }
    
    def load_crime_data(self, 
                        data: pd.DataFrame, 
                        location_cols: List[str] = None,
                        date_col: str = None,
                        crime_type_col: str = None,
                        group_col: str = None,
                        lat_col: str = None,
                        lon_col: str = None) -> None:
        """
        Load crime data from a DataFrame into the network graph
        
        Args:
            data: DataFrame containing crime data
            location_cols: List of columns containing location information
            date_col: Column containing date information
            crime_type_col: Column containing crime type information
            group_col: Column identifying criminal groups
            lat_col: Column containing latitude information
            lon_col: Column containing longitude information
            
        Returns:
            None
        """
        if data.empty:
            logger.warning("Empty DataFrame provided. No data to load.")
            return
            
        # Detect columns if not specified
        if location_cols is None:
            # Try to detect location columns
            possible_location_cols = ["location", "city", "state", "country", "region", "address"]
            location_cols = [col for col in possible_location_cols if col in data.columns]
            
        if date_col is None:
            # Try to detect date column
            possible_date_cols = ["date", "incident_date", "event_date", "time", "datetime"]
            for col in possible_date_cols:
                if col in data.columns:
                    date_col = col
                    break
                    
        if crime_type_col is None:
            # Try to detect crime type column
            possible_type_cols = ["crime_type", "offense", "incident_type", "category"]
            for col in possible_type_cols:
                if col in data.columns:
                    crime_type_col = col
                    break
                    
        if group_col is None:
            # Try to detect group column
            possible_group_cols = ["group", "organization", "gang", "cartel", "network"]
            for col in possible_group_cols:
                if col in data.columns:
                    group_col = col
                    break
        
        # Process rows into network nodes and edges
        location_nodes = {}  # Keep track of created location nodes
        
        for _, row in data.iterrows():
            # Extract or create unique location identifier
            location_id = self._extract_location_id(row, location_cols, lat_col, lon_col)
            if not location_id:
                continue
                
            # Create location node if it doesn't exist
            if location_id not in location_nodes:
                location_attrs = self._extract_location_attributes(row, location_cols, lat_col, lon_col)
                location_node = Node(location_id, "location", location_attrs)
                self.network_graph.add_node(location_node)
                location_nodes[location_id] = location_node
                
            # Extract date
            event_date = None
            if date_col and date_col in row and pd.notna(row[date_col]):
                try:
                    event_date = pd.to_datetime(row[date_col])
                except:
                    pass
                    
            # Extract crime type
            crime_type = "unknown"
            if crime_type_col and crime_type_col in row and pd.notna(row[crime_type_col]):
                crime_type = str(row[crime_type_col]).lower()
                
            # Extract criminal group
            group = None
            if group_col and group_col in row and pd.notna(row[group_col]):
                group = str(row[group_col])
                
                # Create group node if it doesn't exist
                group_id = f"group_{group.lower().replace(' ', '_')}"
                if group_id not in self.network_graph.nodes:
                    group_type = self._determine_group_type(group, crime_type)
                    group_attrs = {
                        "name": group,
                        "crime_types": [crime_type]
                    }
                    group_node = Node(group_id, group_type, group_attrs)
                    self.network_graph.add_node(group_node)
                else:
                    # Update existing group's crime types
                    group_node = self.network_graph.get_node(group_id)
                    if "crime_types" in group_node.attributes:
                        if crime_type not in group_node.attributes["crime_types"]:
                            group_node.attributes["crime_types"].append(crime_type)
                    else:
                        group_node.attributes["crime_types"] = [crime_type]
                        
                # Create activity edge from group to location
                activity_edge = Edge(
                    group_id,
                    location_id,
                    "criminal_activity",
                    weight=1.0,
                    attributes={"crime_type": crime_type},
                    timestamp=event_date
                )
                self.network_graph.add_edge(activity_edge)
            
        # Apply temporal analysis to create movement patterns
        self._analyze_temporal_patterns()
        
    def _extract_location_id(self, row, location_cols, lat_col, lon_col):
        """Extract a unique location identifier from row data"""
        # If latitude and longitude are available, use them
        if lat_col and lon_col and lat_col in row and lon_col in row:
            if pd.notna(row[lat_col]) and pd.notna(row[lon_col]):
                # Round to 3 decimal places for stable IDs (approx 100m precision)
                lat = round(float(row[lat_col]), 3)
                lon = round(float(row[lon_col]), 3)
                return f"loc_{lat}_{lon}"
                
        # Otherwise use location name columns
        if location_cols:
            loc_parts = []
            for col in location_cols:
                if col in row and pd.notna(row[col]):
                    loc_parts.append(str(row[col]))
                    
            if loc_parts:
                return f"loc_{'_'.join(loc_parts).lower().replace(' ', '_')}"
                
        return None
        
    def _extract_location_attributes(self, row, location_cols, lat_col, lon_col):
        """Extract location attributes from row data"""
        attrs = {}
        
        # Add named location components
        if location_cols:
            for col in location_cols:
                if col in row and pd.notna(row[col]):
                    attrs[col] = str(row[col])
                    
        # Add coordinates if available
        if lat_col and lon_col and lat_col in row and lon_col in row:
            if pd.notna(row[lat_col]) and pd.notna(row[lon_col]):
                attrs["latitude"] = float(row[lat_col])
                attrs["longitude"] = float(row[lon_col])
                
        return attrs
    
    def _determine_group_type(self, group_name, crime_type):
        """Determine the type of criminal group based on name and crime type"""
        group_name_lower = group_name.lower()
        
        # Check for cartel indicators
        if "cartel" in group_name_lower or any(term in crime_type for term in 
                                             ["drug", "narco", "trafficking", "smuggling"]):
            return "cartel"
            
        # Check for gang indicators
        if "gang" in group_name_lower or any(term in group_name_lower for term in 
                                           ["crew", "posse", "set"]):
            return "gang"
            
        # Check for human trafficking indicators
        if any(term in crime_type for term in ["human trafficking", "sex trafficking", "forced labor"]):
            return "human_trafficking"
            
        # Check for arms trafficking indicators
        if any(term in crime_type for term in ["weapon", "gun", "arms", "firearm"]):
            return "arms_trafficking"
            
        # Default to generic criminal group
        return "criminal_group"
    
    def _analyze_temporal_patterns(self):
        """Analyze temporal patterns to infer movement and relationships"""
        # Get all criminal activity edges with timestamps
        activity_edges = [edge for edge in self.network_graph.edges 
                         if edge.type == "criminal_activity" and edge.timestamp is not None]
        
        # Sort by timestamp
        activity_edges.sort(key=lambda e: e.timestamp)
        
        # Group by criminal group
        group_activities = defaultdict(list)
        for edge in activity_edges:
            group_activities[edge.source_id].append((edge.timestamp, edge.target_id))
            
        # Analyze sequential locations for each group to infer movements
        for group_id, activities in group_activities.items():
            if len(activities) < 2:
                continue
                
            # Generate movement edges between sequential locations
            for i in range(len(activities) - 1):
                from_time, from_loc = activities[i]
                to_time, to_loc = activities[i + 1]
                
                # Only create edge if locations differ
                if from_loc != to_loc:
                    # Calculate time difference for weighting
                    time_diff = (to_time - from_time).total_seconds() / 86400.0  # in days
                    
                    # Higher weight for shorter time gaps (normalize to 0-1 range)
                    weight = math.exp(-time_diff / 30.0)  # 30-day time constant
                    
                    # Create movement edge
                    movement_edge = Edge(
                        from_loc,
                        to_loc,
                        "criminal_movement",
                        weight=weight,
                        attributes={
                            "group_id": group_id,
                            "time_difference_days": time_diff
                        },
                        timestamp=to_time
                    )
                    self.network_graph.add_edge(movement_edge)
        
    def analyze_trafficking_routes(self, criminal_type: str = None) -> Dict:
        """
        Analyze trafficking routes in the criminal network
        
        Args:
            criminal_type: Optional filter for specific criminal type
                          (e.g., "cartel", "human_trafficking")
            
        Returns:
            Dictionary with route analysis results
        """
        # Fit the route analyzer to our network
        self.route_analyzer.fit(self.network_graph)
        
        # Get all nodes that could be sources or destinations
        location_nodes = self.network_graph.get_nodes_by_type("location")
        
        # Get criminal groups of the specified type
        if criminal_type:
            criminal_nodes = self.network_graph.get_nodes_by_type(criminal_type)
        else:
            # Get all criminal groups
            criminal_types = ["cartel", "gang", "human_trafficking", "arms_trafficking", "criminal_group"]
            criminal_nodes = []
            for c_type in criminal_types:
                criminal_nodes.extend(self.network_graph.get_nodes_by_type(c_type))
                
        # Identify key locations associated with these groups
        key_locations = self._identify_key_locations(criminal_nodes)
        
        # Identify potential routes between key locations
        routes = []
        for source_id, source_attrs in key_locations.items():
            for dest_id, dest_attrs in key_locations.items():
                if source_id != dest_id and source_attrs["activity_level"] > 0.5 and dest_attrs["activity_level"] > 0.5:
                    predicted_routes = self.route_analyzer.predict_routes(
                        source_id, dest_id, n_routes=2
                    )
                    
                    if predicted_routes:
                        for route in predicted_routes:
                            route_data = {
                                "source": source_id,
                                "source_name": self.network_graph.get_node(source_id).attributes.get("city", source_id),
                                "destination": dest_id,
                                "destination_name": self.network_graph.get_node(dest_id).attributes.get("city", dest_id),
                                "path": route["path"],
                                "probability": route["probability"],
                                "groups": [node.id for node in criminal_nodes 
                                         if any(loc in route["path"] for loc in key_locations.get(node.id, {}).get("locations", []))]
                            }
                            routes.append(route_data)
                            
        # Identify hotspots (high centrality nodes)
        critical_nodes = self.route_analyzer.identify_critical_nodes()
        hotspots = []
        
        for node_id, score in critical_nodes[:10]:  # Top 10 critical nodes
            node = self.network_graph.get_node(node_id)
            if node and node.type == "location":
                hotspot = {
                    "id": node_id,
                    "name": node.attributes.get("city", node_id),
                    "criticality_score": score,
                    "connected_groups": []
                }
                
                # Find criminal groups connected to this location
                for c_node in criminal_nodes:
                    if node_id in c_node.get_connected_nodes():
                        hotspot["connected_groups"].append({
                            "id": c_node.id,
                            "name": c_node.attributes.get("name", c_node.id),
                            "type": c_node.type
                        })
                        
                hotspots.append(hotspot)
                
        return {
            "routes": routes,
            "hotspots": hotspots,
            "criminal_groups": [
                {
                    "id": node.id,
                    "name": node.attributes.get("name", node.id),
                    "type": node.type,
                    "crime_types": node.attributes.get("crime_types", [])
                }
                for node in criminal_nodes
            ]
        }
        
    def _identify_key_locations(self, criminal_nodes: List[Node]) -> Dict[str, Dict]:
        """
        Identify key locations associated with criminal groups
        
        Args:
            criminal_nodes: List of criminal group nodes
            
        Returns:
            Dictionary mapping location IDs to attributes
        """
        key_locations = {}
        
        # First pass: find all locations connected to these groups
        for node in criminal_nodes:
            connected_locs = []
            
            for loc_id in node.get_connected_nodes():
                loc_node = self.network_graph.get_node(loc_id)
                if loc_node and loc_node.type == "location":
                    connected_locs.append(loc_id)
                    
                    # Initialize this location if new
                    if loc_id not in key_locations:
                        key_locations[loc_id] = {
                            "groups": [],
                            "activity_count": 0,
                            "activity_level": 0.0,
                            "attributes": loc_node.attributes.copy()
                        }
                    
                    # Add this group to the location
                    key_locations[loc_id]["groups"].append(node.id)
                    key_locations[loc_id]["activity_count"] += 1
                    
        # Calculate activity level (normalized)
        max_activity = max([loc["activity_count"] for loc in key_locations.values()]) if key_locations else 1
        for loc_id in key_locations:
            key_locations[loc_id]["activity_level"] = key_locations[loc_id]["activity_count"] / max_activity
            
        return key_locations
    
    def detect_criminal_communities(self) -> Dict:
        """
        Detect communities of criminal groups and associated locations
        
        Returns:
            Dictionary with community detection results
        """
        communities = self.route_analyzer.detect_communities(self.network_graph)
        
        # Group nodes by community
        community_groups = defaultdict(list)
        for node_id, community_id in communities.items():
            node = self.network_graph.get_node(node_id)
            if node:
                community_groups[community_id].append(node)
                
        # Process each community
        result = {"communities": []}
        
        for community_id, nodes in community_groups.items():
            criminal_nodes = [n for n in nodes if n.type != "location"]
            location_nodes = [n for n in nodes if n.type == "location"]
            
            community_data = {
                "id": community_id,
                "size": len(nodes),
                "criminal_groups": [
                    {
                        "id": node.id,
                        "name": node.attributes.get("name", node.id),
                        "type": node.type,
                        "crime_types": node.attributes.get("crime_types", [])
                    }
                    for node in criminal_nodes
                ],
                "locations": [
                    {
                        "id": node.id,
                        "name": f"{node.attributes.get('city', '')} {node.attributes.get('country', '')}".strip(),
                        "attributes": node.attributes
                    }
                    for node in location_nodes
                ]
            }
            
            # Determine dominant criminal type in this community
            type_counts = Counter([node.type for node in criminal_nodes])
            dominant_type = type_counts.most_common(1)[0][0] if type_counts else "unknown"
            community_data["dominant_type"] = dominant_type
            
            result["communities"].append(community_data)
            
        # Sort communities by size
        result["communities"].sort(key=lambda x: x["size"], reverse=True)
        result["total_communities"] = len(result["communities"])
        
        return result
    
    def predict_future_hotspots(self, time_horizon_days: int = 30) -> List[Dict]:
        """
        Predict potential future hotspots based on network analysis
        
        Args:
            time_horizon_days: Time horizon for predictions in days
            
        Returns:
            List of potential future hotspots with prediction data
        """
        # Get current hotspots
        current_analysis = self.analyze_trafficking_routes()
        current_hotspots = {h["id"]: h for h in current_analysis.get("hotspots", [])}
        
        # Use the HMM analyzer to predict movement patterns
        if HMM_AVAILABLE and self.route_analyzer.hmm_analyzer.trained:
            future_hotspots = []
            
            # Start from current hotspots
            for hotspot_id, hotspot_data in current_hotspots.items():
                # Predict next locations
                next_locations = self.route_analyzer.hmm_analyzer.predict_next_locations(
                    [hotspot_id], n_predictions=3
                )
                
                for next_loc, probability in next_locations:
                    if next_loc != hotspot_id:  # Skip self-references
                        node = self.network_graph.get_node(next_loc)
                        if node:
                            future_hotspots.append({
                                "id": next_loc,
                                "name": node.attributes.get("city", next_loc),
                                "prediction_probability": probability,
                                "source_hotspot": hotspot_id,
                                "source_hotspot_name": hotspot_data["name"],
                                "time_horizon_days": time_horizon_days,
                                "attributes": node.attributes
                            })
            
            # Sort by prediction probability
            future_hotspots.sort(key=lambda x: x["prediction_probability"], reverse=True)
            return future_hotspots
        
        # Fallback if HMM not available: use degree centrality and current activity
        future_hotspots = []
        nx_graph = self.network_graph.get_networkx_graph()
        
        # Get degree centrality
        degree = nx.degree_centrality(nx_graph)
        
        # Use PageRank for prediction
        pagerank = nx.pagerank(nx_graph)
        
        # Get location nodes
        location_nodes = self.network_graph.get_nodes_by_type("location")
        
        # Identify potential future hotspots
        for node in location_nodes:
            # Skip current hotspots
            if node.id in current_hotspots:
                continue
                
            # Calculate prediction score based on centrality and connections
            degree_score = degree.get(node.id, 0)
            pagerank_score = pagerank.get(node.id, 0)
            
            # Higher weight to pagerank which accounts for network structure
            prediction_score = 0.3 * degree_score + 0.7 * pagerank_score
            
            if prediction_score > 0.01:  # Threshold to filter noise
                future_hotspots.append({
                    "id": node.id,
                    "name": node.attributes.get("city", node.id),
                    "prediction_probability": prediction_score,
                    "time_horizon_days": time_horizon_days,
                    "attributes": node.attributes
                })
                
        # Sort by prediction probability
        future_hotspots.sort(key=lambda x: x["prediction_probability"], reverse=True)
        return future_hotspots[:10]  # Return top 10
    
    def calculate_risk_scores(self) -> Dict[str, float]:
        """
        Calculate risk scores for different locations in the network
        
        Returns:
            Dictionary mapping location IDs to risk scores
        """
        risk_scores = {}
        
        # Get location nodes
        location_nodes = self.network_graph.get_nodes_by_type("location")
        
        # Get criminal group nodes
        criminal_types = ["cartel", "gang", "human_trafficking", "arms_trafficking", "criminal_group"]
        criminal_nodes = []
        for c_type in criminal_types:
            criminal_nodes.extend(self.network_graph.get_nodes_by_type(c_type))
            
        # Get centrality measures
        nx_graph = self.network_graph.get_networkx_graph()
        betweenness = nx.betweenness_centrality(nx_graph)
        pagerank = nx.pagerank(nx_graph)
        
        # Calculate risk for each location
        for node in location_nodes:
            # Base risk on centrality measures
            base_risk = 0.4 * betweenness.get(node.id, 0) + 0.6 * pagerank.get(node.id, 0)
            
            # Adjust based on criminal connections
            criminal_connections = []
            for criminal in criminal_nodes:
                if node.id in criminal.get_connected_nodes():
                    criminal_connections.append(criminal)
            
            # Higher risk for more criminal connections
            connection_factor = min(1.0, len(criminal_connections) / 3.0)  # Cap at 3 connections
            
            # Higher risk for connections to cartels and trafficking networks
            high_risk_connections = [c for c in criminal_connections 
                                   if c.type in ["cartel", "human_trafficking", "arms_trafficking"]]
            high_risk_factor = len(high_risk_connections) / max(1, len(criminal_connections))
            
            # Calculate final risk score
            risk_score = base_risk * (1 + connection_factor) * (1 + high_risk_factor)
            
            # Normalize to 0-1 range
            risk_scores[node.id] = min(1.0, risk_score)
            
        return risk_scores
    
    def generate_intelligence_report(self) -> Dict:
        """
        Generate a comprehensive intelligence report on the criminal network
        
        Returns:
            Dictionary with report data
        """
        report = {
            "timestamp": datetime.now().isoformat(),
            "network_summary": {
                "total_locations": len(self.network_graph.get_nodes_by_type("location")),
                "criminal_groups": {}
            },
            "trafficking_routes": [],
            "hotspots": [],
            "communities": [],
            "future_hotspots": [],
            "high_risk_locations": []
        }
        
        # Count criminal groups by type
        criminal_types = ["cartel", "gang", "human_trafficking", "arms_trafficking", "criminal_group"]
        for c_type in criminal_types:
            count = len(self.network_graph.get_nodes_by_type(c_type))
            if count > 0:
                report["network_summary"]["criminal_groups"][c_type] = count
                
        # Get trafficking routes
        routes_analysis = self.analyze_trafficking_routes()
        report["trafficking_routes"] = routes_analysis.get("routes", [])[:10]  # Top 10
        report["hotspots"] = routes_analysis.get("hotspots", [])
        
        # Get communities
        communities = self.detect_criminal_communities()
        report["communities"] = communities.get("communities", [])[:5]  # Top 5
        
        # Get future hotspots
        report["future_hotspots"] = self.predict_future_hotspots()
        
        # Get high risk locations
        risk_scores = self.calculate_risk_scores()
        high_risk = [(loc_id, score) for loc_id, score in risk_scores.items() if score > 0.5]
        high_risk.sort(key=lambda x: x[1], reverse=True)
        
        report["high_risk_locations"] = [
            {
                "id": loc_id,
                "name": self.network_graph.get_node(loc_id).attributes.get("city", loc_id),
                "risk_score": score,
                "attributes": self.network_graph.get_node(loc_id).attributes
            }
            for loc_id, score in high_risk[:10]  # Top 10
        ]
        
        return report


class ShippingNetworkAnalyzer:
    """
    Specialized module for analyzing commercial shipping networks
    built on top of the core network analysis framework.
    """
    def __init__(self):
        self.network_graph = NetworkGraph("Shipping Network")
        self.route_analyzer = RouteAnalyzer()
        
    def load_shipping_data(self,
                          data: pd.DataFrame,
                          origin_cols: List[str] = None,
                          destination_cols: List[str] = None,
                          date_col: str = None,
                          commodity_col: str = None,
                          carrier_col: str = None,
                          volume_col: str = None):
        """
        Load shipping data from a DataFrame into the network graph
        
        Args:
            data: DataFrame containing shipping data
            origin_cols: List of columns containing origin location information
            destination_cols: List of columns containing destination location information
            date_col: Column containing date information
            commodity_col: Column containing commodity information
            carrier_col: Column identifying shipping carriers
            volume_col: Column containing shipment volume information
            
        Returns:
            None
        """
        if data.empty:
            logger.warning("Empty DataFrame provided. No data to load.")
            return
            
        # Detect columns if not specified
        if origin_cols is None:
            # Try to detect origin columns
            possible_origin_cols = ["origin", "origin_city", "origin_country", "from_location"]
            origin_cols = [col for col in possible_origin_cols if col in data.columns]
            
        if destination_cols is None:
            # Try to detect destination columns
            possible_dest_cols = ["destination", "dest_city", "dest_country", "to_location"]
            destination_cols = [col for col in possible_dest_cols if col in data.columns]
            
        if date_col is None:
            # Try to detect date column
            possible_date_cols = ["date", "ship_date", "departure_date", "arrival_date"]
            for col in possible_date_cols:
                if col in data.columns:
                    date_col = col
                    break
                    
        if commodity_col is None:
            # Try to detect commodity column
            possible_commodity_cols = ["commodity", "cargo", "goods", "product"]
            for col in possible_commodity_cols:
                if col in data.columns:
                    commodity_col = col
                    break
                    
        if carrier_col is None:
            # Try to detect carrier column
            possible_carrier_cols = ["carrier", "shipping_line", "vessel", "company"]
            for col in possible_carrier_cols:
                if col in data.columns:
                    carrier_col = col
                    break
                    
        if volume_col is None:
            # Try to detect volume column
            possible_volume_cols = ["volume", "weight", "teu", "quantity", "tons"]
            for col in possible_volume_cols:
                if col in data.columns:
                    volume_col = col
                    break
                    
        # Process rows into network nodes and edges
        location_nodes = {}  # Keep track of created location nodes
        carrier_nodes = {}   # Keep track of created carrier nodes
        
        for _, row in data.iterrows():
            # Extract origin and destination
            origin_id = self._extract_location_id(row, origin_cols, prefix="origin")
            dest_id = self._extract_location_id(row, destination_cols, prefix="dest")
            
            if not origin_id or not dest_id:
                continue
                
            # Create origin node if needed
            if origin_id not in location_nodes:
                origin_attrs = self._extract_location_attributes(row, origin_cols, prefix="origin")
                origin_node = Node(origin_id, "port", origin_attrs)
                self.network_graph.add_node(origin_node)
                location_nodes[origin_id] = origin_node
                
            # Create destination node if needed
            if dest_id not in location_nodes:
                dest_attrs = self._extract_location_attributes(row, destination_cols, prefix="dest")
                dest_node = Node(dest_id, "port", dest_attrs)
                self.network_graph.add_node(dest_node)
                location_nodes[dest_id] = dest_node
                
            # Extract shipping date
            shipping_date = None
            if date_col and date_col in row and pd.notna(row[date_col]):
                try:
                    shipping_date = pd.to_datetime(row[date_col])
                except:
                    pass
                    
            # Extract carrier
            carrier = None
            carrier_id = None
            if carrier_col and carrier_col in row and pd.notna(row[carrier_col]):
                carrier = str(row[carrier_col])
                carrier_id = f"carrier_{carrier.lower().replace(' ', '_')}"
                
                # Create carrier node if needed
                if carrier_id not in carrier_nodes:
                    carrier_node = Node(carrier_id, "carrier", {"name": carrier})
                    self.network_graph.add_node(carrier_node)
                    carrier_nodes[carrier_id] = carrier_node
                    
            # Extract commodity
            commodity = "unknown"
            if commodity_col and commodity_col in row and pd.notna(row[commodity_col]):
                commodity = str(row[commodity_col])
                
            # Extract volume
            volume = 1.0
            if volume_col and volume_col in row and pd.notna(row[volume_col]):
                try:
                    volume = float(row[volume_col])
                except:
                    pass
                    
            # Create shipping route edge
            route_attrs = {
                "commodity": commodity,
                "volume": volume
            }
            
            if carrier_id:
                route_attrs["carrier_id"] = carrier_id
                
            route_edge = Edge(
                origin_id,
                dest_id,
                "shipping_route",
                weight=volume,
                attributes=route_attrs,
                timestamp=shipping_date
            )
            self.network_graph.add_edge(route_edge)
            
            # If carrier is known, create carrier service edges
            if carrier_id:
                # Carrier to origin edge
                origin_service = Edge(
                    carrier_id,
                    origin_id,
                    "carrier_service",
                    weight=1.0,
                    attributes={"service_type": "origin"},
                    timestamp=shipping_date
                )
                self.network_graph.add_edge(origin_service)
                
                # Carrier to destination edge
                dest_service = Edge(
                    carrier_id,
                    dest_id,
                    "carrier_service",
                    weight=1.0,
                    attributes={"service_type": "destination"},
                    timestamp=shipping_date
                )
                self.network_graph.add_edge(dest_service)
                
    def _extract_location_id(self, row, location_cols, prefix=None):
        """Extract a unique location identifier from row data"""
        if not location_cols:
            return None
            
        loc_parts = []
        for col in location_cols:
            # Handle prefixed column names
            col_name = f"{prefix}_{col}" if prefix else col
            if col_name in row and pd.notna(row[col_name]):
                loc_parts.append(str(row[col_name]))
                
        if loc_parts:
            return f"loc_{'_'.join(loc_parts).lower().replace(' ', '_')}"
            
        return None
        
    def _extract_location_attributes(self, row, location_cols, prefix=None):
        """Extract location attributes from row data"""
        attrs = {}
        
        if location_cols:
            for col in location_cols:
                # Handle prefixed column names
                col_name = f"{prefix}_{col}" if prefix else col
                attr_name = col if prefix else col
                
                if col_name in row and pd.notna(row[col_name]):
                    attrs[attr_name] = str(row[col_name])
                    
        return attrs
    
    def analyze_shipping_routes(self, commodity_filter=None) -> Dict:
        """
        Analyze shipping routes in the network
        
        Args:
            commodity_filter: Optional filter for specific commodity
            
        Returns:
            Dictionary with route analysis results
        """
        # Fit the route analyzer to our network
        self.route_analyzer.fit(self.network_graph)
        
        # Get all port nodes
        port_nodes = self.network_graph.get_nodes_by_type("port")
        
        # Filter shipping route edges if commodity specified
        if commodity_filter:
            filtered_edges = [edge for edge in self.network_graph.get_edges_by_type("shipping_route")
                             if edge.attributes.get("commodity") == commodity_filter]
        else:
            filtered_edges = self.network_graph.get_edges_by_type("shipping_route")
            
        # Count routes between port pairs
        route_counts = defaultdict(int)
        route_volumes = defaultdict(float)
        
        for edge in filtered_edges:
            route_key = (edge.source_id, edge.target_id)
            route_counts[route_key] += 1
            route_volumes[route_key] += edge.attributes.get("volume", 1.0)
            
        # Get top routes by volume
        top_routes = sorted(route_volumes.items(), key=lambda x: x[1], reverse=True)
        
        # Prepare results
        routes = []
        for (source_id, target_id), volume in top_routes[:20]:  # Top 20 routes
            source_node = self.network_graph.get_node(source_id)
            target_node = self.network_graph.get_node(target_id)
            
            if source_node and target_node:
                route_data = {
                    "source": source_id,
                    "source_name": source_node.attributes.get("city", source_id),
                    "destination": target_id,
                    "destination_name": target_node.attributes.get("city", target_id),
                    "volume": volume,
                    "frequency": route_counts[(source_id, target_id)]
                }
                
                # Try to find predicted routes
                predicted_routes = self.route_analyzer.predict_routes(
                    source_id, target_id, n_routes=1
                )
                
                if predicted_routes:
                    route_data["path"] = predicted_routes[0]["path"]
                    route_data["probability"] = predicted_routes[0]["probability"]
                    
                routes.append(route_data)
                
        # Identify key ports (high centrality nodes)
        critical_nodes = self.route_analyzer.identify_critical_nodes()
        key_ports = []
        
        for node_id, score in critical_nodes[:10]:  # Top 10 critical nodes
            node = self.network_graph.get_node(node_id)
            if node and node.type == "port":
                port_data = {
                    "id": node_id,
                    "name": node.attributes.get("city", node_id),
                    "country": node.attributes.get("country", "Unknown"),
                    "centrality_score": score,
                    "incoming_volume": 0.0,
                    "outgoing_volume": 0.0
                }
                
                # Calculate incoming and outgoing volumes
                for edge in filtered_edges:
                    if edge.target_id == node_id:
                        port_data["incoming_volume"] += edge.attributes.get("volume", 1.0)
                    elif edge.source_id == node_id:
                        port_data["outgoing_volume"] += edge.attributes.get("volume", 1.0)
                        
                port_data["total_volume"] = port_data["incoming_volume"] + port_data["outgoing_volume"]
                key_ports.append(port_data)
                
        # Sort key ports by total volume
        key_ports.sort(key=lambda x: x["total_volume"], reverse=True)
        
        # Calculate global shipping statistics
        total_volume = sum(edge.attributes.get("volume", 1.0) for edge in filtered_edges)
        total_routes = len(route_volumes)
        
        # Get carrier information
        carrier_nodes = self.network_graph.get_nodes_by_type("carrier")
        carriers = []
        
        for node in carrier_nodes:
            carrier_edges = [edge for edge in self.network_graph.edges 
                            if (edge.source_id == node.id or edge.target_id == node.id) 
                            and edge.type == "carrier_service"]
            
            # Count unique ports served
            served_ports = set()
            for edge in carrier_edges:
                port_id = edge.target_id if edge.source_id == node.id else edge.source_id
                served_ports.add(port_id)
                
            carriers.append({
                "id": node.id,
                "name": node.attributes.get("name", node.id),
                "ports_served": len(served_ports),
                "service_count": len(carrier_edges) // 2  # Divide by 2 for origin/destination pairs
            })
            
        # Sort carriers by ports served
        carriers.sort(key=lambda x: x["ports_served"], reverse=True)
        
        return {
            "routes": routes,
            "key_ports": key_ports,
            "carriers": carriers[:10],  # Top 10 carriers
            "statistics": {
                "total_volume": total_volume,
                "total_routes": total_routes,
                "total_ports": len(port_nodes),
                "total_carriers": len(carrier_nodes)
            }
        }
    
    def optimize_shipping_network(self, volume_threshold: float = 0.0) -> Dict:
        """
        Optimize the shipping network to identify inefficiencies and suggest improvements
        
        Args:
            volume_threshold: Minimum volume for routes to consider
            
        Returns:
            Dictionary with optimization results
        """
        # Get all shipping routes
        shipping_routes = [edge for edge in self.network_graph.get_edges_by_type("shipping_route")
                         if edge.attributes.get("volume", 0.0) > volume_threshold]
        
        # Create NetworkX graph for shortest path calculations
        nx_graph = nx.DiGraph()
        
        # Add edges with distance-based weights
        for edge in shipping_routes:
            source_node = self.network_graph.get_node(edge.source_id)
            target_node = self.network_graph.get_node(edge.target_id)
            
            if source_node and target_node:
                # Calculate straight-line distance if coordinates are available
                distance = 1.0  # Default distance
                
                if all(attr in source_node.attributes and attr in target_node.attributes 
                     for attr in ["latitude", "longitude"]):
                    source_coords = (source_node.attributes["latitude"], source_node.attributes["longitude"])
                    target_coords = (target_node.attributes["latitude"], target_node.attributes["longitude"])
                    
                    try:
                        # Calculate distance in kilometers
                        distance = self._calculate_distance(source_coords, target_coords)
                    except:
                        pass
                
                # Add edge with distance as weight
                nx_graph.add_edge(
                    edge.source_id, 
                    edge.target_id, 
                    weight=distance,
                    volume=edge.attributes.get("volume", 1.0)
                )
                
        # Initialize results
        results = {
            "inefficient_routes": [],
            "hub_recommendations": [],
            "consolidation_opportunities": []
        }
        
        # Check for inefficient routes
        for edge in shipping_routes:
            # Skip routes with no alternatives
            if not nx_graph.has_node(edge.source_id) or not nx_graph.has_node(edge.target_id):
                continue
                
            # Check if direct route is longer than alternative paths
            try:
                # Remove direct edge temporarily
                if nx_graph.has_edge(edge.source_id, edge.target_id):
                    direct_distance = nx_graph[edge.source_id][edge.target_id]["weight"]
                    nx_graph.remove_edge(edge.source_id, edge.target_id)
                    
                    # Check if alternative path exists
                    alternative_path = nx.shortest_path(
                        nx_graph, edge.source_id, edge.target_id, weight="weight"
                    )
                    
                    # Calculate alternative distance
                    alternative_distance = sum(
                        nx_graph[alternative_path[i]][alternative_path[i+1]]["weight"]
                        for i in range(len(alternative_path) - 1)
                    )
                    
                    # If direct route is significantly longer, flag as inefficient
                    if direct_distance > alternative_distance * 1.2:  # 20% threshold
                        source_node = self.network_graph.get_node(edge.source_id)
                        target_node = self.network_graph.get_node(edge.target_id)
                        
                        inefficient_route = {
                            "source": edge.source_id,
                            "source_name": source_node.attributes.get("city", edge.source_id),
                            "destination": edge.target_id,
                            "destination_name": target_node.attributes.get("city", edge.target_id),
                            "direct_distance": direct_distance,
                            "alternative_path": [
                                {
                                    "id": node_id,
                                    "name": self.network_graph.get_node(node_id).attributes.get("city", node_id)
                                }
                                for node_id in alternative_path
                            ],
                            "alternative_distance": alternative_distance,
                            "savings_percent": (direct_distance - alternative_distance) / direct_distance * 100,
                            "volume": edge.attributes.get("volume", 1.0)
                        }
                        
                        results["inefficient_routes"].append(inefficient_route)
                    
                    # Restore direct edge
                    nx_graph.add_edge(
                        edge.source_id, 
                        edge.target_id, 
                        weight=direct_distance,
                        volume=edge.attributes.get("volume", 1.0)
                    )
                    
            except nx.NetworkXNoPath:
                # No alternative path exists, restore edge
                if not nx_graph.has_edge(edge.source_id, edge.target_id):
                    nx_graph.add_edge(
                        edge.source_id, 
                        edge.target_id, 
                        weight=direct_distance,
                        volume=edge.attributes.get("volume", 1.0)
                    )
        
        # Identify potential hub ports
        betweenness = nx.betweenness_centrality(nx_graph, weight="weight")
        
        # Get ports with high betweenness
        hub_candidates = sorted(betweenness.items(), key=lambda x: x[1], reverse=True)[:10]
        
        for port_id, score in hub_candidates:
            port_node = self.network_graph.get_node(port_id)
            if port_node:
                # Calculate current connections
                connections = nx_graph.degree(port_id)
                
                # Identify potential new connections
                potential_connections = []
                for source, target in shipping_routes:
                    # Skip if already connected
                    if source == port_id or target == port_id:
                        continue
                        
                    # Check if this port could serve as an intermediate hub
                    if nx_graph.has_node(source) and nx_graph.has_node(target):
                        try:
                            # Check shortest path
                            path = nx.shortest_path(nx_graph, source, target, weight="weight")
                            
                            # If hub is not in the path but could be a good intermediate
                            if port_id not in path:
                                # Calculate direct vs. hub-connected distance
                                direct_distance = nx_graph[source][target]["weight"] if nx_graph.has_edge(source, target) else float('inf')
                                
                                source_to_hub = nx.shortest_path_length(nx_graph, source, port_id, weight="weight") if nx_graph.has_path(source, port_id) else float('inf')
                                hub_to_target = nx.shortest_path_length(nx_graph, port_id, target, weight="weight") if nx_graph.has_path(port_id, target) else float('inf')
                                
                                hub_distance = source_to_hub + hub_to_target
                                
                                # If hub route is within 30% of direct route, it's a good candidate
                                if hub_distance < direct_distance * 1.3:
                                    potential_connections.append({
                                        "source": source,
                                        "source_name": self.network_graph.get_node(source).attributes.get("city", source),
                                        "destination": target,
                                        "destination_name": self.network_graph.get_node(target).attributes.get("city", target),
                                        "direct_distance": direct_distance,
                                        "hub_distance": hub_distance
                                    })
                        except nx.NetworkXNoPath:
                            continue
                
                # Add hub recommendation if it has potential
                if potential_connections:
                    results["hub_recommendations"].append({
                        "port_id": port_id,
                        "port_name": port_node.attributes.get("city", port_id),
                        "country": port_node.attributes.get("country", "Unknown"),
                        "centrality_score": score,
                        "current_connections": connections,
                        "potential_new_connections": len(potential_connections),
                        "example_connections": potential_connections[:5]  # Show top 5 examples
                    })
        
        # Sort hub recommendations by potential new connections
        results["hub_recommendations"].sort(key=lambda x: x["potential_new_connections"], reverse=True)
        
        # Look for consolidation opportunities
        # Find ports with small volumes that could be consolidated
        port_volumes = defaultdict(float)
        
        for edge in shipping_routes:
            port_volumes[edge.source_id] += edge.attributes.get("volume", 1.0)
            port_volumes[edge.target_id] += edge.attributes.get("volume", 1.0)
            
        # Identify ports with low volumes
        low_volume_ports = [port_id for port_id, volume in port_volumes.items() if volume < volume_threshold]
        
        # For each low volume port, find nearby ports that could serve as consolidation points
        for port_id in low_volume_ports:
            port_node = self.network_graph.get_node(port_id)
            if not port_node:
                continue
                
            # Skip if no coordinates
            if not all(attr in port_node.attributes for attr in ["latitude", "longitude"]):
                continue
                
            port_coords = (port_node.attributes["latitude"], port_node.attributes["longitude"])
            
            # Find nearby ports
            nearby_ports = []
            for other_id, other_volume in port_volumes.items():
                if other_id == port_id or other_volume < volume_threshold:
                    continue
                    
                other_node = self.network_graph.get_node(other_id)
                if not other_node or not all(attr in other_node.attributes for attr in ["latitude", "longitude"]):
                    continue
                    
                other_coords = (other_node.attributes["latitude"], other_node.attributes["longitude"])
                
                try:
                    distance = self._calculate_distance(port_coords, other_coords)
                    
                    # If within reasonable distance, add as potential consolidation
                    if distance < 500:  # 500 km threshold
                        nearby_ports.append({
                            "id": other_id,
                            "name": other_node.attributes.get("city", other_id),
                            "country": other_node.attributes.get("country", "Unknown"),
                            "distance_km": distance,
                            "volume": other_volume
                        })
                except:
                    continue
                    
            # Sort by distance
            nearby_ports.sort(key=lambda x: x["distance_km"])
            
            # Add consolidation opportunity if nearby ports found
            if nearby_ports:
                results["consolidation_opportunities"].append({
                    "low_volume_port": {
                        "id": port_id,
                        "name": port_node.attributes.get("city", port_id),
                        "country": port_node.attributes.get("country", "Unknown"),
                        "volume": port_volumes[port_id]
                    },
                    "nearby_ports": nearby_ports[:3]  # Top 3 closest ports
                })
        
        # Sort consolidation opportunities by volume (ascending)
        results["consolidation_opportunities"].sort(key=lambda x: x["low_volume_port"]["volume"])
        
        return results
    
    def _calculate_distance(self, coords1, coords2):
        """Calculate distance between two coordinate pairs in kilometers"""
        from math import radians, sin, cos, sqrt, atan2
        
        lat1, lon1 = radians(coords1[0]), radians(coords1[1])
        lat2, lon2 = radians(coords2[0]), radians(coords2[1])
        
        # Haversine formula
        dlon = lon2 - lon1
        dlat = lat2 - lat1
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
        c = 2 * atan2(sqrt(a), sqrt(1-a))
        distance = 6371 * c  # Earth radius in kilometers
        
        return distance
        
    def predict_shipping_patterns(self, forecast_days: int = 30) -> Dict:
        """
        Predict future shipping patterns based on historical data
        
        Args:
            forecast_days: Number of days to forecast
            
        Returns:
            Dictionary with shipping pattern predictions
        """
        # Get shipping route edges with timestamps
        shipping_edges = [edge for edge in self.network_graph.get_edges_by_type("shipping_route")
                         if edge.timestamp is not None]
        
        if not shipping_edges:
            return {"error": "No timestamped shipping data available for prediction"}
            
        # Sort by timestamp
        shipping_edges.sort(key=lambda e: e.timestamp)
        
        # Get date range
        start_date = shipping_edges[0].timestamp
        end_date = shipping_edges[-1].timestamp
        
        # Calculate date range in days
        date_range_days = (end_date - start_date).days + 1
        
        # If date range is too short, return error
        if date_range_days < 14:  # Require at least 2 weeks of data
            return {"error": "Insufficient historical data for prediction"}
            
        # Group edges by route (source-destination pair)
        route_history = defaultdict(list)
        for edge in shipping_edges:
            route_key = (edge.source_id, edge.target_id)
            route_history[route_key].append({
                "date": edge.timestamp,
                "volume": edge.attributes.get("volume", 1.0),
                "commodity": edge.attributes.get("commodity", "unknown")
            })
            
        # Calculate route frequencies
        route_frequencies = {}
        commodity_volumes = defaultdict(float)
        
        for route_key, shipments in route_history.items():
            # Calculate frequency statistics
            if len(shipments) >= 3:  # Need at least 3 data points
                # Calculate average interval between shipments
                shipment_dates = [s["date"] for s in shipments]
                intervals = [(shipment_dates[i+1] - shipment_dates[i]).days 
                           for i in range(len(shipment_dates) - 1)]
                
                # Calculate average and standard deviation
                avg_interval = sum(intervals) / len(intervals)
                std_interval = (sum((x - avg_interval)**2 for x in intervals) / len(intervals))**0.5
                
                # Calculate trend (increasing or decreasing frequency)
                if len(intervals) >= 2:
                    # Split into first half and second half
                    half = len(intervals) // 2
                    first_half_avg = sum(intervals[:half]) / half
                    second_half_avg = sum(intervals[half:]) / (len(intervals) - half)
                    trend = "decreasing" if second_half_avg < first_half_avg else "increasing"
                else:
                    trend = "stable"
                    
                route_frequencies[route_key] = {
                    "count": len(shipments),
                    "avg_interval_days": avg_interval,
                    "interval_variability": std_interval,
                    "first_shipment": shipment_dates[0].isoformat(),
                    "last_shipment": shipment_dates[-1].isoformat(),
                    "trend": trend
                }
                
            # Calculate commodity volumes
            for shipment in shipments:
                commodity = shipment["commodity"]
                volume = shipment["volume"]
                commodity_volumes[commodity] += volume
                
        # Make predictions for routes
        predictions = []
        for route_key, freq_data in route_frequencies.items():
            source_id, target_id = route_key
            source_node = self.network_graph.get_node(source_id)
            target_node = self.network_graph.get_node(target_id)
            
            if not source_node or not target_node:
                continue
                
            # Predict next shipment date
            last_date = datetime.fromisoformat(freq_data["last_shipment"])
            next_date = last_date + timedelta(days=freq_data["avg_interval_days"])
            
            # Adjust based on trend
            if freq_data["trend"] == "decreasing":
                next_date += timedelta(days=freq_data["avg_interval_days"] * 0.1)
            elif freq_data["trend"] == "increasing":
                next_date -= timedelta(days=freq_data["avg_interval_days"] * 0.1)
                
            # Only include if prediction is within forecast period
            if (next_date - datetime.now()).days <= forecast_days:
                shipments = route_history[route_key]
                
                # Calculate average volume
                avg_volume = sum(s["volume"] for s in shipments) / len(shipments)
                
                # Get most common commodity
                commodity_counts = Counter(s["commodity"] for s in shipments)
                common_commodity = commodity_counts.most_common(1)[0][0]
                
                prediction = {
                    "source": {
                        "id": source_id,
                        "name": source_node.attributes.get("city", source_id)
                    },
                    "destination": {
                        "id": target_id,
                        "name": target_node.attributes.get("city", target_id)
                    },
                    "predicted_date": next_date.isoformat(),
                    "expected_volume": avg_volume,
                    "likely_commodity": common_commodity,
                    "confidence": 1.0 / (1.0 + freq_data["interval_variability"] / freq_data["avg_interval_days"]),
                    "historical_frequency": freq_data
                }
                
                predictions.append(prediction)
                
        # Sort predictions by date
        predictions.sort(key=lambda x: x["predicted_date"])
        
        # Get port predictions
        port_volumes = defaultdict(float)
        for route_key, shipments in route_history.items():
            source_id, target_id = route_key
            
            # Calculate recent volumes (last 30 days)
            recent_cutoff = datetime.now() - timedelta(days=30)
            recent_shipments = [s for s in shipments if s["date"] >= recent_cutoff]
            
            if recent_shipments:
                recent_volume = sum(s["volume"] for s in recent_shipments)
                port_volumes[source_id] += recent_volume / 2  # Split between source and destination
                port_volumes[target_id] += recent_volume / 2
                
        # Identify ports with changing volumes
        port_predictions = []
        for port_id, volume in port_volumes.items():
            port_node = self.network_graph.get_node(port_id)
            if not port_node:
                continue
                
            # Get historical shipments for this port
            port_shipments = []
            for route_key, shipments in route_history.items():
                source_id, target_id = route_key
                if port_id in (source_id, target_id):
                    for shipment in shipments:
                        # Add direction info
                        shipment_copy = shipment.copy()
                        shipment_copy["direction"] = "outbound" if port_id == source_id else "inbound"
                        port_shipments.append(shipment_copy)
                        
            # Sort by date
            port_shipments.sort(key=lambda s: s["date"])
            
            # Split into time periods
            if len(port_shipments) >= 10:
                period_length = min(30, date_range_days // 2)  # Use 30 days or half the data range
                
                # Group by period
                periods = []
                current_period = []
                period_start = port_shipments[0]["date"]
                
                for shipment in port_shipments:
                    if (shipment["date"] - period_start).days <= period_length:
                        current_period.append(shipment)
                    else:
                        periods.append(current_period)
                        current_period = [shipment]
                        period_start = shipment["date"]
                        
                if current_period:
                    periods.append(current_period)
                    
                # Calculate volume trends
                if len(periods) >= 2:
                    recent_period = periods[-1]
                    previous_period = periods[-2]
                    
                    recent_volume = sum(s["volume"] for s in recent_period)
                    previous_volume = sum(s["volume"] for s in previous_period)
                    
                    volume_change = (recent_volume - previous_volume) / max(previous_volume, 1.0) * 100
                    
                    # Predict future volume
                    predicted_volume = recent_volume * (1 + volume_change / 100)
                    
                    port_predictions.append({
                        "port": {
                            "id": port_id,
                            "name": port_node.attributes.get("city", port_id)
                        },
                        "current_volume": recent_volume,
                        "volume_change_percent": volume_change,
                        "predicted_volume": predicted_volume,
                        "trend": "increasing" if volume_change > 5 else "decreasing" if volume_change < -5 else "stable"
                    })
                    
        # Sort port predictions by absolute volume change
        port_predictions.sort(key=lambda x: abs(x["volume_change_percent"]), reverse=True)
        
        return {
            "route_predictions": predictions,
            "port_predictions": port_predictions[:10],  # Top 10 ports with significant changes
            "commodity_volumes": dict(commodity_volumes),
            "forecast_period_days": forecast_days
        }
        
    def generate_shipping_report(self) -> Dict:
        """
        Generate a comprehensive report on the shipping network
        
        Returns:
            Dictionary with report data
        """
        report = {
            "timestamp": datetime.now().isoformat(),
            "network_summary": {
                "total_ports": len(self.network_graph.get_nodes_by_type("port")),
                "total_carriers": len(self.network_graph.get_nodes_by_type("carrier")),
                "total_routes": len(self.network_graph.get_edges_by_type("shipping_route"))
            },
            "route_analysis": {},
            "optimization_recommendations": {},
            "forecasts": {}
        }
        
        # Add route analysis
        route_analysis = self.analyze_shipping_routes()
        report["route_analysis"] = {
            "top_routes": route_analysis.get("routes", [])[:10],
            "key_ports": route_analysis.get("key_ports", [])[:5],
            "top_carriers": route_analysis.get("carriers", [])[:5],
            "statistics": route_analysis.get("statistics", {})
        }
        
        # Add optimization recommendations
        optimization = self.optimize_shipping_network()
        report["optimization_recommendations"] = {
            "inefficient_routes": optimization.get("inefficient_routes", [])[:5],
            "hub_recommendations": optimization.get("hub_recommendations", [])[:3],
            "consolidation_opportunities": optimization.get("consolidation_opportunities", [])[:3]
        }
        
        # Add forecasts
        forecasts = self.predict_shipping_patterns()
        if "error" not in forecasts:
            report["forecasts"] = {
                "upcoming_shipments": forecasts.get("route_predictions", [])[:10],
                "port_trends": forecasts.get("port_predictions", [])[:5],
                "commodity_trends": dict(sorted(
                    forecasts.get("commodity_volumes", {}).items(), 
                    key=lambda x: x[1], 
                    reverse=True
                )[:5])
            }
        
        return report


class SecurityThreatAnalyzer:
    """
    Specialized module for analyzing security threats and vulnerabilities
    in critical infrastructure and networks.
    """
    def __init__(self):
        self.network_graph = NetworkGraph("Security Threat Network")
        self.route_analyzer = RouteAnalyzer()
        
    # Implementation would follow similar patterns to the other analyzers
    # but with security-specific node and edge types, data loading,
    # and analysis methods focused on threat vectors, vulnerabilities,
    # attack surfaces, and risk assessment.