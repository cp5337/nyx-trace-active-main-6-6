"""
Excel OSINT Data Source
---------------------
Implementation of DataSource interface for Excel-based OSINT data.

This module allows loading incident/event data from Excel spreadsheets
with a specific structure matching OSINT investigation reports.
"""
import pandas as pd
import numpy as np
from datetime import datetime
from typing import Dict, List, Any, Optional
import os
import re

from .base_source import DataSource


class ExcelOSINTDataSource(DataSource):
    """Excel OSINT data source implementation"""
    
    def __init__(self):
        self.excel_file_path = None
        self.data = None
        self.is_configured = False
        self.cache = {}  # Cache for efficient data access
        self.chunk_size = 10000  # Size for chunked loading of large datasets
        
        # Define mappings for standardizing field names
        self.field_mappings = {
            'date': ['event date', 'date', 'incident date', 'occurrence date'],
            'content': ['description', 'details', 'narrative', 'event description'],
            'location': ['city', 'location', 'place', 'venue'],
            'source': ['source', 'reference', 'url', 'link'],
            'activity_level': ['injured', 'dead', 'arrested', 'casualties'] 
        }
        
    @property
    def source_name(self) -> str:
        return "ExcelOSINT"
    
    @property
    def source_type(self) -> str:
        return "osint_excel"
    
    def _load_data(self):
        """Load data from the Excel file with efficient handling for large datasets"""
        if not self.excel_file_path or not os.path.exists(self.excel_file_path):
            raise ValueError(f"Excel file not found: {self.excel_file_path}")
        
        try:
            # Check file size to determine if we need chunked processing
            file_size = os.path.getsize(self.excel_file_path) / (1024 * 1024)  # Size in MB
            print(f"Excel file size: {file_size:.2f} MB")
            
            if file_size > 50:  # If file is larger than 50MB, use chunked processing
                print(f"Large file detected ({file_size:.2f} MB). Using chunked processing.")
                
                # Get the total number of rows first
                excel_info = pd.read_excel(self.excel_file_path, nrows=0)
                
                # Process the file in chunks
                chunks = []
                for chunk in pd.read_excel(
                    self.excel_file_path, 
                    chunksize=self.chunk_size
                ):
                    # Process this chunk
                    chunk.columns = [col.lower() for col in chunk.columns]
                    chunks.append(chunk)
                    print(f"Processed chunk with {len(chunk)} rows")
                
                # Combine all chunks
                self.data = pd.concat(chunks, ignore_index=True)
                print(f"Completed processing {len(chunks)} chunks with {len(self.data)} total rows")
            else:
                # For smaller files, load normally
                self.data = pd.read_excel(self.excel_file_path)
                # Standardize column names (lowercase)
                self.data.columns = [col.lower() for col in self.data.columns]
            
            # Convert date column if it exists
            date_cols = [col for col in self.data.columns 
                        if any(date_term in col.lower() for date_term in self.field_mappings['date'])]
            
            if date_cols:
                date_col = date_cols[0]
                try:
                    # Try to convert the date column to datetime
                    self.data[date_col] = pd.to_datetime(self.data[date_col], errors='coerce')
                except Exception as e:
                    print(f"Error converting date column: {str(e)}")
                    # If conversion fails, try to extract date with regex
                    date_pattern = r'\w+,\s+(\w+\s+\d{1,2},\s+\d{4})'
                    self.data['extracted_date'] = self.data[date_col].str.extract(date_pattern)
                    self.data['extracted_date'] = pd.to_datetime(
                        self.data['extracted_date'], 
                        errors='coerce', 
                        format='%B %d, %Y'
                    )
                    if not self.data['extracted_date'].isna().all():
                        date_col = 'extracted_date'
            
            # Convert boolean columns
            bool_columns = ['social media', 'automated phone', 'verbal', 'phone', 
                           'email', 'written', 'unspecified']
            for col in bool_columns:
                if col in self.data.columns:
                    self.data[col] = self.data[col].astype(bool)
            
            # Create a standardized activity level column
            self.data['activity_level'] = 0
            # Sum arrested, dead, injured if they exist
            for col in ['arrested', 'dead', 'injured']:
                if col in self.data.columns:
                    self.data['activity_level'] += self.data[col].fillna(0)
            
            # Create a simple sentiment score based on incidents
            self.data['sentiment'] = 0
            # Negative sentiment for incidents with casualties
            if 'dead' in self.data.columns:
                self.data.loc[self.data['dead'] > 0, 'sentiment'] = -0.8
            if 'injured' in self.data.columns:
                self.data.loc[(self.data['sentiment'] == 0) & (self.data['injured'] > 0), 'sentiment'] = -0.5
            if 'arrested' in self.data.columns:
                self.data.loc[(self.data['sentiment'] == 0) & (self.data['arrested'] > 0), 'sentiment'] = -0.3
                
            # Set the standard date column for filtering
            if date_cols:
                self.data['Date'] = self.data[date_col]
            else:
                # If no date column, use today's date
                self.data['Date'] = datetime.now()
                
            print(f"Loaded {len(self.data)} records from Excel file")
            return True
            
        except Exception as e:
            print(f"Error loading Excel file: {str(e)}")
            return False
    
    def get_data(self, location: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """Get OSINT data for location in date range with caching for better performance"""
        if not self.is_configured or self.data is None:
            raise ValueError("Excel OSINT data source not configured or data not loaded. Call configure() first.")
            
        # Create a cache key from the parameters
        cache_key = f"data_{location}_{start_date}_{end_date}"
        
        # Check if we have this result cached
        if cache_key in self.cache:
            print(f"Cache hit for {cache_key}")
            return self.cache[cache_key]
            
        # If not in cache, proceed with filtering
        
        # Filter by location if provided
        filtered_data = self.data
        if location and location != "All":
            location_lower = location.lower()
            # Look for the location in city, state, address, or description
            location_mask = False
            for col in ['city', 'state', 'country', 'address', 'description']:
                if col in filtered_data.columns:
                    # Convert column to string and check if location is in it
                    col_mask = filtered_data[col].astype(str).str.lower().str.contains(location_lower, na=False)
                    location_mask = location_mask | col_mask
            
            filtered_data = filtered_data[location_mask]
        
        # Filter by date if date column exists and dates are provided
        if 'Date' in filtered_data.columns:
            # Ensure both sides of the comparison are datetime64[ns]
            if start_date:
                start_date_pd = pd.to_datetime(start_date)
                filtered_data = filtered_data[pd.to_datetime(filtered_data['Date']) >= start_date_pd]
            if end_date:
                end_date_pd = pd.to_datetime(end_date)
                filtered_data = filtered_data[pd.to_datetime(filtered_data['Date']) <= end_date_pd]
        
        # Ensure we have all required columns for the DataSource interface
        result_df = pd.DataFrame()
        result_df['Source'] = self.source_name
        
        # Map dates if available
        if 'Date' in filtered_data.columns:
            result_df['Date'] = filtered_data['Date']
        else:
            result_df['Date'] = datetime.now()
        
        # Map content (description)
        content_cols = [col for col in filtered_data.columns 
                      if any(content_term in col.lower() for content_term in self.field_mappings['content'])]
        if content_cols:
            result_df['Content'] = filtered_data[content_cols[0]]
        else:
            result_df['Content'] = ""
        
        # Map sentiment
        if 'sentiment' in filtered_data.columns:
            result_df['Sentiment'] = filtered_data['sentiment']
        else:
            result_df['Sentiment'] = 0
        
        # Map activity level
        if 'activity_level' in filtered_data.columns:
            result_df['Activity_Level'] = filtered_data['activity_level']
        else:
            result_df['Activity_Level'] = 1  # Default activity level
        
        # Add location column
        location_cols = [col for col in filtered_data.columns 
                       if any(loc_term in col.lower() for loc_term in self.field_mappings['location'])]
        if location_cols:
            result_df['Location'] = filtered_data[location_cols[0]]
        elif 'city' in filtered_data.columns and 'state' in filtered_data.columns:
            # Combine city and state if both exist
            result_df['Location'] = filtered_data['city'].astype(str) + ', ' + filtered_data['state'].astype(str)
        else:
            result_df['Location'] = "Unknown"
        
        # Add all original columns as well with prefix "osint_"
        for col in filtered_data.columns:
            result_df[f'osint_{col}'] = filtered_data[col]
        
        # Store in cache for future requests with same parameters
        self.cache[cache_key] = result_df
        print(f"Cached result for {cache_key}: {len(result_df)} records")
        
        return result_df
    
    def get_keywords_for_location(self, location: str) -> List[str]:
        """Get search keywords for the given location"""
        # Basic implementation - return location and variations
        keywords = [location]
        
        # If location has spaces, add versions without spaces
        if ' ' in location:
            keywords.append(location.replace(' ', ''))
        
        # If the location is in our data, check for incident types at that location
        if self.is_configured and self.data is not None:
            location_lower = location.lower()
            location_data = self.data[
                self.data['city'].astype(str).str.lower().str.contains(location_lower, na=False) |
                self.data['state'].astype(str).str.lower().str.contains(location_lower, na=False) |
                self.data['country'].astype(str).str.lower().str.contains(location_lower, na=False)
            ]
            
            # Add incident types if available
            if 'incident type' in location_data.columns:
                incident_types = location_data['incident type'].dropna().unique()
                keywords.extend(incident_types)
            
            # Add parent infrastructure if available
            if 'parent infrastructure' in location_data.columns:
                infrastructure = location_data['parent infrastructure'].dropna().unique()
                keywords.extend(infrastructure)
        
        return list(set(keywords))  # Deduplicate
    
    def configure(self, config: Dict[str, Any]) -> None:
        """Configure the Excel OSINT data source"""
        if 'excel_file_path' not in config:
            raise ValueError("Missing required configuration parameter: excel_file_path")
        
        self.excel_file_path = config['excel_file_path']
        
        # Load data from Excel file
        if self._load_data():
            self.is_configured = True
        else:
            raise ValueError(f"Failed to load data from Excel file: {self.excel_file_path}")
    
    def test_connection(self) -> bool:
        """Test if the Excel file is accessible and valid"""
        if not self.excel_file_path:
            return False
            
        try:
            # Simple test - try to read the Excel file
            pd.read_excel(self.excel_file_path, nrows=1)
            return True
        except Exception:
            return False
    
    def get_unique_locations(self) -> List[str]:
        """Get a list of unique locations in the dataset"""
        if not self.is_configured or self.data is None:
            return []
        
        locations = []
        
        # Try to get cities
        if 'city' in self.data.columns:
            cities = self.data['city'].dropna().unique()
            locations.extend(cities)
        
        # Try to get states
        if 'state' in self.data.columns:
            states = self.data['state'].dropna().unique()
            locations.extend(states)
        
        # Try to get countries
        if 'country' in self.data.columns:
            countries = self.data['country'].dropna().unique()
            locations.extend(countries)
        
        return sorted(list(set([loc for loc in locations if isinstance(loc, str)])))
    
    def get_incident_types(self) -> List[str]:
        """Get a list of unique incident types in the dataset"""
        if not self.is_configured or self.data is None:
            return []
        
        if 'incident type' in self.data.columns:
            incident_types = self.data['incident type'].dropna().unique()
            return sorted(list(set([inc for inc in incident_types if isinstance(inc, str)])))
        
        return []
    
    def clear_cache(self):
        """Clear the cache to free up memory"""
        cache_size = len(self.cache)
        self.cache = {}
        print(f"Cleared cache with {cache_size} entries")
        
    def get_summary_statistics(self) -> Dict[str, Any]:
        """Get summary statistics for the dataset"""
        if not self.is_configured or self.data is None:
            return {}
        
        stats = {
            'total_records': len(self.data),
            'locations_count': len(self.get_unique_locations()),
            'incident_types_count': len(self.get_incident_types())
        }
        
        # Count totals for key metrics
        for col in ['arrested', 'dead', 'injured']:
            if col in self.data.columns:
                stats[f'total_{col}'] = int(self.data[col].sum())
        
        # Count incidents by type
        if 'incident type' in self.data.columns:
            incident_counts = self.data['incident type'].value_counts().to_dict()
            stats['incidents_by_type'] = incident_counts
        
        # Count by communication method
        comm_methods = ['social media', 'automated phone', 'verbal', 'phone', 'email', 'written']
        comm_counts = {}
        for method in comm_methods:
            if method in self.data.columns:
                comm_counts[method] = int(self.data[method].sum())
        
        if comm_counts:
            stats['communication_methods'] = comm_counts
        
        return stats