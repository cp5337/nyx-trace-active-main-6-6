"""
Base Data Source Interface
-------------------------
This module defines the abstract base class that all data source plugins
must implement.
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any
from datetime import datetime
import pandas as pd


class DataSource(ABC):
    """Abstract base class for all data source plugins"""
    
    @property
    @abstractmethod
    def source_name(self) -> str:
        """Return the name of this data source"""
        pass
    
    @property
    @abstractmethod
    def source_type(self) -> str:
        """Return the type of this data source (social, news, etc.)"""
        pass
    
    @abstractmethod
    def get_data(self, location: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """
        Retrieve data for a specific location and date range
        
        Args:
            location: Name of the location to get data for
            start_date: Start of date range
            end_date: End of date range
            
        Returns:
            DataFrame with standardized columns:
                - Source: name of the data source
                - Date: date of the data point
                - Content: text content (if applicable)
                - Sentiment: calculated sentiment (-1 to 1)
                - Activity_Level: numeric measure of activity
                - Additional source-specific columns as needed
        """
        pass
    
    @abstractmethod
    def get_keywords_for_location(self, location: str) -> List[str]:
        """
        Get the keywords associated with a location for this data source
        
        Args:
            location: Name of the location
            
        Returns:
            List of associated keywords
        """
        pass
    
    @abstractmethod
    def configure(self, config: Dict[str, Any]) -> None:
        """
        Configure the data source with its required parameters
        
        Args:
            config: Dictionary of configuration parameters
        """
        pass
    
    @abstractmethod
    def test_connection(self) -> bool:
        """
        Test if this data source is properly configured and can connect
        
        Returns:
            True if connection successful, False otherwise
        """
        pass