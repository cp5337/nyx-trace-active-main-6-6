"""
Hybrid Threat Reporter
--------------------
This module provides functionality for tracking and reporting hybrid threats
across cyber, physical, and cartel domains.
"""

import os
import json
import logging
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Union
import uuid
from enum import Enum
import hashlib

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('incident_reporter')


class IncidentType(Enum):
    """Enumeration of incident types"""
    CYBER = "cyber"
    PHYSICAL = "physical"
    HYBRID = "hybrid"
    CARTEL = "cartel"


class IncidentSeverity(Enum):
    """Enumeration of incident severity levels"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class IncidentStatus(Enum):
    """Enumeration of incident statuses"""
    OPEN = "open"
    INVESTIGATING = "investigating"
    MITIGATING = "mitigating"
    RESOLVED = "resolved"
    CLOSED = "closed"


class Incident:
    """Class representing a security incident"""
    
    def __init__(self, 
                 title: str,
                 incident_type: IncidentType,
                 severity: IncidentSeverity,
                 status: IncidentStatus = IncidentStatus.OPEN,
                 date: Optional[datetime] = None,
                 location: Optional[str] = None,
                 description: Optional[str] = None,
                 affected_assets: Optional[List[str]] = None,
                 threat_actors: Optional[List[str]] = None,
                 tags: Optional[List[str]] = None):
        """
        Initialize an incident
        
        Args:
            title: Incident title
            incident_type: Type of incident
            severity: Severity level
            status: Current status
            date: Incident date
            location: Location of the incident
            description: Detailed description
            affected_assets: List of affected assets
            threat_actors: List of threat actors involved
            tags: Tags for categorization
        """
        self.id = f"INC-{uuid.uuid4().hex[:8].upper()}"
        self.title = title
        self.incident_type = incident_type
        self.severity = severity
        self.status = status
        self.date = date or datetime.now()
        self.location = location
        self.description = description
        self.affected_assets = affected_assets or []
        self.threat_actors = threat_actors or []
        self.tags = tags or []
        self.created_at = datetime.now()
        self.updated_at = self.created_at
        self.updates = []
    
    def update_status(self, new_status: IncidentStatus, comment: Optional[str] = None) -> None:
        """
        Update the status of the incident
        
        Args:
            new_status: New status
            comment: Optional comment about the update
        """
        old_status = self.status
        self.status = new_status
        self.updated_at = datetime.now()
        
        update = {
            'timestamp': self.updated_at,
            'field': 'status',
            'old_value': old_status.value,
            'new_value': new_status.value,
            'comment': comment
        }
        
        self.updates.append(update)
        
        logger.info(f"Updated incident {self.id} status from {old_status.value} to {new_status.value}")
    
    def update_severity(self, new_severity: IncidentSeverity, comment: Optional[str] = None) -> None:
        """
        Update the severity of the incident
        
        Args:
            new_severity: New severity
            comment: Optional comment about the update
        """
        old_severity = self.severity
        self.severity = new_severity
        self.updated_at = datetime.now()
        
        update = {
            'timestamp': self.updated_at,
            'field': 'severity',
            'old_value': old_severity.value,
            'new_value': new_severity.value,
            'comment': comment
        }
        
        self.updates.append(update)
        
        logger.info(f"Updated incident {self.id} severity from {old_severity.value} to {new_severity.value}")
    
    def add_comment(self, comment: str, author: Optional[str] = None) -> None:
        """
        Add a comment to the incident
        
        Args:
            comment: Comment text
            author: Optional author name
        """
        update = {
            'timestamp': datetime.now(),
            'field': 'comment',
            'old_value': None,
            'new_value': None,
            'comment': comment,
            'author': author
        }
        
        self.updates.append(update)
        self.updated_at = update['timestamp']
        
        logger.info(f"Added comment to incident {self.id}")
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert incident to dictionary
        
        Returns:
            Dictionary representation of the incident
        """
        return {
            'id': self.id,
            'title': self.title,
            'incident_type': self.incident_type.value,
            'severity': self.severity.value,
            'status': self.status.value,
            'date': self.date.isoformat(),
            'location': self.location,
            'description': self.description,
            'affected_assets': self.affected_assets,
            'threat_actors': self.threat_actors,
            'tags': self.tags,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'updates': [{
                'timestamp': u['timestamp'].isoformat(),
                'field': u['field'],
                'old_value': u['old_value'],
                'new_value': u['new_value'],
                'comment': u['comment'],
                'author': u.get('author')
            } for u in self.updates]
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Incident':
        """
        Create incident from dictionary
        
        Args:
            data: Dictionary representation of incident
            
        Returns:
            Incident instance
        """
        incident = cls(
            title=data['title'],
            incident_type=IncidentType(data['incident_type']),
            severity=IncidentSeverity(data['severity']),
            status=IncidentStatus(data['status']),
            date=datetime.fromisoformat(data['date']),
            location=data.get('location'),
            description=data.get('description'),
            affected_assets=data.get('affected_assets', []),
            threat_actors=data.get('threat_actors', []),
            tags=data.get('tags', [])
        )
        
        # Set ID and timestamps
        incident.id = data['id']
        incident.created_at = datetime.fromisoformat(data['created_at'])
        incident.updated_at = datetime.fromisoformat(data['updated_at'])
        
        # Set updates
        incident.updates = [{
            'timestamp': datetime.fromisoformat(u['timestamp']),
            'field': u['field'],
            'old_value': u['old_value'],
            'new_value': u['new_value'],
            'comment': u['comment'],
            'author': u.get('author')
        } for u in data.get('updates', [])]
        
        return incident


class HybridThreatReporter:
    """
    Main class for tracking and reporting hybrid threats
    
    This class provides methods for:
    - Creating and managing incidents
    - Generating reports on incidents
    - Analyzing incident trends
    """
    
    def __init__(self, storage_path: Optional[str] = None):
        """
        Initialize the Hybrid Threat Reporter
        
        Args:
            storage_path: Optional path to store incident data
        """
        self.incidents: Dict[str, Incident] = {}
        self.storage_path = storage_path or os.path.join(os.getcwd(), 'data', 'incidents')
        
        # Create storage directory if it doesn't exist
        os.makedirs(self.storage_path, exist_ok=True)
        
        # Load existing incidents
        self._load_incidents()
        
        logger.info("Hybrid Threat Reporter initialized")
    
    def create_incident(self, 
                        title: str,
                        incident_type: Union[IncidentType, str],
                        severity: Union[IncidentSeverity, str],
                        status: Union[IncidentStatus, str] = IncidentStatus.OPEN,
                        date: Optional[datetime] = None,
                        location: Optional[str] = None,
                        description: Optional[str] = None,
                        affected_assets: Optional[List[str]] = None,
                        threat_actors: Optional[List[str]] = None,
                        tags: Optional[List[str]] = None) -> Incident:
        """
        Create a new incident
        
        Args:
            title: Incident title
            incident_type: Type of incident
            severity: Severity level
            status: Current status
            date: Incident date
            location: Location of the incident
            description: Detailed description
            affected_assets: List of affected assets
            threat_actors: List of threat actors involved
            tags: Tags for categorization
            
        Returns:
            Created Incident instance
        """
        # Convert string enums to enum types if necessary
        if isinstance(incident_type, str):
            incident_type = IncidentType(incident_type)
        
        if isinstance(severity, str):
            severity = IncidentSeverity(severity)
        
        if isinstance(status, str):
            status = IncidentStatus(status)
        
        # Create incident
        incident = Incident(
            title=title,
            incident_type=incident_type,
            severity=severity,
            status=status,
            date=date,
            location=location,
            description=description,
            affected_assets=affected_assets,
            threat_actors=threat_actors,
            tags=tags
        )
        
        # Add to incidents
        self.incidents[incident.id] = incident
        
        # Save incident
        self._save_incident(incident)
        
        logger.info(f"Created incident {incident.id}: {title}")
        
        return incident
    
    def get_incident(self, incident_id: str) -> Optional[Incident]:
        """
        Get an incident by ID
        
        Args:
            incident_id: ID of the incident
            
        Returns:
            Incident instance if found, None otherwise
        """
        return self.incidents.get(incident_id)
    
    def get_incidents(self, 
                      incident_type: Optional[IncidentType] = None,
                      severity: Optional[IncidentSeverity] = None,
                      status: Optional[IncidentStatus] = None,
                      start_date: Optional[datetime] = None,
                      end_date: Optional[datetime] = None,
                      location: Optional[str] = None,
                      tags: Optional[List[str]] = None) -> List[Incident]:
        """
        Get incidents matching the specified filters
        
        Args:
            incident_type: Filter by incident type
            severity: Filter by severity
            status: Filter by status
            start_date: Filter by incidents on or after this date
            end_date: Filter by incidents on or before this date
            location: Filter by location
            tags: Filter by tags (any match)
            
        Returns:
            List of matching incidents
        """
        filtered_incidents = []
        
        for incident in self.incidents.values():
            # Apply filters
            if incident_type and incident.incident_type != incident_type:
                continue
            
            if severity and incident.severity != severity:
                continue
            
            if status and incident.status != status:
                continue
            
            if start_date and incident.date < start_date:
                continue
            
            if end_date and incident.date > end_date:
                continue
            
            if location and (incident.location is None or location.lower() not in incident.location.lower()):
                continue
            
            if tags and not any(tag in incident.tags for tag in tags):
                continue
            
            filtered_incidents.append(incident)
        
        return filtered_incidents
    
    def get_incidents_as_dataframe(self, **filters) -> pd.DataFrame:
        """
        Get incidents as a pandas DataFrame
        
        Args:
            **filters: Filters to pass to get_incidents
            
        Returns:
            DataFrame of incidents
        """
        incidents = self.get_incidents(**filters)
        
        # Convert to list of dictionaries
        incident_dicts = []
        for incident in incidents:
            incident_dict = {
                'id': incident.id,
                'title': incident.title,
                'type': incident.incident_type.value,
                'severity': incident.severity.value,
                'status': incident.status.value,
                'date': incident.date,
                'location': incident.location,
                'created_at': incident.created_at,
                'updated_at': incident.updated_at
            }
            incident_dicts.append(incident_dict)
        
        # Convert to DataFrame
        return pd.DataFrame(incident_dicts)
    
    def update_incident(self, incident_id: str, **updates) -> Optional[Incident]:
        """
        Update an incident
        
        Args:
            incident_id: ID of the incident to update
            **updates: Fields to update
            
        Returns:
            Updated incident if found, None otherwise
        """
        incident = self.get_incident(incident_id)
        if not incident:
            logger.warning(f"Incident {incident_id} not found")
            return None
        
        # Apply updates
        for field, value in updates.items():
            if field == 'status':
                if isinstance(value, str):
                    value = IncidentStatus(value)
                incident.update_status(value)
            
            elif field == 'severity':
                if isinstance(value, str):
                    value = IncidentSeverity(value)
                incident.update_severity(value)
            
            elif field == 'comment':
                incident.add_comment(value)
            
            elif hasattr(incident, field):
                old_value = getattr(incident, field)
                setattr(incident, field, value)
                
                # Record update
                incident.updates.append({
                    'timestamp': datetime.now(),
                    'field': field,
                    'old_value': old_value,
                    'new_value': value,
                    'comment': None
                })
                
                incident.updated_at = datetime.now()
        
        # Save incident
        self._save_incident(incident)
        
        logger.info(f"Updated incident {incident_id}")
        
        return incident
    
    def delete_incident(self, incident_id: str) -> bool:
        """
        Delete an incident
        
        Args:
            incident_id: ID of the incident to delete
            
        Returns:
            True if deleted, False if not found
        """
        if incident_id not in self.incidents:
            logger.warning(f"Incident {incident_id} not found")
            return False
        
        # Remove from incidents
        del self.incidents[incident_id]
        
        # Remove file
        incident_file = os.path.join(self.storage_path, f"{incident_id}.json")
        if os.path.exists(incident_file):
            os.remove(incident_file)
        
        logger.info(f"Deleted incident {incident_id}")
        
        return True
    
    def get_incident_counts(self, 
                           group_by: str = 'type', 
                           start_date: Optional[datetime] = None,
                           end_date: Optional[datetime] = None) -> Dict[str, int]:
        """
        Get incident counts grouped by a field
        
        Args:
            group_by: Field to group by (type, severity, status, location)
            start_date: Filter by incidents on or after this date
            end_date: Filter by incidents on or before this date
            
        Returns:
            Dictionary mapping field values to counts
        """
        # Get incidents in date range
        incidents = self.get_incidents(start_date=start_date, end_date=end_date)
        
        # Group by field
        counts = {}
        for incident in incidents:
            if group_by == 'type':
                key = incident.incident_type.value
            elif group_by == 'severity':
                key = incident.severity.value
            elif group_by == 'status':
                key = incident.status.value
            elif group_by == 'location':
                key = incident.location or 'Unknown'
            else:
                key = 'Unknown'
            
            counts[key] = counts.get(key, 0) + 1
        
        return counts
    
    def get_incident_trend(self, 
                          period: str = 'day',
                          start_date: Optional[datetime] = None,
                          end_date: Optional[datetime] = None,
                          incident_type: Optional[IncidentType] = None) -> Dict[str, Dict[str, int]]:
        """
        Get incident trend over time
        
        Args:
            period: Time period to group by (day, week, month)
            start_date: Filter by incidents on or after this date
            end_date: Filter by incidents on or before this date
            incident_type: Filter by incident type
            
        Returns:
            Dictionary mapping dates to counts by type
        """
        # Set default date range
        if not end_date:
            end_date = datetime.now()
        
        if not start_date:
            if period == 'day':
                start_date = end_date - timedelta(days=30)
            elif period == 'week':
                start_date = end_date - timedelta(weeks=12)
            else:  # month
                start_date = end_date - timedelta(days=365)
        
        # Get incidents in date range
        incidents = self.get_incidents(
            start_date=start_date, 
            end_date=end_date,
            incident_type=incident_type
        )
        
        # Group by period and type
        trends = {}
        for incident in incidents:
            # Format date based on period
            if period == 'day':
                date_key = incident.date.strftime('%Y-%m-%d')
            elif period == 'week':
                # Use ISO week date format
                date_key = incident.date.strftime('%Y-W%W')
            else:  # month
                date_key = incident.date.strftime('%Y-%m')
            
            # Initialize date entry if not exists
            if date_key not in trends:
                trends[date_key] = {
                    'cyber': 0,
                    'physical': 0,
                    'hybrid': 0,
                    'cartel': 0,
                    'total': 0
                }
            
            # Increment counts
            incident_type_key = incident.incident_type.value
            trends[date_key][incident_type_key] += 1
            trends[date_key]['total'] += 1
        
        return trends
    
    def generate_report(self, 
                       report_type: str = 'summary',
                       start_date: Optional[datetime] = None,
                       end_date: Optional[datetime] = None,
                       incident_types: Optional[List[IncidentType]] = None,
                       location: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate a report on incidents
        
        Args:
            report_type: Type of report (summary, detailed, executive)
            start_date: Filter by incidents on or after this date
            end_date: Filter by incidents on or before this date
            incident_types: Filter by incident types
            location: Filter by location
            
        Returns:
            Dictionary with report data
        """
        # Set default date range
        if not end_date:
            end_date = datetime.now()
        
        if not start_date:
            start_date = end_date - timedelta(days=30)
        
        # Get filtered incidents
        incidents = []
        for incident_type in incident_types or [None]:
            filtered_incidents = self.get_incidents(
                incident_type=incident_type,
                start_date=start_date,
                end_date=end_date,
                location=location
            )
            incidents.extend(filtered_incidents)
        
        # Remove duplicates
        unique_incidents = {incident.id: incident for incident in incidents}
        incidents = list(unique_incidents.values())
        
        # Sort by date (newest first)
        incidents.sort(key=lambda x: x.date, reverse=True)
        
        # Generate report based on type
        if report_type == 'summary':
            return self._generate_summary_report(incidents, start_date, end_date)
        elif report_type == 'detailed':
            return self._generate_detailed_report(incidents, start_date, end_date)
        else:  # executive
            return self._generate_executive_report(incidents, start_date, end_date)
    
    def _generate_summary_report(self, incidents: List[Incident], 
                               start_date: datetime, 
                               end_date: datetime) -> Dict[str, Any]:
        """
        Generate a summary report
        
        Args:
            incidents: List of incidents to include
            start_date: Start date of report period
            end_date: End date of report period
            
        Returns:
            Dictionary with report data
        """
        report = {
            'title': 'Incident Summary Report',
            'period': {
                'start_date': start_date.strftime('%Y-%m-%d'),
                'end_date': end_date.strftime('%Y-%m-%d')
            },
            'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'total_incidents': len(incidents),
            'by_type': {},
            'by_severity': {},
            'by_status': {},
            'recent_incidents': []
        }
        
        # Count by type
        for incident in incidents:
            incident_type = incident.incident_type.value
            report['by_type'][incident_type] = report['by_type'].get(incident_type, 0) + 1
        
        # Count by severity
        for incident in incidents:
            severity = incident.severity.value
            report['by_severity'][severity] = report['by_severity'].get(severity, 0) + 1
        
        # Count by status
        for incident in incidents:
            status = incident.status.value
            report['by_status'][status] = report['by_status'].get(status, 0) + 1
        
        # Recent incidents (up to 10)
        for incident in incidents[:10]:
            report['recent_incidents'].append({
                'id': incident.id,
                'title': incident.title,
                'type': incident.incident_type.value,
                'severity': incident.severity.value,
                'status': incident.status.value,
                'date': incident.date.strftime('%Y-%m-%d')
            })
        
        return report
    
    def _generate_detailed_report(self, incidents: List[Incident], 
                                start_date: datetime, 
                                end_date: datetime) -> Dict[str, Any]:
        """
        Generate a detailed report
        
        Args:
            incidents: List of incidents to include
            start_date: Start date of report period
            end_date: End date of report period
            
        Returns:
            Dictionary with report data
        """
        report = self._generate_summary_report(incidents, start_date, end_date)
        report['title'] = 'Detailed Incident Report'
        
        # Add additional sections
        report['incidents'] = []
        
        # Include full incident details
        for incident in incidents:
            report['incidents'].append(incident.to_dict())
        
        # Add trend data
        report['trends'] = {
            'by_day': self.get_incident_trend(
                period='day',
                start_date=start_date,
                end_date=end_date
            )
        }
        
        # Add locations
        locations = {}
        for incident in incidents:
            if incident.location:
                locations[incident.location] = locations.get(incident.location, 0) + 1
        
        report['locations'] = locations
        
        return report
    
    def _generate_executive_report(self, incidents: List[Incident], 
                                 start_date: datetime, 
                                 end_date: datetime) -> Dict[str, Any]:
        """
        Generate an executive report
        
        Args:
            incidents: List of incidents to include
            start_date: Start date of report period
            end_date: End date of report period
            
        Returns:
            Dictionary with report data
        """
        report = {
            'title': 'Executive Threat Intelligence Report',
            'period': {
                'start_date': start_date.strftime('%Y-%m-%d'),
                'end_date': end_date.strftime('%Y-%m-%d')
            },
            'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'summary': {
                'total_incidents': len(incidents),
                'critical_incidents': sum(1 for i in incidents if i.severity == IncidentSeverity.CRITICAL),
                'high_severity_incidents': sum(1 for i in incidents if i.severity == IncidentSeverity.HIGH),
                'open_incidents': sum(1 for i in incidents if i.status == IncidentStatus.OPEN),
                'resolved_incidents': sum(1 for i in incidents if i.status == IncidentStatus.RESOLVED)
            },
            'key_threats': [],
            'threat_landscape': {
                'cyber': {},
                'physical': {},
                'hybrid': {},
                'cartel': {}
            },
            'strategic_recommendations': []
        }
        
        # Identify key threats (critical incidents)
        critical_incidents = [i for i in incidents if i.severity == IncidentSeverity.CRITICAL]
        for incident in critical_incidents[:5]:  # Top 5 critical incidents
            report['key_threats'].append({
                'id': incident.id,
                'title': incident.title,
                'type': incident.incident_type.value,
                'date': incident.date.strftime('%Y-%m-%d'),
                'status': incident.status.value,
                'brief': incident.description[:100] + '...' if incident.description and len(incident.description) > 100 else incident.description
            })
        
        # Threat landscape by type
        for incident_type in IncidentType:
            type_key = incident_type.value
            type_incidents = [i for i in incidents if i.incident_type == incident_type]
            
            if type_incidents:
                report['threat_landscape'][type_key] = {
                    'count': len(type_incidents),
                    'percentage': len(type_incidents) / len(incidents) * 100 if incidents else 0,
                    'severity_distribution': {
                        'critical': sum(1 for i in type_incidents if i.severity == IncidentSeverity.CRITICAL),
                        'high': sum(1 for i in type_incidents if i.severity == IncidentSeverity.HIGH),
                        'medium': sum(1 for i in type_incidents if i.severity == IncidentSeverity.MEDIUM),
                        'low': sum(1 for i in type_incidents if i.severity == IncidentSeverity.LOW)
                    }
                }
        
        # Strategic recommendations (placeholder)
        report['strategic_recommendations'] = [
            "Enhance monitoring of critical infrastructure",
            "Implement additional security controls for remote access",
            "Increase personnel awareness of social engineering threats",
            "Update incident response playbooks",
            "Review supply chain security measures"
        ]
        
        return report
    
    def _save_incident(self, incident: Incident) -> None:
        """
        Save an incident to storage
        
        Args:
            incident: Incident to save
        """
        incident_file = os.path.join(self.storage_path, f"{incident.id}.json")
        
        with open(incident_file, 'w') as f:
            json.dump(incident.to_dict(), f, indent=2)
    
    def _load_incidents(self) -> None:
        """Load incidents from storage"""
        if not os.path.exists(self.storage_path):
            return
        
        for filename in os.listdir(self.storage_path):
            if filename.endswith('.json'):
                incident_file = os.path.join(self.storage_path, filename)
                
                try:
                    with open(incident_file, 'r') as f:
                        incident_data = json.load(f)
                    
                    incident = Incident.from_dict(incident_data)
                    self.incidents[incident.id] = incident
                
                except Exception as e:
                    logger.error(f"Error loading incident from {filename}: {str(e)}")
        
        logger.info(f"Loaded {len(self.incidents)} incidents")
    
    def export_incidents(self, format: str = 'json', filepath: Optional[str] = None) -> Union[str, pd.DataFrame]:
        """
        Export incidents to a file
        
        Args:
            format: Export format (json, csv, excel)
            filepath: Optional file path
            
        Returns:
            File path if saved to file, DataFrame otherwise
        """
        # Convert incidents to list of dictionaries
        incident_dicts = [incident.to_dict() for incident in self.incidents.values()]
        
        if format == 'json':
            if filepath:
                with open(filepath, 'w') as f:
                    json.dump(incident_dicts, f, indent=2)
                return filepath
            else:
                return pd.DataFrame(incident_dicts)
        
        # Convert to DataFrame for CSV/Excel export
        df = pd.DataFrame(incident_dicts)
        
        if format == 'csv':
            if filepath:
                df.to_csv(filepath, index=False)
                return filepath
            else:
                return df
        
        elif format == 'excel':
            if filepath:
                df.to_excel(filepath, index=False)
                return filepath
            else:
                return df
        
        else:
            return pd.DataFrame(incident_dicts)