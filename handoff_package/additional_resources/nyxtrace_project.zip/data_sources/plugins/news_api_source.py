"""
News API Data Source Plugin
--------------------------
This plugin integrates with the News API to fetch news articles
related to specific locations and topics.
"""

import os
import json
import logging
import pandas as pd
import requests
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
import time

from ..base_source import DataSource

# Configure logging
logger = logging.getLogger('news_api_plugin')


class NewsAPISource(DataSource):
    """Data source that fetches news from the News API"""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize News API source
        
        Args:
            api_key: Optional API key (can also be set via configure method)
        """
        self._name = "News API"
        self._api_key = api_key or os.environ.get("NEWS_API_KEY")
        self._base_url = "https://newsapi.org/v2"
        self._cache = {}  # Simple cache
        self._configured = False
    
    @property
    def source_name(self) -> str:
        return self._name
    
    @property
    def source_type(self) -> str:
        return "news"
    
    def get_data(self, location: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """
        Retrieve news data for a specific location and date range
        
        Args:
            location: Name of the location to get data for
            start_date: Start of date range
            end_date: End of date range
            
        Returns:
            DataFrame with standardized columns
        """
        if not self._configured:
            logger.warning("News API source not configured. Please call configure() first.")
            return pd.DataFrame()
        
        # Generate cache key
        cache_key = f"{location}_{start_date.strftime('%Y-%m-%d')}_{end_date.strftime('%Y-%m-%d')}"
        
        # Check cache
        if cache_key in self._cache:
            cache_entry = self._cache[cache_key]
            # Use cache if less than 1 hour old
            if (datetime.now() - cache_entry['timestamp']).total_seconds() < 3600:
                logger.info(f"Using cached data for {cache_key}")
                return cache_entry['data']
        
        # Build query
        keywords = self.get_keywords_for_location(location)
        query = ' OR '.join(keywords)
        
        # Format dates
        from_date = start_date.strftime('%Y-%m-%d')
        to_date = end_date.strftime('%Y-%m-%d')
        
        # Build request
        params = {
            'q': query,
            'from': from_date,
            'to': to_date,
            'language': 'en',
            'sortBy': 'relevancy',
            'pageSize': 100,  # Maximum allowed
            'page': 1
        }
        
        headers = {
            'X-Api-Key': self._api_key
        }
        
        try:
            # Make request
            url = f"{self._base_url}/everything"
            response = requests.get(url, params=params, headers=headers)
            response.raise_for_status()
            
            # Parse response
            data = response.json()
            
            # Check if there are results
            if data.get('totalResults', 0) == 0:
                logger.info(f"No results found for {location}")
                return pd.DataFrame()
            
            # Extract articles
            articles = data.get('articles', [])
            
            # Convert to DataFrame
            return self._articles_to_dataframe(articles, location)
            
        except Exception as e:
            logger.error(f"Error fetching data from News API: {str(e)}")
            return pd.DataFrame()
    
    def get_keywords_for_location(self, location: str) -> List[str]:
        """
        Get keywords for a location
        
        Args:
            location: Location name
            
        Returns:
            List of keywords
        """
        # Basic implementation - can be extended with more sophisticated mappings
        location_lower = location.lower()
        
        # Split location into parts (e.g. "New York City" -> ["New", "York", "City"])
        parts = location_lower.split()
        
        # Generate variations
        keywords = [
            location_lower,  # Full location name
            location_lower.replace(" ", "+"),  # With plus signs
            f'"{location_lower}"'  # Quoted for exact match
        ]
        
        # Add parts if it's a multi-word location
        if len(parts) > 1:
            for part in parts:
                if len(part) > 3:  # Only add parts that are meaningful
                    keywords.append(part)
        
        return keywords
    
    def configure(self, config: Dict[str, Any]) -> None:
        """
        Configure the News API source
        
        Args:
            config: Configuration dictionary
        """
        if 'api_key' in config:
            self._api_key = config['api_key']
        
        if 'name' in config:
            self._name = config['name']
        
        if 'base_url' in config:
            self._base_url = config['base_url']
        
        # Validate configuration
        if not self._api_key:
            logger.warning("News API key not provided")
            self._configured = False
        else:
            self._configured = True
    
    def test_connection(self) -> bool:
        """
        Test connection to News API
        
        Returns:
            True if connection successful, False otherwise
        """
        if not self._api_key:
            logger.warning("News API key not provided")
            return False
        
        try:
            # Test with a simple query
            url = f"{self._base_url}/everything"
            params = {
                'q': 'test',
                'pageSize': 1
            }
            headers = {
                'X-Api-Key': self._api_key
            }
            
            response = requests.get(url, params=params, headers=headers)
            response.raise_for_status()
            
            # Parse response
            data = response.json()
            
            # Check if response is valid
            if 'status' in data and data['status'] == 'ok':
                return True
            else:
                logger.warning(f"Invalid response from News API: {data.get('message', 'Unknown error')}")
                return False
            
        except Exception as e:
            logger.error(f"Error testing connection to News API: {str(e)}")
            return False
    
    def _articles_to_dataframe(self, articles: List[Dict[str, Any]], location: str) -> pd.DataFrame:
        """
        Convert articles to DataFrame
        
        Args:
            articles: List of article dictionaries
            location: Location name
            
        Returns:
            DataFrame with standardized columns
        """
        if not articles:
            return pd.DataFrame()
        
        # Extract data
        rows = []
        for article in articles:
            # Parse date
            try:
                date = datetime.strptime(article.get('publishedAt', ''), '%Y-%m-%dT%H:%M:%SZ')
            except:
                date = datetime.now()
            
            # Extract content
            title = article.get('title', '')
            description = article.get('description', '')
            content = article.get('content', '')
            full_content = f"{title}\n\n{description}\n\n{content}"
            
            # Basic sentiment analysis (placeholder)
            # In a real implementation, this would use NLP
            sentiment = 0.0
            
            # Create row
            row = {
                'Source': self.source_name,
                'Date': date,
                'Content': full_content,
                'Title': title,
                'URL': article.get('url', ''),
                'Author': article.get('author', ''),
                'Source_Name': article.get('source', {}).get('name', ''),
                'Location': location,
                'Sentiment': sentiment,
                'Activity_Level': 1.0  # Default activity level
            }
            
            rows.append(row)
        
        # Create DataFrame
        df = pd.DataFrame(rows)
        
        # Update cache
        cache_key = f"{location}_{min(df['Date']).strftime('%Y-%m-%d')}_{max(df['Date']).strftime('%Y-%m-%d')}"
        self._cache[cache_key] = {
            'data': df,
            'timestamp': datetime.now()
        }
        
        return df