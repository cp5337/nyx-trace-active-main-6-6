"""
AlienVault OTX TAXII Data Source Plugin
--------------------------------------
This module provides integration with AlienVault Open Threat Exchange (OTX)
via TAXII protocol to ingest threat intelligence data.
"""

import os
import json
import logging
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Union, Optional, Tuple
from io import StringIO
import re
import requests
import ipaddress
import time
import cabby
import taxii2client
from taxii2client import Server
from taxii2client.v20 import ApiRoot, Collection, Server as ServerV20
from taxii2client.v21 import ApiRoot as ApiRootV21, Collection as CollectionV21, Server as ServerV21

# Import base class
from data_sources.base_source import DataSource

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('alienvault_otx_source')


class AlienVaultOTXSource(DataSource):
    """
    AlienVault OTX Data Source
    
    This class provides methods to:
    - Connect to AlienVault OTX via TAXII
    - Ingest threat intelligence data
    - Parse and standardize CTI data
    - Extract source-target relationships for visualization
    """
    
    def __init__(self):
        """Initialize AlienVault OTX data source"""
        self._api_key = None
        self._discovery_url = "https://otx.alienvault.com/taxii/discovery"
        self._taxii_url = "https://otx.alienvault.com/taxii/"
        self._otx_base_url = "https://otx.alienvault.com/api/v1/"
        self._client = None
        self._collections = []
        self._connected = False
        self._data_cache = {}
        self._source_target_cache = {}
        
        # TAXII 2.0/2.1 variables
        self._taxii2_server = None
        self._taxii2_api_root = None
        self._taxii2_collections = []
        
        # Try to get API key from environment
        self._api_key = os.environ.get('ALIENVAULT_OTX_API_KEY')
        
    @property
    def source_name(self) -> str:
        """Return the name of this data source"""
        return "AlienVault OTX"
    
    @property
    def source_type(self) -> str:
        """Return the type of this data source"""
        return "threat_intel"
    
    def configure(self, config: Dict[str, Any]) -> None:
        """
        Configure the AlienVault OTX data source
        
        Args:
            config: Dictionary of configuration parameters
                - api_key: AlienVault OTX API key
                - discovery_url: Optional custom discovery URL
                - taxii_url: Optional custom TAXII URL
        """
        if 'api_key' in config:
            self._api_key = config['api_key']
        
        if 'discovery_url' in config:
            self._discovery_url = config['discovery_url']
        
        if 'taxii_url' in config:
            self._taxii_url = config['taxii_url']
        
        # Try to connect with the new configuration
        if self._api_key:
            self._connect()
    
    def test_connection(self) -> bool:
        """
        Test if this data source is properly configured and can connect
        
        Returns:
            True if connection successful, False otherwise
        """
        if not self._api_key:
            logger.warning("No API key configured for AlienVault OTX")
            return False
        
        if self._connected:
            return True
        
        return self._connect()
    
    def _connect(self) -> bool:
        """
        Connect to AlienVault OTX via TAXII
        
        Returns:
            True if connection successful, False otherwise
        """
        try:
            # First try TAXII 1.1 protocol
            self._client = cabby.create_client(
                discovery_path=self._discovery_url,
                use_https=True
            )
            
            # Set authentication if API key available
            if self._api_key:
                self._client.set_auth(username=self._api_key, password='')
            
            # Get available collections
            self._collections = list(self._client.get_collections())
            
            # If we got collections, we're connected
            if self._collections:
                self._connected = True
                logger.info(f"Connected to AlienVault OTX TAXII 1.1 with {len(self._collections)} collections")
                return True
            
            # If TAXII 1.1 failed, try TAXII 2.0/2.1
            logger.info("TAXII 1.1 failed, trying TAXII 2.0/2.1...")
            
            # Try TAXII 2.0
            try:
                self._taxii2_server = Server(
                    url=self._taxii_url,
                    user=self._api_key,
                    password=''
                )
                
                # Get API roots
                roots = self._taxii2_server.api_roots
                
                if roots:
                    self._taxii2_api_root = roots[0]
                    self._taxii2_collections = list(self._taxii2_api_root.collections)
                    
                    if self._taxii2_collections:
                        self._connected = True
                        logger.info(f"Connected to AlienVault OTX TAXII 2.0 with {len(self._taxii2_collections)} collections")
                        return True
            except Exception as e:
                logger.warning(f"TAXII 2.0 connection failed: {str(e)}")
            
            # Try TAXII 2.1
            try:
                self._taxii2_server = ServerV21(
                    url=self._taxii_url,
                    user=self._api_key,
                    password=''
                )
                
                # Get API roots
                roots = self._taxii2_server.api_roots
                
                if roots:
                    self._taxii2_api_root = roots[0]
                    self._taxii2_collections = list(self._taxii2_api_root.collections)
                    
                    if self._taxii2_collections:
                        self._connected = True
                        logger.info(f"Connected to AlienVault OTX TAXII 2.1 with {len(self._taxii2_collections)} collections")
                        return True
            except Exception as e:
                logger.warning(f"TAXII 2.1 connection failed: {str(e)}")
            
            logger.error("Failed to connect to AlienVault OTX via any TAXII version")
            return False
            
        except Exception as e:
            logger.error(f"Error connecting to AlienVault OTX: {str(e)}")
            self._connected = False
            return False
    
    def get_keywords_for_location(self, location: str) -> List[str]:
        """
        Get keywords associated with a location from OTX
        
        Args:
            location: Name of the location
            
        Returns:
            List of associated keywords
        """
        # For OTX, we might associate locations with threat actors known to operate there
        # This is a simplified implementation
        location_keywords = {
            "Russia": ["APT28", "APT29", "Turla", "Sandworm"],
            "China": ["APT1", "APT10", "APT41", "BlackTech"],
            "Iran": ["APT33", "APT35", "Charming Kitten"],
            "North Korea": ["Lazarus Group", "APT37", "Kimsuky"],
            "United States": ["NSA", "Equation Group"],
            "Israel": ["Unit 8200", "POISONED LIBERTY"]
        }
        
        # If we have keywords for this location, return them
        if location in location_keywords:
            return location_keywords[location]
        
        # Otherwise, just use the location name as a keyword
        return [location]
    
    def get_data(self, 
               location: Optional[str] = None, 
               start_date: Optional[datetime] = None, 
               end_date: Optional[datetime] = None) -> pd.DataFrame:
        """
        Retrieve threat intelligence data related to a location and date range
        
        Args:
            location: Name of the location to get data for
            start_date: Start of date range
            end_date: End of date range
            
        Returns:
            DataFrame with standardized columns
        """
        # Set default dates if not provided
        if not start_date:
            start_date = datetime.now() - timedelta(days=30)
        
        if not end_date:
            end_date = datetime.now()
        
        # Get keywords for this location
        keywords = []
        if location:
            keywords = self.get_keywords_for_location(location)
        
        # Check if we have a cached result
        cache_key = f"{location}_{start_date.isoformat()}_{end_date.isoformat()}"
        if cache_key in self._data_cache:
            logger.info(f"Using cached data for {cache_key}")
            return self._data_cache[cache_key]
        
        # Make sure we're connected
        if not self._connected:
            if not self._connect():
                logger.error("Could not connect to AlienVault OTX")
                return pd.DataFrame()
        
        # Retrieve data based on available TAXII version
        try:
            if self._client and self._collections:  # TAXII 1.1
                return self._get_data_taxii11(keywords, start_date, end_date, cache_key)
            elif self._taxii2_collections:  # TAXII 2.0/2.1
                return self._get_data_taxii2(keywords, start_date, end_date, cache_key)
            else:
                logger.error("No valid TAXII connection available")
                return pd.DataFrame()
        except Exception as e:
            logger.error(f"Error retrieving data from AlienVault OTX: {str(e)}")
            return pd.DataFrame()
    
    def _get_data_taxii11(self, 
                        keywords: List[str], 
                        start_date: datetime, 
                        end_date: datetime,
                        cache_key: str) -> pd.DataFrame:
        """
        Get data using TAXII 1.1 protocol
        
        Args:
            keywords: List of keywords to filter data
            start_date: Start date for data retrieval
            end_date: End date for data retrieval
            cache_key: Key for caching results
            
        Returns:
            DataFrame with standardized columns
        """
        all_content_blocks = []
        
        # Convert dates to string format required by TAXII 1.1
        start_str = start_date.strftime("%Y-%m-%dT%H:%M:%S.000000+00:00")
        end_str = end_date.strftime("%Y-%m-%dT%H:%M:%S.000000+00:00")
        
        # Poll each collection for data
        for collection in self._collections:
            try:
                # Only poll collections that might contain relevant information
                if not keywords or any(keyword.lower() in collection.name.lower() for keyword in keywords):
                    logger.info(f"Polling collection: {collection.name}")
                    
                    # Get content blocks from this collection
                    content_blocks = self._client.poll(
                        collection_name=collection.name,
                        begin_date=start_str,
                        end_date=end_str
                    )
                    
                    # Add to all content blocks
                    all_content_blocks.extend(content_blocks)
            except Exception as e:
                logger.warning(f"Error polling collection {collection.name}: {str(e)}")
        
        # Parse content blocks into DataFrame
        data = self._parse_content_blocks(all_content_blocks, keywords)
        
        # Cache result
        self._data_cache[cache_key] = data
        
        return data
    
    def _get_data_taxii2(self, 
                      keywords: List[str], 
                      start_date: datetime, 
                      end_date: datetime,
                      cache_key: str) -> pd.DataFrame:
        """
        Get data using TAXII 2.0/2.1 protocol
        
        Args:
            keywords: List of keywords to filter data
            start_date: Start date for data retrieval
            end_date: End date for data retrieval
            cache_key: Key for caching results
            
        Returns:
            DataFrame with standardized columns
        """
        all_objects = []
        
        # Convert dates to string format required by TAXII 2.0/2.1
        added_after = start_date.strftime("%Y-%m-%dT%H:%M:%SZ")
        
        # Poll each collection for data
        for collection in self._taxii2_collections:
            try:
                # Only poll collections that might contain relevant information
                if not keywords or any(keyword.lower() in collection.title.lower() for keyword in keywords):
                    logger.info(f"Polling collection: {collection.title}")
                    
                    # Get objects from this collection
                    objects = collection.get_objects(added_after=added_after)
                    
                    if hasattr(objects, 'objects'):
                        all_objects.extend(objects.objects)
            except Exception as e:
                logger.warning(f"Error polling collection {collection.title}: {str(e)}")
        
        # Parse objects into DataFrame
        data = self._parse_stix_objects(all_objects, keywords)
        
        # Cache result
        self._data_cache[cache_key] = data
        
        return data
    
    def _parse_content_blocks(self, 
                           content_blocks: List[Any],
                           keywords: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Parse TAXII 1.1 content blocks into a standardized DataFrame
        
        Args:
            content_blocks: List of content blocks from TAXII 1.1
            keywords: Optional list of keywords to filter content
            
        Returns:
            DataFrame with standardized columns
        """
        records = []
        
        for block in content_blocks:
            try:
                # Extract content as string
                content_str = block.content.decode('utf-8')
                
                # Skip if doesn't match keywords
                if keywords and not any(keyword.lower() in content_str.lower() for keyword in keywords):
                    continue
                
                # Try to parse as XML/JSON
                try:
                    import xml.etree.ElementTree as ET
                    root = ET.fromstring(content_str)
                    namespace = {'stix': 'http://stix.mitre.org/stix-1'}
                    
                    # Extract STIX 1.x data
                    title_element = root.find('.//stix:Title', namespace)
                    title = title_element.text if title_element is not None else "Unknown"
                    
                    description_element = root.find('.//stix:Description', namespace)
                    description = description_element.text if description_element is not None else ""
                    
                    # Extract timestamp
                    timestamp_element = root.find('.//stix:Timestamp', namespace)
                    if timestamp_element is not None:
                        timestamp = datetime.strptime(timestamp_element.text, "%Y-%m-%dT%H:%M:%S")
                    else:
                        timestamp = datetime.now()
                    
                    # Try to extract source and target info
                    source_target = self._extract_source_target_from_stix1(root, namespace)
                    source = source_target.get('source', "Unknown")
                    target = source_target.get('target', "Unknown")
                    
                    # Extract indicators
                    indicators = []
                    for indicator in root.findall('.//stix:Indicator', namespace):
                        indicator_title = indicator.find('.//stix:Title', namespace)
                        if indicator_title is not None:
                            indicators.append(indicator_title.text)
                    
                    # Create record
                    record = {
                        'Source': 'AlienVault OTX',
                        'Date': timestamp,
                        'Title': title,
                        'Content': description,
                        'Sentiment': -0.8,  # Threat intelligence is typically negative
                        'Activity_Level': 0.7,
                        'Indicators': '; '.join(indicators),
                        'Source_Entity': source,
                        'Target_Entity': target
                    }
                    
                    records.append(record)
                    
                except ET.ParseError:
                    # Not valid XML, try as JSON
                    try:
                        data = json.loads(content_str)
                        
                        # Extract basic info
                        title = data.get('title', "Unknown")
                        description = data.get('description', "")
                        
                        # Extract timestamp
                        if 'timestamp' in data:
                            timestamp = datetime.fromisoformat(data['timestamp'].replace('Z', '+00:00'))
                        else:
                            timestamp = datetime.now()
                        
                        # Try to extract source and target info
                        source = data.get('source', {}).get('name', "Unknown")
                        target = data.get('target', {}).get('name', "Unknown")
                        
                        # Extract indicators
                        indicators = []
                        for indicator in data.get('indicators', []):
                            if 'title' in indicator:
                                indicators.append(indicator['title'])
                        
                        # Create record
                        record = {
                            'Source': 'AlienVault OTX',
                            'Date': timestamp,
                            'Title': title,
                            'Content': description,
                            'Sentiment': -0.8,  # Threat intelligence is typically negative
                            'Activity_Level': 0.7,
                            'Indicators': '; '.join(indicators),
                            'Source_Entity': source,
                            'Target_Entity': target
                        }
                        
                        records.append(record)
                        
                    except json.JSONDecodeError:
                        # Not valid JSON either, use raw text
                        record = {
                            'Source': 'AlienVault OTX',
                            'Date': block.timestamp,
                            'Title': "Unknown",
                            'Content': content_str[:500],  # Truncate long content
                            'Sentiment': -0.8,  # Threat intelligence is typically negative
                            'Activity_Level': 0.5,
                            'Indicators': "",
                            'Source_Entity': "Unknown",
                            'Target_Entity': "Unknown"
                        }
                        
                        records.append(record)
                        
            except Exception as e:
                logger.warning(f"Error parsing content block: {str(e)}")
        
        # Create DataFrame
        if records:
            df = pd.DataFrame(records)
            
            # Extract lat/lon for visualization
            df = self._enrich_with_geo_data(df)
            
            return df
        else:
            return pd.DataFrame(columns=[
                'Source', 'Date', 'Title', 'Content', 'Sentiment', 'Activity_Level',
                'Indicators', 'Source_Entity', 'Target_Entity', 'lat', 'lon'
            ])
    
    def _parse_stix_objects(self, 
                         stix_objects: List[Any],
                         keywords: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Parse STIX 2.x objects into a standardized DataFrame
        
        Args:
            stix_objects: List of STIX 2.x objects
            keywords: Optional list of keywords to filter objects
            
        Returns:
            DataFrame with standardized columns
        """
        records = []
        
        for obj in stix_objects:
            try:
                # Convert to dictionary if it's an object
                if not isinstance(obj, dict):
                    obj = obj._raw
                
                # Skip if doesn't match keywords
                obj_text = json.dumps(obj)
                if keywords and not any(keyword.lower() in obj_text.lower() for keyword in keywords):
                    continue
                
                # Extract basic info
                obj_type = obj.get('type', 'unknown')
                obj_id = obj.get('id', 'unknown')
                
                # Process based on type
                if obj_type == 'indicator':
                    title = obj.get('name', obj.get('pattern', 'Unknown Indicator'))
                    description = obj.get('description', '')
                    
                    # Extract timestamp
                    if 'created' in obj:
                        timestamp = datetime.fromisoformat(obj['created'].replace('Z', '+00:00'))
                    else:
                        timestamp = datetime.now()
                    
                    # Look for associated entities
                    source = "Unknown"
                    target = "Unknown"
                    
                    # STIX 2.x has references that can help determine source/target
                    created_by_ref = obj.get('created_by_ref', '')
                    if created_by_ref:
                        source = created_by_ref.split('--')[0]
                    
                    # Targets might be in object_refs or target_ref
                    target_refs = obj.get('target_ref', [])
                    if target_refs:
                        if isinstance(target_refs, list):
                            target = target_refs[0].split('--')[0] if target_refs else "Unknown"
                        else:
                            target = target_refs.split('--')[0]
                    
                    # Create record
                    record = {
                        'Source': 'AlienVault OTX',
                        'Date': timestamp,
                        'Title': title,
                        'Content': description,
                        'Sentiment': -0.8,  # Threat intelligence is typically negative
                        'Activity_Level': 0.7,
                        'Indicators': obj.get('pattern', ''),
                        'Source_Entity': source,
                        'Target_Entity': target,
                        'stix_id': obj_id
                    }
                    
                    records.append(record)
                    
                elif obj_type == 'report':
                    title = obj.get('name', 'Unknown Report')
                    description = obj.get('description', '')
                    
                    # Extract timestamp
                    if 'created' in obj:
                        timestamp = datetime.fromisoformat(obj['created'].replace('Z', '+00:00'))
                    else:
                        timestamp = datetime.now()
                    
                    # Extract source and target from report
                    source_target = self._extract_source_target_from_report(obj)
                    source = source_target.get('source', "Unknown")
                    target = source_target.get('target', "Unknown")
                    
                    # Create record
                    record = {
                        'Source': 'AlienVault OTX',
                        'Date': timestamp,
                        'Title': title,
                        'Content': description,
                        'Sentiment': -0.8,  # Threat intelligence is typically negative
                        'Activity_Level': 0.8,
                        'Indicators': '; '.join(obj.get('labels', [])),
                        'Source_Entity': source,
                        'Target_Entity': target,
                        'stix_id': obj_id
                    }
                    
                    records.append(record)
                    
                elif obj_type == 'relationship':
                    source_ref = obj.get('source_ref', 'unknown')
                    target_ref = obj.get('target_ref', 'unknown')
                    relationship_type = obj.get('relationship_type', 'unknown')
                    
                    # Extract timestamp
                    if 'created' in obj:
                        timestamp = datetime.fromisoformat(obj['created'].replace('Z', '+00:00'))
                    else:
                        timestamp = datetime.now()
                    
                    # Extract source and target from refs
                    source = source_ref.split('--')[0] if '--' in source_ref else source_ref
                    target = target_ref.split('--')[0] if '--' in target_ref else target_ref
                    
                    # Create record
                    record = {
                        'Source': 'AlienVault OTX',
                        'Date': timestamp,
                        'Title': f"{relationship_type} relationship",
                        'Content': f"{source_ref} {relationship_type} {target_ref}",
                        'Sentiment': -0.8,  # Threat intelligence is typically negative
                        'Activity_Level': 0.6,
                        'Indicators': relationship_type,
                        'Source_Entity': source,
                        'Target_Entity': target,
                        'stix_id': obj_id
                    }
                    
                    records.append(record)
                    
            except Exception as e:
                logger.warning(f"Error parsing STIX object: {str(e)}")
        
        # Create DataFrame
        if records:
            df = pd.DataFrame(records)
            
            # Extract lat/lon for visualization
            df = self._enrich_with_geo_data(df)
            
            return df
        else:
            return pd.DataFrame(columns=[
                'Source', 'Date', 'Title', 'Content', 'Sentiment', 'Activity_Level',
                'Indicators', 'Source_Entity', 'Target_Entity', 'lat', 'lon'
            ])
    
    def _extract_source_target_from_stix1(self, root, namespace) -> Dict[str, str]:
        """
        Extract source and target information from STIX 1.x XML
        
        Args:
            root: XML root element
            namespace: XML namespace
            
        Returns:
            Dictionary with source and target information
        """
        result = {
            'source': "Unknown",
            'target': "Unknown"
        }
        
        try:
            # Try to find threat actor information
            threat_actor = root.find('.//stix:Threat_Actor', namespace)
            if threat_actor is not None:
                # Get threat actor name
                ta_name = threat_actor.find('.//stix:Name', namespace)
                if ta_name is not None:
                    result['source'] = ta_name.text
            
            # Try to find target information in Victim element
            victim = root.find('.//stix:Victim', namespace)
            if victim is not None:
                # Get victim name
                victim_name = victim.find('.//stix:Name', namespace)
                if victim_name is not None:
                    result['target'] = victim_name.text
            
            # If we couldn't find a victim, look for affected assets or targets
            if result['target'] == "Unknown":
                # Look for Affected_Asset
                asset = root.find('.//stix:Affected_Asset', namespace)
                if asset is not None:
                    asset_type = asset.find('.//stix:Type', namespace)
                    if asset_type is not None:
                        result['target'] = asset_type.text
        except Exception as e:
            logger.warning(f"Error extracting source/target from STIX 1.x: {str(e)}")
        
        return result
    
    def _extract_source_target_from_report(self, report: Dict[str, Any]) -> Dict[str, str]:
        """
        Extract source and target information from STIX 2.x report
        
        Args:
            report: STIX 2.x report object
            
        Returns:
            Dictionary with source and target information
        """
        result = {
            'source': "Unknown",
            'target': "Unknown"
        }
        
        try:
            # Check created_by_ref for source
            created_by_ref = report.get('created_by_ref', '')
            if created_by_ref:
                result['source'] = created_by_ref.split('--')[0]
            
            # Check object_refs for targets
            object_refs = report.get('object_refs', [])
            if object_refs:
                for ref in object_refs:
                    # If the ref is an identity or location, it's likely a target
                    if ref.startswith('identity--') or ref.startswith('location--'):
                        result['target'] = ref.split('--')[0]
                        break
            
            # If we still don't have a target, use text analysis
            if result['target'] == "Unknown":
                # Look for target indicators in description
                description = report.get('description', '')
                
                # List of terms that might indicate a target
                target_terms = ["target", "victim", "affected", "compromised"]
                
                # Search for sentences with target terms
                for term in target_terms:
                    if term in description.lower():
                        # Find the sentence containing the term
                        sentences = description.split('. ')
                        for sentence in sentences:
                            if term in sentence.lower():
                                # Extract potential entity names (capitalized words)
                                words = sentence.split()
                                for i, word in enumerate(words):
                                    if word.lower() == term and i < len(words) - 1:
                                        # The word after "target", "victim", etc. might be the target
                                        result['target'] = words[i + 1].strip('.,;:()"\'')
                                        break
                        
                        if result['target'] != "Unknown":
                            break
        except Exception as e:
            logger.warning(f"Error extracting source/target from report: {str(e)}")
        
        return result
    
    def _enrich_with_geo_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Enrich DataFrame with geographical data based on source/target entities
        
        Args:
            df: DataFrame to enrich
            
        Returns:
            Enriched DataFrame with lat/lon columns
        """
        # Dictionary mapping entity names to coordinates
        # This would ideally be more sophisticated in a production environment
        entity_coords = {
            "Russia": (55.7558, 37.6173),
            "China": (39.9042, 116.4074),
            "Iran": (35.6892, 51.3890),
            "North Korea": (39.0392, 125.7625),
            "United States": (38.8951, -77.0364),
            "Israel": (31.7683, 35.2137),
            "APT28": (55.7558, 37.6173),  # Russia
            "APT29": (55.7558, 37.6173),  # Russia
            "Turla": (55.7558, 37.6173),  # Russia
            "Sandworm": (55.7558, 37.6173),  # Russia
            "APT1": (39.9042, 116.4074),  # China
            "APT10": (39.9042, 116.4074),  # China
            "APT41": (39.9042, 116.4074),  # China
            "BlackTech": (39.9042, 116.4074),  # China
            "APT33": (35.6892, 51.3890),  # Iran
            "APT35": (35.6892, 51.3890),  # Iran
            "Charming Kitten": (35.6892, 51.3890),  # Iran
            "Lazarus Group": (39.0392, 125.7625),  # North Korea
            "APT37": (39.0392, 125.7625),  # North Korea
            "Kimsuky": (39.0392, 125.7625),  # North Korea
            "NSA": (38.8951, -77.0364),  # US
            "Equation Group": (38.8951, -77.0364),  # US
            "Unit 8200": (31.7683, 35.2137),  # Israel
            "POISONED LIBERTY": (31.7683, 35.2137),  # Israel
        }
        
        # Add default lat/lon columns
        df['source_lat'] = None
        df['source_lon'] = None
        df['target_lat'] = None
        df['target_lon'] = None
        
        # Add coordinates based on entity names
        for idx, row in df.iterrows():
            source_entity = row['Source_Entity']
            target_entity = row['Target_Entity']
            
            # Check for exact matches
            if source_entity in entity_coords:
                df.at[idx, 'source_lat'] = entity_coords[source_entity][0]
                df.at[idx, 'source_lon'] = entity_coords[source_entity][1]
            else:
                # Check for partial matches
                for entity, coords in entity_coords.items():
                    if entity in source_entity:
                        df.at[idx, 'source_lat'] = coords[0]
                        df.at[idx, 'source_lon'] = coords[1]
                        break
            
            # Same for target
            if target_entity in entity_coords:
                df.at[idx, 'target_lat'] = entity_coords[target_entity][0]
                df.at[idx, 'target_lon'] = entity_coords[target_entity][1]
            else:
                # Check for partial matches
                for entity, coords in entity_coords.items():
                    if entity in target_entity:
                        df.at[idx, 'target_lat'] = coords[0]
                        df.at[idx, 'target_lon'] = coords[1]
                        break
        
        return df
    
    def get_source_target_flows(self, 
                             location: Optional[str] = None, 
                             start_date: Optional[datetime] = None, 
                             end_date: Optional[datetime] = None) -> pd.DataFrame:
        """
        Get source-target relationship flows for visualization
        
        Args:
            location: Optional location to filter data
            start_date: Optional start date
            end_date: Optional end date
            
        Returns:
            DataFrame with source-target flows
        """
        # Get the base data
        data = self.get_data(location, start_date, end_date)
        
        if data.empty:
            return pd.DataFrame(columns=[
                'source', 'target', 'source_lat', 'source_lon', 'target_lat', 'target_lon',
                'weight', 'type'
            ])
        
        # Extract flows
        flows = []
        
        for idx, row in data.iterrows():
            # Skip if we don't have both source and target with coordinates
            if (pd.isna(row.get('source_lat')) or pd.isna(row.get('source_lon')) or
                pd.isna(row.get('target_lat')) or pd.isna(row.get('target_lon'))):
                continue
            
            # Create flow record
            flow = {
                'source': row['Source_Entity'],
                'target': row['Target_Entity'],
                'source_lat': row['source_lat'],
                'source_lon': row['source_lon'],
                'target_lat': row['target_lat'],
                'target_lon': row['target_lon'],
                'weight': 1,  # Could be based on confidence or other factors
                'type': 'attack',  # Default type
                'title': row['Title'],
                'date': row['Date']
            }
            
            flows.append(flow)
        
        # Aggregate flows (combine duplicate source-target pairs)
        if flows:
            flow_df = pd.DataFrame(flows)
            
            # Group by source-target pairs and aggregate
            aggregated = flow_df.groupby(['source', 'target', 'source_lat', 'source_lon', 
                                        'target_lat', 'target_lon', 'type']).agg({
                'weight': 'sum',
                'title': lambda x: '; '.join(set(x)),
                'date': 'min'  # Use earliest date
            }).reset_index()
            
            return aggregated
        else:
            return pd.DataFrame(columns=[
                'source', 'target', 'source_lat', 'source_lon', 'target_lat', 'target_lon',
                'weight', 'type', 'title', 'date'
            ])