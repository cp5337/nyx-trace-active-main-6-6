"""
Data Source Plugins System
-------------------------
This module provides a plugin architecture for easily adding new 
data sources to the NyxTrace platform without modifying the core code.

Plugins can be added by creating a class that implements the DataSource interface
in this directory, and they will be automatically discovered and registered.
"""

from ..base_source import DataSource
import os
import importlib
import inspect
import logging
import sys
from typing import Dict, Type, List, Optional

logger = logging.getLogger('plugin_manager')

# Registry of plugin classes
_plugin_registry: Dict[str, Type[DataSource]] = {}


def discover_plugins() -> List[Type[DataSource]]:
    """
    Discover and load all plugin modules in the plugins directory
    
    Returns:
        List of discovered plugin classes
    """
    plugins_dir = os.path.dirname(__file__)
    plugin_modules = []
    
    # Find all Python files in the plugins directory
    for filename in os.listdir(plugins_dir):
        if filename.endswith('.py') and filename != '__init__.py':
            module_name = filename[:-3]  # Remove .py extension
            plugin_modules.append(module_name)
    
    # Import each module and find plugin classes
    plugin_classes = []
    for module_name in plugin_modules:
        try:
            # Import the module
            module_path = f"data_sources.plugins.{module_name}"
            module = importlib.import_module(module_path)
            
            # Find all classes that inherit from DataSource
            for name, obj in inspect.getmembers(module, inspect.isclass):
                if issubclass(obj, DataSource) and obj != DataSource:
                    plugin_classes.append(obj)
                    _plugin_registry[name] = obj
                    logger.info(f"Discovered plugin: {name}")
        
        except Exception as e:
            logger.error(f"Error loading plugin module {module_name}: {str(e)}")
    
    return plugin_classes


def get_plugin_class(name: str) -> Optional[Type[DataSource]]:
    """
    Get a plugin class by name
    
    Args:
        name: Name of the plugin class
        
    Returns:
        Plugin class if found, None otherwise
    """
    return _plugin_registry.get(name)


def get_available_plugins() -> Dict[str, Type[DataSource]]:
    """
    Get all available plugins
    
    Returns:
        Dictionary mapping plugin names to plugin classes
    """
    return _plugin_registry.copy()


def register_plugin(plugin_class: Type[DataSource]) -> None:
    """
    Manually register a plugin class
    
    Args:
        plugin_class: Plugin class to register
    """
    name = plugin_class.__name__
    _plugin_registry[name] = plugin_class
    logger.info(f"Manually registered plugin: {name}")


# Auto-discover plugins when the module is imported
discover_plugins()