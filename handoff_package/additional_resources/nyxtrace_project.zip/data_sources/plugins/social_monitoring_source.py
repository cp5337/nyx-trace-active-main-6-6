"""
Social Media Monitoring Data Source Plugin
----------------------------------------
This plugin integrates with social media platforms to monitor mentions
of specific locations and keywords related to threats.
"""

import os
import json
import logging
import pandas as pd
import requests
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
import time
import re

from ..base_source import DataSource

# Configure logging
logger = logging.getLogger('social_monitoring_plugin')


class SocialMonitoringSource(DataSource):
    """Data source that monitors social media platforms"""
    
    def __init__(self, platform: str = "twitter", api_key: Optional[str] = None):
        """
        Initialize social media monitoring source
        
        Args:
            platform: Social media platform to monitor (twitter, reddit, etc.)
            api_key: Optional API key (can also be set via configure method)
        """
        self._name = f"{platform.capitalize()} Monitoring"
        self._platform = platform
        self._api_key = api_key
        self._endpoints = {
            "twitter": "https://api.twitter.com/2",
            "reddit": "https://oauth.reddit.com",
            "facebook": "https://graph.facebook.com/v14.0"
        }
        self._base_url = self._endpoints.get(platform.lower(), "")
        self._cache = {}  # Simple cache
        self._configured = False
        
        # Additional configuration
        self._headers = {}
        self._auth_token = None
        self._client_id = None
        self._client_secret = None
    
    @property
    def source_name(self) -> str:
        return self._name
    
    @property
    def source_type(self) -> str:
        return "social"
    
    def get_data(self, location: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """
        Retrieve social media data for a specific location and date range
        
        Args:
            location: Name of the location to get data for
            start_date: Start of date range
            end_date: End of date range
            
        Returns:
            DataFrame with standardized columns
        """
        if not self._configured:
            logger.warning(f"{self._platform} source not configured. Please call configure() first.")
            return pd.DataFrame()
        
        # Generate cache key
        cache_key = f"{self._platform}_{location}_{start_date.strftime('%Y-%m-%d')}_{end_date.strftime('%Y-%m-%d')}"
        
        # Check cache
        if cache_key in self._cache:
            cache_entry = self._cache[cache_key]
            # Use cache if less than 30 minutes old
            if (datetime.now() - cache_entry['timestamp']).total_seconds() < 1800:
                logger.info(f"Using cached data for {cache_key}")
                return cache_entry['data']
        
        # Get data based on platform
        if self._platform.lower() == "twitter":
            df = self._get_twitter_data(location, start_date, end_date)
        elif self._platform.lower() == "reddit":
            df = self._get_reddit_data(location, start_date, end_date)
        elif self._platform.lower() == "facebook":
            df = self._get_facebook_data(location, start_date, end_date)
        else:
            logger.warning(f"Unsupported platform: {self._platform}")
            return pd.DataFrame()
        
        # Update cache
        self._cache[cache_key] = {
            'data': df,
            'timestamp': datetime.now()
        }
        
        return df
    
    def get_keywords_for_location(self, location: str) -> List[str]:
        """
        Get keywords for a location
        
        Args:
            location: Location name
            
        Returns:
            List of keywords
        """
        # Basic implementation - can be extended with more sophisticated mappings
        location_lower = location.lower()
        
        # Generate hashtags
        hashtags = []
        for word in location_lower.split():
            if len(word) > 2:  # Only add meaningful words
                hashtags.append(f"#{word}")
        
        # For multi-word locations, add hashtag with no spaces
        if len(location_lower.split()) > 1:
            hashtags.append(f"#{location_lower.replace(' ', '')}")
        
        # Combine keywords and hashtags
        keywords = [
            location_lower,  # The location name
            f'"{location_lower}"',  # Quoted for exact match
            *hashtags  # Hashtag variations
        ]
        
        return keywords
    
    def configure(self, config: Dict[str, Any]) -> None:
        """
        Configure the social media monitoring source
        
        Args:
            config: Configuration dictionary
        """
        if 'api_key' in config:
            self._api_key = config['api_key']
        
        if 'platform' in config:
            self._platform = config['platform']
            self._name = f"{self._platform.capitalize()} Monitoring"
            self._base_url = self._endpoints.get(self._platform.lower(), "")
        
        if 'auth_token' in config:
            self._auth_token = config['auth_token']
        
        if 'client_id' in config:
            self._client_id = config['client_id']
        
        if 'client_secret' in config:
            self._client_secret = config['client_secret']
        
        if 'headers' in config:
            self._headers.update(config['headers'])
        
        # Platform-specific configuration
        if self._platform.lower() == "twitter" and self._api_key:
            self._headers['Authorization'] = f"Bearer {self._api_key}"
            self._configured = True
        
        elif self._platform.lower() == "reddit" and self._auth_token:
            self._headers['Authorization'] = f"Bearer {self._auth_token}"
            self._configured = True
        
        elif self._platform.lower() == "facebook" and self._api_key:
            # Facebook uses access_token as a parameter
            self._configured = True
        
        else:
            self._configured = False
    
    def test_connection(self) -> bool:
        """
        Test connection to the social media API
        
        Returns:
            True if connection successful, False otherwise
        """
        if not self._configured:
            logger.warning(f"{self._platform} source not configured.")
            return False
        
        try:
            # Test connection based on platform
            if self._platform.lower() == "twitter":
                # Test with a simple query
                url = f"{self._base_url}/tweets/search/recent"
                params = {
                    'query': 'test',
                    'max_results': 1
                }
                
                response = requests.get(url, params=params, headers=self._headers)
                response.raise_for_status()
                
                return True
            
            elif self._platform.lower() == "reddit":
                # Test with a simple search
                url = f"{self._base_url}/search"
                params = {
                    'q': 'test',
                    'limit': 1
                }
                
                response = requests.get(url, params=params, headers=self._headers)
                response.raise_for_status()
                
                return True
            
            elif self._platform.lower() == "facebook":
                # Test with a simple page search
                url = f"{self._base_url}/search"
                params = {
                    'q': 'test',
                    'type': 'page',
                    'limit': 1,
                    'access_token': self._api_key
                }
                
                response = requests.get(url, params=params)
                response.raise_for_status()
                
                return True
            
            else:
                logger.warning(f"Unsupported platform: {self._platform}")
                return False
            
        except Exception as e:
            logger.error(f"Error testing connection to {self._platform}: {str(e)}")
            return False
    
    def _get_twitter_data(self, location: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """
        Get data from Twitter
        
        Args:
            location: Location name
            start_date: Start date
            end_date: End date
            
        Returns:
            DataFrame with standardized columns
        """
        # Build query
        keywords = self.get_keywords_for_location(location)
        query = ' OR '.join(keywords)
        
        # Format dates
        start_time = start_date.strftime('%Y-%m-%dT%H:%M:%SZ')
        end_time = end_date.strftime('%Y-%m-%dT%H:%M:%SZ')
        
        # Build request
        params = {
            'query': query,
            'start_time': start_time,
            'end_time': end_time,
            'max_results': 100,  # Maximum allowed
            'tweet.fields': 'created_at,author_id,public_metrics,geo',
            'expansions': 'author_id,geo.place_id',
            'user.fields': 'name,username,location',
            'place.fields': 'country,full_name,geo,name'
        }
        
        try:
            # Make request
            url = f"{self._base_url}/tweets/search/recent"
            response = requests.get(url, params=params, headers=self._headers)
            response.raise_for_status()
            
            # Parse response
            data = response.json()
            
            # Check if there are results
            if 'data' not in data or not data['data']:
                logger.info(f"No Twitter results found for {location}")
                return pd.DataFrame()
            
            # Extract tweets
            tweets = data['data']
            
            # Extract users (for mapping author_id to username)
            users = {user['id']: user for user in data.get('includes', {}).get('users', [])}
            
            # Extract places (for mapping place_id to place name)
            places = {place['id']: place for place in data.get('includes', {}).get('places', [])}
            
            # Convert to DataFrame
            rows = []
            for tweet in tweets:
                # Get tweet date
                try:
                    date = datetime.strptime(tweet.get('created_at', ''), '%Y-%m-%dT%H:%M:%S.%fZ')
                except:
                    try:
                        date = datetime.strptime(tweet.get('created_at', ''), '%Y-%m-%dT%H:%M:%SZ')
                    except:
                        date = datetime.now()
                
                # Get user info
                author_id = tweet.get('author_id', '')
                user = users.get(author_id, {})
                username = user.get('username', '')
                user_name = user.get('name', '')
                user_location = user.get('location', '')
                
                # Get place info
                place_id = tweet.get('geo', {}).get('place_id', '')
                place = places.get(place_id, {})
                place_name = place.get('full_name', '')
                
                # Get metrics
                metrics = tweet.get('public_metrics', {})
                retweet_count = metrics.get('retweet_count', 0)
                reply_count = metrics.get('reply_count', 0)
                like_count = metrics.get('like_count', 0)
                
                # Calculate activity level
                activity_level = retweet_count + reply_count + like_count
                
                # Create row
                row = {
                    'Source': self.source_name,
                    'Date': date,
                    'Content': tweet.get('text', ''),
                    'ID': tweet.get('id', ''),
                    'Author': f"{user_name} (@{username})",
                    'Author_Location': user_location,
                    'Place': place_name,
                    'Location': location,
                    'Retweets': retweet_count,
                    'Replies': reply_count,
                    'Likes': like_count,
                    'Sentiment': 0.0,  # Placeholder
                    'Activity_Level': activity_level
                }
                
                rows.append(row)
            
            # Create DataFrame
            df = pd.DataFrame(rows)
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data from Twitter: {str(e)}")
            return pd.DataFrame()
    
    def _get_reddit_data(self, location: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """
        Get data from Reddit
        
        Args:
            location: Location name
            start_date: Start date
            end_date: End date
            
        Returns:
            DataFrame with standardized columns
        """
        # Build query
        keywords = self.get_keywords_for_location(location)
        query = ' OR '.join(keywords)
        
        # Convert dates to timestamps
        start_timestamp = int(start_date.timestamp())
        end_timestamp = int(end_date.timestamp())
        
        # Build request
        params = {
            'q': query,
            'sort': 'relevance',
            'limit': 100,
            't': 'all'
        }
        
        try:
            # Make request
            url = f"{self._base_url}/search"
            response = requests.get(url, params=params, headers=self._headers)
            response.raise_for_status()
            
            # Parse response
            data = response.json()
            
            # Check if there are results
            if 'data' not in data or 'children' not in data['data']:
                logger.info(f"No Reddit results found for {location}")
                return pd.DataFrame()
            
            # Extract posts
            posts = [post['data'] for post in data['data']['children']]
            
            # Filter by date
            filtered_posts = [
                post for post in posts 
                if 'created_utc' in post and 
                start_timestamp <= post['created_utc'] <= end_timestamp
            ]
            
            # Convert to DataFrame
            rows = []
            for post in filtered_posts:
                # Get post date
                date = datetime.fromtimestamp(post.get('created_utc', 0))
                
                # Get content
                title = post.get('title', '')
                selftext = post.get('selftext', '')
                content = f"{title}\n\n{selftext}"
                
                # Get metrics
                score = post.get('score', 0)
                num_comments = post.get('num_comments', 0)
                upvote_ratio = post.get('upvote_ratio', 0.5)
                
                # Calculate activity level
                activity_level = score + num_comments
                
                # Create row
                row = {
                    'Source': self.source_name,
                    'Date': date,
                    'Content': content,
                    'ID': post.get('id', ''),
                    'Author': f"u/{post.get('author', '')}",
                    'Subreddit': f"r/{post.get('subreddit', '')}",
                    'URL': post.get('url', ''),
                    'Location': location,
                    'Score': score,
                    'Comments': num_comments,
                    'Upvote_Ratio': upvote_ratio,
                    'Sentiment': 0.0,  # Placeholder
                    'Activity_Level': activity_level
                }
                
                rows.append(row)
            
            # Create DataFrame
            df = pd.DataFrame(rows)
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data from Reddit: {str(e)}")
            return pd.DataFrame()
    
    def _get_facebook_data(self, location: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """
        Get data from Facebook
        
        Args:
            location: Location name
            start_date: Start date
            end_date: End date
            
        Returns:
            DataFrame with standardized columns
        """
        # For demonstration purposes - implementation would be similar to other platforms
        # but using Facebook Graph API which requires specific permissions
        
        logger.warning("Facebook API implementation is placeholder only - would require specific permissions")
        
        # Return empty DataFrame with expected columns
        return pd.DataFrame(columns=[
            'Source', 'Date', 'Content', 'ID', 'Author', 'Page', 
            'Location', 'Likes', 'Comments', 'Shares', 'Sentiment', 'Activity_Level'
        ])