"""
Data Source Integrator
---------------------
This module provides a unified interface for integrating and managing
various data sources for the NyxTrace platform.
"""

import os
import json
import logging
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Union, Tuple
from enum import Enum
import requests
from bs4 import BeautifulSoup
import feedparser
from pymongo import MongoClient
import boto3
import hashlib
import time
import re

from .base_source import DataSource

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('data_source_integrator')


class SourceType(Enum):
    """Enumeration of supported data source types"""
    WEB = "web"
    API = "api"
    FEED = "feed"
    DATABASE = "database"
    FILE = "file"
    SOCIAL = "social"


class SourceStatus(Enum):
    """Enumeration of possible data source statuses"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    ERROR = "error"
    MAINTENANCE = "maintenance"


class DataSourceIntegrator:
    """
    Main class for integrating and managing data sources
    
    This class provides methods for:
    - Adding and removing data sources
    - Configuring data sources
    - Retrieving data from multiple sources
    - Monitoring source health and status
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize the Data Source Integrator
        
        Args:
            config_path: Optional path to configuration file
        """
        self.sources: Dict[str, DataSource] = {}
        self.source_configs: Dict[str, Dict[str, Any]] = {}
        self.source_status: Dict[str, SourceStatus] = {}
        self.source_health: Dict[str, Dict[str, float]] = {}
        self.last_update: Dict[str, datetime] = {}
        
        # Load configuration if provided
        if config_path and os.path.exists(config_path):
            self._load_config(config_path)
        
        logger.info("Data Source Integrator initialized")
    
    def add_source(self, source: DataSource, config: Dict[str, Any]) -> str:
        """
        Add a new data source
        
        Args:
            source: DataSource instance
            config: Configuration for the data source
            
        Returns:
            Source ID
        """
        source_id = f"{source.source_type}_{source.source_name}_{int(time.time())}"
        
        try:
            # Configure the source
            source.configure(config)
            
            # Test connection
            if not source.test_connection():
                logger.warning(f"Source {source_id} failed connection test")
                self.source_status[source_id] = SourceStatus.ERROR
            else:
                logger.info(f"Source {source_id} added successfully")
                self.source_status[source_id] = SourceStatus.ACTIVE
            
            # Add to sources
            self.sources[source_id] = source
            self.source_configs[source_id] = config
            self.last_update[source_id] = datetime.now()
            self.source_health[source_id] = {
                "uptime": 1.0,
                "response_time": 0.0,
                "reliability": 1.0
            }
            
            return source_id
        
        except Exception as e:
            logger.error(f"Error adding source {source_id}: {str(e)}")
            self.source_status[source_id] = SourceStatus.ERROR
            raise
    
    def remove_source(self, source_id: str) -> bool:
        """
        Remove a data source
        
        Args:
            source_id: ID of the source to remove
            
        Returns:
            True if successful, False otherwise
        """
        if source_id in self.sources:
            del self.sources[source_id]
            del self.source_configs[source_id]
            del self.source_status[source_id]
            del self.source_health[source_id]
            del self.last_update[source_id]
            logger.info(f"Source {source_id} removed successfully")
            return True
        else:
            logger.warning(f"Source {source_id} not found")
            return False
    
    def get_data(self, location: str, start_date: datetime, end_date: datetime, 
                 source_types: Optional[List[SourceType]] = None,
                 source_ids: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Get data from multiple sources for a specific location and date range
        
        Args:
            location: Name of the location to get data for
            start_date: Start of date range
            end_date: End of date range
            source_types: Optional list of source types to include
            source_ids: Optional list of specific source IDs to include
            
        Returns:
            DataFrame combining data from all matching sources
        """
        all_data = []
        
        for source_id, source in self.sources.items():
            # Skip if not in requested source_ids (if specified)
            if source_ids and source_id not in source_ids:
                continue
            
            # Skip if not in requested source_types (if specified)
            if source_types and SourceType(source.source_type) not in source_types:
                continue
            
            # Skip inactive sources
            if self.source_status.get(source_id) != SourceStatus.ACTIVE:
                continue
            
            try:
                # Measure response time
                start_time = time.time()
                source_data = source.get_data(location, start_date, end_date)
                response_time = time.time() - start_time
                
                # Update source health
                self._update_source_health(source_id, response_time, True)
                
                # Add source ID to data
                source_data['source_id'] = source_id
                
                # Append to all data
                all_data.append(source_data)
                
                logger.info(f"Retrieved {len(source_data)} records from {source_id}")
                
            except Exception as e:
                logger.error(f"Error retrieving data from {source_id}: {str(e)}")
                self._update_source_health(source_id, 0, False)
        
        # Combine all data
        if all_data:
            combined_data = pd.concat(all_data, ignore_index=True)
            return combined_data
        else:
            # Return empty DataFrame with expected columns
            return pd.DataFrame(columns=['Source', 'Date', 'Content', 'Sentiment', 'Activity_Level', 'source_id'])
    
    def get_source_health(self) -> pd.DataFrame:
        """
        Get the health status of all data sources
        
        Returns:
            DataFrame with health metrics for each source
        """
        health_data = []
        
        for source_id in self.sources:
            source_info = {
                'source_id': source_id,
                'source_name': self.sources[source_id].source_name,
                'source_type': self.sources[source_id].source_type,
                'status': self.source_status.get(source_id, SourceStatus.INACTIVE).value,
                'uptime': self.source_health.get(source_id, {}).get('uptime', 0),
                'response_time': self.source_health.get(source_id, {}).get('response_time', 0),
                'reliability': self.source_health.get(source_id, {}).get('reliability', 0),
                'last_update': self.last_update.get(source_id, datetime.min).strftime('%Y-%m-%d %H:%M:%S')
            }
            health_data.append(source_info)
        
        return pd.DataFrame(health_data)
    
    def get_source_info(self) -> pd.DataFrame:
        """
        Get information about all data sources
        
        Returns:
            DataFrame with information about each source
        """
        source_info = []
        
        for source_id in self.sources:
            info = {
                'source_id': source_id,
                'source_name': self.sources[source_id].source_name,
                'source_type': self.sources[source_id].source_type,
                'status': self.source_status.get(source_id, SourceStatus.INACTIVE).value,
                'last_update': self.last_update.get(source_id, datetime.min).strftime('%Y-%m-%d %H:%M:%S')
            }
            source_info.append(info)
        
        return pd.DataFrame(source_info)
    
    def _update_source_health(self, source_id: str, response_time: float, success: bool) -> None:
        """
        Update health metrics for a data source
        
        Args:
            source_id: ID of the source
            response_time: Measured response time
            success: Whether the request was successful
        """
        if source_id not in self.source_health:
            self.source_health[source_id] = {
                "uptime": 1.0 if success else 0.0,
                "response_time": response_time,
                "reliability": 1.0 if success else 0.0
            }
            return
        
        # Update metrics with exponential moving average
        alpha = 0.3  # Weight for new observations
        
        # Update uptime (percentage of successful requests)
        current_uptime = self.source_health[source_id]["uptime"]
        new_uptime = current_uptime * (1 - alpha) + (1 if success else 0) * alpha
        self.source_health[source_id]["uptime"] = new_uptime
        
        # Update response time (only if successful)
        if success:
            current_response_time = self.source_health[source_id]["response_time"]
            new_response_time = current_response_time * (1 - alpha) + response_time * alpha
            self.source_health[source_id]["response_time"] = new_response_time
        
        # Update reliability (combination of uptime and response time)
        response_time_factor = 1.0
        if success and response_time > 0:
            # Convert response time to a factor between 0 and 1 (lower is better)
            response_time_factor = min(1.0, 1.0 / (1.0 + response_time))
        
        reliability = new_uptime * 0.7 + response_time_factor * 0.3
        self.source_health[source_id]["reliability"] = reliability
        
        # Update source status based on health
        if reliability < 0.3:
            self.source_status[source_id] = SourceStatus.ERROR
        elif reliability < 0.7:
            self.source_status[source_id] = SourceStatus.MAINTENANCE
        else:
            self.source_status[source_id] = SourceStatus.ACTIVE
        
        # Update last update timestamp
        self.last_update[source_id] = datetime.now()
    
    def test_all_sources(self) -> Dict[str, bool]:
        """
        Test connection to all data sources
        
        Returns:
            Dictionary mapping source IDs to test results
        """
        results = {}
        
        for source_id, source in self.sources.items():
            try:
                result = source.test_connection()
                results[source_id] = result
                
                # Update source status
                if result:
                    self.source_status[source_id] = SourceStatus.ACTIVE
                else:
                    self.source_status[source_id] = SourceStatus.ERROR
                
            except Exception as e:
                logger.error(f"Error testing source {source_id}: {str(e)}")
                results[source_id] = False
                self.source_status[source_id] = SourceStatus.ERROR
        
        return results
    
    def _load_config(self, config_path: str) -> None:
        """
        Load configuration from file
        
        Args:
            config_path: Path to configuration file
        """
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
            
            # Process configuration data
            logger.info(f"Loaded configuration from {config_path}")
            # TODO: Initialize sources from configuration
            
        except Exception as e:
            logger.error(f"Error loading configuration: {str(e)}")
    
    def save_config(self, config_path: str) -> bool:
        """
        Save current configuration to file
        
        Args:
            config_path: Path to save configuration
            
        Returns:
            True if successful, False otherwise
        """
        try:
            config = {
                "sources": {
                    source_id: {
                        "type": source.source_type,
                        "name": source.source_name,
                        "config": self.source_configs[source_id]
                    } for source_id, source in self.sources.items()
                },
                "last_updated": datetime.now().isoformat()
            }
            
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=2)
            
            logger.info(f"Saved configuration to {config_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error saving configuration: {str(e)}")
            return False


class WebScraperSource(DataSource):
    """Data source that scrapes web content"""
    
    def __init__(self, name: str, base_url: str, selectors: Dict[str, str] = None,
                 use_trafilatura: bool = True):
        """
        Initialize web scraper source
        
        Args:
            name: Name of the source
            base_url: Base URL for the source
            selectors: Dictionary of CSS selectors for content extraction
            use_trafilatura: Whether to use Trafilatura for content extraction
        """
        self._name = name
        self._base_url = base_url
        self._selectors = selectors or {}
        self._use_trafilatura = use_trafilatura
        self._session = requests.Session()
        self._headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        # Initialize cache
        self._cache: Dict[str, Dict[str, Any]] = {}
    
    @property
    def source_name(self) -> str:
        return self._name
    
    @property
    def source_type(self) -> str:
        return SourceType.WEB.value
    
    def get_data(self, location: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """
        Retrieve data for a specific location and date range
        
        Args:
            location: Name of the location to get data for
            start_date: Start of date range
            end_date: End of date range
            
        Returns:
            DataFrame with standardized columns
        """
        # Generate URL for the location
        url = self._get_url_for_location(location)
        
        # Fetch content
        content = self._fetch_content(url)
        
        # Extract data from content
        data = self._extract_data(content, url, location, start_date, end_date)
        
        return data
    
    def get_keywords_for_location(self, location: str) -> List[str]:
        """Get keywords for a location"""
        # This would be customized per source
        return [location, location.lower(), location.replace(" ", "-").lower()]
    
    def configure(self, config: Dict[str, Any]) -> None:
        """Configure the web scraper"""
        if 'headers' in config:
            self._headers.update(config['headers'])
        
        if 'selectors' in config:
            self._selectors.update(config['selectors'])
        
        if 'use_trafilatura' in config:
            self._use_trafilatura = config['use_trafilatura']
    
    def test_connection(self) -> bool:
        """Test connection to the web source"""
        try:
            response = self._session.get(
                self._base_url,
                headers=self._headers,
                timeout=10
            )
            return response.status_code == 200
        except Exception as e:
            logger.error(f"Connection test failed for {self.source_name}: {str(e)}")
            return False
    
    def _get_url_for_location(self, location: str) -> str:
        """
        Generate URL for a specific location
        
        Args:
            location: Location name
            
        Returns:
            URL for the location
        """
        # Basic implementation - override in subclasses for specific sources
        location_slug = location.lower().replace(" ", "-")
        return f"{self._base_url}/search?q={location_slug}"
    
    def _fetch_content(self, url: str) -> str:
        """
        Fetch content from URL
        
        Args:
            url: URL to fetch
            
        Returns:
            HTML content
        """
        # Check cache
        cache_key = hashlib.md5(url.encode()).hexdigest()
        if cache_key in self._cache:
            cache_entry = self._cache[cache_key]
            cache_time = cache_entry.get('time', datetime.min)
            # Use cache if less than 1 hour old
            if (datetime.now() - cache_time).total_seconds() < 3600:
                return cache_entry['content']
        
        # Fetch content
        try:
            response = self._session.get(url, headers=self._headers, timeout=10)
            response.raise_for_status()
            content = response.text
            
            # Update cache
            self._cache[cache_key] = {
                'content': content,
                'time': datetime.now()
            }
            
            return content
        except Exception as e:
            logger.error(f"Error fetching content from {url}: {str(e)}")
            return ""
    
    def _extract_data(self, content: str, url: str, location: str, 
                      start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """
        Extract data from content
        
        Args:
            content: HTML content
            url: Source URL
            location: Location name
            start_date: Start date
            end_date: End date
            
        Returns:
            DataFrame with extracted data
        """
        if not content:
            return pd.DataFrame(columns=['Source', 'Date', 'Content', 'Sentiment', 'Activity_Level'])
        
        # Parse HTML
        soup = BeautifulSoup(content, 'html.parser')
        
        # Extract data based on approach
        if self._use_trafilatura:
            try:
                import trafilatura
                extracted_text = trafilatura.extract(content)
                return self._create_dataframe_from_text(extracted_text, url, location)
            except ImportError:
                logger.warning("Trafilatura not available, using BeautifulSoup instead")
        
        # Use BeautifulSoup with selectors
        return self._extract_content_with_bs4(soup, url)
    
    def _extract_content_with_bs4(self, soup: BeautifulSoup, url: str) -> Dict[str, Any]:
        """
        Extract content using BeautifulSoup
        
        Args:
            soup: BeautifulSoup object
            url: Source URL
            
        Returns:
            Dictionary with extracted content
        """
        results = []
        
        # Extract content based on selectors
        if 'article' in self._selectors:
            articles = soup.select(self._selectors['article'])
            for article in articles:
                item = {
                    'Source': self.source_name,
                    'URL': url,
                    'Date': datetime.now()  # Default to current date
                }
                
                # Extract title
                if 'title' in self._selectors:
                    title_elem = article.select_one(self._selectors['title'])
                    if title_elem:
                        item['Title'] = title_elem.get_text().strip()
                
                # Extract content
                if 'content' in self._selectors:
                    content_elem = article.select_one(self._selectors['content'])
                    if content_elem:
                        item['Content'] = content_elem.get_text().strip()
                
                # Extract date
                if 'date' in self._selectors:
                    date_elem = article.select_one(self._selectors['date'])
                    if date_elem:
                        date_text = date_elem.get_text().strip()
                        # Try to parse date
                        try:
                            item['Date'] = self._parse_date(date_text)
                        except:
                            pass  # Keep default date
                
                results.append(item)
        else:
            # No article selector, extract page-level content
            item = {
                'Source': self.source_name,
                'URL': url,
                'Date': datetime.now()
            }
            
            # Extract title from meta
            title_meta = soup.select_one('meta[property="og:title"]')
            if title_meta:
                item['Title'] = title_meta.get('content', '')
            else:
                title_elem = soup.select_one('title')
                if title_elem:
                    item['Title'] = title_elem.get_text().strip()
            
            # Extract main content
            main_content = []
            for p in soup.select('p'):
                text = p.get_text().strip()
                if len(text) > 100:  # Only longer paragraphs
                    main_content.append(text)
            
            item['Content'] = '\n\n'.join(main_content)
            results.append(item)
        
        # Convert to DataFrame
        df = pd.DataFrame(results)
        
        # Add sentiment and activity level columns
        if len(df) > 0:
            # Placeholder for sentiment analysis
            df['Sentiment'] = 0.0
            df['Activity_Level'] = 1.0
        
        return df
    
    def _create_dataframe_from_text(self, text: str, url: str, location: str) -> pd.DataFrame:
        """
        Create DataFrame from extracted text
        
        Args:
            text: Extracted text
            url: Source URL
            location: Location name
            
        Returns:
            DataFrame with extracted data
        """
        if not text:
            return pd.DataFrame(columns=['Source', 'Date', 'Content', 'Sentiment', 'Activity_Level'])
        
        # Create a single row DataFrame
        data = {
            'Source': [self.source_name],
            'Date': [datetime.now()],
            'Content': [text],
            'URL': [url],
            'Location': [location],
            'Sentiment': [0.0],  # Placeholder
            'Activity_Level': [1.0]  # Placeholder
        }
        
        return pd.DataFrame(data)
    
    def _parse_date(self, date_text: str) -> datetime:
        """
        Parse date from text
        
        Args:
            date_text: Date text
            
        Returns:
            Parsed datetime
        """
        # This is a placeholder - would need to implement various date parsing strategies
        # based on the format of the date text from the particular source
        
        # Try common formats
        formats = [
            '%Y-%m-%d',
            '%d/%m/%Y',
            '%m/%d/%Y',
            '%B %d, %Y',
            '%d %B %Y',
            '%Y-%m-%dT%H:%M:%S',
            '%Y-%m-%d %H:%M:%S'
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(date_text, fmt)
            except ValueError:
                continue
        
        # Try to handle relative dates
        if 'ago' in date_text.lower():
            # Handle "X days ago", "X hours ago", etc.
            match = re.search(r'(\d+)\s+(minute|hour|day|week|month|year)s?\s+ago', date_text.lower())
            if match:
                value = int(match.group(1))
                unit = match.group(2)
                
                if unit == 'minute':
                    return datetime.now() - timedelta(minutes=value)
                elif unit == 'hour':
                    return datetime.now() - timedelta(hours=value)
                elif unit == 'day':
                    return datetime.now() - timedelta(days=value)
                elif unit == 'week':
                    return datetime.now() - timedelta(weeks=value)
                elif unit == 'month':
                    return datetime.now() - timedelta(days=value * 30)
                elif unit == 'year':
                    return datetime.now() - timedelta(days=value * 365)
        
        # If nothing worked, raise an exception
        raise ValueError(f"Could not parse date: {date_text}")


# More data source classes could be implemented here:
# - APIDatasource
# - FeedDataSource
# - SocialMediaDataSource
# - etc.