"""
OSINT Analysis Module
-------------------
This module provides tools for analyzing open-source intelligence (OSINT) data
with a focus on emotional content, sentiment analysis, and key insights extraction.
"""
import pandas as pd
import numpy as np
import re
from typing import List, Dict, Any, Tuple
from collections import Counter


class OSINTAnalyzer:
    """Class for analyzing OSINT data from various sources"""
    
    def __init__(self):
        # Emotional state keyword dictionaries based on the OSINT document
        self.emotional_keywords = {
            'anger': [
                'outrage', 'furious', 'angry', 'disgusted', 'unacceptable', 
                'scandal', 'boycott', 'protest', 'shameful', 'vent', 'rant',
                'cancel culture', 'outrage fatigue', 'moral panic', 'rage-bait',
                'triggered', 'virtue signaling', 'keyboard warrior', 'calling out',
                'backlash', 'outrage economy', 'tone policing', 'echo chamber'
            ],
            'fear': [
                'scared', 'anxious', 'nervous', 'afraid', 'concerned', 'worried',
                'terrified', 'panic', 'stress', 'fearful', 'existential dread',
                'what if', 'doomscrolling', 'paranoia', 'impending doom',
                'hypervigilance', 'fear-mongering', 'safety net', 'uncertainty',
                'false flag', 'trust issues', 'catastrophizing'
            ],
            'excitement': [
                'excited', 'thrilled', 'proud', 'elated', 'overjoyed', 'achieved',
                'celebrating', 'honored', 'pumped', 'enthusiastic', 'humblebrag',
                'milestone', 'proud moment', 'bucket list', 'achievement unlocked',
                'on top of the world', 'goal achieved', 'living the dream',
                'dream come true', 'accomplished', 'winning at life', 'recognition'
            ]
        }
        
        # Personal pronoun phrases indicating subjective content
        self.pronoun_phrases = [
            'i am', 'we are', 'i must', 'we must', 'they are', 'they must'
        ]
        
        # Common emoji patterns for emotional states
        self.emoji_patterns = {
            'anger': [r'😠', r'😡', r'🤬', r'💢', r'👿', r'😤', r'🔥'],
            'fear': [r'😨', r'😰', r'😱', r'😳', r'😬', r'😥', r'😢', r'😭'],
            'excitement': [r'😀', r'😃', r'😄', r'😁', r'🤩', r'🥳', r'😊', r'😍', r'🙌', r'👏', r'🎉']
        }
        
    def analyze_text(self, text: str) -> Dict[str, Any]:
        """
        Analyze a text for emotional content and key insights
        
        Args:
            text: The text content to analyze
            
        Returns:
            Dictionary with analysis results including:
            - dominant_emotion: The most prevalent emotional state
            - emotion_scores: Scores for different emotional states
            - key_phrases: Important phrases extracted from the text
            - subject_indicators: Phrases indicating the subject of discussion
            - entities: Extracted entities (locations, organizations, etc.)
        """
        if not text or not isinstance(text, str):
            return {
                'dominant_emotion': None,
                'emotion_scores': {},
                'key_phrases': [],
                'subject_indicators': [],
                'entities': []
            }
            
        # Normalize text
        text_lower = text.lower()
        
        # Calculate emotion scores
        emotion_scores = {}
        for emotion, keywords in self.emotional_keywords.items():
            score = sum(text_lower.count(keyword) for keyword in keywords)
            
            # Add emoji contributions
            for pattern in self.emoji_patterns.get(emotion, []):
                score += len(re.findall(pattern, text))
                
            emotion_scores[emotion] = score
            
        # Get dominant emotion
        if any(emotion_scores.values()):
            dominant_emotion = max(emotion_scores.items(), key=lambda x: x[1])[0]
        else:
            dominant_emotion = 'neutral'
            
        # Extract key phrases (sentences with emotional keywords)
        sentences = re.split(r'[.!?]+', text)
        key_phrases = []
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
                
            # Check if the sentence contains emotional keywords or pronouns
            has_emotion = any(keyword in sentence.lower() for emotion, keywords in 
                            self.emotional_keywords.items() for keyword in keywords)
            has_pronoun = any(phrase in sentence.lower() for phrase in self.pronoun_phrases)
            
            if has_emotion or has_pronoun:
                if len(sentence) > 10:  # Avoid very short fragments
                    key_phrases.append(sentence)
        
        # Find subject indicators (what is being discussed)
        subject_indicators = []
        for pronoun in self.pronoun_phrases:
            pattern = fr'\b{re.escape(pronoun)}\b\s+([^,.!?;]+)'
            matches = re.findall(pattern, text_lower)
            subject_indicators.extend(matches)
            
        # Basic entity extraction (very simplified - would use NER in production)
        # Look for capitalized words that could be names, organizations, locations
        entity_pattern = r'\b[A-Z][a-zA-Z]+\b'
        potential_entities = re.findall(entity_pattern, text)
        # Filter out common words that might be capitalized
        common_words = ['I', 'The', 'A', 'An', 'And', 'But', 'Or', 'For', 'To', 'This', 'That']
        entities = [entity for entity in potential_entities if entity not in common_words]
        
        return {
            'dominant_emotion': dominant_emotion,
            'emotion_scores': emotion_scores,
            'key_phrases': key_phrases[:5],  # Return top 5 key phrases
            'subject_indicators': subject_indicators[:3],  # Return top 3 subject indicators
            'entities': list(set(entities))[:10]  # Return up to 10 unique entities
        }
        
    def analyze_dataframe(self, df: pd.DataFrame, content_column: str = 'Content') -> pd.DataFrame:
        """
        Analyze content in a dataframe and add analysis columns
        
        Args:
            df: DataFrame with content to analyze
            content_column: Name of the column containing text content
            
        Returns:
            DataFrame with additional analysis columns
        """
        if df.empty or content_column not in df.columns:
            return df
            
        # Create a copy to avoid modifying the original
        result_df = df.copy()
        
        # Apply analysis to each row
        analysis_results = []
        for text in result_df[content_column]:
            if pd.isna(text) or not isinstance(text, str):
                analysis_results.append({
                    'dominant_emotion': None,
                    'emotion_scores': {},
                    'key_phrases': [],
                    'subject_indicators': [],
                    'entities': []
                })
            else:
                analysis_results.append(self.analyze_text(text))
                
        # Add analysis columns
        result_df['dominant_emotion'] = [result['dominant_emotion'] for result in analysis_results]
        result_df['emotion_scores'] = [result['emotion_scores'] for result in analysis_results]
        result_df['key_phrases'] = [result['key_phrases'] for result in analysis_results]
        result_df['subject_indicators'] = [result['subject_indicators'] for result in analysis_results]
        result_df['entities'] = [result['entities'] for result in analysis_results]
        
        # Add simplified sentiment score (-1 to 1)
        def calculate_sentiment(row):
            if row['dominant_emotion'] == 'anger':
                return -0.7 + np.random.uniform(-0.3, 0.3)  # Negative with some variation
            elif row['dominant_emotion'] == 'fear':
                return -0.4 + np.random.uniform(-0.3, 0.3)  # Somewhat negative
            elif row['dominant_emotion'] == 'excitement':
                return 0.6 + np.random.uniform(-0.3, 0.3)   # Positive with some variation
            else:
                return np.random.uniform(-0.2, 0.2)  # Neutral with slight variation
                
        result_df['Sentiment'] = result_df.apply(calculate_sentiment, axis=1)
        
        # Calculate activity level based on content length and emotional intensity
        def calculate_activity(row):
            # Start with a base level proportional to content length (if available)
            content = row.get(content_column, '')
            if pd.isna(content) or not isinstance(content, str):
                return 0
                
            # Base activity on content length
            base_activity = min(100, len(content) / 100)
            
            # Adjust based on emotional intensity
            emotion_scores = row.get('emotion_scores', {})
            if emotion_scores:
                emotional_intensity = sum(emotion_scores.values())
                # Scale up activity based on emotional intensity
                activity_multiplier = 1 + (emotional_intensity / 10)
                return min(100, base_activity * activity_multiplier)
            
            return base_activity
            
        result_df['Activity_Level'] = result_df.apply(calculate_activity, axis=1)
        
        return result_df
        
    def generate_insights_report(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Generate high-level insights from analyzed content
        
        Args:
            df: DataFrame with analysis results
            
        Returns:
            Dictionary with insights including:
            - dominant_emotions: Overall dominant emotions
            - key_entities: Frequently mentioned entities
            - emotional_trends: Trends in emotional content over time
            - subject_summary: Summary of main discussion subjects
        """
        if df.empty or 'dominant_emotion' not in df.columns:
            return {
                'dominant_emotions': {},
                'key_entities': [],
                'emotional_trends': {},
                'subject_summary': []
            }
            
        # Count dominant emotions
        emotion_counts = Counter(df['dominant_emotion'].dropna())
        total_emotions = sum(emotion_counts.values())
        dominant_emotions = {
            emotion: {
                'count': count,
                'percentage': round((count / total_emotions) * 100, 1) if total_emotions else 0
            }
            for emotion, count in emotion_counts.most_common()
        }
        
        # Extract frequent entities
        all_entities = []
        for entities in df['entities'].dropna():
            if isinstance(entities, list):
                all_entities.extend(entities)
        
        key_entities = [entity for entity, count in Counter(all_entities).most_common(10)]
        
        # Extract subject summary
        all_subjects = []
        for subjects in df['subject_indicators'].dropna():
            if isinstance(subjects, list):
                all_subjects.extend(subjects)
                
        subject_summary = [subj for subj, count in Counter(all_subjects).most_common(5)]
        
        # Calculate emotional trends over time (if Date column exists)
        emotional_trends = {}
        if 'Date' in df.columns:
            # Ensure Date is datetime
            if not pd.api.types.is_datetime64_any_dtype(df['Date']):
                date_df = df.copy()
                date_df['Date'] = pd.to_datetime(date_df['Date'], errors='coerce')
            else:
                date_df = df
                
            # Group by date and emotion
            date_df = date_df.dropna(subset=['Date', 'dominant_emotion'])
            if not date_df.empty:
                # Extract date component only
                date_df['date_only'] = date_df['Date'].dt.date
                
                # Group by date and count emotions
                emotion_by_date = date_df.groupby(['date_only', 'dominant_emotion']).size().unstack(fill_value=0)
                
                # Convert to format suitable for charts
                for emotion in emotion_by_date.columns:
                    emotional_trends[emotion] = {
                        'dates': [str(d) for d in emotion_by_date.index],
                        'counts': emotion_by_date[emotion].tolist()
                    }
        
        return {
            'dominant_emotions': dominant_emotions,
            'key_entities': key_entities,
            'emotional_trends': emotional_trends,
            'subject_summary': subject_summary
        }