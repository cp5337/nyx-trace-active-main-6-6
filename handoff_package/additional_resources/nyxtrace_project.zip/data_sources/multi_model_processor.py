"""
Multi-model Content Processing (MCP) Module
------------------------------------------
This module integrates multiple AI models (Anthropic/Claude, OpenAI, Grok, Gemini) 
for advanced content analysis of news articles and web content.

Key capabilities:
1. Entity extraction (people, organizations, locations)
2. Semantic keyword identification
3. Incident classification
4. Threat intelligence analysis
5. Cross-model validation for higher accuracy

The module uses model-specific API clients and implements fallback mechanisms
to ensure continuous operation even if one API service is unavailable.
"""
import os
import json
import time
from typing import Dict, List, Any, Optional, Tuple, Union
import pandas as pd
from datetime import datetime

# Model-specific client imports - will be used conditionally based on available API keys
try:
    from anthropic import Anthropic
    ANTHROPIC_AVAILABLE = True
except (ImportError, Exception):
    ANTHROPIC_AVAILABLE = False
    
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except (ImportError, Exception):
    OPENAI_AVAILABLE = False

# Constants for model selection
CLAUDE_MODEL = "claude-3-5-sonnet-20241022" # the newest Anthropic model is "claude-3-5-sonnet-20241022" which was released October 22, 2024
GPT_MODEL = "gpt-4o" # the newest OpenAI model is "gpt-4o" which was released May 13, 2024
GEMINI_MODEL = "gemini-pro"
GROK_MODEL = "grok-2-1212"

class MultiModelProcessor:
    """
    Integrates multiple AI models for comprehensive content analysis
    with fallback mechanisms and result validation
    """
    
    def __init__(self):
        # Initialize clients as None - they'll be created on demand
        self.anthropic_client = None
        self.openai_client = None
        self.xai_client = None  # For Grok
        self.gemini_client = None
        
        # Track available models
        self.available_models = []
        
        # Cache for processed results to avoid duplicate API calls
        self.cache = {}
        
        # Initialize API keys from environment
        self._initialize_api_keys()
    
    def _initialize_api_keys(self):
        """Initialize API clients based on available keys"""
        # Anthropic/Claude
        if os.environ.get('ANTHROPIC_API_KEY') and ANTHROPIC_AVAILABLE:
            try:
                self.anthropic_client = Anthropic(api_key=os.environ.get('ANTHROPIC_API_KEY'))
                self.available_models.append("claude")
            except Exception as e:
                print(f"Failed to initialize Anthropic client: {str(e)}")
        
        # OpenAI
        if os.environ.get('OPENAI_API_KEY') and OPENAI_AVAILABLE:
            try:
                self.openai_client = OpenAI(api_key=os.environ.get('OPENAI_API_KEY'))
                self.available_models.append("openai")
            except Exception as e:
                print(f"Failed to initialize OpenAI client: {str(e)}")
        
        # xAI Grok
        if os.environ.get('XAI_API_KEY') and OPENAI_AVAILABLE:
            try:
                self.xai_client = OpenAI(
                    base_url="https://api.x.ai/v1", 
                    api_key=os.environ.get('XAI_API_KEY')
                )
                self.available_models.append("grok")
            except Exception as e:
                print(f"Failed to initialize xAI client: {str(e)}")
                
        print(f"Initialized with models: {', '.join(self.available_models)}")
        if not self.available_models:
            print("WARNING: No AI models available. Please provide API keys.")
            
    def analyze_content(self, content: str, analysis_type: str = "complete") -> Dict[str, Any]:
        """
        Analyze content using available models with fallback mechanisms
        
        Args:
            content: The text content to analyze
            analysis_type: Type of analysis to perform (complete, entities, keywords, incidents, cyber)
            
        Returns:
            Dictionary with analysis results
        """
        # Generate cache key based on content and analysis type
        cache_key = f"{hash(content)}_{analysis_type}"
        if cache_key in self.cache:
            return self.cache[cache_key]
            
        # Determine which analysis to run
        if analysis_type == "entities":
            result = self._extract_entities(content)
        elif analysis_type == "keywords":
            result = self._extract_keywords(content)
        elif analysis_type == "incidents":
            result = self._classify_incident(content)
        elif analysis_type == "cyber":
            result = self._analyze_cyber_threat(content)
        else:  # "complete"
            result = self._complete_analysis(content)
            
        # Cache result
        self.cache[cache_key] = result
        return result
    
    def _extract_entities(self, content: str) -> Dict[str, List[Dict[str, Any]]]:
        """
        Extract named entities (people, organizations, locations) from content
        
        Args:
            content: Text content to analyze
            
        Returns:
            Dictionary with entity lists by category
        """
        # Try Claude first if available
        if "claude" in self.available_models:
            try:
                prompt = f"""
                Extract named entities from the following text. Focus on People (full names with roles), 
                Organizations (company names, government agencies), and Locations (cities, states, countries).
                
                Return the results as JSON with these keys:
                - people: list of objects with 'name' and 'role' (if available)
                - organizations: list of objects with 'name' and 'type' (if available)
                - locations: list of objects with 'name' and 'type' (city, state, country)
                
                TEXT TO ANALYZE:
                {content}
                """
                
                response = self.anthropic_client.messages.create(
                    model=CLAUDE_MODEL,
                    max_tokens=1000,
                    messages=[
                        {"role": "user", "content": prompt}
                    ]
                )
                
                # Extract JSON from response
                try:
                    # Look for JSON in the content
                    message_content = response.content[0].text
                    json_str = self._extract_json_from_text(message_content)
                    result = json.loads(json_str)
                    return result
                except Exception as e:
                    print(f"Error parsing Claude entity extraction response: {str(e)}")
            
            except Exception as e:
                print(f"Claude entity extraction failed: {str(e)}")
        
        # Fall back to OpenAI if Claude failed or isn't available
        if "openai" in self.available_models:
            try:
                prompt = f"""
                Extract named entities from the following text. Focus on People (full names with roles), 
                Organizations (company names, government agencies), and Locations (cities, states, countries).
                
                Return the results as JSON with these keys:
                - people: list of objects with 'name' and 'role' (if available)
                - organizations: list of objects with 'name' and 'type' (if available)
                - locations: list of objects with 'name' and 'type' (city, state, country)
                
                TEXT TO ANALYZE:
                {content}
                """
                
                response = self.openai_client.chat.completions.create(
                    model=GPT_MODEL,
                    messages=[{"role": "user", "content": prompt}],
                    response_format={"type": "json_object"}
                )
                
                result = json.loads(response.choices[0].message.content)
                return result
                
            except Exception as e:
                print(f"OpenAI entity extraction failed: {str(e)}")
                
        # Fall back to Grok if available
        if "grok" in self.available_models:
            try:
                prompt = f"""
                Extract named entities from the following text. Focus on People (full names with roles), 
                Organizations (company names, government agencies), and Locations (cities, states, countries).
                
                Return the results as JSON with these keys:
                - people: list of objects with 'name' and 'role' (if available)
                - organizations: list of objects with 'name' and 'type' (if available)
                - locations: list of objects with 'name' and 'type' (city, state, country)
                
                TEXT TO ANALYZE:
                {content}
                """
                
                response = self.xai_client.chat.completions.create(
                    model=GROK_MODEL,
                    messages=[{"role": "user", "content": prompt}],
                    response_format={"type": "json_object"}
                )
                
                result = json.loads(response.choices[0].message.content)
                return result
                
            except Exception as e:
                print(f"Grok entity extraction failed: {str(e)}")
        
        # If all models failed, return empty structure
        return {
            "people": [],
            "organizations": [],
            "locations": []
        }
    
    def _extract_keywords(self, content: str) -> Dict[str, Any]:
        """
        Extract semantic keywords and key phrases from content
        
        Args:
            content: Text content to analyze
            
        Returns:
            Dictionary with keywords and key phrases
        """
        # Try available models in sequence
        for model in self.available_models:
            try:
                if model == "claude" and self.anthropic_client:
                    prompt = f"""
                    Extract the most important keywords and key phrases from the following text.
                    Focus on extracting three types of information:
                    
                    1. General keywords (nouns and important terms)
                    2. Key phrases (important multi-word expressions)
                    3. Semantic themes (underlying topics or concepts)
                    
                    Return the result as JSON with these keys:
                    - keywords: list of important single words
                    - key_phrases: list of important phrases
                    - themes: list of thematic concepts
                    
                    TEXT TO ANALYZE:
                    {content}
                    """
                    
                    response = self.anthropic_client.messages.create(
                        model=CLAUDE_MODEL,
                        max_tokens=1000,
                        messages=[
                            {"role": "user", "content": prompt}
                        ]
                    )
                    
                    message_content = response.content[0].text
                    json_str = self._extract_json_from_text(message_content)
                    return json.loads(json_str)
                    
                elif model == "openai" and self.openai_client:
                    prompt = f"""
                    Extract the most important keywords and key phrases from the following text.
                    Focus on extracting three types of information:
                    
                    1. General keywords (nouns and important terms)
                    2. Key phrases (important multi-word expressions)
                    3. Semantic themes (underlying topics or concepts)
                    
                    Return the result as JSON with these keys:
                    - keywords: list of important single words
                    - key_phrases: list of important phrases
                    - themes: list of thematic concepts
                    
                    TEXT TO ANALYZE:
                    {content}
                    """
                    
                    response = self.openai_client.chat.completions.create(
                        model=GPT_MODEL,
                        messages=[{"role": "user", "content": prompt}],
                        response_format={"type": "json_object"}
                    )
                    
                    return json.loads(response.choices[0].message.content)
                    
                elif model == "grok" and self.xai_client:
                    prompt = f"""
                    Extract the most important keywords and key phrases from the following text.
                    Focus on extracting three types of information:
                    
                    1. General keywords (nouns and important terms)
                    2. Key phrases (important multi-word expressions)
                    3. Semantic themes (underlying topics or concepts)
                    
                    Return the result as JSON with these keys:
                    - keywords: list of important single words
                    - key_phrases: list of important phrases
                    - themes: list of thematic concepts
                    
                    TEXT TO ANALYZE:
                    {content}
                    """
                    
                    response = self.xai_client.chat.completions.create(
                        model=GROK_MODEL,
                        messages=[{"role": "user", "content": prompt}],
                        response_format={"type": "json_object"}
                    )
                    
                    return json.loads(response.choices[0].message.content)
                    
            except Exception as e:
                print(f"{model.capitalize()} keyword extraction failed: {str(e)}")
                continue
        
        # If all models failed, return empty structure
        return {
            "keywords": [],
            "key_phrases": [],
            "themes": []
        }
    
    def _classify_incident(self, content: str) -> Dict[str, Any]:
        """
        Classify the type of incident described in the content
        
        Args:
            content: Text content to analyze
            
        Returns:
            Dictionary with incident classification details
        """
        # Define incident types with examples for better classification
        incident_types = {
            "Bomb Threat": "A threat involving explosives or bombs, whether real or hoax.",
            "Device Discovered": "Discovery of explosive devices, suspicious packages, or IEDs.",
            "Device Emplaced": "Actual placement or detonation of explosive devices.",
            "Cyber Attack": "Digital attacks including ransomware, data breaches, or DDoS attacks.",
            "Physical Intrusion": "Unauthorized physical access to secure locations.",
            "Mass Shooting": "Incidents involving firearms and multiple victims.",
            "Infrastructure Attack": "Attacks on critical infrastructure like power grids or water systems.",
            "None": "No specific security incident is described."
        }
        
        # Try available models in sequence
        for model in self.available_models:
            try:
                if model == "claude" and self.anthropic_client:
                    prompt = f"""
                    Analyze the following text and classify what type of security incident it describes.
                    
                    Here are the possible incident types:
                    {json.dumps(incident_types, indent=2)}
                    
                    Return your analysis as JSON with these keys:
                    - incident_type: The most likely incident type from the list above
                    - confidence: A number between 0 and 1 indicating confidence in classification
                    - evidence: Key phrases from the text that support this classification
                    - communication_method: How the threat was communicated (if applicable): Social Media, Email, Phone, Written, Verbal, Automated Phone, or None
                    - is_cyber: Boolean indicating if this is a cyber security incident
                    - is_physical: Boolean indicating if this is a physical security incident
                    
                    TEXT TO ANALYZE:
                    {content}
                    """
                    
                    response = self.anthropic_client.messages.create(
                        model=CLAUDE_MODEL,
                        max_tokens=1000,
                        messages=[
                            {"role": "user", "content": prompt}
                        ]
                    )
                    
                    message_content = response.content[0].text
                    json_str = self._extract_json_from_text(message_content)
                    return json.loads(json_str)
                    
                elif model == "openai" and self.openai_client:
                    prompt = f"""
                    Analyze the following text and classify what type of security incident it describes.
                    
                    Here are the possible incident types:
                    {json.dumps(incident_types, indent=2)}
                    
                    Return your analysis as JSON with these keys:
                    - incident_type: The most likely incident type from the list above
                    - confidence: A number between 0 and 1 indicating confidence in classification
                    - evidence: Key phrases from the text that support this classification
                    - communication_method: How the threat was communicated (if applicable): Social Media, Email, Phone, Written, Verbal, Automated Phone, or None
                    - is_cyber: Boolean indicating if this is a cyber security incident
                    - is_physical: Boolean indicating if this is a physical security incident
                    
                    TEXT TO ANALYZE:
                    {content}
                    """
                    
                    response = self.openai_client.chat.completions.create(
                        model=GPT_MODEL,
                        messages=[{"role": "user", "content": prompt}],
                        response_format={"type": "json_object"}
                    )
                    
                    return json.loads(response.choices[0].message.content)
                    
                elif model == "grok" and self.xai_client:
                    prompt = f"""
                    Analyze the following text and classify what type of security incident it describes.
                    
                    Here are the possible incident types:
                    {json.dumps(incident_types, indent=2)}
                    
                    Return your analysis as JSON with these keys:
                    - incident_type: The most likely incident type from the list above
                    - confidence: A number between 0 and 1 indicating confidence in classification
                    - evidence: Key phrases from the text that support this classification
                    - communication_method: How the threat was communicated (if applicable): Social Media, Email, Phone, Written, Verbal, Automated Phone, or None
                    - is_cyber: Boolean indicating if this is a cyber security incident
                    - is_physical: Boolean indicating if this is a physical security incident
                    
                    TEXT TO ANALYZE:
                    {content}
                    """
                    
                    response = self.xai_client.chat.completions.create(
                        model=GROK_MODEL,
                        messages=[{"role": "user", "content": prompt}],
                        response_format={"type": "json_object"}
                    )
                    
                    return json.loads(response.choices[0].message.content)
                    
            except Exception as e:
                print(f"{model.capitalize()} incident classification failed: {str(e)}")
                continue
        
        # If all models failed, return unknown classification
        return {
            "incident_type": "Unknown",
            "confidence": 0,
            "evidence": [],
            "communication_method": "None",
            "is_cyber": False,
            "is_physical": False
        }
    
    def _analyze_cyber_threat(self, content: str) -> Dict[str, Any]:
        """
        Analyze content specifically for cyber threat intelligence
        
        Args:
            content: Text content to analyze
            
        Returns:
            Dictionary with cyber threat analysis
        """
        # Try available models in sequence
        for model in self.available_models:
            try:
                if model == "claude" and self.anthropic_client:
                    prompt = f"""
                    Analyze the following text for cyber threat intelligence.
                    Extract indicators of compromise (IOCs) and provide a threat assessment.
                    
                    Return your analysis as JSON with these keys:
                    - threat_type: Primary type of cyber threat described (ransomware, phishing, etc.)
                    - severity: Estimated severity (Low, Medium, High, Critical)
                    - iocs: Dictionary of indicators of compromise with these keys:
                      - ip_addresses: List of suspicious IP addresses
                      - domains: List of suspicious domains
                      - hashes: List of file hashes
                      - emails: List of suspicious email addresses
                    - attack_vector: Primary method of attack
                    - targeted_systems: Systems or sectors targeted
                    - mitigations: Suggested mitigations if mentioned
                    
                    TEXT TO ANALYZE:
                    {content}
                    """
                    
                    response = self.anthropic_client.messages.create(
                        model=CLAUDE_MODEL,
                        max_tokens=1500,
                        messages=[
                            {"role": "user", "content": prompt}
                        ]
                    )
                    
                    message_content = response.content[0].text
                    json_str = self._extract_json_from_text(message_content)
                    return json.loads(json_str)
                    
                elif model == "openai" and self.openai_client:
                    prompt = f"""
                    Analyze the following text for cyber threat intelligence.
                    Extract indicators of compromise (IOCs) and provide a threat assessment.
                    
                    Return your analysis as JSON with these keys:
                    - threat_type: Primary type of cyber threat described (ransomware, phishing, etc.)
                    - severity: Estimated severity (Low, Medium, High, Critical)
                    - iocs: Dictionary of indicators of compromise with these keys:
                      - ip_addresses: List of suspicious IP addresses
                      - domains: List of suspicious domains
                      - hashes: List of file hashes
                      - emails: List of suspicious email addresses
                    - attack_vector: Primary method of attack
                    - targeted_systems: Systems or sectors targeted
                    - mitigations: Suggested mitigations if mentioned
                    
                    TEXT TO ANALYZE:
                    {content}
                    """
                    
                    response = self.openai_client.chat.completions.create(
                        model=GPT_MODEL,
                        messages=[{"role": "user", "content": prompt}],
                        response_format={"type": "json_object"}
                    )
                    
                    return json.loads(response.choices[0].message.content)
                    
                elif model == "grok" and self.xai_client:
                    prompt = f"""
                    Analyze the following text for cyber threat intelligence.
                    Extract indicators of compromise (IOCs) and provide a threat assessment.
                    
                    Return your analysis as JSON with these keys:
                    - threat_type: Primary type of cyber threat described (ransomware, phishing, etc.)
                    - severity: Estimated severity (Low, Medium, High, Critical)
                    - iocs: Dictionary of indicators of compromise with these keys:
                      - ip_addresses: List of suspicious IP addresses
                      - domains: List of suspicious domains
                      - hashes: List of file hashes
                      - emails: List of suspicious email addresses
                    - attack_vector: Primary method of attack
                    - targeted_systems: Systems or sectors targeted
                    - mitigations: Suggested mitigations if mentioned
                    
                    TEXT TO ANALYZE:
                    {content}
                    """
                    
                    response = self.xai_client.chat.completions.create(
                        model=GROK_MODEL,
                        messages=[{"role": "user", "content": prompt}],
                        response_format={"type": "json_object"}
                    )
                    
                    return json.loads(response.choices[0].message.content)
                    
            except Exception as e:
                print(f"{model.capitalize()} cyber threat analysis failed: {str(e)}")
                continue
        
        # If all models failed, return empty structure
        return {
            "threat_type": "Unknown",
            "severity": "Unknown",
            "iocs": {
                "ip_addresses": [],
                "domains": [],
                "hashes": [],
                "emails": []
            },
            "attack_vector": "Unknown",
            "targeted_systems": [],
            "mitigations": []
        }
    
    def _complete_analysis(self, content: str) -> Dict[str, Any]:
        """
        Perform comprehensive analysis using all available methods
        
        Args:
            content: Text content to analyze
            
        Returns:
            Dictionary with complete analysis results
        """
        # Start with a summary request to determine if it's an incident
        # and what type of analysis to prioritize
        summary = self._get_content_summary(content)
        
        # Collect results from all analysis methods
        result = {
            "summary": summary,
            "entities": self._extract_entities(content),
            "keywords": self._extract_keywords(content),
        }
        
        # If it looks like a security incident, add incident classification
        if summary.get("is_incident", False):
            result["incident"] = self._classify_incident(content)
            
            # If it's a cyber incident, add cyber threat analysis
            if result["incident"].get("is_cyber", False):
                result["cyber_threat"] = self._analyze_cyber_threat(content)
        
        return result
    
    def _get_content_summary(self, content: str) -> Dict[str, Any]:
        """
        Get a high-level summary of content to guide further analysis
        
        Args:
            content: Text content to analyze
            
        Returns:
            Dictionary with summary information
        """
        # Try available models in sequence
        for model in self.available_models:
            try:
                if model == "claude" and self.anthropic_client:
                    prompt = f"""
                    Provide a brief summary of the following text.
                    
                    Return your summary as JSON with these keys:
                    - main_topic: One sentence description of the main topic
                    - is_incident: Boolean indicating if this describes a security incident
                    - incident_type: Type of incident if applicable (bomb threat, cyber attack, etc.) or "None"
                    - is_news_article: Boolean indicating if this appears to be a news article
                    - locations: List of mentioned locations
                    - has_technical_details: Boolean indicating if technical details are present
                    
                    TEXT TO ANALYZE:
                    {content}
                    """
                    
                    response = self.anthropic_client.messages.create(
                        model=CLAUDE_MODEL,
                        max_tokens=800,
                        messages=[
                            {"role": "user", "content": prompt}
                        ]
                    )
                    
                    message_content = response.content[0].text
                    json_str = self._extract_json_from_text(message_content)
                    return json.loads(json_str)
                    
                elif model == "openai" and self.openai_client:
                    prompt = f"""
                    Provide a brief summary of the following text.
                    
                    Return your summary as JSON with these keys:
                    - main_topic: One sentence description of the main topic
                    - is_incident: Boolean indicating if this describes a security incident
                    - incident_type: Type of incident if applicable (bomb threat, cyber attack, etc.) or "None"
                    - is_news_article: Boolean indicating if this appears to be a news article
                    - locations: List of mentioned locations
                    - has_technical_details: Boolean indicating if technical details are present
                    
                    TEXT TO ANALYZE:
                    {content}
                    """
                    
                    response = self.openai_client.chat.completions.create(
                        model=GPT_MODEL,
                        messages=[{"role": "user", "content": prompt}],
                        response_format={"type": "json_object"}
                    )
                    
                    return json.loads(response.choices[0].message.content)
                    
                elif model == "grok" and self.xai_client:
                    prompt = f"""
                    Provide a brief summary of the following text.
                    
                    Return your summary as JSON with these keys:
                    - main_topic: One sentence description of the main topic
                    - is_incident: Boolean indicating if this describes a security incident
                    - incident_type: Type of incident if applicable (bomb threat, cyber attack, etc.) or "None"
                    - is_news_article: Boolean indicating if this appears to be a news article
                    - locations: List of mentioned locations
                    - has_technical_details: Boolean indicating if technical details are present
                    
                    TEXT TO ANALYZE:
                    {content}
                    """
                    
                    response = self.xai_client.chat.completions.create(
                        model=GROK_MODEL,
                        messages=[{"role": "user", "content": prompt}],
                        response_format={"type": "json_object"}
                    )
                    
                    return json.loads(response.choices[0].message.content)
                    
            except Exception as e:
                print(f"{model.capitalize()} summary generation failed: {str(e)}")
                continue
        
        # If all models failed, return minimal summary
        return {
            "main_topic": "Unable to determine",
            "is_incident": False,
            "incident_type": "None",
            "is_news_article": False,
            "locations": [],
            "has_technical_details": False
        }
    
    def _extract_json_from_text(self, text: str) -> str:
        """
        Extract JSON from text that might contain explanation or surrounding text
        
        Args:
            text: Text that might contain JSON
            
        Returns:
            Extracted JSON string
        """
        # Look for JSON within triple backticks
        json_pattern = r"```(?:json)?\s*([\s\S]*?)```"
        match = re.search(json_pattern, text)
        if match:
            return match.group(1).strip()
        
        # Look for JSON within curly braces if no triple backticks found
        json_pattern = r"\{[\s\S]*\}"
        match = re.search(json_pattern, text)
        if match:
            return match.group(0).strip()
        
        # Default to the full text if no JSON patterns found
        return text.strip()
        
    def convert_analysis_to_osint_format(self, analysis_result: Dict[str, Any], source_url: str) -> Dict[str, Any]:
        """
        Convert a comprehensive analysis result to the OSINT dataset format
        
        Args:
            analysis_result: The analysis result from analyze_content()
            source_url: URL of the content source
            
        Returns:
            Dictionary formatted for the OSINT dataset
        """
        # Start with a basic structure
        osint_data = {
            'Event Date': datetime.now(),
            'Source': source_url,
            'Other Notes': '',
            'Social Media': False,
            'Automated Phone': False,
            'Verbal': False,
            'Phone': False,
            'Email': False,
            'Written': False,
            'Incident Type': 'Unknown',
            'Arrested': 0,
            'Dead': 0,
            'Injured': 0
        }
        
        # Add summary information
        if 'summary' in analysis_result:
            summary = analysis_result['summary']
            osint_data['Other Notes'] = summary.get('main_topic', '')
        
        # Extract location information from entities
        if 'entities' in analysis_result and 'locations' in analysis_result['entities']:
            locations = analysis_result['entities']['locations']
            if locations and len(locations) > 0:
                primary_location = locations[0]
                if isinstance(primary_location, dict):
                    location_name = primary_location.get('name', '')
                    location_type = primary_location.get('type', '').lower()
                    
                    # Set location based on type
                    if 'city' in location_type:
                        osint_data['City'] = location_name
                    elif 'state' in location_type or 'province' in location_type:
                        osint_data['State'] = location_name
                    elif 'country' in location_type:
                        osint_data['Country'] = location_name
                else:
                    # If location is just a string
                    osint_data['City'] = locations[0]
        
        # Set incident type from classification
        if 'incident' in analysis_result:
            incident = analysis_result['incident']
            osint_data['Incident Type'] = incident.get('incident_type', 'Unknown')
            
            # Set communication methods
            comm_method = incident.get('communication_method', 'None')
            if comm_method != 'None':
                osint_data[comm_method] = True
                
            # Extract evidence as description
            evidence = incident.get('evidence', [])
            if evidence and isinstance(evidence, list) and len(evidence) > 0:
                osint_data['Description'] = ' '.join(evidence)
        
        # Add cyber threat information if available
        if 'cyber_threat' in analysis_result:
            cyber = analysis_result['cyber_threat']
            threat_type = cyber.get('threat_type', 'Unknown')
            severity = cyber.get('severity', 'Unknown')
            
            # Add to description
            cyber_desc = f"Cyber threat type: {threat_type}. Severity: {severity}."
            
            if 'attack_vector' in cyber and cyber['attack_vector'] != 'Unknown':
                cyber_desc += f" Attack vector: {cyber['attack_vector']}."
                
            if 'Description' in osint_data:
                osint_data['Description'] += f" {cyber_desc}"
            else:
                osint_data['Description'] = cyber_desc
                
            # Add IOCs to Other Notes
            if 'iocs' in cyber and isinstance(cyber['iocs'], dict):
                ioc_notes = []
                
                for ioc_type, values in cyber['iocs'].items():
                    if values and len(values) > 0:
                        ioc_notes.append(f"{ioc_type}: {', '.join(values)}")
                
                if ioc_notes:
                    osint_data['Other Notes'] += f" IOCs: {'; '.join(ioc_notes)}."
        
        return osint_data