"""
Data Source Manager
------------------
This module manages all available data sources, allowing them to be loaded,
configured, and accessed through a unified interface.
"""
import pandas as pd
from datetime import datetime
from typing import Dict, List, Any, Optional, Type

from .base_source import DataSource


class DataSourceManager:
    """Manager for all data source plugins"""
    
    def __init__(self):
        self.sources: Dict[str, DataSource] = {}
        self.available_sources: Dict[str, Type[DataSource]] = {}
        
    def register_source_type(self, source_class: Type[DataSource]) -> None:
        """
        Register a data source class as available for instantiation
        
        Args:
            source_class: The DataSource class to register
        """
        # Create a temporary instance just to get the name
        temp_instance = source_class()
        self.available_sources[temp_instance.source_name] = source_class
    
    def create_source(self, source_name: str) -> DataSource:
        """
        Create a new instance of the specified data source
        
        Args:
            source_name: Name of the source to create
            
        Returns:
            New instance of the requested DataSource
            
        Raises:
            ValueError: If the source name is not registered
        """
        if source_name not in self.available_sources:
            raise ValueError(f"Unknown data source: {source_name}")
            
        source_class = self.available_sources[source_name]
        source = source_class()
        return source
    
    def add_source(self, source: DataSource) -> None:
        """
        Add a configured data source to the manager
        
        Args:
            source: Configured DataSource instance
        """
        self.sources[source.source_name] = source
    
    def get_source(self, source_name: str) -> DataSource:
        """
        Get a specific data source by name
        
        Args:
            source_name: Name of the source to retrieve
            
        Returns:
            The requested DataSource
            
        Raises:
            ValueError: If the source is not added to the manager
        """
        if source_name not in self.sources:
            raise ValueError(f"Data source not loaded: {source_name}")
            
        return self.sources[source_name]
    
    def get_sources_by_type(self, source_type: str) -> List[DataSource]:
        """
        Get all data sources of a specific type
        
        Args:
            source_type: Type of sources to retrieve
            
        Returns:
            List of matching DataSource instances
        """
        return [
            source for source in self.sources.values()
            if source.source_type == source_type
        ]
    
    def get_all_sources(self) -> List[DataSource]:
        """
        Get all configured data sources
        
        Returns:
            List of all DataSource instances
        """
        return list(self.sources.values())
    
    def get_combined_data(self, 
                       location: str, 
                       start_date: datetime, 
                       end_date: datetime,
                       source_type: Optional[str] = None) -> pd.DataFrame:
        """
        Get combined data from all relevant sources
        
        Args:
            location: Location to get data for
            start_date: Start of date range
            end_date: End of date range
            source_type: Optional type of sources to include (all if None)
            
        Returns:
            DataFrame with combined data from all matching sources
        """
        sources_to_query = (
            self.get_sources_by_type(source_type) if source_type
            else self.get_all_sources()
        )
        
        all_data = []
        for source in sources_to_query:
            try:
                source_data = source.get_data(location, start_date, end_date)
                if not source_data.empty:
                    all_data.append(source_data)
            except Exception as e:
                print(f"Error getting data from {source.source_name}: {str(e)}")
                continue
                
        if not all_data:
            return pd.DataFrame()
            
        return pd.concat(all_data, ignore_index=True)