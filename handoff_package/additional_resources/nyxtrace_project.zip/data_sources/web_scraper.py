"""
Web Scraper Data Source
----------------------
Implementation of DataSource interface for web scraping.

Uses trafilatura to extract textual content from websites.
Includes URL resolution to handle shortened URLs and redirects.
Follows content links for comprehensive data gathering.
"""
import pandas as pd
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple, Set
import json
import trafilatura
import concurrent.futures
import time
import random
import requests
import re
import urllib.parse
from urllib3.exceptions import InsecureRequestWarning
from .base_source import DataSource

# Suppress insecure request warnings for non-critical scraping
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


class WebScraperDataSource(DataSource):
    """Web Scraper data source implementation"""
    
    def __init__(self):
        self.target_urls = []
        self.default_websites = {}
        self.is_configured = False
        self.url_cache = {}  # Cache for resolved URLs
        self.content_cache = {}  # Cache for fetched content
        self.max_follow_links = 3  # Maximum depth for following links
        self.follow_same_domain = True  # Whether to only follow links on same domain
        
        # Location-specific websites mapping
        self.location_websites = {
            "Houston": [
                "https://porthouston.com/news/",
                "https://www.houstonpublicmedia.org/tag/port-of-houston/"
            ],
            "Los Angeles": [
                "https://www.portoflosangeles.org/newsroom",
                "https://www.dailybreeze.com/tag/port-of-los-angeles/"
            ],
            "New York": [
                "https://www.panynj.gov/port/en/news.html",
                "https://www.silive.com/tag/port-of-new-york/"
            ],
            "Miami": [
                "https://www.miamidade.gov/portmiami/news.asp",
                "https://www.miamiherald.com/news/local/community/miami-dade/"
            ],
            "Seattle": [
                "https://www.portseattle.org/news",
                "https://www.seattletimes.com/tag/port-of-seattle/"
            ],
            "Detroit": [
                "https://www.cbp.gov/newsroom/local-media-release/detroit-field-office",
                "https://www.detroitnews.com/search/?q=border"
            ],
            "El Paso": [
                "https://www.cbp.gov/newsroom/local-media-release/el-paso-field-office",
                "https://www.elpasotimes.com/search/?q=border"
            ],
            "Nogales": [
                "https://www.cbp.gov/newsroom/local-media-release/tucson-field-office",
                "https://www.nogalesinternational.com/search/?k=%22border%22"
            ],
            "Laredo": [
                "https://www.cbp.gov/newsroom/local-media-release/laredo-field-office",
                "https://www.lmtonline.com/search/?q=border"
            ],
            "San Diego": [
                "https://www.cbp.gov/newsroom/local-media-release/san-diego-field-office",
                "https://www.sandiegouniontribune.com/search?q=border"
            ]
        }
    
    def resolve_url(self, url: str) -> str:
        """
        Resolve URL, following redirects and handling shortened URLs
        
        Args:
            url: The URL to resolve
            
        Returns:
            The resolved (final) URL
        """
        # Check cache first
        if url in self.url_cache:
            return self.url_cache[url]
            
        try:
            # Handle common URL shorteners and redirects
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            response = requests.head(url, allow_redirects=True, timeout=10, headers=headers)
            resolved_url = response.url
            
            # Cache the result
            self.url_cache[url] = resolved_url
            
            print(f"Resolved URL: {url} -> {resolved_url}")
            return resolved_url
            
        except Exception as e:
            print(f"Error resolving URL {url}: {str(e)}")
            # If resolution fails, use original URL
            self.url_cache[url] = url
            return url
    
    def extract_links_from_html(self, html_content: str, base_url: str) -> List[str]:
        """
        Extract links from HTML content
        
        Args:
            html_content: The HTML content to extract links from
            base_url: The base URL for resolving relative links
            
        Returns:
            List of absolute URLs found in the HTML
        """
        if not html_content:
            return []
            
        try:
            # Extract domain for filtering if needed
            parsed_base = urllib.parse.urlparse(base_url)
            base_domain = parsed_base.netloc
            
            # Simple link extraction with regex - could use BeautifulSoup for more robust parsing
            link_pattern = re.compile(r'<a[^>]+href=["\'](.*?)["\']', re.IGNORECASE)
            matches = link_pattern.findall(html_content)
            
            # Process and filter links
            links = []
            for match in matches:
                # Ignore anchors, javascript, mailto
                if match.startswith('#') or match.startswith('javascript:') or match.startswith('mailto:'):
                    continue
                    
                # Handle relative URLs
                if not match.startswith('http'):
                    # Create absolute URL
                    if match.startswith('/'):
                        match = f"{parsed_base.scheme}://{base_domain}{match}"
                    else:
                        match = f"{base_url.rstrip('/')}/{match.lstrip('/')}"
                
                # Filter by domain if configured to follow only same domain
                if self.follow_same_domain:
                    parsed_match = urllib.parse.urlparse(match)
                    if parsed_match.netloc != base_domain:
                        continue
                        
                links.append(match)
                
            return links
            
        except Exception as e:
            print(f"Error extracting links from {base_url}: {str(e)}")
            return []

    def get_website_text_content(self, url: str, depth: int = 0, visited: Set[str] = None) -> Tuple[str, List[Dict]]:
        """
        Extract main text content from a website and follow links if needed
        
        Args:
            url: URL of the website to extract content from
            depth: Current depth level for link following (recursion control)
            visited: Set of already visited URLs to prevent loops
            
        Returns:
            Tuple of (extracted text content, list of additional content dictionaries)
        """
        if visited is None:
            visited = set()
            
        # Prevent visiting the same URL twice
        if url in visited:
            return "", []
            
        # Track visited URLs
        visited.add(url)
        
        # Check cache for this URL
        if url in self.content_cache:
            print(f"Cache hit for URL: {url}")
            return self.content_cache[url], []
        
        try:
            # Resolve the URL first (follow redirects, handle shortened URLs)
            resolved_url = self.resolve_url(url)
            
            # Send a request to the website
            downloaded = trafilatura.fetch_url(resolved_url)
            if not downloaded:
                return "", []
                
            # Extract the main text content
            text = trafilatura.extract(downloaded)
            content = text or ""
            
            # Cache the result
            self.content_cache[url] = content
            
            # If we've reached max depth, don't follow more links
            if depth >= self.max_follow_links:
                return content, []
                
            # Extract links to follow
            additional_content = []
            links = self.extract_links_from_html(downloaded, resolved_url)
            
            # Follow a limited number of links
            for link in links[:3]:  # Limit to 3 links per page
                if link not in visited:
                    # Recursively get content from linked page
                    linked_content, _ = self.get_website_text_content(link, depth + 1, visited)
                    if linked_content:
                        additional_content.append({
                            'url': link,
                            'content': linked_content,
                            'title': linked_content[:50] + "..." if len(linked_content) > 50 else linked_content
                        })
            
            return content, additional_content
            
        except Exception as e:
            print(f"Error extracting content from {url}: {str(e)}")
            return "", []
    
    @property
    def source_name(self) -> str:
        return "WebScraper"
    
    @property
    def source_type(self) -> str:
        return "osint"
    
    def get_data(self, location: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """Get web-scraped data for location"""
        if not self.is_configured:
            raise ValueError("Web Scraper data source not configured. Call configure() first.")
        
        # Get websites relevant to this location
        urls = self.get_websites_for_location(location)
        if not urls:
            return pd.DataFrame(columns=[
                'Source', 'Date', 'Content', 'Sentiment', 'Activity_Level',
                'URL', 'Title', 'Location', 'Related_URLs'
            ])
        
        # Scrape content from websites in parallel
        scraped_data = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            # Use enhanced content extraction that follows linked content
            future_to_url = {executor.submit(self.get_website_text_content, url): url for url in urls}
            
            for future in concurrent.futures.as_completed(future_to_url):
                url = future_to_url[future]
                try:
                    # Get main content and additional linked content
                    main_content, additional_contents = future.result()
                    
                    if main_content:
                        # Use current date for scraping (in a real implementation, we'd extract dates from content)
                        current_date = datetime.now()
                        
                        # Extract a title (first 50 chars of content)
                        title = main_content[:50] + "..." if len(main_content) > 50 else main_content
                        
                        # Calculate a simple activity level based on text length
                        activity_level = min(100, len(main_content) / 100)
                        
                        # Simple sentiment score (random for now, would use NLP in real implementation)
                        sentiment = random.uniform(-0.5, 0.5)
                        
                        # Store linked URLs for reference
                        related_urls = [item['url'] for item in additional_contents] if additional_contents else []
                        
                        # Add main content data
                        scraped_data.append({
                            'Source': self.source_name,
                            'Date': current_date,
                            'Content': main_content[:1000] + "..." if len(main_content) > 1000 else main_content,
                            'Sentiment': sentiment,
                            'Activity_Level': activity_level,
                            'URL': url,
                            'Title': title,
                            'Location': location,
                            'Related_URLs': ','.join(related_urls)
                        })
                        
                        # Add each linked content as its own entry
                        for item in additional_contents:
                            linked_content = item['content']
                            linked_url = item['url']
                            linked_title = item['title']
                            
                            # Calculate activity level for linked content
                            linked_activity = min(80, len(linked_content) / 100)  # Slightly less than main content
                            
                            # Generate sentiment score
                            linked_sentiment = random.uniform(-0.5, 0.5)
                            
                            scraped_data.append({
                                'Source': f"{self.source_name}_LinkedContent",
                                'Date': current_date,
                                'Content': linked_content[:800] + "..." if len(linked_content) > 800 else linked_content,
                                'Sentiment': linked_sentiment,
                                'Activity_Level': linked_activity,
                                'URL': linked_url,
                                'Title': linked_title,
                                'Location': location,
                                'Related_URLs': url  # Reference back to original URL
                            })
                            
                except Exception as e:
                    print(f"Error processing {url}: {str(e)}")
                    continue
        
        if not scraped_data:
            return pd.DataFrame(columns=[
                'Source', 'Date', 'Content', 'Sentiment', 'Activity_Level',
                'URL', 'Title', 'Location', 'Related_URLs'
            ])
        
        # Create DataFrame with all the scraped data
        result_df = pd.DataFrame(scraped_data)
        
        # Apply date filtering if needed
        if start_date or end_date:
            date_mask = True
            if start_date:
                date_mask = date_mask & (result_df['Date'] >= start_date)
            if end_date:
                date_mask = date_mask & (result_df['Date'] <= end_date)
            result_df = result_df[date_mask]
            
        return result_df
    
    def get_websites_for_location(self, location: str) -> List[str]:
        """Get websites associated with a location"""
        return self.location_websites.get(location, [])
    
    def get_keywords_for_location(self, location: str) -> List[str]:
        """Get search keywords for the given location"""
        # For web scraping, we use websites rather than keywords
        # But we can return keywords for potential use in filtering content
        if location == "Houston":
            return ["port", "shipping", "cargo", "trade", "terminal"]
        elif location == "Los Angeles":
            return ["port", "Long Beach", "cargo", "terminal", "shipping"]
        elif location == "New York":
            return ["port", "harbor", "shipping", "cargo", "terminal"]
        elif location == "Miami":
            return ["port", "cruise", "cargo", "shipping", "terminal"]
        elif location == "Seattle":
            return ["port", "Tacoma", "cargo", "terminal", "shipping"]
        elif location == "Detroit":
            return ["border", "crossing", "customs", "transit", "Windsor"]
        elif location == "El Paso":
            return ["border", "crossing", "customs", "Juarez", "transit"]
        elif location == "Nogales":
            return ["border", "crossing", "customs", "Sonora", "transit"]
        elif location == "Laredo":
            return ["border", "crossing", "customs", "Nuevo Laredo", "transit"]
        elif location == "San Diego":
            return ["border", "crossing", "San Ysidro", "Tijuana", "transit"]
        else:
            return [location]
    
    def configure(self, config: Dict[str, Any]) -> None:
        """Configure the web scraper"""
        # No API key needed, but we can configure custom websites
        if 'custom_websites' in config and isinstance(config['custom_websites'], dict):
            self.location_websites.update(config['custom_websites'])
        
        # Set any default websites to use for all locations
        if 'default_websites' in config and isinstance(config['default_websites'], list):
            self.default_websites = config['default_websites']
        
        self.is_configured = True
        
        # Register URLs with the URL health monitor if available
        try:
            import streamlit as st
            if 'data_source_urls' not in st.session_state:
                st.session_state.data_source_urls = []
                
            # Add all website URLs to the monitored list
            for location_urls in self.location_websites.values():
                for url in location_urls:
                    if url not in st.session_state.data_source_urls:
                        st.session_state.data_source_urls.append(url)
                        
            # Add default websites if any
            for url in self.default_websites:
                if url not in st.session_state.data_source_urls:
                    st.session_state.data_source_urls.append(url)
                    
            print(f"Registered {len(st.session_state.data_source_urls)} URLs with health monitor")
        except Exception as e:
            print(f"Could not register URLs with health monitor: {str(e)}")
    
    def test_connection(self) -> bool:
        """Test if the web scraper works by fetching a test website"""
        test_url = "https://en.wikipedia.org/wiki/Main_Page"
        try:
            content, _ = self.get_website_text_content(test_url)
            return bool(content)
        except Exception as e:
            print(f"Test connection failed: {str(e)}")
            return False
            
    def clear_cache(self) -> None:
        """Clear URL and content caches to free up memory"""
        url_cache_size = len(self.url_cache)
        content_cache_size = len(self.content_cache)
        
        self.url_cache = {}
        self.content_cache = {}
        
        print(f"Cache cleared: {url_cache_size} URLs and {content_cache_size} content items removed")