"""
Target-based Threat Analysis Module
----------------------------------
This module provides specialized analysis for identifying potential threats
to specific types of targets and critical infrastructure through geospatial
analysis and pattern recognition across incident data.

Key capabilities:
1. Critical infrastructure threat assessment
2. Soft target vulnerability analysis
3. Geofencing and proximity alerting
4. Pattern recognition for latent threats
5. Predictive targeting indicators
6. Geographic correlation of disparate incidents
"""

import os
import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.express as px
import plotly.graph_objects as go
from typing import Dict, List, Any, Optional, Tuple
import math

# Try to import geospatial libraries
try:
    import shapely
    from shapely.geometry import Point, Polygon
    SHAPELY_AVAILABLE = True
except ImportError:
    SHAPELY_AVAILABLE = False

try:
    import geopy
    from geopy.distance import geodesic
    GEOPY_AVAILABLE = True
except ImportError:
    GEOPY_AVAILABLE = False

class TargetAnalyzer:
    """
    Analyzes potential threats to specific targets and critical infrastructure
    based on geospatial patterns and incident data.
    """
    
    def __init__(self, data_handler=None):
        """
        Initialize the target analyzer
        
        Args:
            data_handler: Optional data handler for accessing OSINT data
        """
        self.data_handler = data_handler
        
        # Initialize target databases
        self.critical_infrastructure = self._load_critical_infrastructure()
        self.soft_targets = self._load_soft_targets()
        self.custom_targets = []
        
        # Track alert history to prevent duplicates
        self.alert_history = {}
        
        # Active geofences
        self.geofences = []
    
    def _load_critical_infrastructure(self):
        """Load critical infrastructure database"""
        # This would typically load from a secured database
        # For now, we'll include some sample categories and examples
        
        infrastructure = {
            "power_plants": [
                {"name": "Example Nuclear Facility", "type": "nuclear", "latitude": 40.7128, "longitude": -74.0060, "radius_km": 10},
                {"name": "Example Hydroelectric Dam", "type": "hydro", "latitude": 37.7749, "longitude": -122.4194, "radius_km": 5}
            ],
            "government_facilities": [
                {"name": "Example Government Complex", "type": "federal", "latitude": 38.9072, "longitude": -77.0369, "radius_km": 3}
            ],
            "transportation_hubs": [
                {"name": "Example International Airport", "type": "airport", "latitude": 33.6407, "longitude": -84.4277, "radius_km": 5},
                {"name": "Example Train Terminal", "type": "rail", "latitude": 40.7306, "longitude": -73.9352, "radius_km": 2}
            ],
            "water_systems": [
                {"name": "Example Water Treatment Plant", "type": "treatment", "latitude": 34.0522, "longitude": -118.2437, "radius_km": 3}
            ],
            "communications": [
                {"name": "Example Data Center", "type": "data", "latitude": 39.7392, "longitude": -104.9903, "radius_km": 2}
            ],
            "healthcare": [
                {"name": "Example Major Hospital", "type": "hospital", "latitude": 29.7604, "longitude": -95.3698, "radius_km": 2}
            ]
        }
        
        print(f"Loaded {sum(len(v) for v in infrastructure.values())} critical infrastructure locations")
        return infrastructure
    
    def _load_soft_targets(self):
        """Load soft target location database"""
        # This would typically load from a secured database
        # For now, we'll include some sample categories and examples
        
        soft_targets = {
            "event_venues": [
                {"name": "Example Stadium", "type": "sports", "latitude": 40.8128, "longitude": -73.9260, "capacity": 70000},
                {"name": "Example Concert Hall", "type": "music", "latitude": 34.0522, "longitude": -118.2437, "capacity": 20000}
            ],
            "shopping_centers": [
                {"name": "Example Mall", "type": "mall", "latitude": 33.4484, "longitude": -112.0740, "capacity": 15000}
            ],
            "tourist_attractions": [
                {"name": "Example Tourist Site", "type": "landmark", "latitude": 37.7749, "longitude": -122.4194, "capacity": 5000}
            ],
            "transportation_terminals": [
                {"name": "Example Bus Terminal", "type": "bus", "latitude": 29.7604, "longitude": -95.3698, "capacity": 10000}
            ],
            "schools": [
                {"name": "Example University", "type": "university", "latitude": 38.9072, "longitude": -77.0369, "capacity": 25000}
            ],
            "religious_centers": [
                {"name": "Example Religious Center", "type": "religious", "latitude": 41.8781, "longitude": -87.6298, "capacity": 2000}
            ]
        }
        
        print(f"Loaded {sum(len(v) for v in soft_targets.values())} soft target locations")
        return soft_targets
    
    def add_custom_target(self, name, target_type, latitude, longitude, radius_km=2, capacity=None, attributes=None):
        """
        Add a custom target location for monitoring
        
        Args:
            name: Name of the target
            target_type: Type of target (e.g., power_plant, stadium, hospital)
            latitude: Target latitude
            longitude: Target longitude
            radius_km: Monitoring radius in kilometers
            capacity: Optional capacity for soft targets
            attributes: Additional target attributes
            
        Returns:
            Dictionary with target information
        """
        if not attributes:
            attributes = {}
            
        target = {
            "name": name,
            "type": target_type,
            "latitude": latitude,
            "longitude": longitude,
            "radius_km": radius_km,
            "added_date": datetime.now().isoformat()
        }
        
        if capacity:
            target["capacity"] = capacity
            
        target.update(attributes)
        
        self.custom_targets.append(target)
        print(f"Added custom target: {name} ({target_type})")
        
        return target
    
    def create_geofence(self, name, center_lat, center_long, radius_km, target_types=None, alert_threshold=1):
        """
        Create a geofence for monitoring incidents near specific locations
        
        Args:
            name: Name of the geofence
            center_lat: Center latitude
            center_long: Center longitude
            radius_km: Radius in kilometers
            target_types: Optional list of target types to include
            alert_threshold: Number of incidents to trigger an alert
            
        Returns:
            Dictionary with geofence information
        """
        geofence = {
            "id": f"geofence_{len(self.geofences) + 1}",
            "name": name,
            "center": {"latitude": center_lat, "longitude": center_long},
            "radius_km": radius_km,
            "created_date": datetime.now().isoformat(),
            "target_types": target_types,
            "alert_threshold": alert_threshold,
            "active": True
        }
        
        self.geofences.append(geofence)
        print(f"Created geofence: {name} with radius {radius_km}km")
        
        return geofence
    
    def analyze_targets_at_risk(self, days_back=90, incident_types=None, proximity_threshold_km=10):
        """
        Analyze which targets may be at risk based on nearby incidents
        
        Args:
            days_back: Number of days to look back for incidents
            incident_types: Optional filter for specific incident types
            proximity_threshold_km: Distance threshold in kilometers
            
        Returns:
            Dictionary with targets at risk and analysis
        """
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days_back)
        
        # Get incident data for the specified time period
        if self.data_handler:
            try:
                data = self.data_handler.load_osint_data("all", start_date=start_date, end_date=end_date)
                
                # Filter by incident types if specified
                if incident_types and "Incident Type" in data.columns:
                    type_filter = data["Incident Type"].str.contains("|".join(incident_types), case=False, na=False)
                    data = data[type_filter]
            except Exception as e:
                print(f"Error loading data for target analysis: {str(e)}")
                data = pd.DataFrame()
        else:
            data = pd.DataFrame()
        
        if data.empty:
            return {"error": "No incident data available for analysis"}
            
        # Check if we have geographic coordinates
        if not all(col in data.columns for col in ["Latitude", "Longitude"]):
            return {"error": "Incident data missing geographic coordinates"}
        
        # Remove rows with missing coordinates
        data = data.dropna(subset=["Latitude", "Longitude"])
        
        if data.empty:
            return {"error": "No incident data with valid coordinates available"}
        
        # Initialize results
        results = {
            "timestamp": datetime.now().isoformat(),
            "analysis_period": {
                "start_date": start_date.isoformat(),
                "end_date": end_date.isoformat()
            },
            "parameters": {
                "days_back": days_back,
                "proximity_threshold_km": proximity_threshold_km,
                "incident_types": incident_types
            },
            "critical_infrastructure_at_risk": [],
            "soft_targets_at_risk": [],
            "custom_targets_at_risk": [],
            "geographic_patterns": []
        }
        
        # Check all critical infrastructure
        for category, targets in self.critical_infrastructure.items():
            for target in targets:
                # Calculate nearby incidents
                nearby_incidents = self._get_nearby_incidents(
                    data, 
                    target["latitude"], 
                    target["longitude"], 
                    proximity_threshold_km
                )
                
                # If we found nearby incidents, add to results
                if len(nearby_incidents) > 0:
                    target_info = {
                        "target": target,
                        "category": category,
                        "incident_count": len(nearby_incidents),
                        "nearest_incident_km": min(nearby_incidents["distance_km"]),
                        "incident_types": nearby_incidents["Incident Type"].unique().tolist() if "Incident Type" in nearby_incidents.columns else []
                    }
                    results["critical_infrastructure_at_risk"].append(target_info)
        
        # Check all soft targets
        for category, targets in self.soft_targets.items():
            for target in targets:
                # Calculate nearby incidents
                nearby_incidents = self._get_nearby_incidents(
                    data, 
                    target["latitude"], 
                    target["longitude"], 
                    proximity_threshold_km
                )
                
                # If we found nearby incidents, add to results
                if len(nearby_incidents) > 0:
                    target_info = {
                        "target": target,
                        "category": category,
                        "incident_count": len(nearby_incidents),
                        "nearest_incident_km": min(nearby_incidents["distance_km"]),
                        "incident_types": nearby_incidents["Incident Type"].unique().tolist() if "Incident Type" in nearby_incidents.columns else []
                    }
                    results["soft_targets_at_risk"].append(target_info)
        
        # Check all custom targets
        for target in self.custom_targets:
            # Calculate nearby incidents
            nearby_incidents = self._get_nearby_incidents(
                data, 
                target["latitude"], 
                target["longitude"], 
                proximity_threshold_km
            )
            
            # If we found nearby incidents, add to results
            if len(nearby_incidents) > 0:
                target_info = {
                    "target": target,
                    "incident_count": len(nearby_incidents),
                    "nearest_incident_km": min(nearby_incidents["distance_km"]),
                    "incident_types": nearby_incidents["Incident Type"].unique().tolist() if "Incident Type" in nearby_incidents.columns else []
                }
                results["custom_targets_at_risk"].append(target_info)
        
        # Analyze geographic patterns
        if len(data) >= 3:
            results["geographic_patterns"] = self._analyze_geographic_patterns(data)
        
        return results
    
    def _get_nearby_incidents(self, data, target_lat, target_long, max_distance_km):
        """
        Get incidents within specified distance of a target
        
        Args:
            data: DataFrame of incident data
            target_lat: Target latitude
            target_long: Target longitude
            max_distance_km: Maximum distance in kilometers
            
        Returns:
            DataFrame with nearby incidents and distances
        """
        if not GEOPY_AVAILABLE:
            print("Geopy not available for distance calculations")
            return pd.DataFrame()
        
        # Create a copy of the data
        result = data.copy()
        
        # Calculate distances
        distances = []
        for _, row in result.iterrows():
            dist = geodesic(
                (target_lat, target_long), 
                (row["Latitude"], row["Longitude"])
            ).kilometers
            distances.append(dist)
        
        result["distance_km"] = distances
        
        # Filter by max distance
        result = result[result["distance_km"] <= max_distance_km]
        
        return result
    
    def _analyze_geographic_patterns(self, data):
        """
        Analyze geographic patterns in incident data to identify clusters
        
        Args:
            data: DataFrame of incident data
            
        Returns:
            List of identified geographic patterns
        """
        patterns = []
        
        # Attempt to identify clusters
        try:
            from sklearn.cluster import DBSCAN
            
            # Extract coordinates
            coords = data[["Latitude", "Longitude"]].values
            
            # Convert to radians
            coords_rad = np.radians(coords)
            
            # Earth radius in kilometers
            kms_per_radian = 6371.0
            
            # Epsilon is the maximum distance between two samples
            # 10km converted to radians
            epsilon = 10 / kms_per_radian
            
            # Minimum samples for a cluster
            min_samples = 3
            
            # Perform clustering
            db = DBSCAN(eps=epsilon, min_samples=min_samples, algorithm='ball_tree', metric='haversine').fit(coords_rad)
            
            # Get cluster labels
            labels = db.labels_
            
            # Number of clusters (excluding noise)
            n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
            
            if n_clusters > 0:
                # Add cluster labels to data
                data_with_clusters = data.copy()
                data_with_clusters['cluster'] = labels
                
                # Analyze each cluster
                for cluster_id in range(n_clusters):
                    cluster_data = data_with_clusters[data_with_clusters['cluster'] == cluster_id]
                    
                    # Calculate cluster center
                    center_lat = cluster_data['Latitude'].mean()
                    center_long = cluster_data['Longitude'].mean()
                    
                    # Calculate average distance to center
                    distances = []
                    for _, row in cluster_data.iterrows():
                        dist = geodesic(
                            (center_lat, center_long), 
                            (row["Latitude"], row["Longitude"])
                        ).kilometers
                        distances.append(dist)
                    
                    avg_radius = sum(distances) / len(distances) if distances else 0
                    
                    # Check if the cluster is near any targets
                    nearby_ci = self._find_targets_near_point(
                        center_lat, center_long, 
                        max(avg_radius * 2, 10),  # Look within 2x the radius or 10km, whichever is larger
                        "critical_infrastructure"
                    )
                    
                    nearby_soft = self._find_targets_near_point(
                        center_lat, center_long, 
                        max(avg_radius * 2, 10),
                        "soft_targets"
                    )
                    
                    # Get incident types in cluster
                    if "Incident Type" in cluster_data.columns:
                        incident_types = cluster_data["Incident Type"].unique().tolist()
                    else:
                        incident_types = []
                    
                    # Create pattern entry
                    pattern = {
                        "type": "cluster",
                        "center": {"latitude": center_lat, "longitude": center_long},
                        "radius_km": avg_radius,
                        "incident_count": len(cluster_data),
                        "incident_types": incident_types,
                        "nearby_critical_infrastructure": nearby_ci,
                        "nearby_soft_targets": nearby_soft,
                        "significance": "high" if (nearby_ci or nearby_soft) else "medium"
                    }
                    
                    patterns.append(pattern)
        
        except Exception as e:
            print(f"Error in cluster analysis: {str(e)}")
            
            # Fallback to basic density analysis if clustering fails
            # Divide the area into grid cells and count incidents per cell
            if len(data) >= 5:
                try:
                    # Calculate geographic bounds
                    min_lat = data["Latitude"].min()
                    max_lat = data["Latitude"].max()
                    min_long = data["Longitude"].min()
                    max_long = data["Longitude"].max()
                    
                    # Create grid cells (1 degree ~ 111km)
                    cell_size = 0.1  # ~11km cells
                    
                    grid = {}
                    for _, row in data.iterrows():
                        lat = row["Latitude"]
                        long = row["Longitude"]
                        
                        # Calculate grid cell
                        lat_cell = math.floor(lat / cell_size) * cell_size
                        long_cell = math.floor(long / cell_size) * cell_size
                        
                        cell_key = f"{lat_cell}_{long_cell}"
                        
                        if cell_key not in grid:
                            grid[cell_key] = {
                                "center": {"latitude": lat_cell + cell_size/2, "longitude": long_cell + cell_size/2},
                                "count": 0,
                                "incidents": []
                            }
                        
                        grid[cell_key]["count"] += 1
                        grid[cell_key]["incidents"].append(row.to_dict())
                    
                    # Find cells with high density
                    high_density_cells = [cell for cell_key, cell in grid.items() if cell["count"] >= 3]
                    
                    for cell in high_density_cells:
                        center_lat = cell["center"]["latitude"]
                        center_long = cell["center"]["longitude"]
                        
                        # Check for nearby targets
                        nearby_ci = self._find_targets_near_point(
                            center_lat, center_long, 15,  # 15km radius
                            "critical_infrastructure"
                        )
                        
                        nearby_soft = self._find_targets_near_point(
                            center_lat, center_long, 15,
                            "soft_targets"
                        )
                        
                        # Extract incident types
                        incident_types = []
                        for incident in cell["incidents"]:
                            if "Incident Type" in incident and incident["Incident Type"] not in incident_types:
                                incident_types.append(incident["Incident Type"])
                        
                        # Create pattern entry
                        pattern = {
                            "type": "density_hotspot",
                            "center": {"latitude": center_lat, "longitude": center_long},
                            "radius_km": 5.5,  # Half-cell
                            "incident_count": cell["count"],
                            "incident_types": incident_types,
                            "nearby_critical_infrastructure": nearby_ci,
                            "nearby_soft_targets": nearby_soft,
                            "significance": "high" if (nearby_ci or nearby_soft) else "medium"
                        }
                        
                        patterns.append(pattern)
                
                except Exception as e:
                    print(f"Error in density analysis: {str(e)}")
        
        # Analyze linear patterns
        if len(data) >= 5:
            try:
                # Check for incidents that form a line
                from sklearn.linear_model import LinearRegression
                
                # Extract coordinates
                coords = data[["Latitude", "Longitude"]].values
                
                # Try to fit a linear model to the coordinates
                model = LinearRegression().fit(coords[:, 0].reshape(-1, 1), coords[:, 1])
                
                # Get R-squared value to determine if they're linear
                r_squared = model.score(coords[:, 0].reshape(-1, 1), coords[:, 1])
                
                # If R-squared is high, we have a linear pattern
                if r_squared > 0.7:  # Strong linear relationship
                    # Calculate points along the line for reference
                    min_lat = data["Latitude"].min()
                    max_lat = data["Latitude"].max()
                    
                    start_long = model.predict([[min_lat]])[0]
                    end_long = model.predict([[max_lat]])[0]
                    
                    # Get targets near this line
                    # (This is a simplification - ideally we'd check proximity to the line itself)
                    mid_lat = (min_lat + max_lat) / 2
                    mid_long = (start_long + end_long) / 2
                    
                    # Roughly estimate the length of the line
                    line_length_km = geodesic(
                        (min_lat, start_long), 
                        (max_lat, end_long)
                    ).kilometers
                    
                    search_radius = max(line_length_km / 2, 20)  # Half the line length or 20km
                    
                    nearby_ci = self._find_targets_near_point(
                        mid_lat, mid_long, search_radius,
                        "critical_infrastructure"
                    )
                    
                    nearby_soft = self._find_targets_near_point(
                        mid_lat, mid_long, search_radius,
                        "soft_targets"
                    )
                    
                    # Extract incident types
                    if "Incident Type" in data.columns:
                        incident_types = data["Incident Type"].unique().tolist()
                    else:
                        incident_types = []
                    
                    # Create pattern entry
                    pattern = {
                        "type": "linear",
                        "endpoints": [
                            {"latitude": min_lat, "longitude": start_long},
                            {"latitude": max_lat, "longitude": end_long}
                        ],
                        "length_km": line_length_km,
                        "r_squared": r_squared,
                        "incident_count": len(data),
                        "incident_types": incident_types,
                        "nearby_critical_infrastructure": nearby_ci,
                        "nearby_soft_targets": nearby_soft,
                        "significance": "high" if r_squared > 0.85 else "medium"
                    }
                    
                    patterns.append(pattern)
                
            except Exception as e:
                print(f"Error in linear pattern analysis: {str(e)}")
        
        return patterns
    
    def _find_targets_near_point(self, lat, long, radius_km, target_type):
        """
        Find targets near a specified point
        
        Args:
            lat: Point latitude
            long: Point longitude
            radius_km: Search radius in kilometers
            target_type: Type of targets to search ('critical_infrastructure' or 'soft_targets')
            
        Returns:
            List of nearby targets
        """
        if not GEOPY_AVAILABLE:
            return []
        
        nearby = []
        
        if target_type == "critical_infrastructure":
            # Search critical infrastructure
            for category, targets in self.critical_infrastructure.items():
                for target in targets:
                    dist = geodesic(
                        (lat, long), 
                        (target["latitude"], target["longitude"])
                    ).kilometers
                    
                    if dist <= radius_km:
                        nearby.append({
                            "name": target["name"],
                            "type": target["type"],
                            "category": category,
                            "distance_km": dist
                        })
        
        elif target_type == "soft_targets":
            # Search soft targets
            for category, targets in self.soft_targets.items():
                for target in targets:
                    dist = geodesic(
                        (lat, long), 
                        (target["latitude"], target["longitude"])
                    ).kilometers
                    
                    if dist <= radius_km:
                        nearby.append({
                            "name": target["name"],
                            "type": target["type"],
                            "category": category,
                            "distance_km": dist
                        })
        
        # Sort by distance
        nearby.sort(key=lambda x: x["distance_km"])
        
        return nearby
    
    def check_geofences(self, data=None, days_back=7):
        """
        Check for incidents within defined geofences
        
        Args:
            data: Optional incident data (if None, will fetch recent data)
            days_back: Number of days to look back if fetching data
            
        Returns:
            Dictionary with geofence alerts
        """
        # If no data provided, fetch recent data
        if data is None and self.data_handler:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days_back)
            
            try:
                data = self.data_handler.load_osint_data("all", start_date=start_date, end_date=end_date)
            except Exception as e:
                print(f"Error loading data for geofence check: {str(e)}")
                data = pd.DataFrame()
        
        if data is None or data.empty:
            return {"error": "No incident data available for geofence checking"}
        
        # Check if we have geographic coordinates
        if not all(col in data.columns for col in ["Latitude", "Longitude"]):
            return {"error": "Incident data missing geographic coordinates"}
        
        # Remove rows with missing coordinates
        data = data.dropna(subset=["Latitude", "Longitude"])
        
        if data.empty:
            return {"error": "No incident data with valid coordinates available"}
        
        # Initialize results
        results = {
            "timestamp": datetime.now().isoformat(),
            "geofence_alerts": [],
            "total_alerts": 0
        }
        
        # Check each geofence
        for geofence in self.geofences:
            if not geofence["active"]:
                continue
                
            center_lat = geofence["center"]["latitude"]
            center_long = geofence["center"]["longitude"]
            radius_km = geofence["radius_km"]
            
            # Get incidents within geofence
            within_geofence = self._get_nearby_incidents(
                data, center_lat, center_long, radius_km
            )
            
            # If we have incidents over the threshold, create an alert
            if len(within_geofence) >= geofence["alert_threshold"]:
                # Generate alert ID
                alert_id = f"alert_{geofence['id']}_{datetime.now().strftime('%Y%m%d')}"
                
                # Check if we've already alerted for this geofence today
                if geofence["id"] in self.alert_history:
                    last_alert = self.alert_history[geofence["id"]]
                    
                    # If last alert was today, skip
                    if last_alert["date"] == datetime.now().strftime("%Y-%m-%d"):
                        continue
                
                # Create alert
                alert = {
                    "id": alert_id,
                    "geofence": geofence,
                    "incident_count": len(within_geofence),
                    "timestamp": datetime.now().isoformat(),
                    "incident_types": within_geofence["Incident Type"].unique().tolist() if "Incident Type" in within_geofence.columns else []
                }
                
                # Add nearby targets if available
                nearby_ci = self._find_targets_near_point(
                    center_lat, center_long, radius_km,
                    "critical_infrastructure"
                )
                
                nearby_soft = self._find_targets_near_point(
                    center_lat, center_long, radius_km,
                    "soft_targets"
                )
                
                if nearby_ci:
                    alert["nearby_critical_infrastructure"] = nearby_ci
                
                if nearby_soft:
                    alert["nearby_soft_targets"] = nearby_soft
                
                # Add alert to results
                results["geofence_alerts"].append(alert)
                
                # Update alert history
                self.alert_history[geofence["id"]] = {
                    "date": datetime.now().strftime("%Y-%m-%d"),
                    "alert_id": alert_id
                }
        
        # Update total alerts
        results["total_alerts"] = len(results["geofence_alerts"])
        
        return results
    
    def identify_latent_threats(self, days_back=180, min_incident_count=3, proximity_threshold_km=15):
        """
        Identify potential latent threats to targets based on extended pattern analysis
        
        Args:
            days_back: Number of days to analyze
            min_incident_count: Minimum number of incidents to consider
            proximity_threshold_km: Maximum distance between related incidents
            
        Returns:
            Dictionary with identified latent threats
        """
        # Get historical data
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days_back)
        
        if self.data_handler:
            try:
                data = self.data_handler.load_osint_data("all", start_date=start_date, end_date=end_date)
            except Exception as e:
                print(f"Error loading data for latent threat analysis: {str(e)}")
                data = pd.DataFrame()
        else:
            data = pd.DataFrame()
        
        if data.empty:
            return {"error": "No historical data available for latent threat analysis"}
        
        # Check if we have geographic coordinates
        if not all(col in data.columns for col in ["Latitude", "Longitude"]):
            return {"error": "Incident data missing geographic coordinates"}
        
        # Remove rows with missing coordinates
        data = data.dropna(subset=["Latitude", "Longitude"])
        
        if data.empty:
            return {"error": "No incident data with valid coordinates available"}
        
        # Initialize results
        results = {
            "timestamp": datetime.now().isoformat(),
            "analysis_period": {
                "start_date": start_date.isoformat(),
                "end_date": end_date.isoformat()
            },
            "identified_patterns": [],
            "potential_targets": []
        }
        
        # Look for temporal patterns
        if "Event Date" in data.columns:
            try:
                data["Event Date"] = pd.to_datetime(data["Event Date"])
                
                # Group by month
                data["month"] = data["Event Date"].dt.to_period("M")
                monthly_counts = data.groupby("month").size()
                
                # Check for increasing trends
                if len(monthly_counts) >= 3:
                    is_increasing = True
                    for i in range(1, len(monthly_counts)):
                        if monthly_counts.iloc[i] < monthly_counts.iloc[i-1]:
                            is_increasing = False
                            break
                    
                    if is_increasing:
                        results["identified_patterns"].append({
                            "type": "temporal",
                            "pattern": "increasing_frequency",
                            "description": "Increasing frequency of incidents over time",
                            "significance": "high" if monthly_counts.iloc[-1] >= 2*monthly_counts.iloc[0] else "medium"
                        })
                
                # Check for cyclical patterns
                if len(monthly_counts) >= 6:
                    # Simple check for alternating high/low counts
                    highs = monthly_counts.iloc[::2].mean()
                    lows = monthly_counts.iloc[1::2].mean()
                    
                    if highs > 1.5 * lows:
                        results["identified_patterns"].append({
                            "type": "temporal",
                            "pattern": "cyclical",
                            "description": "Possible cyclical pattern in incident frequency",
                            "significance": "medium"
                        })
                
                # Check for day-of-week patterns
                data["day_of_week"] = data["Event Date"].dt.day_name()
                dow_counts = data.groupby("day_of_week").size()
                
                if len(dow_counts) > 0:
                    max_day = dow_counts.idxmax()
                    max_count = dow_counts.max()
                    avg_count = dow_counts.mean()
                    
                    if max_count > 1.5 * avg_count:
                        results["identified_patterns"].append({
                            "type": "temporal",
                            "pattern": "day_of_week",
                            "description": f"Higher concentration of incidents on {max_day}s",
                            "significance": "medium"
                        })
            
            except Exception as e:
                print(f"Error in temporal pattern analysis: {str(e)}")
        
        # Use geographic pattern analysis for spatial patterns
        geographic_patterns = self._analyze_geographic_patterns(data)
        
        # Add significant geographic patterns
        for pattern in geographic_patterns:
            if pattern.get("significance") == "high":
                results["identified_patterns"].append(pattern)
        
        # Find potential targets based on patterns
        for pattern in results["identified_patterns"]:
            if pattern["type"] in ["cluster", "density_hotspot", "linear"]:
                # For spatial patterns, find targets that aren't yet in the nearby lists
                
                if pattern["type"] == "linear":
                    # For linear patterns, search along the line
                    endpoint1 = pattern["endpoints"][0]
                    endpoint2 = pattern["endpoints"][1]
                    
                    # Calculate midpoint
                    mid_lat = (endpoint1["latitude"] + endpoint2["latitude"]) / 2
                    mid_long = (endpoint1["longitude"] + endpoint2["longitude"]) / 2
                    
                    # Search radius based on line length
                    search_radius = pattern["length_km"] * 0.75  # 75% of line length
                    
                    # Get all targets in the area
                    all_ci = self._collect_all_targets_in_area(
                        mid_lat, mid_long, search_radius, "critical_infrastructure"
                    )
                    
                    all_soft = self._collect_all_targets_in_area(
                        mid_lat, mid_long, search_radius, "soft_targets"
                    )
                    
                    # Filter out targets already in the nearby lists
                    existing_ci = {target["name"] for target in pattern.get("nearby_critical_infrastructure", [])}
                    existing_soft = {target["name"] for target in pattern.get("nearby_soft_targets", [])}
                    
                    new_ci = [target for target in all_ci if target["name"] not in existing_ci]
                    new_soft = [target for target in all_soft if target["name"] not in existing_soft]
                    
                    # Add potential targets if not already found
                    for target in new_ci:
                        if self._is_approximately_on_line(
                            target["latitude"], target["longitude"],
                            endpoint1["latitude"], endpoint1["longitude"],
                            endpoint2["latitude"], endpoint2["longitude"]
                        ):
                            results["potential_targets"].append({
                                "target": target,
                                "related_pattern": pattern["type"],
                                "threat_level": "medium",
                                "reasoning": "Target aligns with linear pattern of incidents"
                            })
                    
                    for target in new_soft:
                        if self._is_approximately_on_line(
                            target["latitude"], target["longitude"],
                            endpoint1["latitude"], endpoint1["longitude"],
                            endpoint2["latitude"], endpoint2["longitude"]
                        ):
                            results["potential_targets"].append({
                                "target": target,
                                "related_pattern": pattern["type"],
                                "threat_level": "medium",
                                "reasoning": "Target aligns with linear pattern of incidents"
                            })
                
                else:  # cluster or density_hotspot
                    # Get center coordinates
                    center_lat = pattern["center"]["latitude"]
                    center_long = pattern["center"]["longitude"]
                    
                    # Expand search radius beyond the pattern
                    search_radius = pattern["radius_km"] * 2  # Double the pattern radius
                    
                    # Get all targets in the expanded area
                    all_ci = self._collect_all_targets_in_area(
                        center_lat, center_long, search_radius, "critical_infrastructure"
                    )
                    
                    all_soft = self._collect_all_targets_in_area(
                        center_lat, center_long, search_radius, "soft_targets"
                    )
                    
                    # Filter out targets already in the nearby lists
                    existing_ci = {target["name"] for target in pattern.get("nearby_critical_infrastructure", [])}
                    existing_soft = {target["name"] for target in pattern.get("nearby_soft_targets", [])}
                    
                    new_ci = [target for target in all_ci if target["name"] not in existing_ci]
                    new_soft = [target for target in all_soft if target["name"] not in existing_soft]
                    
                    # Add potential targets
                    for target in new_ci:
                        dist = geodesic(
                            (center_lat, center_long), 
                            (target["latitude"], target["longitude"])
                        ).kilometers
                        
                        if pattern["radius_km"] < dist <= search_radius:
                            results["potential_targets"].append({
                                "target": target,
                                "related_pattern": pattern["type"],
                                "distance_from_pattern_km": dist - pattern["radius_km"],
                                "threat_level": "medium" if dist <= pattern["radius_km"] * 1.5 else "low",
                                "reasoning": f"Target is in extended vicinity of {pattern['type']} pattern"
                            })
                    
                    for target in new_soft:
                        dist = geodesic(
                            (center_lat, center_long), 
                            (target["latitude"], target["longitude"])
                        ).kilometers
                        
                        if pattern["radius_km"] < dist <= search_radius:
                            results["potential_targets"].append({
                                "target": target,
                                "related_pattern": pattern["type"],
                                "distance_from_pattern_km": dist - pattern["radius_km"],
                                "threat_level": "medium" if dist <= pattern["radius_km"] * 1.5 else "low",
                                "reasoning": f"Target is in extended vicinity of {pattern['type']} pattern"
                            })
        
        # Look for similar targets to those already affected
        if data is not None and "Incident Type" in data.columns:
            # Find targets that are of the same type as those near incidents
            target_types_near_incidents = set()
            
            # For each incident, find nearby targets and note their types
            for _, incident in data.iterrows():
                if "Latitude" in incident and "Longitude" in incident and pd.notna(incident["Latitude"]) and pd.notna(incident["Longitude"]):
                    nearby_ci = self._find_targets_near_point(
                        incident["Latitude"], incident["Longitude"], 10,
                        "critical_infrastructure"
                    )
                    
                    nearby_soft = self._find_targets_near_point(
                        incident["Latitude"], incident["Longitude"], 10,
                        "soft_targets"
                    )
                    
                    for target in nearby_ci:
                        target_types_near_incidents.add((target["type"], "critical_infrastructure"))
                    
                    for target in nearby_soft:
                        target_types_near_incidents.add((target["type"], "soft_targets"))
            
            # Now find other targets of the same types that aren't near incidents
            for target_type, category in target_types_near_incidents:
                if category == "critical_infrastructure":
                    for cat, targets in self.critical_infrastructure.items():
                        for target in targets:
                            if target["type"] == target_type:
                                # Check if this target is already in potential_targets
                                already_included = False
                                for pot_target in results["potential_targets"]:
                                    if pot_target["target"]["name"] == target["name"]:
                                        already_included = True
                                        break
                                
                                if not already_included:
                                    # Check if it's near any incidents
                                    nearby_incidents = self._get_nearby_incidents(
                                        data, 
                                        target["latitude"], 
                                        target["longitude"], 
                                        proximity_threshold_km
                                    )
                                    
                                    if len(nearby_incidents) == 0:  # No incidents nearby
                                        results["potential_targets"].append({
                                            "target": {
                                                "name": target["name"],
                                                "type": target["type"],
                                                "category": cat,
                                                "latitude": target["latitude"],
                                                "longitude": target["longitude"]
                                            },
                                            "related_pattern": "target_similarity",
                                            "threat_level": "medium",
                                            "reasoning": f"Target is similar to others that have had incidents nearby"
                                        })
                
                elif category == "soft_targets":
                    for cat, targets in self.soft_targets.items():
                        for target in targets:
                            if target["type"] == target_type:
                                # Check if this target is already in potential_targets
                                already_included = False
                                for pot_target in results["potential_targets"]:
                                    if pot_target["target"]["name"] == target["name"]:
                                        already_included = True
                                        break
                                
                                if not already_included:
                                    # Check if it's near any incidents
                                    nearby_incidents = self._get_nearby_incidents(
                                        data, 
                                        target["latitude"], 
                                        target["longitude"], 
                                        proximity_threshold_km
                                    )
                                    
                                    if len(nearby_incidents) == 0:  # No incidents nearby
                                        results["potential_targets"].append({
                                            "target": {
                                                "name": target["name"],
                                                "type": target["type"],
                                                "category": cat,
                                                "latitude": target["latitude"],
                                                "longitude": target["longitude"]
                                            },
                                            "related_pattern": "target_similarity",
                                            "threat_level": "medium",
                                            "reasoning": f"Target is similar to others that have had incidents nearby"
                                        })
        
        # Sort potential targets by threat level
        threat_level_map = {"high": 3, "medium": 2, "low": 1}
        results["potential_targets"].sort(key=lambda x: threat_level_map.get(x["threat_level"], 0), reverse=True)
        
        return results
    
    def _collect_all_targets_in_area(self, center_lat, center_long, radius_km, target_type):
        """
        Collect all targets in an area with their coordinates
        
        Args:
            center_lat: Center latitude
            center_long: Center longitude
            radius_km: Search radius in kilometers
            target_type: Type of targets to collect
            
        Returns:
            List of targets with coordinates
        """
        targets = []
        
        if target_type == "critical_infrastructure":
            for category, category_targets in self.critical_infrastructure.items():
                for target in category_targets:
                    dist = geodesic(
                        (center_lat, center_long), 
                        (target["latitude"], target["longitude"])
                    ).kilometers
                    
                    if dist <= radius_km:
                        targets.append({
                            "name": target["name"],
                            "type": target["type"],
                            "category": category,
                            "latitude": target["latitude"],
                            "longitude": target["longitude"],
                            "distance_km": dist
                        })
        
        elif target_type == "soft_targets":
            for category, category_targets in self.soft_targets.items():
                for target in category_targets:
                    dist = geodesic(
                        (center_lat, center_long), 
                        (target["latitude"], target["longitude"])
                    ).kilometers
                    
                    if dist <= radius_km:
                        targets.append({
                            "name": target["name"],
                            "type": target["type"],
                            "category": category,
                            "latitude": target["latitude"],
                            "longitude": target["longitude"],
                            "distance_km": dist
                        })
        
        return targets
    
    def _is_approximately_on_line(self, point_lat, point_long, line_start_lat, line_start_long, line_end_lat, line_end_long, tolerance_km=5):
        """
        Check if a point is approximately on a line
        
        Args:
            point_lat: Point latitude
            point_long: Point longitude
            line_start_lat: Line start latitude
            line_start_long: Line start longitude
            line_end_lat: Line end latitude
            line_end_long: Line end longitude
            tolerance_km: Distance tolerance in kilometers
            
        Returns:
            Boolean indicating if point is approximately on the line
        """
        if not SHAPELY_AVAILABLE:
            # Fallback if shapely not available
            # Calculate distance to line using the formula from point to line
            # This is an approximation assuming a flat earth
            
            # Convert to Cartesian coordinates (simple approximation)
            x1, y1 = line_start_long, line_start_lat
            x2, y2 = line_end_long, line_end_lat
            x0, y0 = point_long, point_lat
            
            # Calculate distance from point to line
            numerator = abs((y2-y1)*x0 - (x2-x1)*y0 + x2*y1 - y2*x1)
            denominator = math.sqrt((y2-y1)**2 + (x2-x1)**2)
            
            if denominator == 0:
                return False
                
            distance = numerator / denominator
            
            # Convert to kilometers (very rough approximation)
            # 1 degree is approximately 111 km
            distance_km = distance * 111
            
            # Check if point is within tolerance
            if distance_km <= tolerance_km:
                # Also check if point is between the endpoints
                min_lat = min(line_start_lat, line_end_lat)
                max_lat = max(line_start_lat, line_end_lat)
                min_long = min(line_start_long, line_end_long)
                max_long = max(line_start_long, line_end_long)
                
                return (min_lat - 0.1 <= point_lat <= max_lat + 0.1) and (min_long - 0.1 <= point_long <= max_long + 0.1)
            
            return False
        else:
            # Use shapely for more accurate calculation
            from shapely.geometry import Point, LineString
            
            # Create point and line
            point = Point(point_long, point_lat)
            line = LineString([(line_start_long, line_start_lat), (line_end_long, line_end_lat)])
            
            # Calculate distance in degrees
            distance_degrees = point.distance(line)
            
            # Convert to kilometers (rough approximation)
            distance_km = distance_degrees * 111
            
            return distance_km <= tolerance_km
    
    def generate_target_analysis_report(self, days_back=90, include_latent_threats=True):
        """
        Generate a comprehensive target analysis report
        
        Args:
            days_back: Number of days to analyze
            include_latent_threats: Whether to include latent threat analysis
            
        Returns:
            Dictionary containing the full analysis report
        """
        # Initialize report
        report = {
            "timestamp": datetime.now().isoformat(),
            "analysis_period": {
                "days_back": days_back,
                "start_date": (datetime.now() - timedelta(days=days_back)).isoformat(),
                "end_date": datetime.now().isoformat()
            },
            "target_analysis": {},
            "geofence_analysis": {},
            "latent_threats": {}
        }
        
        # Add target analysis
        target_analysis = self.analyze_targets_at_risk(days_back=days_back)
        if "error" not in target_analysis:
            report["target_analysis"] = target_analysis
        
        # Add geofence analysis
        geofence_analysis = self.check_geofences(days_back=min(days_back, 30))  # Limit to last 30 days for geofences
        if "error" not in geofence_analysis:
            report["geofence_analysis"] = geofence_analysis
        
        # Add latent threat analysis if requested
        if include_latent_threats:
            latent_threats = self.identify_latent_threats(days_back=days_back)
            if "error" not in latent_threats:
                report["latent_threats"] = latent_threats
        
        # Generate summary statistics
        summary = {
            "critical_infrastructure_at_risk": len(target_analysis.get("critical_infrastructure_at_risk", [])) if "error" not in target_analysis else 0,
            "soft_targets_at_risk": len(target_analysis.get("soft_targets_at_risk", [])) if "error" not in target_analysis else 0,
            "active_geofence_alerts": geofence_analysis.get("total_alerts", 0) if "error" not in geofence_analysis else 0
        }
        
        if include_latent_threats and "error" not in latent_threats:
            summary["identified_patterns"] = len(latent_threats.get("identified_patterns", []))
            summary["potential_targets"] = len(latent_threats.get("potential_targets", []))
        
        report["summary"] = summary
        
        return report
    
    def export_target_database(self, format="json"):
        """
        Export the target database in the specified format
        
        Args:
            format: Export format (json, csv)
            
        Returns:
            Exported target database
        """
        # Collect all targets
        all_targets = []
        
        # Add critical infrastructure
        for category, targets in self.critical_infrastructure.items():
            for target in targets:
                target_data = target.copy()
                target_data["category"] = category
                target_data["target_type"] = "critical_infrastructure"
                all_targets.append(target_data)
        
        # Add soft targets
        for category, targets in self.soft_targets.items():
            for target in targets:
                target_data = target.copy()
                target_data["category"] = category
                target_data["target_type"] = "soft_targets"
                all_targets.append(target_data)
        
        # Add custom targets
        for target in self.custom_targets:
            target_data = target.copy()
            target_data["target_type"] = "custom"
            all_targets.append(target_data)
        
        if format == "json":
            import json
            return json.dumps(all_targets, indent=2)
        
        elif format == "csv":
            import csv
            import io
            
            output = io.StringIO()
            
            # Get all possible fields
            fields = set()
            for target in all_targets:
                fields.update(target.keys())
            
            writer = csv.DictWriter(output, fieldnames=sorted(fields))
            writer.writeheader()
            writer.writerows(all_targets)
            
            return output.getvalue()
        
        else:
            return {"error": f"Export format '{format}' not supported"}
    
    def import_target_database(self, data, format="json", merge=True):
        """
        Import targets from external data
        
        Args:
            data: Target data to import
            format: Import format (json, csv)
            merge: Whether to merge with existing data or replace
            
        Returns:
            Import status information
        """
        # Parse the data
        imported_targets = []
        
        if format == "json":
            try:
                import json
                targets = json.loads(data)
                
                if isinstance(targets, list):
                    imported_targets = targets
                else:
                    return {"error": "Invalid JSON format. Expected a list of targets."}
            
            except Exception as e:
                return {"error": f"Error parsing JSON: {str(e)}"}
        
        elif format == "csv":
            try:
                import csv
                import io
                
                csvfile = io.StringIO(data)
                reader = csv.DictReader(csvfile)
                
                for row in reader:
                    imported_targets.append(row)
            
            except Exception as e:
                return {"error": f"Error parsing CSV: {str(e)}"}
        
        else:
            return {"error": f"Import format '{format}' not supported"}
        
        # Process the imported targets
        if not merge:
            # Clear existing targets if not merging
            self.critical_infrastructure = {}
            self.soft_targets = {}
            self.custom_targets = []
        
        # Process each imported target
        imported_count = {"critical_infrastructure": 0, "soft_targets": 0, "custom": 0}
        
        for target in imported_targets:
            target_type = target.get("target_type", "custom")
            category = target.get("category", "other")
            
            # Ensure required fields are present
            if not all(field in target for field in ["name", "latitude", "longitude"]):
                continue
            
            if target_type == "critical_infrastructure":
                # Add to critical infrastructure
                if category not in self.critical_infrastructure:
                    self.critical_infrastructure[category] = []
                
                self.critical_infrastructure[category].append({
                    "name": target["name"],
                    "type": target.get("type", "unknown"),
                    "latitude": float(target["latitude"]),
                    "longitude": float(target["longitude"]),
                    "radius_km": float(target.get("radius_km", 5))
                })
                
                imported_count["critical_infrastructure"] += 1
            
            elif target_type == "soft_targets":
                # Add to soft targets
                if category not in self.soft_targets:
                    self.soft_targets[category] = []
                
                self.soft_targets[category].append({
                    "name": target["name"],
                    "type": target.get("type", "unknown"),
                    "latitude": float(target["latitude"]),
                    "longitude": float(target["longitude"]),
                    "capacity": int(target.get("capacity", 1000))
                })
                
                imported_count["soft_targets"] += 1
            
            else:  # custom
                # Add to custom targets
                self.custom_targets.append({
                    "name": target["name"],
                    "type": target.get("type", "unknown"),
                    "latitude": float(target["latitude"]),
                    "longitude": float(target["longitude"]),
                    "radius_km": float(target.get("radius_km", 2)),
                    "added_date": target.get("added_date", datetime.now().isoformat())
                })
                
                imported_count["custom"] += 1
        
        # Return import statistics
        return {
            "status": "success",
            "imported_count": imported_count,
            "total_imported": sum(imported_count.values())
        }