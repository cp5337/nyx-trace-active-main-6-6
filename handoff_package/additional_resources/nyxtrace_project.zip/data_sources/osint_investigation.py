"""
OSINT Investigation Module
------------------------
This module provides functionality for conducting OSINT investigations
using various data sources and integrating the results.
"""

import os
import json
import logging
import pandas as pd
import numpy as np
import re
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Union
import hashlib
import time
from enum import Enum

from .data_source_integrator import DataSourceIntegrator, SourceType
from .plugins import get_available_plugins, get_plugin_class

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('osint_investigation')


class InvestigationType(Enum):
    """Types of OSINT investigations"""
    LOCATION = "location"
    PERSON = "person"
    ORGANIZATION = "organization"
    DOMAIN = "domain"
    IP_ADDRESS = "ip_address"
    EMAIL = "email"
    THREAT_ACTOR = "threat_actor"


class OsintInvestigation:
    """
    Main class for conducting OSINT investigations
    
    This class provides methods for:
    - Initializing and managing data sources
    - Conducting investigations on different entity types
    - Analyzing and reporting on investigation results
    """
    
    def __init__(self):
        """Initialize OSINT Investigation module"""
        self.data_integrator = DataSourceIntegrator()
        self.investigations = {}
        self.results = {}
        
        # Initialize plugins
        self._initialize_plugins()
        
        logger.info("OSINT Investigation module initialized")
    
    def _initialize_plugins(self):
        """
        Initialize data source plugins
        
        This method demonstrates the plugin system by initializing
        the available data source plugins from the plugins directory.
        """
        plugins = get_available_plugins()
        logger.info(f"Found {len(plugins)} data source plugins")
        
        # For demonstration, we'll initialize a few of these plugins
        # In a real application, this would be configured from settings
        
        # Initialize News API plugin if available
        news_api_plugin = get_plugin_class("NewsAPISource")
        if news_api_plugin:
            try:
                # Create instance
                news_source = news_api_plugin()
                
                # Configure with API key
                api_key = os.environ.get("NEWS_API_KEY")
                if api_key:
                    news_source.configure({"api_key": api_key})
                    
                    # Add to data integrator
                    self.data_integrator.add_source(news_source, {"name": "News API"})
                    logger.info("Added News API source")
                else:
                    logger.warning("News API key not found in environment variables")
            except Exception as e:
                logger.error(f"Error initializing News API plugin: {str(e)}")
        
        # Initialize Twitter plugin if available
        twitter_plugin = get_plugin_class("SocialMonitoringSource")
        if twitter_plugin:
            try:
                # Create instance
                twitter_source = twitter_plugin(platform="twitter")
                
                # Configure with API key
                api_key = os.environ.get("TWITTER_API_KEY")
                if api_key:
                    twitter_source.configure({
                        "api_key": api_key,
                        "platform": "twitter"
                    })
                    
                    # Add to data integrator
                    self.data_integrator.add_source(twitter_source, {"name": "Twitter Monitoring"})
                    logger.info("Added Twitter source")
                else:
                    logger.warning("Twitter API key not found in environment variables")
            except Exception as e:
                logger.error(f"Error initializing Twitter plugin: {str(e)}")
    
    def investigate(self, 
                   query: str, 
                   investigation_type: Union[InvestigationType, str] = InvestigationType.LOCATION,
                   start_date: Optional[datetime] = None,
                   end_date: Optional[datetime] = None,
                   source_types: Optional[List[str]] = None) -> str:
        """
        Start a new investigation
        
        Args:
            query: Query string (location, person, etc.)
            investigation_type: Type of investigation
            start_date: Start date for data collection
            end_date: End date for data collection
            source_types: Optional list of source types to include
            
        Returns:
            Investigation ID
        """
        # Convert string enum to enum type if necessary
        if isinstance(investigation_type, str):
            investigation_type = InvestigationType(investigation_type)
        
        # Set default dates if not provided
        if not end_date:
            end_date = datetime.now()
        
        if not start_date:
            start_date = end_date - timedelta(days=30)
        
        # Generate investigation ID
        investigation_id = hashlib.md5(f"{query}_{investigation_type.value}_{int(time.time())}".encode()).hexdigest()
        
        # Setup investigation
        self.investigations[investigation_id] = {
            'id': investigation_id,
            'query': query,
            'type': investigation_type.value,
            'start_date': start_date,
            'end_date': end_date,
            'source_types': source_types,
            'status': 'pending',
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        }
        
        # Start the investigation in the background
        # (in a real application, this would be done asynchronously)
        try:
            self._run_investigation(investigation_id)
            logger.info(f"Started investigation {investigation_id} for {query}")
        except Exception as e:
            logger.error(f"Error starting investigation {investigation_id}: {str(e)}")
            self.investigations[investigation_id]['status'] = 'error'
            self.investigations[investigation_id]['error'] = str(e)
        
        return investigation_id
    
    def get_investigation_status(self, investigation_id: str) -> Dict[str, Any]:
        """
        Get status of an investigation
        
        Args:
            investigation_id: ID of the investigation
            
        Returns:
            Status dictionary
        """
        if investigation_id not in self.investigations:
            return {'status': 'not_found'}
        
        return self.investigations[investigation_id]
    
    def get_investigation_results(self, investigation_id: str) -> Optional[pd.DataFrame]:
        """
        Get results of an investigation
        
        Args:
            investigation_id: ID of the investigation
            
        Returns:
            Results DataFrame if available, None otherwise
        """
        if investigation_id not in self.results:
            return None
        
        return self.results[investigation_id]
    
    def get_investigation_summary(self, investigation_id: str) -> Dict[str, Any]:
        """
        Get a summary of investigation results
        
        Args:
            investigation_id: ID of the investigation
            
        Returns:
            Summary dictionary
        """
        if investigation_id not in self.investigations:
            return {'status': 'not_found'}
        
        if investigation_id not in self.results:
            return {
                'status': self.investigations[investigation_id]['status'],
                'query': self.investigations[investigation_id]['query'],
                'type': self.investigations[investigation_id]['type'],
                'message': 'Results not available'
            }
        
        df = self.results[investigation_id]
        
        # Generate summary
        summary = {
            'status': 'completed',
            'query': self.investigations[investigation_id]['query'],
            'type': self.investigations[investigation_id]['type'],
            'total_records': len(df),
            'date_range': {
                'start': self.investigations[investigation_id]['start_date'].strftime('%Y-%m-%d'),
                'end': self.investigations[investigation_id]['end_date'].strftime('%Y-%m-%d')
            },
            'sources': df['Source'].value_counts().to_dict(),
            'activity_by_date': self._summarize_activity_by_date(df),
            'sentiment_analysis': self._summarize_sentiment(df)
        }
        
        # Add type-specific summary
        if self.investigations[investigation_id]['type'] == InvestigationType.LOCATION.value:
            summary['location_analysis'] = self._summarize_location(df, self.investigations[investigation_id]['query'])
        
        return summary
    
    def _run_investigation(self, investigation_id: str) -> None:
        """
        Run an investigation
        
        Args:
            investigation_id: ID of the investigation
        """
        investigation = self.investigations[investigation_id]
        investigation['status'] = 'running'
        investigation['updated_at'] = datetime.now()
        
        try:
            # Get parameters
            query = investigation['query']
            investigation_type = investigation['type']
            start_date = investigation['start_date']
            end_date = investigation['end_date']
            source_types = investigation['source_types']
            
            # Convert source types to SourceType enum
            source_type_enums = None
            if source_types:
                source_type_enums = [SourceType(st) for st in source_types]
            
            # Run different investigation based on type
            if investigation_type == InvestigationType.LOCATION.value:
                results = self._investigate_location(query, start_date, end_date, source_type_enums)
            elif investigation_type == InvestigationType.PERSON.value:
                results = self._investigate_person(query, start_date, end_date, source_type_enums)
            elif investigation_type == InvestigationType.ORGANIZATION.value:
                results = self._investigate_organization(query, start_date, end_date, source_type_enums)
            elif investigation_type == InvestigationType.DOMAIN.value:
                results = self._investigate_domain(query, start_date, end_date, source_type_enums)
            elif investigation_type == InvestigationType.IP_ADDRESS.value:
                results = self._investigate_ip_address(query, start_date, end_date, source_type_enums)
            elif investigation_type == InvestigationType.EMAIL.value:
                results = self._investigate_email(query, start_date, end_date, source_type_enums)
            elif investigation_type == InvestigationType.THREAT_ACTOR.value:
                results = self._investigate_threat_actor(query, start_date, end_date, source_type_enums)
            else:
                # Default to location investigation
                results = self._investigate_location(query, start_date, end_date, source_type_enums)
            
            # Store results
            self.results[investigation_id] = results
            
            # Update investigation status
            investigation['status'] = 'completed'
            investigation['updated_at'] = datetime.now()
            
            logger.info(f"Completed investigation {investigation_id} for {query}")
            
        except Exception as e:
            logger.error(f"Error during investigation {investigation_id}: {str(e)}")
            investigation['status'] = 'error'
            investigation['error'] = str(e)
            investigation['updated_at'] = datetime.now()
    
    def _investigate_location(self, 
                             location: str, 
                             start_date: datetime, 
                             end_date: datetime,
                             source_types: Optional[List[SourceType]] = None) -> pd.DataFrame:
        """
        Investigate a location
        
        Args:
            location: Location name
            start_date: Start date
            end_date: End date
            source_types: Optional list of source types to include
            
        Returns:
            DataFrame with results
        """
        # Get data from integrator
        df = self.data_integrator.get_data(location, start_date, end_date, source_types)
        
        # If no data, return empty DataFrame
        if df.empty:
            return pd.DataFrame(columns=['Source', 'Date', 'Content', 'Sentiment', 'Activity_Level'])
        
        return df
    
    def _investigate_person(self, 
                           person: str, 
                           start_date: datetime, 
                           end_date: datetime,
                           source_types: Optional[List[SourceType]] = None) -> pd.DataFrame:
        """
        Investigate a person
        
        Args:
            person: Person name
            start_date: Start date
            end_date: End date
            source_types: Optional list of source types to include
            
        Returns:
            DataFrame with results
        """
        # This would be implemented similar to location but with person-specific logic
        # For now, we'll use the same approach as location
        return self._investigate_location(person, start_date, end_date, source_types)
    
    def _investigate_organization(self, 
                                organization: str, 
                                start_date: datetime, 
                                end_date: datetime,
                                source_types: Optional[List[SourceType]] = None) -> pd.DataFrame:
        """
        Investigate an organization
        
        Args:
            organization: Organization name
            start_date: Start date
            end_date: End date
            source_types: Optional list of source types to include
            
        Returns:
            DataFrame with results
        """
        # This would be implemented similar to location but with organization-specific logic
        # For now, we'll use the same approach as location
        return self._investigate_location(organization, start_date, end_date, source_types)
    
    def _investigate_domain(self, 
                          domain: str, 
                          start_date: datetime, 
                          end_date: datetime,
                          source_types: Optional[List[SourceType]] = None) -> pd.DataFrame:
        """
        Investigate a domain
        
        Args:
            domain: Domain name
            start_date: Start date
            end_date: End date
            source_types: Optional list of source types to include
            
        Returns:
            DataFrame with results
        """
        # This would involve domain-specific data sources and analysis
        # For now, we'll use a placeholder
        return pd.DataFrame(columns=['Source', 'Date', 'Content', 'Sentiment', 'Activity_Level'])
    
    def _investigate_ip_address(self, 
                              ip_address: str, 
                              start_date: datetime, 
                              end_date: datetime,
                              source_types: Optional[List[SourceType]] = None) -> pd.DataFrame:
        """
        Investigate an IP address
        
        Args:
            ip_address: IP address
            start_date: Start date
            end_date: End date
            source_types: Optional list of source types to include
            
        Returns:
            DataFrame with results
        """
        # This would involve IP-specific data sources and analysis
        # For now, we'll use a placeholder
        return pd.DataFrame(columns=['Source', 'Date', 'Content', 'Sentiment', 'Activity_Level'])
    
    def _investigate_email(self, 
                         email: str, 
                         start_date: datetime, 
                         end_date: datetime,
                         source_types: Optional[List[SourceType]] = None) -> pd.DataFrame:
        """
        Investigate an email address
        
        Args:
            email: Email address
            start_date: Start date
            end_date: End date
            source_types: Optional list of source types to include
            
        Returns:
            DataFrame with results
        """
        # This would involve email-specific data sources and analysis
        # For now, we'll use a placeholder
        return pd.DataFrame(columns=['Source', 'Date', 'Content', 'Sentiment', 'Activity_Level'])
    
    def _investigate_threat_actor(self, 
                                 actor: str, 
                                 start_date: datetime, 
                                 end_date: datetime,
                                 source_types: Optional[List[SourceType]] = None) -> pd.DataFrame:
        """
        Investigate a threat actor
        
        Args:
            actor: Threat actor name
            start_date: Start date
            end_date: End date
            source_types: Optional list of source types to include
            
        Returns:
            DataFrame with results
        """
        # This would involve threat actor-specific data sources and analysis
        # For now, we'll use a placeholder approach similar to location
        return self._investigate_location(actor, start_date, end_date, source_types)
    
    def _summarize_activity_by_date(self, df: pd.DataFrame) -> Dict[str, float]:
        """
        Summarize activity by date
        
        Args:
            df: DataFrame with results
            
        Returns:
            Dictionary mapping dates to activity levels
        """
        if 'Date' not in df.columns or 'Activity_Level' not in df.columns:
            return {}
        
        # Group by date and sum activity levels
        df['Date_Str'] = df['Date'].dt.strftime('%Y-%m-%d')
        activity_by_date = df.groupby('Date_Str')['Activity_Level'].sum().to_dict()
        
        return activity_by_date
    
    def _summarize_sentiment(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Summarize sentiment analysis
        
        Args:
            df: DataFrame with results
            
        Returns:
            Dictionary with sentiment summary
        """
        if 'Sentiment' not in df.columns:
            return {}
        
        # Calculate statistics
        mean_sentiment = df['Sentiment'].mean()
        median_sentiment = df['Sentiment'].median()
        min_sentiment = df['Sentiment'].min()
        max_sentiment = df['Sentiment'].max()
        
        # Count positives and negatives
        positive_count = len(df[df['Sentiment'] > 0])
        negative_count = len(df[df['Sentiment'] < 0])
        neutral_count = len(df[df['Sentiment'] == 0])
        
        return {
            'mean': mean_sentiment,
            'median': median_sentiment,
            'min': min_sentiment,
            'max': max_sentiment,
            'counts': {
                'positive': positive_count,
                'negative': negative_count,
                'neutral': neutral_count
            }
        }
    
    def _summarize_location(self, df: pd.DataFrame, location: str) -> Dict[str, Any]:
        """
        Summarize location analysis
        
        Args:
            df: DataFrame with results
            location: Location name
            
        Returns:
            Dictionary with location summary
        """
        # This would include geospatial analysis and location-specific metrics
        # For now, we'll use a placeholder
        
        return {
            'location': location,
            'sources': len(df['Source'].unique()),
            'mentions': len(df),
            'timespan': {
                'start': df['Date'].min().strftime('%Y-%m-%d') if not df.empty else None,
                'end': df['Date'].max().strftime('%Y-%m-%d') if not df.empty else None
            }
        }
    
    # Additional methods could be implemented for more sophisticated analysis
    # For example:
    # - Entity extraction
    # - Network analysis
    # - Geospatial analysis
    # - Timeline generation
    # - etc.