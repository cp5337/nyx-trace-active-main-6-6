"""
Critical Infrastructure Scanner Module
-------------------------------------
This module is designed to identify, catalog, and monitor critical infrastructure 
across the 16 official sectors defined by CISA. It combines Shodan data mining,
web scraping, OSINT techniques, and geospatial analysis to build a comprehensive
database of critical infrastructure assets that can be used for threat analysis.

Key capabilities:
1. Shodan search with sector-specific dorks
2. OSINT data collection for critical infrastructure
3. Geolocation and verification of infrastructure assets
4. Risk scoring based on exposure and vulnerabilities
5. Integration with multi-model processing for data enrichment
6. Secure, access-controlled database of sensitive infrastructure data
"""

import os
import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
import re
import csv
from typing import Dict, List, Any, Optional, Tuple, Set
import logging
import requests
from urllib3.exceptions import InsecureRequestWarning
import socket
import ipaddress

# Suppress insecure request warnings
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Try to import specialized modules
try:
    import shodan
    SHODAN_AVAILABLE = True
except ImportError:
    SHODAN_AVAILABLE = False

try:
    from geopy.geocoders import Nominatim
    from geopy.distance import geodesic
    GEOPY_AVAILABLE = True
except ImportError:
    GEOPY_AVAILABLE = False

try:
    from .multi_model_processor import MultiModelProcessor
    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('infrastructure_scanner')

class InfrastructureScanner:
    """
    Scanner for identifying and cataloging critical infrastructure across
    the 16 official sectors defined by CISA.
    """
    
    def __init__(self):
        """Initialize the infrastructure scanner"""
        self.sector_definitions = self._load_sector_definitions()
        self.shodan_client = None
        self.mcp = MultiModelProcessor() if MCP_AVAILABLE else None
        self.infrastructure_database = self._initialize_database()
        self.api_keys = {}
        
        # Tracking for rate limiting
        self.last_request_time = {}
        
        # Geolocation services
        self.geolocator = Nominatim(user_agent="infrastructure_scanner") if GEOPY_AVAILABLE else None
        
        # Statistics tracking
        self.scan_statistics = {}
    
    def _load_sector_definitions(self):
        """Load the definitions of the 16 critical infrastructure sectors"""
        
        # Full definitions based on CISA classifications
        sectors = {
            "agriculture_food": {
                "name": "Agriculture and Food",
                "description": "The Agriculture and Food Sector is almost entirely under private ownership and is composed of farms, restaurants, and registered food manufacturing, processing, and storage facilities.",
                "subsectors": ["farms", "food_processing", "food_distribution", "restaurants"],
                "keywords": ["farm", "agriculture", "food processing", "dairy", "meat", "grain", "crop", "livestock", "agricultural"],
                "common_systems": ["irrigation systems", "temperature control systems", "food processing equipment", "supply chain management"],
                "shodan_dorks": [
                    "port:502 country:US", # Modbus protocol often used in agricultural systems
                    "niagara fox", # Building automation systems used in food storage
                    "scada country:US", # SCADA systems commonly used in agriculture
                    "temperature controller", # Used in food processing and storage
                    "customer:\"farm\" country:US", # Farms specifically
                ]
            },
            "chemical": {
                "name": "Chemical",
                "description": "The Chemical Sector converts raw materials into products for everyday use, and is essential to the nation's economy. The sector can be divided into five main segments.",
                "subsectors": ["basic_chemicals", "specialty_chemicals", "agricultural_chemicals", "pharmaceuticals", "consumer_products"],
                "keywords": ["chemical", "refinery", "pharmaceutical", "petrochemical", "manufacturing", "industrial chemical", "hazardous material"],
                "common_systems": ["industrial control systems", "SCADA", "chemical process controllers", "safety systems", "monitoring equipment"],
                "shodan_dorks": [
                    "chemical port:502 country:US", # Modbus in chemical facilities
                    "port:44818 country:US", # EtherNet/IP used in chemical processing
                    "Rockwell country:US", # Allen-Bradley/Rockwell Automation systems
                    "Siemens S7 country:US", # Siemens S7 PLCs used in chemical plants
                    "DeltaV country:US", # DeltaV distributed control systems
                ]
            },
            "commercial_facilities": {
                "name": "Commercial Facilities",
                "description": "The Commercial Facilities Sector includes a diverse range of sites that draw large crowds of people for shopping, business, entertainment, or lodging.",
                "subsectors": ["entertainment_venues", "lodging", "outdoor_events", "public_assembly", "real_estate", "retail", "sports_leagues"],
                "keywords": ["mall", "stadium", "hotel", "theater", "convention center", "shopping", "retail", "entertainment", "sports venue"],
                "common_systems": ["HVAC controls", "security systems", "building automation", "access control", "point of sale"],
                "shodan_dorks": [
                    "bACnet country:US", # Building Automation and Control Networks
                    "webcam mall", # Security cameras in commercial spaces
                    "niagara fox", # Building automation systems
                    "port:5000 title:\"Metasys\"", # Johnson Controls building management
                    "mikrotik country:US", # Common in retail environments for networking
                ]
            },
            "communications": {
                "name": "Communications",
                "description": "The Communications Sector is an integral component of the U.S. economy, underlying the operations of all businesses, public safety organizations, and government.",
                "subsectors": ["wired", "wireless", "satellite", "cable", "broadcasting"],
                "keywords": ["telecom", "ISP", "network", "data center", "communications provider", "cellular", "satellite", "radio", "television", "broadcasting"],
                "common_systems": ["network infrastructure", "routing equipment", "transmission systems", "data centers", "switching equipment"],
                "shodan_dorks": [
                    "org:\"AT&T\" country:US", # Major telecom
                    "org:\"Verizon\" country:US", # Major telecom
                    "org:\"Comcast\" country:US", # Major telecom
                    "mikrotik country:US", # Common communication networking
                    "cisco country:US", # Network infrastructure equipment
                    "juniper country:US", # Network infrastructure equipment
                ]
            },
            "critical_manufacturing": {
                "name": "Critical Manufacturing",
                "description": "The Critical Manufacturing Sector identifies several industries that are essential to U.S. economic prosperity and continuity of government functions.",
                "subsectors": ["primary_metals", "machinery", "electrical_equipment", "transportation_equipment"],
                "keywords": ["manufacturing", "factory", "assembly", "industrial", "fabrication", "production", "automotive", "aerospace", "electronics"],
                "common_systems": ["industrial control systems", "PLCs", "manufacturing execution systems", "robotics", "SCADA"],
                "shodan_dorks": [
                    "Siemens S7 country:US", # Siemens S7 PLCs
                    "port:44818 country:US", # EtherNet/IP used in manufacturing
                    "Rockwell country:US", # Allen-Bradley/Rockwell Automation systems
                    "Fanuc country:US", # Robotics controllers
                    "Mitsubishi country:US", # Factory Automation systems
                ]
            },
            "dams": {
                "name": "Dams",
                "description": "The Dams Sector delivers critical water retention and control services, including hydroelectric power, drinking water, irrigation, waste management, and flood control.",
                "subsectors": ["hydropower", "navigation_locks", "flood_control", "water_treatment", "irrigation"],
                "keywords": ["dam", "reservoir", "hydroelectric", "flood control", "water supply", "irrigation", "hydropower", "levee"],
                "common_systems": ["SCADA", "water level monitoring", "spillway controls", "hydroelectric systems", "flood warning systems"],
                "shodan_dorks": [
                    "scada dam country:US", # SCADA systems for dams
                    "hydroelectric country:US", # Hydroelectric plants
                    "water control country:US", # Water control systems
                    "port:502 dam country:US", # Modbus protocol often used in dam control systems
                    "water level controller country:US", # Water level monitoring
                ]
            },
            "defense_industrial_base": {
                "name": "Defense Industrial Base",
                "description": "The Defense Industrial Base Sector is the worldwide industrial complex that enables research and development, design, production, delivery, and maintenance of military weapons systems and components.",
                "subsectors": ["military_facilities", "defense_contractors", "research_labs", "logistics_providers"],
                "keywords": ["defense contractor", "military", "aerospace", "weapons", "munitions", "national security", "DoD"],
                "common_systems": ["secure communications", "specialized manufacturing", "research facilities", "logistics systems"],
                "shodan_dorks": [
                    "org:\"Lockheed Martin\" country:US", # Major defense contractor
                    "org:\"Raytheon\" country:US", # Major defense contractor
                    "org:\"Northrop Grumman\" country:US", # Major defense contractor
                    "org:\"Boeing\" country:US", # Major defense and aerospace
                    "org:\"General Dynamics\" country:US", # Major defense contractor
                ]
            },
            "emergency_services": {
                "name": "Emergency Services",
                "description": "The Emergency Services Sector (ESS) is a community of millions of highly skilled personnel, along with the physical and cyber resources, that provide a wide range of prevention, preparedness, response, and recovery services.",
                "subsectors": ["law_enforcement", "fire_rescue", "emergency_medical", "public_works", "emergency_management"],
                "keywords": ["police", "fire department", "EMS", "emergency management", "911", "dispatch", "first responder", "emergency operations center"],
                "common_systems": ["emergency alert systems", "CAD systems", "dispatch systems", "public safety networks", "surveillance systems"],
                "shodan_dorks": [
                    "emergency management country:US", # Emergency management systems
                    "911 center country:US", # Emergency call centers
                    "police department country:US", # Law enforcement
                    "fire department country:US", # Fire services
                    "EMS country:US", # Emergency medical services
                ]
            },
            "energy": {
                "name": "Energy",
                "description": "The Energy Sector consists of widely diverse and geographically dispersed critical assets and systems that are primarily owned by the private sector, and includes electricity, oil, and natural gas.",
                "subsectors": ["electricity", "oil", "natural_gas", "renewable_energy"],
                "keywords": ["power plant", "substation", "refinery", "pipeline", "grid", "electricity", "oil", "gas", "nuclear", "solar", "wind"],
                "common_systems": ["SCADA", "energy management systems", "distribution automation", "generation control", "pipeline monitoring"],
                "shodan_dorks": [
                    "Siemens SIMATIC country:US", # Common in power generation
                    "GE Multilin country:US", # Electrical substation equipment
                    "SEL port:20000 country:US", # Schweitzer Engineering power grid equipment
                    "port:502 energy country:US", # Modbus in energy systems
                    "oil pipeline country:US", # Oil infrastructure
                    "gas pipeline country:US", # Natural gas infrastructure
                    "power plant country:US", # Electricity generation
                    "iec61850 country:US", # Power utility protocol
                    "dnp3 country:US", # Power utility protocol
                ]
            },
            "financial_services": {
                "name": "Financial Services",
                "description": "The Financial Services Sector represents a vital component of U.S. critical infrastructure, containing more than 18,000 banks, investment companies, and other institutions.",
                "subsectors": ["banks", "investment_firms", "insurance", "exchanges", "payment_systems"],
                "keywords": ["bank", "financial", "credit union", "exchange", "trading", "investment", "brokerage", "insurance", "clearinghouse"],
                "common_systems": ["trading platforms", "payment processing", "banking systems", "transaction systems", "ATMs", "core banking"],
                "shodan_dorks": [
                    "org:\"JPMorgan Chase\" country:US", # Major bank
                    "org:\"Bank of America\" country:US", # Major bank
                    "org:\"Citigroup\" country:US", # Major bank
                    "org:\"Wells Fargo\" country:US", # Major bank
                    "ATM country:US", # Automated teller machines
                    "banking portal country:US", # Online banking
                ]
            },
            "government_facilities": {
                "name": "Government Facilities",
                "description": "The Government Facilities Sector includes buildings owned or leased by federal, state, local, or tribal governments located both domestically and outside the U.S.",
                "subsectors": ["federal_buildings", "education", "national_monuments", "embassies"],
                "keywords": ["federal building", "government office", "courthouse", "military base", "federal agency", "embassy", "school", "university", "national monument"],
                "common_systems": ["access control", "security systems", "HVAC", "government networks", "surveillance systems"],
                "shodan_dorks": [
                    "org:\"Department of\" country:US", # US federal departments
                    "org:\"State of\" country:US", # State government
                    "org:\"County of\" country:US", # County government
                    "\"US Government\" country:US", # Federal government
                    "org:\"City of\" country:US", # City government
                    "".gov" country:US", # Government domains
                ]
            },
            "healthcare_public_health": {
                "name": "Healthcare and Public Health",
                "description": "The Healthcare and Public Health Sector protects all sectors of the economy from hazards such as terrorism, infectious disease outbreaks, and natural disasters.",
                "subsectors": ["hospitals", "clinics", "public_health_agencies", "pharmaceutical", "laboratories", "health_insurance"],
                "keywords": ["hospital", "medical center", "clinic", "healthcare", "public health", "laboratory", "pharmaceutical", "health department", "CDC", "NIH"],
                "common_systems": ["electronic health records", "medical devices", "laboratory information systems", "pharmacy systems", "telemedicine"],
                "shodan_dorks": [
                    "org:\"Hospital\" country:US", # Hospitals
                    "medical center country:US", # Medical centers
                    "Dicom country:US", # Medical imaging
                    "port:104 country:US", # Medical imaging DICOM protocol
                    "HL7 country:US", # Healthcare data protocol
                    "org:\"Department of Health\" country:US", # Health departments
                ]
            },
            "information_technology": {
                "name": "Information Technology",
                "description": "The IT Sector provides both products and services that enable the secure management, storage, communication, and sharing of information critical to every sector of the economy.",
                "subsectors": ["internet", "it_products", "it_services", "cloud_services", "data_centers"],
                "keywords": ["data center", "cloud provider", "ISP", "hosting", "software development", "IT services", "cybersecurity", "internet exchange"],
                "common_systems": ["servers", "networking equipment", "cloud infrastructure", "storage systems", "security systems"],
                "shodan_dorks": [
                    "org:\"Amazon\" country:US", # AWS
                    "org:\"Microsoft\" country:US", # Azure
                    "org:\"Google\" country:US", # Google Cloud
                    "org:\"IBM\" country:US", # IBM Cloud
                    "org:\"Oracle\" country:US", # Oracle Cloud
                    "data center country:US", # Data centers
                ]
            },
            "nuclear": {
                "name": "Nuclear Reactors, Materials, and Waste",
                "description": "The Nuclear Reactors, Materials, and Waste Sector includes nuclear power plants; non-power nuclear reactors used for research, testing, and training; manufacturers of nuclear reactors or components; and more.",
                "subsectors": ["nuclear_power", "research_reactors", "nuclear_materials", "waste_storage"],
                "keywords": ["nuclear power plant", "nuclear reactor", "nuclear waste", "uranium", "plutonium", "nuclear fuel", "radioactive", "NRC"],
                "common_systems": ["reactor control systems", "radiation monitoring", "security systems", "safety systems", "cooling systems"],
                "shodan_dorks": [
                    "nuclear power plant country:US", # Nuclear facilities
                    "reactor control country:US", # Reactor systems
                    "radiation monitor country:US", # Radiation detection
                    "org:\"Nuclear Regulatory Commission\" country:US", # NRC
                    "org:\"Department of Energy\" country:US", # DOE nuclear facilities
                ]
            },
            "transportation": {
                "name": "Transportation Systems",
                "description": "The Transportation Systems Sector consists of seven key subsectors, or modes: Aviation, Highway and Motor Carrier, Maritime Transportation, Mass Transit and Passenger Rail, Pipeline, Freight Rail, and Postal and Shipping.",
                "subsectors": ["aviation", "highway", "maritime", "mass_transit", "pipeline", "freight_rail", "postal_shipping"],
                "keywords": ["airport", "seaport", "railway", "highway", "bridge", "tunnel", "transit", "transportation", "logistics", "shipping"],
                "common_systems": ["traffic management", "air traffic control", "railway signaling", "vessel tracking", "logistics systems", "shipping management"],
                "shodan_dorks": [
                    "airport country:US", # Airports
                    "port authority country:US", # Seaports and maritime
                    "traffic management country:US", # Traffic systems
                    "rail control country:US", # Railway systems
                    "AIS country:US", # Maritime vessel tracking
                    "bridge country:US", # Bridge infrastructure
                    "tunnel country:US", # Tunnel infrastructure
                ]
            },
            "water": {
                "name": "Water and Wastewater Systems",
                "description": "The Water and Wastewater Systems Sector is vulnerable to a variety of attacks, including contamination with deadly agents, disruption of water supply or disruption of wastewater treatment, and cyberattacks.",
                "subsectors": ["drinking_water", "wastewater", "stormwater", "water_resources"],
                "keywords": ["water treatment", "wastewater", "sewage", "water utility", "water supply", "water system", "water infrastructure", "water resources", "stormwater"],
                "common_systems": ["SCADA", "water treatment controls", "pumping stations", "water quality monitoring", "distribution systems"],
                "shodan_dorks": [
                    "water treatment country:US", # Water treatment plants
                    "wastewater country:US", # Wastewater facilities
                    "scada water country:US", # Water SCADA systems
                    "water pump country:US", # Water pumping stations
                    "water system country:US", # Water distribution
                    "water level country:US", # Water level monitoring
                ]
            }
        }
        
        return sectors
    
    def _initialize_database(self):
        """Initialize the infrastructure database"""
        db = {}
        
        # Create entries for each sector
        for sector_id in self.sector_definitions:
            db[sector_id] = {
                "name": self.sector_definitions[sector_id]["name"],
                "facilities": [],
                "last_updated": None
            }
        
        return db
    
    def set_api_key(self, service, key):
        """
        Set an API key for a particular service
        
        Args:
            service: Service name (e.g., "shodan", "google", "censys")
            key: API key for the service
            
        Returns:
            Boolean indicating success
        """
        self.api_keys[service] = key
        
        # Initialize clients that require API keys
        if service == "shodan" and SHODAN_AVAILABLE:
            try:
                self.shodan_client = shodan.Shodan(key)
                return True
            except Exception as e:
                logger.error(f"Failed to initialize Shodan client: {str(e)}")
                return False
        
        return True
    
    def scan_infrastructure_with_shodan(self, sector_id=None, max_results=100, save_results=True):
        """
        Scan for critical infrastructure using Shodan
        
        Args:
            sector_id: ID of the sector to scan (or None for all sectors)
            max_results: Maximum results to return per sector
            save_results: Whether to save results to the database
            
        Returns:
            Dictionary with scan results
        """
        if not SHODAN_AVAILABLE:
            return {"error": "Shodan module not available. Please install it with 'pip install shodan'."}
        
        if not self.shodan_client:
            return {"error": "Shodan API key not set. Use set_api_key('shodan', 'your_api_key') first."}
        
        # Initialize results
        results = {
            "timestamp": datetime.now().isoformat(),
            "sectors_scanned": [],
            "total_results": 0,
            "facilities_found": []
        }
        
        # Determine which sectors to scan
        sectors_to_scan = [sector_id] if sector_id else list(self.sector_definitions.keys())
        
        # Scan each sector
        for sector in sectors_to_scan:
            if sector not in self.sector_definitions:
                logger.warning(f"Unknown sector ID: {sector}")
                continue
                
            sector_def = self.sector_definitions[sector]
            sector_results = {
                "sector_id": sector,
                "sector_name": sector_def["name"],
                "facilities_found": []
            }
            
            # Use each Shodan dork for this sector
            for dork in sector_def["shodan_dorks"]:
                logger.info(f"Scanning sector '{sector_def['name']}' with query: {dork}")
                
                try:
                    # Rate limiting
                    self._respect_rate_limit("shodan", 1.0)  # 1 request per second
                    
                    # Execute Shodan search
                    search_results = self.shodan_client.search(dork, limit=max_results)
                    
                    # Process each result
                    for result in search_results.get("matches", []):
                        facility = self._process_shodan_result(result, sector)
                        
                        if facility:
                            sector_results["facilities_found"].append(facility)
                            results["facilities_found"].append(facility)
                            
                            # Save to database if requested
                            if save_results:
                                self._add_facility_to_database(facility, sector)
                
                except Exception as e:
                    logger.error(f"Error in Shodan search for '{dork}': {str(e)}")
            
            # Update sector results
            sector_results["total_found"] = len(sector_results["facilities_found"])
            results["sectors_scanned"].append(sector_results)
        
        # Update total results
        results["total_results"] = len(results["facilities_found"])
        
        return results
    
    def _process_shodan_result(self, result, sector_id):
        """
        Process a Shodan search result into a facility entry
        
        Args:
            result: Shodan search result
            sector_id: ID of the sector being scanned
            
        Returns:
            Dictionary with facility information or None if invalid
        """
        # Skip if missing crucial information
        if "ip_str" not in result or "port" not in result:
            return None
        
        # Basic facility information
        facility = {
            "ip": result["ip_str"],
            "port": result["port"],
            "last_update": result.get("timestamp", datetime.now().isoformat()),
            "source": "shodan",
            "sector_id": sector_id,
            "sector_name": self.sector_definitions[sector_id]["name"],
            "confidence": "medium",  # Default confidence
            "tags": [],
            "vulnerabilities": []
        }
        
        # Extract hostname if available
        if "hostnames" in result and result["hostnames"]:
            facility["hostname"] = result["hostnames"][0]
        
        # Extract organization if available
        if "org" in result and result["org"]:
            facility["organization"] = result["org"]
            
            # Remove "LLC", "Inc", etc. for the name
            name = re.sub(r'\s+(LLC|Inc|Corp|Corporation|Company)\.?\s*$', '', result["org"], flags=re.IGNORECASE)
            facility["name"] = name
        
        # Extract location if available
        if all(k in result for k in ["city", "region_code", "country_name"]):
            facility["location"] = {
                "city": result.get("city", "Unknown"),
                "region": result.get("region_code", "Unknown"),
                "country": result.get("country_name", "Unknown"),
                "latitude": result.get("latitude"),
                "longitude": result.get("longitude")
            }
        
        # Extract data from the banner
        if "data" in result:
            # Look for common product/service identifiers
            # This helps with classification
            product_indicators = {
                "SCADA": ["scada", "modbus", "dnp3", "bacnet", "profinet", "ethernet/ip"],
                "ICS": ["plc", "controller", "automation", "siemens", "schneider", "rockwell", "abb"],
                "Water": ["water", "treatment", "pump", "valve", "flow", "level"],
                "Energy": ["power", "energy", "electricity", "turbine", "generator", "substation"],
                "Healthcare": ["medical", "hospital", "patient", "health", "dicom", "hl7"],
                "Transportation": ["traffic", "transit", "railway", "airport", "port", "bridge"],
                "Manufacturing": ["factory", "manufacturing", "production", "assembly", "industrial"]
            }
            
            # Check banner for indicators
            banner = result["data"].lower()
            for category, indicators in product_indicators.items():
                if any(indicator in banner for indicator in indicators):
                    facility["tags"].append(category)
                    
                    # Increase confidence if banner matches sector
                    if any(indicator in self.sector_definitions[sector_id]["keywords"] for indicator in indicators):
                        facility["confidence"] = "high"
            
            # Check for security issues
            security_issues = []
            
            # Default credentials in banner
            default_creds_indicators = ["admin", "password", "default credentials", "default password"]
            if any(indicator in banner for indicator in default_creds_indicators):
                security_issues.append("Possible default credentials")
            
            # Error messages in banner
            error_indicators = ["error", "exception", "failed", "denied"]
            if any(indicator in banner for indicator in error_indicators):
                security_issues.append("Error messages visible")
            
            # Debug information
            debug_indicators = ["debug", "verbose", "trace", "stack"]
            if any(indicator in banner for indicator in debug_indicators):
                security_issues.append("Debug information exposed")
            
            if security_issues:
                facility["security_issues"] = security_issues
        
        # Extract vulnerabilities if available
        if "vulns" in result:
            for vuln_id in result["vulns"]:
                cvss = result["vulns"][vuln_id].get("cvss", 0)
                facility["vulnerabilities"].append({
                    "id": vuln_id,
                    "cvss": cvss,
                    "severity": "critical" if cvss >= 9.0 else "high" if cvss >= 7.0 else "medium" if cvss >= 4.0 else "low"
                })
        
        return facility
    
    def _add_facility_to_database(self, facility, sector_id):
        """
        Add a facility to the infrastructure database
        
        Args:
            facility: Facility information
            sector_id: ID of the sector
            
        Returns:
            Boolean indicating success
        """
        if sector_id not in self.infrastructure_database:
            logger.warning(f"Unknown sector ID: {sector_id}")
            return False
            
        # Check if facility already exists (by IP)
        existing_facilities = [f for f in self.infrastructure_database[sector_id]["facilities"] 
                              if "ip" in f and f["ip"] == facility["ip"]]
        
        if existing_facilities:
            # Update existing facility
            for i, existing in enumerate(self.infrastructure_database[sector_id]["facilities"]):
                if "ip" in existing and existing["ip"] == facility["ip"]:
                    # Merge the records, keeping the highest confidence
                    if facility.get("confidence") == "high" or (facility.get("confidence") == "medium" and existing.get("confidence") != "high"):
                        existing["confidence"] = facility["confidence"]
                    
                    # Update last seen
                    existing["last_seen"] = datetime.now().isoformat()
                    
                    # Merge tags
                    existing_tags = set(existing.get("tags", []))
                    existing_tags.update(facility.get("tags", []))
                    existing["tags"] = list(existing_tags)
                    
                    # Update vulnerabilities
                    if "vulnerabilities" in facility and facility["vulnerabilities"]:
                        existing_vuln_ids = {v["id"] for v in existing.get("vulnerabilities", [])}
                        for vuln in facility["vulnerabilities"]:
                            if vuln["id"] not in existing_vuln_ids:
                                if "vulnerabilities" not in existing:
                                    existing["vulnerabilities"] = []
                                existing["vulnerabilities"].append(vuln)
                    
                    # Update security issues
                    if "security_issues" in facility and facility["security_issues"]:
                        existing_issues = set(existing.get("security_issues", []))
                        existing_issues.update(facility["security_issues"])
                        existing["security_issues"] = list(existing_issues)
                    
                    self.infrastructure_database[sector_id]["facilities"][i] = existing
                    break
        else:
            # Add as new facility
            facility["first_seen"] = datetime.now().isoformat()
            facility["last_seen"] = facility["first_seen"]
            self.infrastructure_database[sector_id]["facilities"].append(facility)
        
        # Update last updated timestamp
        self.infrastructure_database[sector_id]["last_updated"] = datetime.now().isoformat()
        
        return True
    
    def _respect_rate_limit(self, service, min_interval):
        """
        Respect rate limits for API services
        
        Args:
            service: Service name
            min_interval: Minimum interval between requests in seconds
            
        Returns:
            None
        """
        now = time.time()
        
        if service in self.last_request_time:
            elapsed = now - self.last_request_time[service]
            if elapsed < min_interval:
                time.sleep(min_interval - elapsed)
        
        self.last_request_time[service] = time.time()
    
    def scan_infrastructure_with_web_scraping(self, sector_id=None, max_pages=5):
        """
        Scan for critical infrastructure using web scraping techniques
        
        Args:
            sector_id: ID of the sector to scan (or None for all sectors)
            max_pages: Maximum pages to scrape per source
            
        Returns:
            Dictionary with scan results
        """
        # Initialize results
        results = {
            "timestamp": datetime.now().isoformat(),
            "sectors_scanned": [],
            "total_results": 0,
            "facilities_found": []
        }
        
        # Determine which sectors to scan
        sectors_to_scan = [sector_id] if sector_id else list(self.sector_definitions.keys())
        
        # Sources to scrape for different sectors
        # These are examples of public sources that may contain facility information
        sector_sources = {
            "energy": [
                "https://www.eia.gov/electricity/data/eia860/",  # EIA Form 860 for power plants
                "https://hifld-geoplatform.opendata.arcgis.com/datasets/electric-power-transmission-lines",  # Transmission lines
                "https://hifld-geoplatform.opendata.arcgis.com/datasets/electric-substations"  # Substations
            ],
            "water": [
                "https://www.epa.gov/ground-water-and-drinking-water/safe-drinking-water-information-system-sdwis-federal-reporting",  # EPA SDWIS
                "https://hifld-geoplatform.opendata.arcgis.com/datasets/water-treatment-plants"  # Water treatment plants
            ],
            "chemical": [
                "https://www.epa.gov/toxics-release-inventory-tri-program",  # EPA TRI program
                "https://hifld-geoplatform.opendata.arcgis.com/datasets/toxic-release-inventory-facilities"  # TRI facilities
            ],
            "nuclear": [
                "https://www.nrc.gov/info-finder/reactors/",  # NRC reactor information
                "https://hifld-geoplatform.opendata.arcgis.com/datasets/nuclear-power-plants"  # Nuclear plants
            ],
            "transportation": [
                "https://hifld-geoplatform.opendata.arcgis.com/datasets/major-ports",  # Major ports
                "https://hifld-geoplatform.opendata.arcgis.com/datasets/major-airports",  # Airports
                "https://hifld-geoplatform.opendata.arcgis.com/datasets/amtrak-stations"  # Amtrak stations
            ],
            "healthcare_public_health": [
                "https://hifld-geoplatform.opendata.arcgis.com/datasets/hospitals",  # Hospitals
                "https://nppes.cms.hhs.gov/NPPES/Welcome.do"  # Healthcare providers
            ],
            # Add more sectors and sources as needed
        }
        
        # For each sector to scan
        for sector in sectors_to_scan:
            if sector not in self.sector_definitions:
                logger.warning(f"Unknown sector ID: {sector}")
                continue
                
            sector_def = self.sector_definitions[sector]
            sector_results = {
                "sector_id": sector,
                "sector_name": sector_def["name"],
                "facilities_found": []
            }
            
            # Skip if no sources defined for this sector
            if sector not in sector_sources:
                logger.info(f"No scraping sources defined for sector: {sector}")
                continue
            
            # For each source for this sector
            for source_url in sector_sources[sector]:
                logger.info(f"Scraping source for '{sector_def['name']}': {source_url}")
                
                try:
                    # Rate limiting
                    self._respect_rate_limit("web_scraping", 2.0)  # 1 request per 2 seconds
                    
                    # This is a placeholder for actual scraping implementation
                    # In a real implementation, you would:
                    # 1. Request the web page
                    # 2. Parse the HTML
                    # 3. Extract facility information
                    # 4. Process into a common format
                    
                    # For demonstration, we'll just log that we would scrape this source
                    logger.info(f"Would scrape {source_url} for {sector_def['name']} facilities")
                    
                    # If the Multi-Model Processor is available, we could use it for content extraction
                    if MCP_AVAILABLE and self.mcp:
                        logger.info(f"Would use MCP to process content from {source_url}")
                    
                except Exception as e:
                    logger.error(f"Error scraping source {source_url}: {str(e)}")
            
            # Update sector results
            sector_results["total_found"] = len(sector_results["facilities_found"])
            results["sectors_scanned"].append(sector_results)
        
        # Update total results
        results["total_results"] = len(results["facilities_found"])
        
        return results
    
    def analyze_facility_with_mcp(self, facility_data):
        """
        Use the Multi-Model Processor to analyze and enrich facility data
        
        Args:
            facility_data: Raw facility data to analyze
            
        Returns:
            Dictionary with enriched facility information
        """
        if not MCP_AVAILABLE or not self.mcp:
            return {"error": "Multi-Model Processor not available"}
        
        # Convert facility data to text for analysis
        facility_text = f"""
        Facility Name: {facility_data.get('name', 'Unknown')}
        Organization: {facility_data.get('organization', 'Unknown')}
        Sector: {facility_data.get('sector_name', 'Unknown')}
        IP Address: {facility_data.get('ip', 'Unknown')}
        Location: {facility_data.get('location', {}).get('city', 'Unknown')}, 
                 {facility_data.get('location', {}).get('region', 'Unknown')}, 
                 {facility_data.get('location', {}).get('country', 'Unknown')}
        Tags: {', '.join(facility_data.get('tags', []))}
        Security Issues: {', '.join(facility_data.get('security_issues', []))}
        Vulnerabilities: {', '.join(v.get('id', '') for v in facility_data.get('vulnerabilities', []))}
        """
        
        try:
            # Use MCP to analyze the facility
            analysis_result = self.mcp.analyze_content(facility_text)
            
            # Extract relevant information from analysis
            enriched_data = {
                "original_data": facility_data,
                "mcp_analysis": analysis_result,
                "enriched_tags": [],
                "risk_factors": [],
                "potential_uses": []
            }
            
            # Extract keywords as tags
            if "keywords" in analysis_result:
                enriched_data["enriched_tags"].extend(analysis_result["keywords"])
            
            # Extract potential risk factors from analysis
            if "incident" in analysis_result and "evidence" in analysis_result["incident"]:
                enriched_data["risk_factors"].extend(analysis_result["incident"]["evidence"])
            
            return enriched_data
            
        except Exception as e:
            logger.error(f"Error using MCP to analyze facility: {str(e)}")
            return {"error": f"MCP analysis failed: {str(e)}", "original_data": facility_data}
    
    def get_sector_statistics(self, sector_id=None):
        """
        Get statistics for a specific sector or all sectors
        
        Args:
            sector_id: ID of the sector (or None for all sectors)
            
        Returns:
            Dictionary with sector statistics
        """
        # Initialize results
        results = {
            "timestamp": datetime.now().isoformat(),
            "sectors": []
        }
        
        # Determine which sectors to include
        sectors_to_include = [sector_id] if sector_id else list(self.infrastructure_database.keys())
        
        total_facilities = 0
        total_vulnerable = 0
        
        # Calculate statistics for each sector
        for sector in sectors_to_include:
            if sector not in self.infrastructure_database:
                continue
                
            sector_db = self.infrastructure_database[sector]
            facilities = sector_db["facilities"]
            
            # Count facilities with vulnerabilities
            vulnerable_facilities = [f for f in facilities if "vulnerabilities" in f and f["vulnerabilities"]]
            high_risk_facilities = [f for f in vulnerable_facilities 
                                  if any(v["severity"] in ["critical", "high"] for v in f.get("vulnerabilities", []))]
            
            # Count by country if location available
            country_counts = {}
            for facility in facilities:
                if "location" in facility and "country" in facility["location"]:
                    country = facility["location"]["country"]
                    country_counts[country] = country_counts.get(country, 0) + 1
            
            # Calculate statistics
            sector_stats = {
                "sector_id": sector,
                "sector_name": sector_db["name"],
                "total_facilities": len(facilities),
                "vulnerable_facilities": len(vulnerable_facilities),
                "high_risk_facilities": len(high_risk_facilities),
                "countries": country_counts,
                "last_updated": sector_db["last_updated"]
            }
            
            # Add to results
            results["sectors"].append(sector_stats)
            
            # Update totals
            total_facilities += len(facilities)
            total_vulnerable += len(vulnerable_facilities)
        
        # Add overall statistics
        results["total_facilities"] = total_facilities
        results["total_vulnerable"] = total_vulnerable
        results["vulnerable_percentage"] = (total_vulnerable / total_facilities * 100) if total_facilities > 0 else 0
        
        return results
    
    def search_facilities(self, query=None, sector_id=None, country=None, vulnerability=None, tag=None):
        """
        Search for facilities matching specific criteria
        
        Args:
            query: Text query to search in name and organization
            sector_id: ID of the sector to search
            country: Country to filter by
            vulnerability: Vulnerability ID to filter by
            tag: Tag to filter by
            
        Returns:
            List of matching facilities
        """
        results = []
        
        # Determine which sectors to search
        sectors_to_search = [sector_id] if sector_id else list(self.infrastructure_database.keys())
        
        # Search each sector
        for sector in sectors_to_search:
            if sector not in self.infrastructure_database:
                continue
                
            # Get facilities in this sector
            facilities = self.infrastructure_database[sector]["facilities"]
            
            # Apply filters
            for facility in facilities:
                # Skip if doesn't match query
                if query and not self._matches_text_query(facility, query):
                    continue
                
                # Skip if doesn't match country
                if country and not self._matches_country(facility, country):
                    continue
                
                # Skip if doesn't have vulnerability
                if vulnerability and not self._has_vulnerability(facility, vulnerability):
                    continue
                
                # Skip if doesn't have tag
                if tag and not self._has_tag(facility, tag):
                    continue
                
                # Add to results if passes all filters
                results.append(facility)
        
        return results
    
    def _matches_text_query(self, facility, query):
        """Check if facility matches text query"""
        query = query.lower()
        
        # Check name
        if "name" in facility and query in facility["name"].lower():
            return True
            
        # Check organization
        if "organization" in facility and query in facility["organization"].lower():
            return True
            
        # Check hostname
        if "hostname" in facility and query in facility["hostname"].lower():
            return True
            
        return False
    
    def _matches_country(self, facility, country):
        """Check if facility is in the specified country"""
        if "location" in facility and "country" in facility["location"]:
            return facility["location"]["country"].lower() == country.lower()
        return False
    
    def _has_vulnerability(self, facility, vulnerability):
        """Check if facility has the specified vulnerability"""
        if "vulnerabilities" in facility:
            return any(v["id"].lower() == vulnerability.lower() for v in facility["vulnerabilities"])
        return False
    
    def _has_tag(self, facility, tag):
        """Check if facility has the specified tag"""
        if "tags" in facility:
            return tag.lower() in [t.lower() for t in facility["tags"]]
        return False
    
    def export_facilities(self, sector_id=None, format="json"):
        """
        Export facility data for a sector or all sectors
        
        Args:
            sector_id: ID of the sector (or None for all sectors)
            format: Export format (json, csv)
            
        Returns:
            Exported facility data
        """
        # Determine which sectors to export
        sectors_to_export = [sector_id] if sector_id else list(self.infrastructure_database.keys())
        
        # Collect facilities from all relevant sectors
        all_facilities = []
        for sector in sectors_to_export:
            if sector in self.infrastructure_database:
                # Add sector info to each facility
                for facility in self.infrastructure_database[sector]["facilities"]:
                    facility_copy = facility.copy()
                    facility_copy["sector_id"] = sector
                    facility_copy["sector_name"] = self.infrastructure_database[sector]["name"]
                    all_facilities.append(facility_copy)
        
        # Export in the requested format
        if format == "json":
            import json
            return json.dumps(all_facilities, indent=2)
            
        elif format == "csv":
            import csv
            import io
            
            output = io.StringIO()
            
            # Determine all possible fields
            fields = set()
            for facility in all_facilities:
                fields.update(self._flatten_keys(facility))
            
            writer = csv.DictWriter(output, fieldnames=sorted(fields))
            writer.writeheader()
            
            # Write each facility as a flattened row
            for facility in all_facilities:
                flat_facility = self._flatten_dict(facility)
                writer.writerow(flat_facility)
            
            return output.getvalue()
            
        else:
            return {"error": f"Unsupported export format: {format}"}
    
    def _flatten_keys(self, d, prefix=""):
        """Get all keys from a nested dictionary with dot notation"""
        keys = set()
        for k, v in d.items():
            new_key = f"{prefix}{k}" if prefix else k
            if isinstance(v, dict):
                keys.update(self._flatten_keys(v, f"{new_key}."))
            else:
                keys.add(new_key)
        return keys
    
    def _flatten_dict(self, d, prefix=""):
        """Flatten a nested dictionary with dot notation"""
        flat_dict = {}
        for k, v in d.items():
            new_key = f"{prefix}{k}" if prefix else k
            if isinstance(v, dict):
                flat_dict.update(self._flatten_dict(v, f"{new_key}."))
            else:
                flat_dict[new_key] = v
        return flat_dict
    
    def import_facilities(self, data, format="json", sector_id=None):
        """
        Import facility data
        
        Args:
            data: Facility data to import
            format: Import format (json, csv)
            sector_id: Optional sector ID to assign to facilities
            
        Returns:
            Import results
        """
        imported_facilities = []
        
        # Parse the import data
        if format == "json":
            try:
                import json
                facilities = json.loads(data)
                
                if isinstance(facilities, list):
                    imported_facilities = facilities
                else:
                    return {"error": "Invalid JSON format. Expected a list of facilities."}
                    
            except Exception as e:
                return {"error": f"Error parsing JSON: {str(e)}"}
                
        elif format == "csv":
            try:
                import csv
                import io
                
                # Parse CSV
                csvfile = io.StringIO(data)
                reader = csv.DictReader(csvfile)
                
                # Process each row
                for row in reader:
                    # Unflatten dot notation
                    facility = {}
                    for k, v in row.items():
                        if not v:  # Skip empty values
                            continue
                            
                        if "." in k:
                            parts = k.split(".")
                            current = facility
                            for part in parts[:-1]:
                                if part not in current:
                                    current[part] = {}
                                current = current[part]
                            current[parts[-1]] = v
                        else:
                            facility[k] = v
                    
                    imported_facilities.append(facility)
                    
            except Exception as e:
                return {"error": f"Error parsing CSV: {str(e)}"}
                
        else:
            return {"error": f"Unsupported import format: {format}"}
        
        # Track import stats
        results = {
            "total_processed": len(imported_facilities),
            "successfully_imported": 0,
            "errors": []
        }
        
        # Import each facility
        for facility in imported_facilities:
            # Determine the sector
            if sector_id:
                facility_sector = sector_id
            elif "sector_id" in facility:
                facility_sector = facility["sector_id"]
            else:
                results["errors"].append(f"No sector specified for facility: {facility.get('name', 'Unknown')}")
                continue
            
            # Verify sector exists
            if facility_sector not in self.infrastructure_database:
                results["errors"].append(f"Unknown sector ID: {facility_sector}")
                continue
            
            # Add to database
            try:
                self._add_facility_to_database(facility, facility_sector)
                results["successfully_imported"] += 1
            except Exception as e:
                results["errors"].append(f"Error importing facility {facility.get('name', 'Unknown')}: {str(e)}")
        
        return results
    
    def scrape_sector_specific_sources(self, sector_id, max_pages=5):
        """
        Scrape sector-specific sources for infrastructure data
        
        Args:
            sector_id: ID of the sector to scrape
            max_pages: Maximum number of pages to scrape per source
            
        Returns:
            Dictionary with scraping results
        """
        # Verify sector exists
        if sector_id not in self.sector_definitions:
            return {"error": f"Unknown sector ID: {sector_id}"}
        
        sector_def = self.sector_definitions[sector_id]
        
        # Initialize results
        results = {
            "timestamp": datetime.now().isoformat(),
            "sector_id": sector_id,
            "sector_name": sector_def["name"],
            "sources_scraped": [],
            "facilities_found": []
        }
        
        # This is a placeholder for actual implementation
        # In a real implementation, you would:
        # 1. Maintain a list of sector-specific sources
        # 2. Implement scraping for each source format
        # 3. Process results into a common format
        # 4. Add to the database
        
        logger.info(f"Would scrape specific sources for sector: {sector_def['name']}")
        
        # Example of how this might work for specific sectors
        if sector_id == "energy":
            # Scrape EIA power plant data
            logger.info("Would scrape EIA Form 860 data for power plants")
            
            # Scrape HIFLD data for electrical infrastructure
            logger.info("Would scrape HIFLD data for electrical substations and transmission lines")
            
        elif sector_id == "water":
            # Scrape EPA SDWIS data
            logger.info("Would scrape EPA SDWIS data for water systems")
            
            # Scrape HIFLD data for water infrastructure
            logger.info("Would scrape HIFLD data for water treatment plants")
            
        elif sector_id == "nuclear":
            # Scrape NRC reactor data
            logger.info("Would scrape NRC data for nuclear reactors")
            
        # ... and so on for each sector
        
        return results
    
    def generate_infrastructure_report(self, sector_id=None):
        """
        Generate a comprehensive report on infrastructure for a sector or all sectors
        
        Args:
            sector_id: ID of the sector (or None for all sectors)
            
        Returns:
            Dictionary with report data
        """
        # Determine which sectors to include
        sectors_to_include = [sector_id] if sector_id else list(self.infrastructure_database.keys())
        
        # Initialize report
        report = {
            "title": "Critical Infrastructure Assessment Report",
            "timestamp": datetime.now().isoformat(),
            "overview": {},
            "sectors": [],
            "vulnerabilities": {},
            "recommendations": []
        }
        
        # Track totals
        total_facilities = 0
        vulnerable_facilities = 0
        high_risk_facilities = 0
        
        # Process each sector
        for sector in sectors_to_include:
            if sector not in self.infrastructure_database:
                continue
                
            sector_db = self.infrastructure_database[sector]
            facilities = sector_db["facilities"]
            
            # Skip empty sectors
            if not facilities:
                continue
            
            # Count vulnerabilities
            sector_vuln_facilities = [f for f in facilities if "vulnerabilities" in f and f["vulnerabilities"]]
            sector_high_risk = [f for f in sector_vuln_facilities 
                              if any(v["severity"] in ["critical", "high"] for v in f.get("vulnerabilities", []))]
            
            # Add sector data
            sector_report = {
                "sector_id": sector,
                "sector_name": sector_db["name"],
                "total_facilities": len(facilities),
                "vulnerable_facilities": len(sector_vuln_facilities),
                "high_risk_facilities": len(sector_high_risk),
                "risk_level": self._calculate_risk_level(
                    len(facilities), len(sector_vuln_facilities), len(sector_high_risk)
                )
            }
            
            # Add geographic distribution if available
            locations = {}
            for facility in facilities:
                if "location" in facility and "country" in facility["location"]:
                    country = facility["location"]["country"]
                    if country not in locations:
                        locations[country] = {"total": 0, "regions": {}}
                    locations[country]["total"] += 1
                    
                    if "region" in facility["location"]:
                        region = facility["location"]["region"]
                        if region not in locations[country]["regions"]:
                            locations[country]["regions"][region] = 0
                        locations[country]["regions"][region] += 1
            
            sector_report["geographic_distribution"] = locations
            
            # Add to report
            report["sectors"].append(sector_report)
            
            # Update totals
            total_facilities += len(facilities)
            vulnerable_facilities += len(sector_vuln_facilities)
            high_risk_facilities += len(sector_high_risk)
        
        # Add overview
        report["overview"] = {
            "total_facilities": total_facilities,
            "vulnerable_facilities": vulnerable_facilities,
            "high_risk_facilities": high_risk_facilities,
            "overall_risk_level": self._calculate_risk_level(
                total_facilities, vulnerable_facilities, high_risk_facilities
            )
        }
        
        # Add vulnerability statistics
        vuln_stats = self._get_vulnerability_statistics(sectors_to_include)
        report["vulnerabilities"] = vuln_stats
        
        # Add recommendations
        report["recommendations"] = self._generate_recommendations(sectors_to_include, vuln_stats)
        
        return report
    
    def _calculate_risk_level(self, total, vulnerable, high_risk):
        """Calculate risk level based on vulnerability statistics"""
        if total == 0:
            return "unknown"
            
        vuln_percentage = (vulnerable / total) * 100
        high_risk_percentage = (high_risk / total) * 100
        
        if high_risk_percentage >= 10 or vuln_percentage >= 30:
            return "high"
        elif high_risk_percentage >= 5 or vuln_percentage >= 15:
            return "medium"
        else:
            return "low"
    
    def _get_vulnerability_statistics(self, sectors):
        """Get statistics on vulnerabilities across sectors"""
        vuln_counts = {}
        vuln_severity = {}
        
        # Process each sector
        for sector in sectors:
            if sector not in self.infrastructure_database:
                continue
                
            facilities = self.infrastructure_database[sector]["facilities"]
            
            # Count vulnerabilities
            for facility in facilities:
                if "vulnerabilities" in facility:
                    for vuln in facility["vulnerabilities"]:
                        vuln_id = vuln["id"]
                        
                        # Update counts
                        if vuln_id not in vuln_counts:
                            vuln_counts[vuln_id] = 0
                        vuln_counts[vuln_id] += 1
                        
                        # Update severity
                        vuln_severity[vuln_id] = vuln["severity"]
        
        # Sort by count
        top_vulns = sorted(vuln_counts.items(), key=lambda x: x[1], reverse=True)
        
        return {
            "top_vulnerabilities": [
                {"id": v[0], "count": v[1], "severity": vuln_severity[v[0]]} 
                for v in top_vulns[:10]
            ],
            "total_unique_vulnerabilities": len(vuln_counts)
        }
    
    def _generate_recommendations(self, sectors, vuln_stats):
        """Generate recommendations based on findings"""
        recommendations = []
        
        # General recommendations
        recommendations.append({
            "title": "Implement Comprehensive Vulnerability Management",
            "description": "Establish a regular schedule for vulnerability scanning and management across all critical infrastructure assets.",
            "priority": "high"
        })
        
        recommendations.append({
            "title": "Enhance Network Segmentation",
            "description": "Implement strict network segmentation to isolate critical infrastructure from public-facing systems.",
            "priority": "high"
        })
        
        # Add specific recommendations based on vulnerability findings
        if "top_vulnerabilities" in vuln_stats and vuln_stats["top_vulnerabilities"]:
            critical_vulns = [v for v in vuln_stats["top_vulnerabilities"] if v["severity"] == "critical"]
            if critical_vulns:
                recommendations.append({
                    "title": "Address Critical Vulnerabilities Immediately",
                    "description": f"Prioritize patching the following critical vulnerabilities: {', '.join(v['id'] for v in critical_vulns)}",
                    "priority": "critical"
                })
        
        # Sector-specific recommendations
        for sector in sectors:
            if sector not in self.infrastructure_database:
                continue
                
            sector_db = self.infrastructure_database[sector]
            if not sector_db["facilities"]:
                continue
                
            # Add sector-specific recommendation based on sector type
            if sector == "energy":
                recommendations.append({
                    "title": "Enhance Energy Sector Cybersecurity",
                    "description": "Implement IEC 62351 standards for power systems communication security and conduct regular security assessments.",
                    "priority": "high",
                    "sector": "Energy"
                })
            elif sector == "water":
                recommendations.append({
                    "title": "Secure Water Treatment SCADA Systems",
                    "description": "Update legacy SCADA systems in water treatment facilities and implement multi-factor authentication for all remote access.",
                    "priority": "high",
                    "sector": "Water and Wastewater Systems"
                })
            elif sector == "healthcare_public_health":
                recommendations.append({
                    "title": "Protect Healthcare Systems",
                    "description": "Implement network segmentation for medical devices and enhance protection of electronic health record systems.",
                    "priority": "high",
                    "sector": "Healthcare and Public Health"
                })
        
        return recommendations