import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from datetime import datetime, timedelta
import plotly.io as pio

# Configure dark mode template for Plotly
dark_template = go.layout.Template(
    layout=dict(
        paper_bgcolor='#0E1117',
        plot_bgcolor='#0E1117',
        font=dict(color='#FAFAFA'),
        title=dict(font=dict(color='#FAFAFA')),
        colorway=['#4D96FF', '#FF6B6B', '#32CD32', '#FF9F1C', '#FFCC29', '#A78BFA', '#FF8FAB', '#00CCCC'],
        xaxis=dict(
            gridcolor='#1A1C24',
            zerolinecolor='#1A1C24',
            linecolor='#444444'
        ),
        yaxis=dict(
            gridcolor='#1A1C24',
            zerolinecolor='#1A1C24',
            linecolor='#444444'
        )
    )
)

# Configure light mode template for Plotly
light_template = go.layout.Template(
    layout=dict(
        paper_bgcolor='#FFFFFF',
        plot_bgcolor='#FFFFFF',
        font=dict(color='#262730'),
        title=dict(font=dict(color='#262730')),
        colorway=px.colors.qualitative.Plotly,
        xaxis=dict(
            gridcolor='#E0E0E0',
            zerolinecolor='#E0E0E0',
            linecolor='#E0E0E0'
        ),
        yaxis=dict(
            gridcolor='#E0E0E0',
            zerolinecolor='#E0E0E0',
            linecolor='#E0E0E0'
        )
    )
)

def get_theme_settings():
    """Get the current theme settings based on session state"""
    is_dark = st.session_state.get('theme', 'light') == 'dark'
    
    # Default map style based on theme (using Carto)
    default_style = "carto-darkmatter" if is_dark else "carto-positron"
    
    # Get map provider and style from session state
    map_provider = st.session_state.get('map_provider', 'carto')
    
    # Set default values
    mapbox_style = default_style
    mapbox_token = None
    google_key = None
    
    # Map style based on provider and theme
    if map_provider == 'mapbox':
        # Use Mapbox styles
        mapbox_style = "mapbox://styles/mapbox/dark-v11" if is_dark else "mapbox://styles/mapbox/light-v11"
        # If API key is provided, it will be used
        mapbox_token = st.session_state.get('mapbox_token', None)
    elif map_provider == 'google_earth':
        # For Google Earth/Maps
        mapbox_style = "white-bg"  # This will be ignored, as we'll use the Google Maps base layer
        google_key = st.session_state.get('google_api_key', None)
    elif map_provider == 'open-street-map':
        # OpenStreetMap needs no token
        mapbox_style = "open-street-map"
    elif map_provider == 'stamen':
        # Stamen maps
        mapbox_style = "stamen-terrain" if not is_dark else "stamen-toner"
    else:
        # Use default Carto styles
        mapbox_style = default_style
    
    # Plot template based on theme
    template = dark_template if is_dark else light_template
    
    return {
        'mapbox_style': mapbox_style,
        'mapbox_token': mapbox_token,
        'google_key': google_key,
        'map_provider': map_provider,
        'template': template,
        'is_dark': is_dark
    }

def create_map(df, zoom=3):
    # Get theme settings
    theme = get_theme_settings()
    map_provider = theme['map_provider']
    
    # Default center coordinates (center of US)
    center_lat = 39.8283
    center_lon = -98.5795
    
    if map_provider == 'google_earth':
        # Using Google Maps/Earth approach
        if theme['google_key']:
            fig = go.Figure()
            
            # Create scatter traces for each location type
            for loc_type in df['Type'].unique():
                type_df = df[df['Type'] == loc_type]
                fig.add_trace(go.Scattermapbox(
                    lat=type_df["Latitude"],
                    lon=type_df["Longitude"],
                    mode='markers',
                    marker=dict(size=15),
                    text=type_df["City"],
                    hoverinfo='text',
                    name=loc_type
                ))
            
            # Configure Google Maps
            fig.update_layout(
                mapbox=dict(
                    style="white-bg",
                    layers=[
                        {
                            "below": 'traces',
                            "sourcetype": "raster",
                            "sourceattribution": "Google Maps",
                            "source": [
                                f"https://mt1.google.com/vt/lyrs=m&x={{x}}&y={{y}}&z={{z}}&key={theme['google_key']}"
                            ],
                        }
                    ],
                    center=dict(lat=center_lat, lon=center_lon),
                    zoom=zoom
                ),
                height=600,
                margin={"r":0,"t":0,"l":0,"b":0},
                template=theme['template']
            )
        else:
            # Fall back to default if no Google API key provided
            st.warning("Google Maps API key required. Using default map provider instead.")
            map_provider = 'carto'  # Fall back to default
    
    # Use Plotly Express for other providers
    if map_provider != 'google_earth':
        # Get mapbox token if present
        mapbox_config = dict(
            style=theme['mapbox_style'],
            center=dict(lat=center_lat, lon=center_lon)
        )
        
        # Add token if available
        if theme['mapbox_token'] and map_provider == 'mapbox':
            mapbox_config['accesstoken'] = theme['mapbox_token']
        
        # Create the map
        fig = px.scatter_mapbox(
            df,
            lat="Latitude",
            lon="Longitude",
            hover_name="City",
            hover_data=["Type"],
            color="Type",
            size=[15] * len(df),
            zoom=zoom,
            height=600,
            mapbox_style=theme['mapbox_style'],
        )
        
        # Update layout with mapbox configuration
        fig.update_layout(
            margin={"r":0,"t":0,"l":0,"b":0},
            template=theme['template'],
            mapbox=mapbox_config
        )
    
    return fig

def display_location_info(location):
    st.subheader(f"📍 {location['City']}")
    st.write(f"**Type:** {location['Type']}")
    st.write(f"**Coordinates:** {location['Latitude']:.4f}, {location['Longitude']:.4f}")

def create_time_series_plot(data, title="Activity Level Over Time"):
    # Get theme settings
    theme = get_theme_settings()
    
    fig = go.Figure()
    
    for city in data['City'].unique():
        city_data = data[data['City'] == city]
        fig.add_trace(go.Scatter(
            x=city_data['Date'],
            y=city_data['Activity_Level'],
            name=city,
            mode='lines',
            hovertemplate="<b>%{x}</b><br>" +
                         "Activity: %{y:.1f}<br>" +
                         "<extra></extra>"
        ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Date",
        yaxis_title="Activity Level",
        height=400,
        showlegend=True,
        hovermode='x unified',
        template=theme['template']
    )
    
    return fig

def create_download_buttons(data_handler):
    col1, col2 = st.columns(2)
    
    with col1:
        st.download_button(
            label="Download CSV",
            data=data_handler.get_csv(),
            file_name="strategic_locations.csv",
            mime="text/csv"
        )
    
    with col2:
        st.download_button(
            label="Download JSON",
            data=data_handler.get_json(),
            file_name="strategic_locations.json",
            mime="application/json"
        )
