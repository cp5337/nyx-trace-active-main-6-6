# URL HEALTH DASHBOARD
#########################
elif app_mode == "URL Health":
    st.title("🔗 URL Health Dashboard")
    st.write("Monitoring real-time link reliability and accessibility metrics.")
    
    # Import the URL health dashboard functionality from pages module
    try:
        import importlib
        url_health_module = importlib.import_module("pages.url_health_dashboard")
        
        # We don't need to call any functions here as the module will execute on import
        # and render its content to the Streamlit app
        st.success("URL Health Dashboard loaded successfully")
    except Exception as e:
        st.error(f"Error loading URL Health Dashboard: {str(e)}")
        st.info("Try selecting 'URL Health' from the sidebar navigation directly.")
