import pandas as pd
import json
from datetime import datetime, timedelta
import numpy as np

class DataHandler:
    def __init__(self):
        # Base location data
        self.locations_data = {
            "City": [
                "Houston", "Los Angeles", "New York", "Miami", "Seattle",
                "Detroit", "El Paso", "Nogales", "Laredo", "San Diego"
            ],
            "Type": [
                "Port", "Port", "Port", "Port", "Port",
                "Border", "Border", "Border", "Border", "Border"
            ],
            "Latitude": [
                29.7604, 34.0522, 40.7128, 25.7617, 47.6062,
                42.3314, 31.7619, 31.3400, 27.5036, 32.7157
            ],
            "Longitude": [
                -95.3698, -118.2437, -74.0060, -80.1918, -122.3321,
                -83.0458, -106.4850, -110.9335, -99.5075, -117.1611
            ]
        }
        
        # Create base DataFrame
        self.df = pd.DataFrame(self.locations_data)
        
        # OSINT data cache
        self.osint_cache = {}
        
        # Generate time series data for each location
        self._generate_time_series_data()

    def get_filtered_data(self, location_type=None):
        if location_type and location_type != "All":
            return self.df[self.df["Type"] == location_type]
        return self.df

    def get_location_types(self):
        return ["All"] + list(self.df["Type"].unique())

    def get_csv(self):
        return self.df.to_csv(index=False)

    def get_json(self):
        return self.df.to_json(orient="records")
        
    def _generate_time_series_data(self):
        # Generate daily data for the past year
        end_date = datetime.now()
        start_date = end_date - timedelta(days=365)
        dates = pd.date_range(start=start_date, end=end_date, freq='D')
        
        # Create time series data for each location
        time_series_data = []
        for _, row in self.df.iterrows():
            # Generate synthetic activity data with seasonal patterns
            base_activity = np.random.normal(100, 20, len(dates))
            seasonal_pattern = 20 * np.sin(np.linspace(0, 2*np.pi, len(dates)))
            activity = base_activity + seasonal_pattern
            
            # Ensure all values are positive
            activity = np.maximum(activity, 0)
            
            for date, value in zip(dates, activity):
                time_series_data.append({
                    'City': row['City'],
                    'Date': date,
                    'Activity_Level': value,
                    'Type': row['Type'],
                    'Latitude': row['Latitude'],
                    'Longitude': row['Longitude']
                })
        
        # Create time series DataFrame
        self.time_series_df = pd.DataFrame(time_series_data)
        
    def get_time_series_data(self, city=None, start_date=None, end_date=None):
        data = self.time_series_df
        
        if city:
            data = data[data['City'] == city]
        if start_date:
            # Convert Python date to pandas datetime with the same time component
            start_datetime = pd.to_datetime(start_date).tz_localize(None)
            data = data[data['Date'].dt.date >= start_datetime.date()]
        if end_date:
            # Convert Python date to pandas datetime with the same time component
            end_datetime = pd.to_datetime(end_date).tz_localize(None)
            data = data[data['Date'].dt.date <= end_datetime.date()]
            
        return data
    
    def get_activity_summary(self, city=None):
        data = self.time_series_df
        if city:
            data = data[data['City'] == city]
            
        return data.groupby('City')['Activity_Level'].agg([
            'mean', 'std', 'min', 'max'
        ]).round(2)
    
    # Methods for handling large OSINT datasets
    def load_osint_data(self, data_source, location=None, start_date=None, end_date=None):
        """
        Load OSINT data from a specific source with filtering options
        and cache results to improve performance
        
        Args:
            data_source: Name of the data source
            location: Optional location filter
            start_date: Optional start date filter
            end_date: Optional end date filter
            
        Returns:
            DataFrame of filtered OSINT data
        """
        # Create a cache key based on the filter parameters
        cache_key = f"{data_source}_{location}_{start_date}_{end_date}"
        
        # Check if we have this data cached
        if cache_key in self.osint_cache:
            return self.osint_cache[cache_key]
            
        # If not cached, load the data
        # In a real implementation, this would load from a database or file
        # For now, we'll pass through to the data source
        
        # Cache the result for future requests
        # We'll implement this as a pass-through for now
        return None
    
    def get_osint_data_paginated(self, data, page=1, page_size=100):
        """
        Get a paginated subset of OSINT data for efficient display
        
        Args:
            data: The full DataFrame of OSINT data
            page: The page number to return (1-based)
            page_size: Number of records per page
            
        Returns:
            DataFrame containing just the requested page of data
        """
        if data is None or data.empty:
            return pd.DataFrame()
            
        # Calculate start and end indices
        start_idx = (page - 1) * page_size
        end_idx = start_idx + page_size
        
        # Get total number of records and pages
        total_records = len(data)
        total_pages = (total_records + page_size - 1) // page_size
        
        # Return requested slice of data
        return {
            'data': data.iloc[start_idx:end_idx].copy(),
            'page': page,
            'page_size': page_size,
            'total_records': total_records,
            'total_pages': total_pages
        }
        
    def get_osint_summary_stats(self, data):
        """
        Calculate summary statistics for OSINT data
        
        Args:
            data: DataFrame of OSINT data
            
        Returns:
            Dictionary of summary statistics
        """
        if data is None or data.empty:
            return {}
            
        # Calculate basic stats
        stats = {
            'total_records': len(data),
            'locations': len(data['City'].unique()) if 'City' in data.columns else 0,
            'date_range': [data['Date'].min(), data['Date'].max()] if 'Date' in data.columns else None,
        }
        
        # Add content stats if available
        if 'Content' in data.columns:
            # Calculate average content length
            data['content_length'] = data['Content'].apply(lambda x: len(str(x)) if x else 0)
            stats['avg_content_length'] = data['content_length'].mean()
            
        # Add sentiment stats if available
        if 'Sentiment' in data.columns:
            stats['avg_sentiment'] = data['Sentiment'].mean()
            stats['sentiment_distribution'] = {
                'positive': (data['Sentiment'] > 0.2).mean(),
                'neutral': ((data['Sentiment'] >= -0.2) & (data['Sentiment'] <= 0.2)).mean(),
                'negative': (data['Sentiment'] < -0.2).mean()
            }
            
        return stats
