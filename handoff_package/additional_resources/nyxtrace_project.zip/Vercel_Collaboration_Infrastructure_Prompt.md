# Vercel Development Task: Real-time Collaboration Infrastructure for NyxTrace

## Project Context
I'm developing "NyxTrace," an advanced geospatial intelligence platform for tracking convergent threats across physical, cyber, and cartel domains. The platform combines OSINT capabilities with interactive visualization to provide comprehensive threat intelligence.

The system follows the "Hunt, Detect, Disrupt, Disable, Dominate" framework derived from FIVE EYES intelligence operations and monitors critical infrastructure across multiple sectors including agriculture/food, chemical, communications, energy, healthcare, and more.

As intelligence analysis is often a collaborative process, I need to implement real-time collaboration capabilities that allow multiple analysts to work together on investigations, share findings, and coordinate responses—all while maintaining strict operational security.

## Development Request
Please develop a secure real-time collaboration infrastructure for the NyxTrace platform with the following capabilities:

### 1. Real-time Communication Channels
- Implement WebSocket-based real-time communication between users
- Create secure message channels for text-based communication
- Develop presence indicators to show which analysts are online
- Create typing indicators for active communication
- Implement read receipts for critical communications
- Develop push notifications for important events
- Create voice and video communication channels for live collaboration

### 2. Collaborative Workspaces
- Implement shared workspaces for team-based investigations
- Create document collaboration features with conflict resolution
- Develop real-time map and visualization sharing
- Implement shared timelines for coordinating investigation activities
- Create annotation tools for collaborative analysis
- Develop shared query builders for team-based investigations
- Implement team dashboards for displaying collective findings

### 3. Access Control System
- Design granular permission system for different access levels
- Implement role-based access control for different team functions
- Create temporary access grants for time-limited collaborations
- Develop approval workflows for sensitive operations
- Implement activity auditing for all collaborative actions
- Create data classification and handling policies
- Develop an access revocation system for when team members leave

### 4. Secure Sharing Mechanisms
- Implement end-to-end encrypted sharing for sensitive information
- Create secure links with expiration and access limitations
- Develop watermarking for shared exports to trace leaks
- Implement secure file transfer capabilities
- Create secure snapshot functionality for sharing investigation state
- Develop read-only views for limited sharing
- Implement secure printing and export controls

### 5. Operational Awareness Features
- Create activity feeds to show recent actions by team members
- Implement assignment and task tracking for investigations
- Develop timeline views of collaborative activities
- Create notification systems for important events
- Implement metrics on team productivity and collaboration
- Develop incident coordination tools for team response
- Create shift handover tools for 24/7 operations

## Technical Requirements
- All communication must be end-to-end encrypted
- Implement proper authentication and authorization for all actions
- Ensure data sovereignty compliance with regional data handling
- Create high-performance real-time synchronization
- Implement proper conflict resolution for concurrent edits
- Ensure all collaboration features work within low-bandwidth environments
- Create fallback mechanisms for disconnected operations
- Develop clear APIs for integration with other platform components

## Architecture Diagram
Please provide a detailed architecture diagram showing:
- WebSocket connection management
- Real-time data synchronization flow
- End-to-end encryption implementation
- Conflict resolution mechanisms
- Presence and awareness systems
- Notification delivery paths

## Security Considerations
The collaboration infrastructure must address these security concerns:

1. **Communication Security**:
   - End-to-end encryption for all messages
   - Perfect forward secrecy
   - Secure key exchange
   - Message authentication

2. **Access Control**:
   - Fine-grained permissions model
   - Context-aware access decisions
   - Principle of least privilege
   - Separation of duties

3. **Operational Security**:
   - Minimize metadata leakage
   - Secure presence indicators
   - Minimal trust in the server
   - Secure group management

4. **Audit & Compliance**:
   - Tamper-evident activity logs
   - Comprehensive audit trail
   - Conflict investigation tools
   - Compliance with intelligence community standards

## Example Implementation
Here's an example of how the WebSocket server implementation might look:

```typescript
import { Server } from "socket.io";
import { createServer } from "http";
import { verify } from "jsonwebtoken";
import { encrypt, decrypt } from "./encryption";

// Create HTTP server
const httpServer = createServer();

// Create Socket.IO server with authentication middleware
const io = new Server(httpServer, {
  cors: {
    origin: process.env.FRONTEND_URL,
    methods: ["GET", "POST"],
    credentials: true
  }
});

// Authentication middleware
io.use((socket, next) => {
  const token = socket.handshake.auth.token;
  
  if (!token) {
    return next(new Error("Authentication required"));
  }
  
  try {
    // Verify JWT token
    const decoded = verify(token, process.env.JWT_SECRET);
    
    // Attach user info to socket
    socket.data.user = {
      id: decoded.sub,
      name: decoded.name,
      role: decoded.role,
      teams: decoded.teams
    };
    
    next();
  } catch (err) {
    next(new Error("Invalid authentication token"));
  }
});

// Track active users by workspace
const activeUsers = new Map();

// Handle connections
io.on("connection", (socket) => {
  const user = socket.data.user;
  console.log(`User connected: ${user.name} (${user.id})`);
  
  // Join user-specific room for direct messages
  socket.join(`user:${user.id}`);
  
  // Handle joining workspaces
  socket.on("join-workspace", async (workspaceId) => {
    // Check if user has access to this workspace
    const hasAccess = await checkWorkspaceAccess(user.id, workspaceId);
    
    if (!hasAccess) {
      socket.emit("error", { message: "Access denied to workspace" });
      return;
    }
    
    // Join workspace room
    socket.join(`workspace:${workspaceId}`);
    
    // Track active user in this workspace
    if (!activeUsers.has(workspaceId)) {
      activeUsers.set(workspaceId, new Set());
    }
    activeUsers.get(workspaceId).add(user.id);
    
    // Notify others in workspace
    socket.to(`workspace:${workspaceId}`).emit("user-joined", {
      userId: user.id,
      userName: user.name,
      timestamp: new Date().toISOString()
    });
    
    // Send current active users to the joining user
    const workspaceUsers = await getWorkspaceUsers(workspaceId, Array.from(activeUsers.get(workspaceId)));
    socket.emit("active-users", workspaceUsers);
    
    console.log(`User ${user.name} joined workspace ${workspaceId}`);
  });
  
  // Handle collaboration messages
  socket.on("collab-message", async (data) => {
    // Validate message format
    if (!data.workspaceId || !data.content || !data.encryptionData) {
      socket.emit("error", { message: "Invalid message format" });
      return;
    }
    
    // Check workspace access
    const hasAccess = await checkWorkspaceAccess(user.id, data.workspaceId);
    if (!hasAccess) {
      socket.emit("error", { message: "Access denied to workspace" });
      return;
    }
    
    // Prepare message
    const message = {
      id: generateId(),
      sender: user.id,
      senderName: user.name,
      content: data.content,
      encryptionData: data.encryptionData,
      timestamp: new Date().toISOString(),
      type: data.type || "text"
    };
    
    // Store message in database
    await storeMessage(message, data.workspaceId);
    
    // Broadcast to workspace members
    socket.to(`workspace:${data.workspaceId}`).emit("collab-message", message);
    
    // Acknowledge receipt
    socket.emit("message-ack", { id: message.id, timestamp: message.timestamp });
    
    // Generate notifications for offline members
    generateNotifications(data.workspaceId, message, activeUsers.get(data.workspaceId));
  });
  
  // Handle real-time edits
  socket.on("document-update", async (data) => {
    // Validate update format
    if (!data.documentId || !data.operations || !data.version) {
      socket.emit("error", { message: "Invalid update format" });
      return;
    }
    
    try {
      // Apply operations to the document
      const result = await applyDocumentOperations(
        data.documentId,
        data.operations,
        data.version,
        user.id
      );
      
      if (result.conflict) {
        // Handle conflict
        socket.emit("document-conflict", {
          documentId: data.documentId,
          serverVersion: result.currentVersion,
          operations: result.conflictingOperations
        });
        return;
      }
      
      // Broadcast changes to others editing the document
      socket.to(`document:${data.documentId}`).emit("document-update", {
        documentId: data.documentId,
        operations: data.operations,
        version: result.newVersion,
        author: user.id,
        authorName: user.name,
        timestamp: new Date().toISOString()
      });
      
      // Acknowledge update
      socket.emit("document-ack", {
        documentId: data.documentId,
        version: result.newVersion,
        timestamp: new Date().toISOString()
      });
    } catch (err) {
      console.error(`Document update error: ${err.message}`);
      socket.emit("error", { message: "Failed to update document", details: err.message });
    }
  });
  
  // Handle cursor position updates (for collaborative editing)
  socket.on("cursor-update", (data) => {
    if (!data.documentId || !data.position) {
      return;
    }
    
    // Broadcast cursor position to others
    socket.to(`document:${data.documentId}`).emit("cursor-update", {
      userId: user.id,
      userName: user.name,
      position: data.position,
      timestamp: Date.now()
    });
  });
  
  // Handle map view synchronization
  socket.on("map-sync", async (data) => {
    if (!data.workspaceId || !data.viewState) {
      socket.emit("error", { message: "Invalid map sync data" });
      return;
    }
    
    // Check workspace access
    const hasAccess = await checkWorkspaceAccess(user.id, data.workspaceId);
    if (!hasAccess) {
      socket.emit("error", { message: "Access denied to workspace" });
      return;
    }
    
    // Broadcast map view to others
    socket.to(`workspace:${data.workspaceId}`).emit("map-sync", {
      userId: user.id,
      userName: user.name,
      viewState: data.viewState,
      timestamp: Date.now()
    });
  });
  
  // Handle disconnection
  socket.on("disconnect", async () => {
    console.log(`User disconnected: ${user.name} (${user.id})`);
    
    // Remove user from active users in all workspaces
    for (const [workspaceId, users] of activeUsers.entries()) {
      if (users.has(user.id)) {
        users.delete(user.id);
        
        // Notify others in workspace
        socket.to(`workspace:${workspaceId}`).emit("user-left", {
          userId: user.id,
          userName: user.name,
          timestamp: new Date().toISOString()
        });
      }
    }
  });
});

// Start server
const PORT = process.env.PORT || 3001;
httpServer.listen(PORT, () => {
  console.log(`Collaboration server running on port ${PORT}`);
});

// Helper functions (implementations would be in separate files)
async function checkWorkspaceAccess(userId, workspaceId) {
  // Implementation to check if user has access to workspace
  return true;
}

async function getWorkspaceUsers(workspaceId, activeUserIds) {
  // Implementation to get user details for active users
  return [];
}

function generateId() {
  // Implementation to generate unique IDs
  return Math.random().toString(36).substring(2, 15);
}

async function storeMessage(message, workspaceId) {
  // Implementation to store message in database
}

async function generateNotifications(workspaceId, message, activeUsers) {
  // Implementation to generate notifications for offline users
}

async function applyDocumentOperations(documentId, operations, version, userId) {
  // Implementation to apply operations to document with conflict resolution
  return { newVersion: version + 1, conflict: false };
}
```

## Frontend Integration
The collaboration infrastructure should integrate with the Streamlit frontend through a custom component or side-channel. Here's how it might integrate:

```python
import streamlit as st
import streamlit.components.v1 as components
import json

# Custom component for collaboration features
def collaboration_component(workspace_id, user_id, auth_token):
    # Generate unique key for this instance
    key = f"collab_{workspace_id}_{user_id}"
    
    # Pass configuration to JavaScript component
    component_config = {
        "workspaceId": workspace_id,
        "userId": user_id,
        "authToken": auth_token,
        "apiEndpoint": st.secrets["collaboration_api_endpoint"],
        "wsEndpoint": st.secrets["collaboration_ws_endpoint"]
    }
    
    # Create component with the collaboration UI
    return components.html(
        f"""
        <div id="nyxtrace-collaboration" data-config='{json.dumps(component_config)}'></div>
        <script src="https://nyxtrace-cdn.vercel.app/collaboration-widget.js"></script>
        """,
        height=600,
        key=key
    )

# Main application code
st.title("NyxTrace Collaborative Intelligence")

# Authentication would happen earlier
user_id = st.session_state.get("user_id", "user-123")
auth_token = st.session_state.get("auth_token", "dummy-token")

# Sidebar with collaboration features
with st.sidebar:
    st.header("Team Collaboration")
    workspace_id = st.selectbox(
        "Select Workspace",
        options=["global-threats", "cyber-threats", "physical-threats"]
    )
    
    # Add the collaboration component to the sidebar
    collaboration_component(workspace_id, user_id, auth_token)

# Main content remains the same, but now with collaboration
st.header("Threat Intelligence Dashboard")

# Example of showing collaborative presence on a map
if "map_data" in st.session_state:
    st.map(st.session_state.map_data)
    
    # Show other analysts looking at this map
    if "map_viewers" in st.session_state:
        st.caption(f"Also viewing: {', '.join(st.session_state.map_viewers)}")
```

## Progressive Enhancement
The collaboration features should be designed with progressive enhancement in mind:

1. **Basic functionality** works without real-time features
2. **Enhanced experience** when collaboration server is available
3. **Offline support** for field operations with eventual synchronization
4. **Fallback mechanisms** for high-latency environments

## Next Steps and Expansion
After implementing the basic collaboration infrastructure, we'll want to:

1. Implement advanced features like shared annotations and markups
2. Add AI-assisted collaboration features for team coordination
3. Develop specialized collaboration tools for different analysis types
4. Implement cross-organization collaboration with proper security boundaries

Please develop this collaboration infrastructure with a focus on security, usability, and performance. The solution should enable effective team coordination while maintaining the strict security requirements of intelligence operations.