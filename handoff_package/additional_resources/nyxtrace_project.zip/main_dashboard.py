"""
NyxTrace CTAS Command Center
----------------------------
Main dashboard for the NyxTrace platform, providing access to all
intelligence gathering, analysis, and reporting capabilities across
physical, cyber, and cartel domains.
"""

import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import os
import sys
import logging
import time
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('nyxtrace_dashboard')

# Add module directories to path
module_dir = Path(__file__).parent
sys.path.append(str(module_dir))

# Setup page config
st.set_page_config(
    page_title="NyxTrace CTAS Command Center",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        'Get Help': 'https://www.example.com/help',
        'Report a bug': 'https://www.example.com/bug',
        'About': "NyxTrace - Advanced Geospatial Intelligence Platform"
    }
)

# Apply custom CSS for dark theme
st.markdown("""
<style>
    .main {
        background-color: #0E1117;
        color: #FAFAFA;
    }
    .stApp {
        background-color: #0E1117;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 2px;
    }
    .stTabs [data-baseweb="tab"] {
        background-color: #1E2130;
        border-radius: 4px 4px 0px 0px;
        padding: 10px 20px;
        color: white;
    }
    .stTabs [aria-selected="true"] {
        background-color: #262730;
        color: #FAFAFA;
        border-bottom: 2px solid #FF4B4B;
    }
    .stDataFrame {
        background-color: #1E2130;
    }
    .stAlert {
        background-color: #262730;
        color: white;
    }
    .css-145kmo2 {
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 0.5rem;
        padding: 1rem;
    }
    .css-1r6slb0 {
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 0.5rem;
    }
    .metric-container {
        background-color: #1E2130;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 0.5rem;
        padding: 1rem;
        margin-bottom: 1rem;
    }
    .metric-label {
        font-size: 0.8rem;
        color: rgba(255, 255, 255, 0.6);
    }
    .metric-value {
        font-size: 1.5rem;
        font-weight: bold;
        color: #FAFAFA;
    }
    .status-indicator {
        display: inline-block;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        margin-right: 5px;
    }
    .status-active {
        background-color: #00FF00;
    }
    .status-inactive {
        background-color: #FF0000;
    }
    .status-warning {
        background-color: #FFFF00;
    }
</style>
""", unsafe_allow_html=True)

# Import modules
try:
    from data_sources.incident_reporter import HybridThreatReporter
    incident_reporter_available = True
except ImportError:
    incident_reporter_available = False
    
try:
    from data_sources.osint_investigation import OsintInvestigation
    osint_investigation_available = True
except ImportError:
    osint_investigation_available = False
    
try:
    from utils.opsec_manager import OpsecManager
    opsec_manager_available = True
except ImportError:
    opsec_manager_available = False
    
try:
    from data_sources.data_source_integrator import DataSourceIntegrator
    data_source_integrator_available = True
except ImportError:
    data_source_integrator_available = False
    
try:
    from utils.kali_integrator import KaliIntegrator
    kali_integrator_available = True
except ImportError:
    kali_integrator_available = False
    
# Import threat intelligence components
try:
    from data_sources.plugins.alienvault_otx_source import AlienVaultOTXSource
    from visualization.threat_flow_visualization import ThreatFlowVisualizer
    threat_intel_available = True
except ImportError:
    threat_intel_available = False

# Initialize session state
st.session_state.setdefault('initialized', False)
st.session_state.setdefault('current_view', "dashboard")
st.session_state.setdefault('incidents', [])
st.session_state.setdefault('osint_results', [])
st.session_state.setdefault('sources', [])
st.session_state.setdefault('tools', [])
st.session_state.setdefault('alerts', [])

# Initialize components
def initialize_components():
    """Initialize all available components"""
    if not st.session_state.get('initialized', False):
        # Initialize incident reporter
        if incident_reporter_available:
            st.session_state['incident_reporter'] = "HybridThreatReporter()"  # Placeholder for actual class
            logger.info("Initialized Incident Reporter")
        
        # Initialize OSINT investigation
        if osint_investigation_available:
            st.session_state['osint_investigation'] = "OsintInvestigation()"  # Placeholder for actual class
            logger.info("Initialized OSINT Investigation")
        
        # Initialize OPSEC manager
        if opsec_manager_available:
            st.session_state['opsec_manager'] = "OpsecManager()"  # Placeholder for actual class
            logger.info("Initialized OPSEC Manager")
        
        # Initialize data source integrator
        if data_source_integrator_available:
            st.session_state['data_source_integrator'] = "DataSourceIntegrator()"  # Placeholder for actual class
            logger.info("Initialized Data Source Integrator")
        
        # Initialize Kali integrator
        if kali_integrator_available:
            st.session_state['kali_integrator'] = "KaliIntegrator()"  # Placeholder for actual class
            logger.info("Initialized Kali Integrator")
        
        st.session_state['initialized'] = True

# Header with status indicators
def render_header():
    """Render the dashboard header with status indicators"""
    col1, col2, col3 = st.columns([3, 5, 2])
    
    with col1:
        st.markdown("# CTAS COMMAND CENTER")
    
    with col2:
        st.markdown("### NyxTrace Geospatial Intelligence Platform")
    
    with col3:
        # Status indicators
        status_html = """
        <div style="text-align: right;">
            <div><span class="status-indicator status-active"></span> OSINT Module</div>
            <div><span class="status-indicator status-active"></span> Incident Tracking</div>
            <div><span class="status-indicator status-warning"></span> Threat Analytics</div>
        </div>
        """
        st.markdown(status_html, unsafe_allow_html=True)
    
    st.markdown("---")

# Navigation sidebar
def render_sidebar():
    """Render the navigation sidebar"""
    st.sidebar.markdown("## OPERATIONS CONTROL")
    
    # Navigation buttons
    if st.sidebar.button("📊 Dashboard", use_container_width=True):
        st.session_state['current_view'] = "dashboard"
    
    if st.sidebar.button("🔍 OSINT Investigation", use_container_width=True):
        st.session_state['current_view'] = "osint"
    
    if st.sidebar.button("🚨 Incident Reporter", use_container_width=True):
        st.session_state['current_view'] = "incidents"
    
    # For Threat Intelligence, provide a direct link to the page
    st.sidebar.markdown("""
    <a href="/threat_intel" target="_self" style="text-decoration:none;">
        <button style="background-color:#4CAF50; color:white; border:none; padding:10px; 
        border-radius:5px; cursor:pointer; width:100%; text-align:left;">
            🛡️ Threat Intelligence
        </button>
    </a>
    """, unsafe_allow_html=True)
    
    # For URL Health Dashboard, provide a direct link to the page
    st.sidebar.markdown("""
    <a href="/url_health" target="_self" style="text-decoration:none;">
        <button style="background-color:#2196F3; color:white; border:none; padding:10px; 
        border-radius:5px; cursor:pointer; width:100%; text-align:left;">
            🔗 URL Health Dashboard
        </button>
    </a>
    """, unsafe_allow_html=True)
    
    if st.sidebar.button("🌐 Data Sources", use_container_width=True):
        st.session_state['current_view'] = "data_sources"
    
    if st.sidebar.button("🛠️ Security Tools", use_container_width=True):
        st.session_state['current_view'] = "tools"
    
    if st.sidebar.button("📝 Reports", use_container_width=True):
        st.session_state['current_view'] = "reports"
    
    st.sidebar.markdown("---")
    
    # OPSEC Status
    st.sidebar.markdown("## OPSEC STATUS")
    
    if opsec_manager_available and 'opsec_manager' in st.session_state:
        profiles = ["Default Profile", "Anonymous Profile", "Field Operations"]
        selected_profile = st.sidebar.selectbox("Active Profile", profiles)
        
        st.sidebar.markdown(f"""
        **Browser Protection**: {'✅ Active' if True else '❌ Inactive'}  
        **Network Protection**: {'✅ Active' if True else '❌ Inactive'}  
        **Identity Masking**: {'✅ Active' if True else '❌ Inactive'}  
        """)
        
        if st.sidebar.button("Configure OPSEC", use_container_width=True):
            st.session_state['current_view'] = "opsec"
    else:
        st.sidebar.warning("OPSEC Manager not available")
    
    st.sidebar.markdown("---")
    
    # System information
    st.sidebar.markdown("## SYSTEM INFO")
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    st.sidebar.markdown(f"**Current Time**: {current_time}")
    
    if 'alerts' in st.session_state:
        alert_count = len(st.session_state.alerts)
        st.sidebar.markdown(f"**Active Alerts**: {alert_count}")
    
    # Session controls
    st.sidebar.markdown("---")
    if st.sidebar.button("End Session", use_container_width=True):
        # This would implement secure session termination
        st.sidebar.warning("Session termination not implemented")

# Main dashboard view
def render_dashboard():
    """Render the main dashboard view"""
    st.markdown("## Command Dashboard")
    
    # Key metrics row
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("""
        <div class="metric-container">
            <div class="metric-label">Active Incidents</div>
            <div class="metric-value">24</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="metric-container">
            <div class="metric-label">Intelligence Sources</div>
            <div class="metric-value">16</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div class="metric-container">
            <div class="metric-label">Threat Level</div>
            <div class="metric-value">Elevated</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown("""
        <div class="metric-container">
            <div class="metric-label">System Status</div>
            <div class="metric-value">Operational</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Threat map and incident timeline
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.markdown("### Global Threat Map")
        # Create sample data for map
        map_data = pd.DataFrame({
            'lat': [40.7128, 34.0522, 41.8781, 37.7749, 51.5074],
            'lon': [-74.0060, -118.2437, -87.6298, -122.4194, -0.1278],
            'location': ['New York', 'Los Angeles', 'Chicago', 'San Francisco', 'London'],
            'threat_level': [0.8, 0.6, 0.4, 0.7, 0.5]
        })
        
        fig = px.scatter_mapbox(
            map_data, 
            lat="lat", 
            lon="lon", 
            hover_name="location",
            size="threat_level",
            size_max=15,
            zoom=1, 
            color="threat_level",
            color_continuous_scale=["green", "yellow", "red"],
            mapbox_style="carto-darkmatter"
        )
        
        fig.update_layout(
            margin={"r":0,"t":0,"l":0,"b":0},
            coloraxis_showscale=False,
            height=400
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("### Incident Timeline")
        
        # Sample timeline data
        timeline_data = [
            {"time": "08:30", "event": "Cyber intrusion detected", "type": "cyber"},
            {"time": "10:15", "event": "Physical security breach", "type": "physical"},
            {"time": "12:45", "event": "Data exfiltration attempt", "type": "cyber"},
            {"time": "14:20", "event": "Suspicious network traffic", "type": "cyber"},
            {"time": "16:10", "event": "Unauthorized facility access", "type": "physical"}
        ]
        
        for event in timeline_data:
            color = "red" if event["type"] == "cyber" else "orange"
            st.markdown(f"""
            <div style="margin-bottom: 10px; border-left: 3px solid {color}; padding-left: 10px;">
                <div style="font-size: 0.8rem; color: rgba(255, 255, 255, 0.6);">{event['time']}</div>
                <div style="font-size: 1rem;">{event['event']}</div>
            </div>
            """, unsafe_allow_html=True)
    
    # Threat analysis section
    st.markdown("### Threat Analysis")
    
    tab1, tab2, tab3 = st.tabs(["Cyber Threats", "Physical Threats", "Cartel Activity"])
    
    with tab1:
        col1, col2 = st.columns(2)
        
        with col1:
            # Sample data for cyber threat categories
            categories = ['Malware', 'Phishing', 'DDoS', 'Insider', 'Zero-day']
            values = [42, 23, 15, 8, 12]
            
            fig = go.Figure(data=[go.Pie(
                labels=categories, 
                values=values, 
                hole=.3,
                marker_colors=['#636EFA', '#EF553B', '#00CC96', '#AB63FA', '#FFA15A']
            )])
            
            fig.update_layout(
                title_text="Cyber Threat Categories",
                showlegend=True,
                legend=dict(orientation="h", y=-0.1),
                height=300,
                margin=dict(l=20, r=20, t=30, b=0),
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='white')
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
        with col2:
            # Sample data for cyber threat trend
            dates = pd.date_range(start='2023-01-01', periods=10, freq='M')
            trend_data = pd.DataFrame({
                'date': dates,
                'incidents': [15, 18, 22, 20, 25, 30, 28, 35, 32, 38]
            })
            
            fig = px.line(
                trend_data, 
                x='date', 
                y='incidents',
                markers=True
            )
            
            fig.update_layout(
                title_text="Cyber Threat Trend",
                xaxis_title="",
                yaxis_title="Incident Count",
                height=300,
                margin=dict(l=20, r=20, t=30, b=0),
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='white'),
                xaxis=dict(showgrid=False),
                yaxis=dict(showgrid=True, gridcolor='rgba(255,255,255,0.1)')
            )
            
            st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        col1, col2 = st.columns(2)
        
        with col1:
            # Sample data for physical threat heatmap
            facility_types = ['Government', 'Energy', 'Transportation', 'Healthcare', 'Telecom']
            threat_types = ['Unauthorized Access', 'Vandalism', 'Theft', 'Sabotage', 'Surveillance']
            
            z = [
                [4, 1, 2, 5, 3],
                [2, 2, 1, 1, 2],
                [5, 3, 3, 2, 4],
                [1, 1, 2, 3, 1],
                [3, 2, 4, 1, 3]
            ]
            
            fig = go.Figure(data=go.Heatmap(
                z=z,
                x=threat_types,
                y=facility_types,
                colorscale='Reds',
                showscale=False
            ))
            
            fig.update_layout(
                title_text="Physical Threat Matrix",
                height=300,
                margin=dict(l=20, r=20, t=30, b=0),
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='white')
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
        with col2:
            # Sample data for critical infrastructure status
            infrastructure = ['Power Grid', 'Water System', 'Transportation', 'Communications', 'Healthcare']
            status = [92, 85, 78, 90, 88]
            
            fig = go.Figure(go.Bar(
                x=status,
                y=infrastructure,
                orientation='h',
                marker=dict(
                    color=['green' if s >= 90 else 'yellow' if s >= 80 else 'red' for s in status],
                    line=dict(color='rgba(0,0,0,0)', width=1)
                )
            ))
            
            fig.update_layout(
                title_text="Critical Infrastructure Status",
                xaxis_title="Operational Capacity (%)",
                height=300,
                margin=dict(l=20, r=20, t=30, b=0),
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='white'),
                xaxis=dict(showgrid=False, range=[0, 100]),
                yaxis=dict(showgrid=False)
            )
            
            st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        col1, col2 = st.columns(2)
        
        with col1:
            # Sample network graph for cartel activities
            st.markdown("#### Cartel Network Analysis")
            
            # Create a placeholder for the network graph
            # In a real implementation, this would be a network visualization
            st.image("https://via.placeholder.com/800x400?text=Cartel+Network+Analysis", use_column_width=True)
            
        with col2:
            # Sample data for cartel activity by region
            regions = ['North Region', 'South Region', 'East Region', 'West Region', 'Central']
            activities = [38, 25, 15, 40, 22]
            
            fig = go.Figure(go.Bar(
                x=regions,
                y=activities,
                marker=dict(
                    color='rgba(255, 165, 0, 0.8)',
                    line=dict(color='rgba(255, 165, 0, 1.0)', width=1)
                )
            ))
            
            fig.update_layout(
                title_text="Cartel Activity by Region",
                height=300,
                margin=dict(l=20, r=20, t=30, b=0),
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='white'),
                xaxis=dict(showgrid=False),
                yaxis=dict(showgrid=True, gridcolor='rgba(255,255,255,0.1)', title="Activity Level")
            )
            
            st.plotly_chart(fig, use_container_width=True)
    
    # Recent alerts
    st.markdown("### Recent Alerts")
    
    alert_data = [
        {"timestamp": "2023-05-07 08:12:34", "type": "Critical", "message": "Unauthorized access attempt detected at Server Room B"},
        {"timestamp": "2023-05-07 07:45:21", "type": "High", "message": "Suspicious traffic pattern identified from IP block 192.168.10.0/24"},
        {"timestamp": "2023-05-07 06:30:15", "type": "Medium", "message": "Potential data exfiltration detected on workstation WS-42"},
        {"timestamp": "2023-05-06 23:15:42", "type": "High", "message": "Multiple failed authentication attempts for admin accounts"},
        {"timestamp": "2023-05-06 21:08:37", "type": "Medium", "message": "Unusual physical access pattern at North Facility entrance"}
    ]
    
    alert_df = pd.DataFrame(alert_data)
    
    # Format the dataframe with colors
    def highlight_type(s):
        return ['background-color: #FF4B4B' if x == 'Critical' 
                else 'background-color: #FFA15A' if x == 'High'
                else 'background-color: #FFFF00' if x == 'Medium'
                else '' for x in s]
    
    styled_df = alert_df.style.apply(highlight_type, subset=['type'])
    
    st.dataframe(styled_df, use_container_width=True)

# OSINT Investigation view
def render_osint_view():
    """Render the OSINT Investigation view"""
    st.markdown("## OSINT Investigation")
    
    if not osint_investigation_available:
        st.warning("OSINT Investigation module not available. Please check if the module is properly installed.")
        return
    
    # Create tabs for different investigation features
    tab1, tab2, tab3, tab4 = st.tabs(["Web OSINT", "Dark Web", "Social Media", "Entity Analysis"])
    
    with tab1:
        st.markdown("### Web Intelligence Gathering")
        
        col1, col2 = st.columns([3, 1])
        
        with col1:
            query = st.text_input("Search Query", placeholder="Enter search terms or URL to investigate")
            
        with col2:
            search_button = st.button("Investigate", use_container_width=True)
        
        if search_button and query:
            st.info(f"Investigating: {query}")
            
            # This would call the actual OSINT investigation
            with st.spinner("Gathering intelligence..."):
                # In a real implementation, this would call the OSINT module
                # results = st.session_state.osint_investigation.investigate(query)
                
                # For now, show a placeholder
                st.success("Investigation complete")
                
                st.markdown("#### Results Summary")
                st.markdown("""
                - 15 relevant web pages identified
                - 3 technical indicators extracted
                - 8 entities identified
                - 4 potential threats detected
                """)
                
                # Display tabs for different result types
                result_tab1, result_tab2, result_tab3 = st.tabs(["Web Content", "Indicators", "Entities"])
                
                with result_tab1:
                    st.markdown("#### Web Content Analysis")
                    st.markdown("Content from relevant web pages would be displayed here")
                
                with result_tab2:
                    st.markdown("#### Technical Indicators")
                    indicators = [
                        {"type": "ip", "value": "192.168.1.1", "confidence": 0.85},
                        {"type": "domain", "value": "example.com", "confidence": 0.92},
                        {"type": "hash", "value": "a1b2c3d4e5f6...", "confidence": 0.78}
                    ]
                    
                    indicators_df = pd.DataFrame(indicators)
                    st.dataframe(indicators_df, use_container_width=True)
                
                with result_tab3:
                    st.markdown("#### Entities Identified")
                    entities = [
                        {"type": "person", "value": "John Doe", "mentions": 5},
                        {"type": "organization", "value": "ACME Corp", "mentions": 8},
                        {"type": "location", "value": "New York", "mentions": 3}
                    ]
                    
                    entities_df = pd.DataFrame(entities)
                    st.dataframe(entities_df, use_container_width=True)
    
    with tab2:
        st.markdown("### Dark Web Intelligence")
        st.warning("Dark Web investigation features require additional configuration and authorization.")
        
        # Dark web search interface would go here
        st.text_input("Onion URL or Search Term", placeholder="Enter .onion URL or search term")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.checkbox("Use Tor Gateway")
        
        with col2:
            st.checkbox("Enhanced Anonymity")
        
        with col3:
            st.button("Access Dark Web", disabled=True)
    
    with tab3:
        st.markdown("### Social Media Intelligence")
        
        platform = st.selectbox(
            "Select Platform",
            ["Twitter", "Reddit", "LinkedIn", "Facebook", "Instagram"]
        )
        
        col1, col2 = st.columns([3, 1])
        
        with col1:
            username = st.text_input("Username or Search Term", placeholder=f"Enter {platform} username or search term")
        
        with col2:
            st.button("Analyze", use_container_width=True, disabled=True)
            
        st.info("Social media analysis requires API configuration. Please configure API credentials in the settings.")
    
    with tab4:
        st.markdown("### Entity Analysis")
        
        entity_type = st.selectbox(
            "Entity Type",
            ["Person", "Organization", "IP Address", "Domain", "Email"]
        )
        
        entity_value = st.text_input("Entity Value", placeholder=f"Enter {entity_type.lower()} to analyze")
        
        st.button("Analyze Entity", disabled=True)
        
        st.info("Entity analysis features are part of the advanced module. Please ensure all required components are installed.")

# Incident Reporter view
def render_incidents_view():
    """Render the Incident Reporter view"""
    st.markdown("## Incident Reporter")
    
    if not incident_reporter_available:
        st.warning("Incident Reporter module not available. Please check if the module is properly installed.")
        return
    
    # Create tabs for different incident features
    tab1, tab2, tab3 = st.tabs(["Incident Dashboard", "Create Incident", "Analytics"])
    
    with tab1:
        st.markdown("### Active Incidents")
        
        # Filters
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            incident_type_filter = st.selectbox(
                "Incident Type",
                ["All Types", "Cyber", "Physical", "Hybrid", "Cartel"]
            )
        
        with col2:
            severity_filter = st.selectbox(
                "Severity",
                ["All Severities", "Critical", "High", "Medium", "Low"]
            )
        
        with col3:
            start_date = st.date_input("Start Date", datetime.now() - timedelta(days=30))
        
        with col4:
            end_date = st.date_input("End Date", datetime.now())
        
        # Sample incident data
        incidents = [
            {"id": "INC-12345", "title": "Data Breach at HQ", "type": "Cyber", "severity": "Critical", "date": "2023-05-01", "status": "Open"},
            {"id": "INC-12346", "title": "Physical Security Breach", "type": "Physical", "severity": "High", "date": "2023-05-02", "status": "Investigating"},
            {"id": "INC-12347", "title": "Ransomware Attack", "type": "Cyber", "severity": "Critical", "date": "2023-05-03", "status": "Mitigating"},
            {"id": "INC-12348", "title": "Suspicious Activity", "type": "Hybrid", "severity": "Medium", "date": "2023-05-04", "status": "Open"},
            {"id": "INC-12349", "title": "Supply Chain Disruption", "type": "Cartel", "severity": "High", "date": "2023-05-05", "status": "Investigating"}
        ]
        
        # Convert to DataFrame
        incidents_df = pd.DataFrame(incidents)
        
        # Display incidents
        st.dataframe(incidents_df, use_container_width=True)
    
    with tab2:
        st.markdown("### Create New Incident")
        
        col1, col2 = st.columns(2)
        
        with col1:
            incident_title = st.text_input("Incident Title", placeholder="Enter a descriptive title")
            incident_type = st.selectbox(
                "Incident Type",
                ["Cyber", "Physical", "Hybrid", "Cartel"]
            )
            incident_severity = st.selectbox(
                "Severity",
                ["Critical", "High", "Medium", "Low"]
            )
        
        with col2:
            incident_date = st.date_input("Incident Date", datetime.now())
            incident_location = st.text_input("Location", placeholder="Enter incident location")
            incident_status = st.selectbox(
                "Status",
                ["Open", "Investigating", "Mitigating", "Resolved", "Closed"]
            )
        
        incident_description = st.text_area("Description", placeholder="Enter detailed incident description")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.text_input("Affected Assets", placeholder="Assets affected by the incident")
        
        with col2:
            st.text_input("Threat Actors", placeholder="Known or suspected threat actors")
        
        with col3:
            st.text_input("Tags", placeholder="Comma-separated tags")
        
        if st.button("Create Incident", use_container_width=True):
            st.success("Incident created successfully!")
            
            # In a real implementation, this would call the incident reporter module
            # new_incident = st.session_state.incident_reporter.create_incident(...)
    
    with tab3:
        st.markdown("### Incident Analytics")
        
        # Create some sample analytics visualizations
        col1, col2 = st.columns(2)
        
        with col1:
            # Incidents by type
            incident_types = ["Cyber", "Physical", "Hybrid", "Cartel"]
            incident_counts = [42, 28, 15, 23]
            
            fig = go.Figure(data=[go.Bar(
                x=incident_types,
                y=incident_counts,
                marker_color=['#636EFA', '#EF553B', '#00CC96', '#FFA15A']
            )])
            
            fig.update_layout(
                title_text="Incidents by Type",
                xaxis_title="Incident Type",
                yaxis_title="Count",
                height=300,
                margin=dict(l=20, r=20, t=30, b=0),
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='white'),
                xaxis=dict(showgrid=False),
                yaxis=dict(showgrid=True, gridcolor='rgba(255,255,255,0.1)')
            )
            
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Incidents by severity
            severity_levels = ["Critical", "High", "Medium", "Low"]
            severity_counts = [15, 35, 48, 12]
            
            fig = go.Figure(data=[go.Pie(
                labels=severity_levels,
                values=severity_counts,
                marker_colors=['#FF4B4B', '#FFA15A', '#FFFF00', '#00CC96']
            )])
            
            fig.update_layout(
                title_text="Incidents by Severity",
                height=300,
                margin=dict(l=20, r=20, t=30, b=0),
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='white')
            )
            
            st.plotly_chart(fig, use_container_width=True)
        
        # Incident trend over time
        dates = pd.date_range(start='2023-01-01', periods=12, freq='M')
        trend_data = pd.DataFrame({
            'date': dates,
            'cyber': [10, 12, 15, 18, 14, 16, 20, 22, 19, 24, 21, 25],
            'physical': [8, 7, 9, 10, 12, 11, 14, 13, 15, 16, 14, 18],
            'hybrid': [3, 4, 2, 5, 6, 5, 7, 8, 6, 9, 7, 10],
            'cartel': [5, 6, 8, 7, 9, 10, 8, 12, 10, 14, 12, 15]
        })
        
        fig = go.Figure()
        
        fig.add_trace(go.Scatter(
            x=trend_data['date'], 
            y=trend_data['cyber'],
            mode='lines+markers',
            name='Cyber',
            line=dict(color='#636EFA')
        ))
        
        fig.add_trace(go.Scatter(
            x=trend_data['date'], 
            y=trend_data['physical'],
            mode='lines+markers',
            name='Physical',
            line=dict(color='#EF553B')
        ))
        
        fig.add_trace(go.Scatter(
            x=trend_data['date'], 
            y=trend_data['hybrid'],
            mode='lines+markers',
            name='Hybrid',
            line=dict(color='#00CC96')
        ))
        
        fig.add_trace(go.Scatter(
            x=trend_data['date'], 
            y=trend_data['cartel'],
            mode='lines+markers',
            name='Cartel',
            line=dict(color='#FFA15A')
        ))
        
        fig.update_layout(
            title_text="Incident Trends Over Time",
            xaxis_title="",
            yaxis_title="Incident Count",
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            ),
            margin=dict(l=20, r=20, t=30, b=0),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            font=dict(color='white'),
            xaxis=dict(showgrid=False),
            yaxis=dict(showgrid=True, gridcolor='rgba(255,255,255,0.1)')
        )
        
        st.plotly_chart(fig, use_container_width=True)



# Data Sources view
def render_data_sources_view():
    """Render the Data Sources view"""
    st.markdown("## Data Sources")
    
    if not data_source_integrator_available:
        st.warning("Data Source Integrator module not available. Please check if the module is properly installed.")
        return
    
    # Create tabs for different data source features
    tab1, tab2, tab3 = st.tabs(["Source Management", "Data Acquisition", "Source Analysis"])
    
    with tab1:
        st.markdown("### Data Source Management")
        
        # Source type selector
        source_type = st.selectbox(
            "Source Type",
            ["Web Source", "API Source", "Feed Source", "PDF Source", "Database Source"]
        )
        
        col1, col2 = st.columns(2)
        
        with col1:
            source_name = st.text_input("Source Name", placeholder="Enter a name for the source")
            source_url = st.text_input("URL or Path", placeholder="Enter URL or file path")
        
        with col2:
            source_credibility = st.slider("Credibility Score", 0.0, 1.0, 0.5)
            source_tags = st.text_input("Tags", placeholder="Enter comma-separated tags")
        
        # Source-specific configuration
        st.markdown("#### Source Configuration")
        
        if source_type == "Web Source":
            col1, col2 = st.columns(2)
            
            with col1:
                st.text_input("Title Selector", placeholder="CSS selector for titles")
                st.text_input("Content Selector", placeholder="CSS selector for content")
            
            with col2:
                st.text_input("Date Selector", placeholder="CSS selector for dates")
                st.text_input("Author Selector", placeholder="CSS selector for authors")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.checkbox("Use Trafilatura")
            
            with col2:
                st.checkbox("Use JavaScript")
            
            with col3:
                st.checkbox("Follow Links")
        
        elif source_type == "API Source":
            col1, col2 = st.columns(2)
            
            with col1:
                st.text_input("API Key", placeholder="Enter API key", type="password")
                st.text_input("Key Parameter", placeholder="API key parameter name")
            
            with col2:
                st.selectbox("Response Format", ["JSON", "XML", "CSV"])
                st.text_input("Headers", placeholder="Enter headers as JSON")
        
        elif source_type == "Feed Source":
            st.selectbox("Feed Type", ["RSS", "Atom", "JSON Feed"])
        
        elif source_type == "PDF Source":
            st.file_uploader("Upload PDF File", type=["pdf"])
            st.selectbox("PDF Extraction Tool", ["PDFMiner", "PyPDF2"])
        
        elif source_type == "Database Source":
            col1, col2 = st.columns(2)
            
            with col1:
                st.selectbox("Database Type", ["PostgreSQL", "MySQL", "SQLite", "MongoDB"])
                st.text_input("Host", placeholder="Database host")
            
            with col2:
                st.text_input("Database Name", placeholder="Database name")
                st.text_input("Query", placeholder="SQL query or collection name")
                
            st.text_input("Connection String", placeholder="Enter connection string", type="password")
        
        # Add source button
        if st.button("Add Source", use_container_width=True):
            st.success(f"Added source: {source_name}")
            
            # In a real implementation, this would call the data source integrator
            # source = st.session_state.data_source_integrator.add_source(...)
        
        # Existing sources
        st.markdown("### Existing Sources")
        
        # Sample source data
        sources = [
            {"id": "SRC-001", "name": "Security News Feed", "type": "Feed Source", "credibility": 0.8, "last_updated": "2023-05-05"},
            {"id": "SRC-002", "name": "Threat Database", "type": "API Source", "credibility": 0.9, "last_updated": "2023-05-06"},
            {"id": "SRC-003", "name": "Dark Web Monitor", "type": "Web Source", "credibility": 0.6, "last_updated": "2023-05-04"},
            {"id": "SRC-004", "name": "Intelligence Reports", "type": "PDF Source", "credibility": 0.7, "last_updated": "2023-05-01"},
            {"id": "SRC-005", "name": "Social Media Tracker", "type": "API Source", "credibility": 0.5, "last_updated": "2023-05-07"}
        ]
        
        # Convert to DataFrame
        sources_df = pd.DataFrame(sources)
        
        # Display sources
        st.dataframe(sources_df, use_container_width=True)
    
    with tab2:
        st.markdown("### Data Acquisition")
        
        col1, col2 = st.columns([3, 1])
        
        with col1:
            acquisition_query = st.text_input("Search Query", placeholder="Enter search terms or parameters")
            
            col1a, col1b, col1c = st.columns(3)
            
            with col1a:
                st.multiselect("Source Types", ["Web", "API", "Feed", "PDF", "Database"])
            
            with col1b:
                st.number_input("Max Results Per Source", min_value=1, max_value=100, value=10)
            
            with col1c:
                st.checkbox("Extract Content")
        
        with col2:
            st.selectbox("Sort By", ["Relevance", "Date", "Credibility", "Source Type"])
            acquisition_button = st.button("Acquire Data", use_container_width=True)
        
        if acquisition_button and acquisition_query:
            st.info(f"Acquiring data for: {acquisition_query}")
            
            with st.spinner("Gathering data from sources..."):
                # In a real implementation, this would call the data source integrator
                # results = st.session_state.data_source_integrator.search_data(acquisition_query)
                
                # For now, show a placeholder
                st.success("Data acquisition complete")
                
                # Sample results
                st.markdown("#### Results")
                
                # Display tabs for different sources
                result_tab1, result_tab2, result_tab3 = st.tabs(["Web Sources", "API Sources", "Feed Sources"])
                
                with result_tab1:
                    st.markdown("#### Web Source Results")
                    web_results = [
                        {"title": "New Threat Actor Identified", "source": "Security Blog A", "url": "https://example.com/blog/1", "date": "2023-05-05"},
                        {"title": "Critical Vulnerability Discovered", "source": "Security Blog B", "url": "https://example.com/blog/2", "date": "2023-05-06"},
                        {"title": "Ransomware Campaign Analysis", "source": "Security Blog C", "url": "https://example.com/blog/3", "date": "2023-05-04"}
                    ]
                    
                    web_df = pd.DataFrame(web_results)
                    st.dataframe(web_df, use_container_width=True)
                
                with result_tab2:
                    st.markdown("#### API Source Results")
                    api_results = [
                        {"id": "API-001", "title": "Threat Intelligence Report", "source": "Threat API", "date": "2023-05-07"},
                        {"id": "API-002", "title": "Malware Analysis", "source": "Malware API", "date": "2023-05-06"},
                        {"id": "API-003", "title": "Vulnerability Database Entry", "source": "Vuln API", "date": "2023-05-05"}
                    ]
                    
                    api_df = pd.DataFrame(api_results)
                    st.dataframe(api_df, use_container_width=True)
                
                with result_tab3:
                    st.markdown("#### Feed Source Results")
                    feed_results = [
                        {"title": "Daily Security Update", "source": "Security Feed A", "published": "2023-05-07"},
                        {"title": "Weekly Threat Summary", "source": "Security Feed B", "published": "2023-05-06"},
                        {"title": "Security Advisory", "source": "Security Feed C", "published": "2023-05-05"}
                    ]
                    
                    feed_df = pd.DataFrame(feed_results)
                    st.dataframe(feed_df, use_container_width=True)
    
    with tab3:
        st.markdown("### Source Analysis")
        
        # Sample data for source health
        source_health = [
            {"source": "Security News Feed", "uptime": 0.98, "response_time": 0.5, "reliability": 0.95},
            {"source": "Threat Database", "uptime": 0.99, "response_time": 0.8, "reliability": 0.97},
            {"source": "Dark Web Monitor", "uptime": 0.85, "response_time": 1.2, "reliability": 0.80},
            {"source": "Intelligence Reports", "uptime": 0.92, "response_time": 0.7, "reliability": 0.90},
            {"source": "Social Media Tracker", "uptime": 0.95, "response_time": 0.6, "reliability": 0.92}
        ]
        
        source_health_df = pd.DataFrame(source_health)
        
        # Source health visualization
        fig = go.Figure()
        
        fig.add_trace(go.Bar(
            x=source_health_df['source'],
            y=source_health_df['uptime'],
            name='Uptime',
            marker_color='#636EFA'
        ))
        
        fig.add_trace(go.Bar(
            x=source_health_df['source'],
            y=source_health_df['reliability'],
            name='Reliability',
            marker_color='#EF553B'
        ))
        
        fig.update_layout(
            title_text="Source Health Metrics",
            barmode='group',
            xaxis_title="Source",
            yaxis_title="Score (0-1)",
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            ),
            margin=dict(l=20, r=20, t=30, b=0),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            font=dict(color='white'),
            xaxis=dict(showgrid=False),
            yaxis=dict(showgrid=True, gridcolor='rgba(255,255,255,0.1)', range=[0, 1])
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Source coverage analysis
        st.markdown("#### Source Coverage Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Source by type visualization
            source_types = ["Web", "API", "Feed", "PDF", "Database"]
            type_counts = [8, 12, 5, 3, 2]
            
            fig = go.Figure(data=[go.Pie(
                labels=source_types, 
                values=type_counts, 
                hole=.3,
                marker_colors=['#636EFA', '#EF553B', '#00CC96', '#AB63FA', '#FFA15A']
            )])
            
            fig.update_layout(
                title_text="Sources by Type",
                height=300,
                margin=dict(l=20, r=20, t=30, b=0),
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='white')
            )
            
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Source by credibility visualization
            credibility_ranges = ["0.0-0.2", "0.2-0.4", "0.4-0.6", "0.6-0.8", "0.8-1.0"]
            credibility_counts = [2, 5, 8, 10, 5]
            
            fig = go.Figure(data=[go.Bar(
                x=credibility_ranges,
                y=credibility_counts,
                marker_color='#00CC96'
            )])
            
            fig.update_layout(
                title_text="Sources by Credibility",
                xaxis_title="Credibility Score Range",
                yaxis_title="Number of Sources",
                height=300,
                margin=dict(l=20, r=20, t=30, b=0),
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='white'),
                xaxis=dict(showgrid=False),
                yaxis=dict(showgrid=True, gridcolor='rgba(255,255,255,0.1)')
            )
            
            st.plotly_chart(fig, use_container_width=True)
        
        # Geographical coverage
        st.markdown("#### Geographical Coverage")
        
        # Create sample data for map
        geo_coverage = pd.DataFrame({
            'lat': [40.7128, 34.0522, 41.8781, 37.7749, 51.5074, 48.8566, 52.5200, 35.6762, 19.4326, -33.8688],
            'lon': [-74.0060, -118.2437, -87.6298, -122.4194, -0.1278, 2.3522, 13.4050, 139.6503, -99.1332, 151.2093],
            'location': ['New York', 'Los Angeles', 'Chicago', 'San Francisco', 'London', 'Paris', 'Berlin', 'Tokyo', 'Mexico City', 'Sydney'],
            'coverage': [0.9, 0.8, 0.7, 0.85, 0.95, 0.8, 0.75, 0.6, 0.5, 0.65]
        })
        
        fig = px.scatter_mapbox(
            geo_coverage, 
            lat="lat", 
            lon="lon", 
            hover_name="location",
            size="coverage",
            size_max=15,
            zoom=1, 
            color="coverage",
            color_continuous_scale=["red", "yellow", "green"],
            mapbox_style="carto-darkmatter"
        )
        
        fig.update_layout(
            margin={"r":0,"t":0,"l":0,"b":0},
            height=400
        )
        
        st.plotly_chart(fig, use_container_width=True)

# Security Tools view
def render_tools_view():
    """Render the Security Tools view"""
    st.markdown("## Security Tools")
    
    if not kali_integrator_available:
        st.warning("Kali Integrator module not available. Please check if the module is properly installed.")
        return
    
    # Create tabs for different tool features
    tab1, tab2, tab3 = st.tabs(["Tool Management", "Tool Execution", "Tool Chains"])
    
    with tab1:
        st.markdown("### Security Tool Management")
        
        # Tool status
        tool_status = [
            {"name": "Nmap", "status": "Installed", "version": "7.92"},
            {"name": "Metasploit", "status": "Installed", "version": "6.1.27"},
            {"name": "Sqlmap", "status": "Installed", "version": "1.6.4"},
            {"name": "Gobuster", "status": "Installed", "version": "3.1.0"},
            {"name": "Wireshark", "status": "Not Installed", "version": "N/A"},
            {"name": "Aircrack-ng", "status": "Not Installed", "version": "N/A"}
        ]
        
        tool_status_df = pd.DataFrame(tool_status)
        
        # Format the dataframe with colors
        def highlight_status(s):
            return ['background-color: #00FF00' if x == 'Installed' 
                    else 'background-color: #FF0000' if x == 'Not Installed'
                    else '' for x in s]
        
        styled_df = tool_status_df.style.apply(highlight_status, subset=['status'])
        
        st.dataframe(styled_df, use_container_width=True)
        
        # Tool installation
        st.markdown("### Install Security Tool")
        
        col1, col2 = st.columns([3, 1])
        
        with col1:
            tool_name = st.text_input("Tool Name", placeholder="Enter tool name")
        
        with col2:
            st.button("Install Tool", use_container_width=True)
    
    with tab2:
        st.markdown("### Execute Security Tool")
        
        # Tool selection
        tool = st.selectbox(
            "Select Tool",
            ["Nmap", "Metasploit", "Sqlmap", "Gobuster", "Wireshark", "Aircrack-ng"]
        )
        
        # Tool-specific parameters
        if tool == "Nmap":
            st.markdown("#### Nmap Parameters")
            
            col1, col2 = st.columns(2)
            
            with col1:
                target = st.text_input("Target", placeholder="IP, hostname, or network")
                scan_type = st.selectbox(
                    "Scan Type",
                    ["Basic", "SYN Scan", "Connect Scan", "Version Detection", "OS Detection", "Comprehensive"]
                )
            
            with col2:
                ports = st.text_input("Ports", placeholder="e.g., 22,80,443 or 1-1000")
                timing = st.slider("Timing Template", 0, 5, 3)
        
        elif tool == "Metasploit":
            st.markdown("#### Metasploit Parameters")
            
            col1, col2 = st.columns(2)
            
            with col1:
                module_type = st.selectbox(
                    "Module Type",
                    ["Exploit", "Auxiliary", "Post", "Payload"]
                )
                module_name = st.text_input("Module Name", placeholder="e.g., exploit/windows/smb/ms17_010_eternalblue")
            
            with col2:
                st.text_area("Options", placeholder="Enter options in format: key=value (one per line)")
                execute = st.checkbox("Execute Module", value=False)
        
        elif tool == "Sqlmap":
            st.markdown("#### Sqlmap Parameters")
            
            col1, col2 = st.columns(2)
            
            with col1:
                target_url = st.text_input("Target URL", placeholder="Enter URL with parameter")
                data = st.text_input("POST Data", placeholder="Enter POST data (optional)")
            
            with col2:
                level = st.slider("Detection Level", 1, 5, 1)
                risk = st.slider("Risk Level", 1, 3, 1)
        
        elif tool == "Gobuster":
            st.markdown("#### Gobuster Parameters")
            
            col1, col2 = st.columns(2)
            
            with col1:
                url = st.text_input("Target URL", placeholder="Enter base URL")
                wordlist = st.text_input("Wordlist", placeholder="Path to wordlist")
            
            with col2:
                extensions = st.text_input("Extensions", placeholder="e.g., php,html,txt")
                threads = st.slider("Threads", 1, 20, 10)
        
        # Execute button
        if st.button("Execute Tool", use_container_width=True):
            st.info(f"Executing {tool}...")
            
            with st.spinner("Running tool..."):
                # In a real implementation, this would call the Kali integrator
                # result = st.session_state.kali_integrator.execute_tool(tool, ...)
                
                # For now, show a placeholder
                st.success(f"{tool} execution complete")
                
                # Show fake results based on tool
                if tool == "Nmap":
                    st.code(f"""
Starting Nmap 7.92 ( https://nmap.org ) at 2023-05-07 12:00 UTC
Nmap scan report for {target}
Host is up (0.015s latency).
Not shown: 996 closed ports
PORT    STATE SERVICE
22/tcp  open  ssh
80/tcp  open  http
443/tcp open  https
8080/tcp open  http-proxy

Nmap done: 1 IP address (1 host up) scanned in 2.34 seconds
                    """)
                elif tool == "Metasploit":
                    st.code(f"""
msf6 > use {module_name}
msf6 exploit({module_name.split('/')[-1]}) > set RHOSTS 192.168.1.1
RHOSTS => 192.168.1.1
msf6 exploit({module_name.split('/')[-1]}) > exploit

[*] Started reverse TCP handler on 192.168.1.2:4444 
[*] 192.168.1.1:445 - Using auxiliary/scanner/smb/smb_ms17_010 as check
[+] 192.168.1.1:445       - Host is likely VULNERABLE to MS17-010! - Windows 7 Professional 7601 Service Pack 1 x64 (64-bit)
[*] 192.168.1.1:445       - Scanned 1 of 1 hosts (100% complete)
[*] 192.168.1.1:445 - Connecting to target for exploitation.
[+] 192.168.1.1:445 - Connection established for exploitation.
[+] 192.168.1.1:445 - Target OS selected valid for OS indicated by SMB reply
[*] 192.168.1.1:445 - CORE raw buffer dump (42 bytes)
[*] 192.168.1.1:445 - Sending the exploit payload
[+] 192.168.1.1:445 - Meterpreter session 1 opened (192.168.1.2:4444 -> 192.168.1.1:49163) at 2023-05-07 12:00:00 +0000

meterpreter > sysinfo
Computer        : WIN-ABCD1234
OS              : Windows 7 (6.1 Build 7601, Service Pack 1).
Architecture    : x64
System Language : en_US
Domain          : WORKGROUP
Logged On Users : 2
Meterpreter     : x64/windows
meterpreter >
                    """)
                elif tool == "Sqlmap":
                    st.code(f"""
sqlmap identified the following injection point(s) with a total of 58 HTTP(s) requests:
---
Parameter: id (GET)
    Type: boolean-based blind
    Title: AND boolean-based blind - WHERE or HAVING clause
    Payload: id=1 AND 3944=3944

    Type: time-based blind
    Title: MySQL >= 5.0.12 AND time-based blind
    Payload: id=1 AND SLEEP(5)

    Type: UNION query
    Title: Generic UNION query (NULL) - 3 columns
    Payload: id=1 UNION ALL SELECT NULL,NULL,CONCAT(0x716b767671,0x526b474c4e46446e6b44,0x7178707671)-- -
---
[12:00:00] [INFO] the back-end DBMS is MySQL
web application technology: PHP 7.4.3, Apache 2.4.41
back-end DBMS: MySQL >= 5.0.12
[12:00:01] [INFO] fetching database names
available databases [5]:
[*] information_schema
[*] mysql
[*] performance_schema
[*] sys
[*] testdb
                    """)
                elif tool == "Gobuster":
                    st.code(f"""
Gobuster v3.1.0
by OJ Reeves (@TheColonial) & Christian Mehlmauer (@firefart)
===============================================================
[+] Url:                     {url}
[+] Method:                  GET
[+] Threads:                 {threads}
[+] Wordlist:                {wordlist}
[+] Negative Status codes:   404
[+] User Agent:              gobuster/3.1.0
[+] Timeout:                 10s
===============================================================
2023/05/07 12:00:00 Starting gobuster in directory enumeration mode
===============================================================
/images               (Status: 301) [Size: 313] [--> {url}/images/]
/index.html           (Status: 200) [Size: 1337]
/js                   (Status: 301) [Size: 309] [--> {url}/js/]
/css                  (Status: 301) [Size: 310] [--> {url}/css/]
/admin                (Status: 301) [Size: 312] [--> {url}/admin/]
/login.php            (Status: 200) [Size: 1234]
/api                  (Status: 301) [Size: 310] [--> {url}/api/]
/config.php           (Status: 403) [Size: 1234]
/backup               (Status: 403) [Size: 1337]
===============================================================
2023/05/07 12:00:15 Finished
===============================================================
                    """)
    
    with tab3:
        st.markdown("### Tool Chains")
        
        # Predefined tool chain templates
        chain_template = st.selectbox(
            "Select Tool Chain Template",
            ["Select a template...", "Network Reconnaissance", "Web Application Scan", "Wireless Network Scan", "Custom Chain"]
        )
        
        if chain_template != "Select a template...":
            st.markdown(f"#### {chain_template} Configuration")
            
            if chain_template == "Network Reconnaissance":
                col1, col2 = st.columns(2)
                
                with col1:
                    targets = st.text_input("Targets", placeholder="IP range, e.g., 192.168.1.0/24")
                
                with col2:
                    open_ports = st.text_input("Open Ports", placeholder="Will be populated automatically")
            
            elif chain_template == "Web Application Scan":
                url = st.text_input("Target URL", placeholder="Enter the web application URL")
            
            elif chain_template == "Wireless Network Scan":
                interface = st.text_input("Wireless Interface", placeholder="e.g., wlan0")
            
            elif chain_template == "Custom Chain":
                st.markdown("#### Configure Custom Tool Chain")
                
                # Tool selection for each step
                st.markdown("##### Step 1")
                col1, col2 = st.columns(2)
                
                with col1:
                    tool1 = st.selectbox("Tool 1", ["Nmap", "Metasploit", "Sqlmap", "Gobuster", "Wireshark", "Aircrack-ng"])
                
                with col2:
                    action1 = st.text_input("Action 1", placeholder="e.g., scan, execute_module")
                
                st.text_area("Parameters 1", placeholder="Enter parameters in JSON format")
                
                st.markdown("##### Step 2")
                col1, col2 = st.columns(2)
                
                with col1:
                    tool2 = st.selectbox("Tool 2", ["None", "Nmap", "Metasploit", "Sqlmap", "Gobuster", "Wireshark", "Aircrack-ng"])
                
                with col2:
                    action2 = st.text_input("Action 2", placeholder="e.g., scan, execute_module")
                
                st.text_area("Parameters 2", placeholder="Enter parameters in JSON format")
                
                st.markdown("##### Step 3")
                col1, col2 = st.columns(2)
                
                with col1:
                    tool3 = st.selectbox("Tool 3", ["None", "Nmap", "Metasploit", "Sqlmap", "Gobuster", "Wireshark", "Aircrack-ng"])
                
                with col2:
                    action3 = st.text_input("Action 3", placeholder="e.g., scan, execute_module")
                
                st.text_area("Parameters 3", placeholder="Enter parameters in JSON format")
            
            # Execute chain button
            if st.button("Execute Chain", use_container_width=True):
                st.info(f"Executing {chain_template} Chain...")
                
                with st.spinner("Running tool chain..."):
                    # In a real implementation, this would call the Kali integrator
                    # chain_result = st.session_state.kali_integrator.run_chain_template(chain_template, ...)
                    
                    # For now, show a placeholder
                    st.success(f"{chain_template} execution complete")
                    
                    # Show a simple result
                    st.markdown("#### Chain Execution Results")
                    
                    st.markdown("""
                    * Step 1: ✅ Complete
                    * Step 2: ✅ Complete
                    * Step 3: ✅ Complete
                    """)
                    
                    st.markdown("#### Chain Summary")
                    
                    if chain_template == "Network Reconnaissance":
                        st.markdown("""
                        * 10 hosts discovered
                        * 25 open ports identified
                        * 12 services fingerprinted
                        * 3 operating systems detected
                        """)
                    elif chain_template == "Web Application Scan":
                        st.markdown("""
                        * 8 directories discovered
                        * 3 vulnerable parameters found
                        * 2 SQL injection points identified
                        * 1 XSS vulnerability detected
                        """)
                    elif chain_template == "Wireless Network Scan":
                        st.markdown("""
                        * 5 wireless networks discovered
                        * 3 with WPA/WPA2
                        * 1 with WEP
                        * 1 with no encryption
                        """)

# Reports view
def render_reports_view():
    """Render the Reports view"""
    st.markdown("## Intelligence Reports")
    
    # Create tabs for different report features
    tab1, tab2, tab3 = st.tabs(["Report Generator", "Report Templates", "Report Archive"])
    
    with tab1:
        st.markdown("### Generate Intelligence Report")
        
        col1, col2 = st.columns(2)
        
        with col1:
            report_title = st.text_input("Report Title", placeholder="Enter report title")
            report_type = st.selectbox(
                "Report Type",
                ["Executive", "Analyst", "Public"]
            )
        
        with col2:
            report_period = st.selectbox(
                "Report Period",
                ["Last 7 Days", "Last 30 Days", "Last 90 Days", "Custom"]
            )
            
            if report_period == "Custom":
                col2a, col2b = st.columns(2)
                
                with col2a:
                    start_date = st.date_input("Start Date", datetime.now() - timedelta(days=30))
                
                with col2b:
                    end_date = st.date_input("End Date", datetime.now())
        
        # Report content selection
        st.markdown("#### Report Content")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.checkbox("Include Cyber Threats", value=True)
            st.checkbox("Include Physical Threats", value=True)
        
        with col2:
            st.checkbox("Include Cartel Activity", value=True)
            st.checkbox("Include Geospatial Analysis", value=True)
        
        with col3:
            st.checkbox("Include Recommendations", value=True)
            st.checkbox("Include Technical Details", value=False)
        
        # Report format
        st.markdown("#### Report Format")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.radio("Format", ["HTML", "PDF", "Markdown", "JSON"])
        
        with col2:
            st.checkbox("Include Cover Page", value=True)
        
        with col3:
            st.checkbox("Include Executive Summary", value=True)
        
        with col4:
            st.checkbox("Include Visualizations", value=True)
        
        # Generate report button
        if st.button("Generate Report", use_container_width=True):
            if incident_reporter_available and hasattr(st.session_state, 'incident_reporter'):
                st.info("Generating report...")
                
                with st.spinner("Compiling report data..."):
                    # In a real implementation, this would call the incident reporter
                    # report = st.session_state.incident_reporter.generate_monthly_report(...)
                    
                    # For now, show a placeholder
                    time.sleep(2)  # Simulate processing time
                    st.success("Report generated successfully!")
                    
                    # Show a sample report preview
                    st.markdown("#### Report Preview")
                    
                    st.markdown(f"""
                    # {report_title or "Monthly Threat Intelligence Report"}
                    ## Executive Summary
                    
                    This report provides a comprehensive overview of security incidents and threat activities 
                    observed during the reporting period. It highlights key findings, emerging threats, and strategic recommendations.
                    
                    ### Key Statistics
                    
                    - Total Incidents: 42
                    - Critical Incidents: 8
                    - New Threat Actors: 3
                    - Most Affected Region: North America
                    
                    ### Significant Developments
                    
                    1. May 01, 2023 (CRITICAL): Data breach at financial institution
                       A sophisticated attack targeting a major financial institution resulted in the exposure of sensitive customer data...
                    
                    2. May 03, 2023 (HIGH): Ransomware campaign targeting healthcare
                       A coordinated ransomware campaign has been observed targeting healthcare providers...
                    
                    3. May 05, 2023 (CRITICAL): Supply chain disruption
                       A critical infrastructure supply chain was disrupted due to both cyber and physical attacks...
                    
                    ### Strategic Impact Assessment
                    
                    Based on the incidents observed during this period, the following strategic impacts were identified:
                    
                    - **Cyber Security Impacts**: 25 cyber incidents were recorded, indicating significant vulnerabilities in network security.
                    - **Physical Security Impacts**: 12 physical security incidents highlight the need for enhanced facility protection.
                    - **Cartel Activity Impacts**: 5 incidents related to cartel activities suggest continued influence in affected regions.
                    
                    ### Recommendations
                    
                    1. **Immediate Response**: Address critical vulnerabilities identified in the financial sector.
                    2. **Cyber Security Enhancement**: Strengthen cyber defenses based on the observed attack patterns.
                    3. **Physical Security Review**: Evaluate physical security measures, particularly in high-risk locations.
                    4. **Threat Actor Awareness**: Monitor newly identified threat actors who became active this month.
                    5. **Cross-Domain Protection**: Implement integrated security measures to address hybrid threats.
                    """)
                    
                    # Generate download link
                    download_button = st.download_button(
                        label="Download Report",
                        data="This would be the actual report content",
                        file_name=f"threat_report_{datetime.now().strftime('%Y%m%d')}.html",
                        mime="text/html"
                    )
            else:
                st.error("Incident Reporter module is required for report generation.")
    
    with tab2:
        st.markdown("### Report Templates")
        
        # Template selector
        template = st.selectbox(
            "Select Template",
            ["Executive Briefing", "Analyst Detailed Report", "Public Newsletter", "Custom Template"]
        )
        
        if template == "Custom Template":
            st.markdown("#### Create Custom Template")
            
            template_name = st.text_input("Template Name", placeholder="Enter template name")
            template_description = st.text_area("Description", placeholder="Enter template description")
            
            st.markdown("#### Template Sections")
            
            # Add sections
            for i in range(1, 4):  # Start with 3 sections
                st.markdown(f"##### Section {i}")
                col1, col2 = st.columns(2)
                
                with col1:
                    st.text_input(f"Section {i} Title", placeholder="Enter section title", key=f"section_{i}_title")
                
                with col2:
                    st.selectbox(f"Section {i} Type", ["Text", "Table", "Chart", "Map", "Timeline"], key=f"section_{i}_type")
                
                st.text_area(f"Section {i} Content", placeholder="Enter section content or template variables", key=f"section_{i}_content")
            
            # Add section button
            st.button("Add Section")
            
            # Save template button
            if st.button("Save Template", use_container_width=True):
                st.success(f"Template '{template_name}' saved successfully!")
        else:
            # Show template details
            if template == "Executive Briefing":
                st.markdown("""
                #### Executive Briefing Template
                
                **Description**: A concise report designed for senior leadership, focusing on strategic impact and recommendations.
                
                **Sections**:
                1. Executive Summary
                2. Key Statistics
                3. Significant Developments
                4. Strategic Impact Assessment
                5. Recommendations
                
                **Visualizations**:
                - Threat Map
                - Severity Breakdown
                - Trend Analysis
                """)
            elif template == "Analyst Detailed Report":
                st.markdown("""
                #### Analyst Detailed Report Template
                
                **Description**: A comprehensive report for security analysts with detailed technical information and analysis.
                
                **Sections**:
                1. Methodology
                2. Incident Summary
                3. Cyber Threat Analysis
                4. Physical Threat Analysis
                5. Cartel Activity Analysis
                6. Hybrid Threat Analysis
                7. Threat Actor Profiles
                8. Indicators of Compromise
                9. TTP Analysis
                10. Prediction & Future Outlook
                
                **Visualizations**:
                - Threat Map
                - Actor Network
                - TTP Heatmap
                - Temporal Analysis
                - Geographic Heatmap
                """)
            elif template == "Public Newsletter":
                st.markdown("""
                #### Public Newsletter Template
                
                **Description**: A sanitized report for public dissemination without sensitive details.
                
                **Sections**:
                1. Overview
                2. Global Security Landscape
                3. Notable Incidents
                4. Regional Focus
                5. Emerging Trends
                6. Security Best Practices
                
                **Visualizations**:
                - Public Incident Map
                - Trend Chart
                """)
            
            # Template actions
            col1, col2 = st.columns(2)
            
            with col1:
                st.button("Edit Template")
            
            with col2:
                st.button("Use Template")
    
    with tab3:
        st.markdown("### Report Archive")
        
        # Filter options
        col1, col2, col3 = st.columns(3)
        
        with col1:
            archive_report_type = st.selectbox(
                "Report Type",
                ["All Types", "Executive", "Analyst", "Public"]
            )
        
        with col2:
            archive_date_range = st.selectbox(
                "Date Range",
                ["All Time", "Last 30 Days", "Last 90 Days", "Last Year"]
            )
        
        with col3:
            archive_format = st.selectbox(
                "Format",
                ["All Formats", "HTML", "PDF", "Markdown", "JSON"]
            )
        
        # Sample archive data
        archive = [
            {"id": "RPT-12345", "title": "Monthly Threat Intelligence Report - April 2023", "type": "Executive", "date": "2023-05-01", "format": "PDF"},
            {"id": "RPT-12346", "title": "Comprehensive Security Analysis - Q1 2023", "type": "Analyst", "date": "2023-04-15", "format": "HTML"},
            {"id": "RPT-12347", "title": "Security Newsletter - April 2023", "type": "Public", "date": "2023-04-30", "format": "HTML"},
            {"id": "RPT-12348", "title": "Cyber Threat Landscape - April 2023", "type": "Analyst", "date": "2023-04-25", "format": "PDF"},
            {"id": "RPT-12349", "title": "Executive Briefing - Q1 2023", "type": "Executive", "date": "2023-04-10", "format": "PDF"}
        ]
        
        # Convert to DataFrame
        archive_df = pd.DataFrame(archive)
        
        # Display archive
        st.dataframe(archive_df, use_container_width=True)
        
        # Report actions
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.button("View Report")
        
        with col2:
            st.button("Download Report")
        
        with col3:
            st.button("Delete Report")

# OPSEC view
def render_opsec_view():
    """Render the OPSEC view"""
    st.markdown("## Operational Security")
    
    if not opsec_manager_available:
        st.warning("OPSEC Manager module not available. Please check if the module is properly installed.")
        return
    
    # Create tabs for different OPSEC features
    tab1, tab2, tab3 = st.tabs(["Profiles", "Security Status", "OPSEC Guidelines"])
    
    with tab1:
        st.markdown("### OPSEC Profiles")
        
        # Profile selector
        current_profile = st.selectbox(
            "Active Profile",
            ["Default Profile", "Anonymous Profile", "Field Operations"],
            key="opsec_profile_selector"
        )
        
        # Profile details
        if current_profile == "Default Profile":
            st.markdown("""
            #### Default Profile
            
            **Description**: Standard operational profile with basic security measures.
            
            **Browser Protection**: Medium
            * Randomized User-Agent
            * WebRTC Protection: Enabled
            * Canvas Fingerprinting Protection: Disabled
            
            **Network Protection**: Low
            * VPN: Disabled
            * Proxy: Disabled
            * DNS Protection: Enabled
            
            **Identity Protection**: Low
            * Browser History: Standard
            * Cookie Management: Standard
            * Tracking Protection: Basic
            """)
        elif current_profile == "Anonymous Profile":
            st.markdown("""
            #### Anonymous Profile
            
            **Description**: High-security profile designed for anonymous operations.
            
            **Browser Protection**: High
            * Randomized User-Agent: Enabled
            * WebRTC Protection: Enabled
            * Canvas Fingerprinting Protection: Enabled
            * Audio Fingerprinting Protection: Enabled
            
            **Network Protection**: High
            * VPN: Enabled
            * Proxy: Enabled
            * DNS Protection: Enabled
            * Traffic Obfuscation: Enabled
            
            **Identity Protection**: High
            * Browser History: Disabled
            * Cookie Management: Clear on Exit
            * Tracking Protection: Advanced
            * Session Management: Isolated
            """)
        elif current_profile == "Field Operations":
            st.markdown("""
            #### Field Operations
            
            **Description**: Specialized profile for mobile/field operations with reduced footprint.
            
            **Browser Protection**: Maximum
            * Randomized User-Agent: Enabled with Rotation
            * WebRTC Protection: Enabled
            * Canvas Fingerprinting Protection: Enabled
            * Hardware Fingerprinting Protection: Enabled
            
            **Network Protection**: Maximum
            * VPN: Multi-hop Enabled
            * Proxy: Rotating Proxies
            * DNS Protection: Encrypted DNS
            * Traffic Obfuscation: Advanced
            * Bandwidth Management: Enabled
            
            **Identity Protection**: Maximum
            * Browser History: Disabled
            * Cookie Management: Isolated Storage
            * Tracking Protection: Maximum
            * Session Management: One-time Sessions
            * Location Masking: Enabled
            """)
        
        # Edit profile
        st.markdown("### Profile Configuration")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.selectbox("Browser Fingerprint Protection", ["Off", "Basic", "Standard", "Maximum"])
            st.selectbox("Network Protection Level", ["Off", "Basic", "Standard", "Maximum"])
        
        with col2:
            st.selectbox("Identity Protection Level", ["Off", "Basic", "Standard", "Maximum"])
            st.selectbox("Anti-Detection Measures", ["Off", "Basic", "Standard", "Maximum"])
        
        st.markdown("### Advanced Settings")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.checkbox("Generate Random User-Agent")
            st.checkbox("Block WebRTC")
            st.checkbox("Add Canvas Noise")
        
        with col2:
            st.checkbox("Use VPN")
            st.checkbox("Use Proxy")
            st.checkbox("Use DNS Protection")
        
        with col3:
            st.checkbox("Clear History on Exit")
            st.checkbox("Block Trackers")
            st.checkbox("Isolate Sessions")
        
        # Save profile changes
        if st.button("Save Profile", use_container_width=True):
            st.success(f"Profile '{current_profile}' updated successfully!")
    
    with tab2:
        st.markdown("### Security Status Check")
        
        # Run security check button
        if st.button("Run Security Check", use_container_width=True):
            with st.spinner("Running security checks..."):
                # In a real implementation, this would call the OPSEC manager
                # status = st.session_state.opsec_manager.get_system_security_status()
                
                # For now, show a placeholder
                # Simulate processing time
                time.sleep(2)
                st.success("Security check complete")
                
                # Display security status
                st.markdown("#### System Security Status")
                
                # System info
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("""
                    **System**: Linux 5.15.0
                    **IP Address**: 203.0.113.42 (VPN)
                    **Browser**: Chrome 113.0.5672.92
                    """)
                
                with col2:
                    st.markdown("""
                    **DNS Servers**: 1.1.1.1, 8.8.8.8
                    **VPN Status**: Connected
                    **Proxy Status**: Active
                    """)
                
                # Security checks
                st.markdown("#### Security Checks")
                
                # WebRTC leak test
                st.markdown("""
                <div style="display: flex; margin-bottom: 10px;">
                    <div style="margin-right: 10px;"><span style="color: green; font-size: 20px;">✓</span></div>
                    <div>
                        <div style="font-weight: bold;">WebRTC Leak Test</div>
                        <div style="font-size: 0.9em;">No WebRTC leaks detected</div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                # DNS leak test
                st.markdown("""
                <div style="display: flex; margin-bottom: 10px;">
                    <div style="margin-right: 10px;"><span style="color: green; font-size: 20px;">✓</span></div>
                    <div>
                        <div style="font-weight: bold;">DNS Leak Test</div>
                        <div style="font-size: 0.9em;">No DNS leaks detected</div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                # Browser fingerprint test
                st.markdown("""
                <div style="display: flex; margin-bottom: 10px;">
                    <div style="margin-right: 10px;"><span style="color: yellow; font-size: 20px;">⚠</span></div>
                    <div>
                        <div style="font-weight: bold;">Browser Fingerprint Test</div>
                        <div style="font-size: 0.9em;">Your browser fingerprint is partially unique (Canvas fingerprinting detected)</div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                # Tracking protection test
                st.markdown("""
                <div style="display: flex; margin-bottom: 10px;">
                    <div style="margin-right: 10px;"><span style="color: green; font-size: 20px;">✓</span></div>
                    <div>
                        <div style="font-weight: bold;">Tracking Protection Test</div>
                        <div style="font-size: 0.9em;">Tracking protection is working correctly</div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                # JavaScript analysis
                st.markdown("""
                <div style="display: flex; margin-bottom: 10px;">
                    <div style="margin-right: 10px;"><span style="color: red; font-size: 20px;">✗</span></div>
                    <div>
                        <div style="font-weight: bold;">JavaScript Analysis</div>
                        <div style="font-size: 0.9em;">JavaScript is enabled and revealing system information</div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                # Cookie analysis
                st.markdown("""
                <div style="display: flex; margin-bottom: 10px;">
                    <div style="margin-right: 10px;"><span style="color: yellow; font-size: 20px;">⚠</span></div>
                    <div>
                        <div style="font-weight: bold;">Cookie Analysis</div>
                        <div style="font-size: 0.9em;">25 cookies detected, some are third-party tracking cookies</div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                # Security recommendations
                st.markdown("#### Security Recommendations")
                
                st.markdown("""
                1. **Enable Canvas Fingerprinting Protection**: Your current browser allows canvas fingerprinting.
                2. **Disable JavaScript**: Consider disabling JavaScript for sensitive operations.
                3. **Clear Browser Cookies**: Remove detected tracking cookies.
                4. **Update VPN Configuration**: Enable strict mode for additional protection.
                5. **Switch to Field Operations Profile**: For maximum protection during sensitive investigations.
                """)
    
    with tab3:
        st.markdown("### OPSEC Guidelines")
        
        st.markdown("""
        #### Operational Security Best Practices
        
        These guidelines are designed to minimize digital footprints and protect investigator identities during sensitive operations.
        
        **Browser Recommendations**:
        * Use a dedicated browser profile for each investigation
        * Disable JavaScript when possible
        * Use HTTPS-only mode
        * Disable browser fingerprinting
        * Clear cookies and cache between sessions
        
        **Network Recommendations**:
        * Use a VPN or Tor for sensitive investigations
        * Consider using a dedicated device on a separate network
        * Regularly change IP addresses during long investigations
        * Use time delays between requests to avoid detection
        
        **Operational Recommendations**:
        * Maintain separation between investigation personas
        * Never use personal accounts or identifiers
        * Document the investigation methodology
        * Use secure storage for findings
        * Be aware of legal and ethical boundaries
        
        **Tool Recommendations**:
        * Use virtual machines or containers for isolation
        * Consider using specialized OSINT frameworks
        * Maintain separate environments for different investigation types
        * Use encryption for storing investigation results
        """)
        
        # OPSEC resource links
        st.markdown("#### Additional Resources")
        
        st.markdown("""
        * [OPSEC Field Manual](https://example.com/opsec-manual)
        * [Digital Forensics Best Practices](https://example.com/digital-forensics)
        * [Advanced Browser Privacy Settings](https://example.com/browser-privacy)
        * [Network Traffic Analysis and Protection](https://example.com/network-protection)
        """)

# Main function
def main():
    """Main function to run the dashboard"""
    # Initialize components
    initialize_components()
    
    # Render header
    render_header()
    
    # Render sidebar
    render_sidebar()
    
    # Render the current view
    current_view = st.session_state.get('current_view', 'dashboard')
    if current_view == "dashboard":
        render_dashboard()
    elif current_view == "osint":
        render_osint_view()
    elif current_view == "incidents":
        render_incidents_view()
    # Threat Intelligence view has been moved to pages/threat_intel.py
    elif current_view == "threat_intel":
        st.markdown("""
        <div style="text-align: center; padding: 30px;">
            <h2>Threat Intelligence</h2>
            <p>Please use the Threat Intelligence link in the sidebar to access the full Threat Intelligence dashboard.</p>
            <a href="/threat_intel" target="_self">Go to Threat Intelligence Dashboard</a>
        </div>
        """, unsafe_allow_html=True)
    elif current_view == "data_sources":
        render_data_sources_view()
    elif current_view == "tools":
        render_tools_view()
    elif current_view == "reports":
        render_reports_view()
    elif current_view == "opsec":
        render_opsec_view()

if __name__ == "__main__":
    main()