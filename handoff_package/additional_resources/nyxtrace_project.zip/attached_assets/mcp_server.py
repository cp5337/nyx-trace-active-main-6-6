# USIM: MCP_CORE_0001
# UUID: CTAS_CORE_MCP_001
# Domain: Command and Control
# Description: Main MCP server that receives command instructions and coordinates CTAS modules
# Tags: [MCP, server, coordination, socket, CLI, USIM]
# Dependencies: socket, threading, json, uuid, mongo, neo4j, supabase

import asyncio
import json
import logging
import os
import uuid
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union

import httpx
from dotenv import load_dotenv
from fastapi import BackgroundTasks, FastAPI, HTTPException, Request, status
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel, ConfigDict, Field

# Load environment variables
load_dotenv()

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('mcp_server.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

app = FastAPI(title="MCP Server")

class LLMType(str, Enum):
    """LLM types supported by the MCP server"""
    GPT = "gpt"
    GROK = "grok"
    GEMINI = "gemini"
    LOCAL_LLM1 = "local_llm1"
    LOCAL_LLM2 = "local_llm2"
    NEURAL_NET = "neural_net"
    ANTHROPIC = "anthropic"

class LLMConfig(BaseModel):
    """Configuration for an LLM instance"""
    model_config = ConfigDict(use_enum_values=True)

    type: LLMType
    api_key: str = Field(..., description="API key for the LLM service")
    endpoint: str = Field(..., description="Endpoint URL for the LLM service")
    model: str = Field(..., description="Model identifier")
    temperature: float = Field(0.7, ge=0.0, le=1.0)
    max_tokens: int = Field(2048, gt=0)

class WorkflowStep(BaseModel):
    """A step in the agentic workflow"""
    model_config = ConfigDict(use_enum_values=True)

    step_id: str
    llm_type: LLMType
    prompt: str
    input_variables: List[str]
    output_variables: List[str]
    dependencies: List[str] = []

class Workflow(BaseModel):
    """A workflow definition"""
    model_config = ConfigDict(use_enum_values=True)

    workflow_id: Optional[str] = None
    name: str
    description: str
    steps: List[WorkflowStep]
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class MCPResponse(BaseModel):
    """Response from an LLM"""
    model_config = ConfigDict(use_enum_values=True)

    response_id: str
    llm_type: LLMType
    content: str
    metadata: Dict[str, Any]
    timestamp: datetime

class WorkflowExecuteRequest(BaseModel):
    """Request model for workflow execution"""
    workflow_id: str
    inputs: Dict[str, Any] = Field(default_factory=dict)

class WorkflowExecuteResponse(BaseModel):
    """Response model for workflow execution"""
    status: str
    message: str

# Global state
llm_configs: Dict[LLMType, LLMConfig] = {}
workflows: Dict[str, Workflow] = {}
responses: Dict[str, MCPResponse] = {}

@app.post("/llm/register")
async def register_llm(config: LLMConfig) -> Dict[str, Any]:
    """Register a new LLM configuration"""
    llm_configs[config.type] = config
    return {"status": "success", "message": f"LLM {config.type} registered"}

@app.post("/workflow/create")
async def create_workflow(workflow: Workflow) -> Dict[str, Any]:
    """Create a new workflow"""
    workflow.workflow_id = str(uuid.uuid4())
    workflow.created_at = datetime.utcnow()
    workflow.updated_at = workflow.created_at
    workflows[workflow.workflow_id] = workflow
    return {"status": "success", "workflow_id": workflow.workflow_id}

@app.post("/workflow/execute", response_model=WorkflowExecuteResponse)
async def execute_workflow(
    request: WorkflowExecuteRequest,
    background_tasks: BackgroundTasks
) -> WorkflowExecuteResponse:
    """Execute a workflow"""
    if request.workflow_id not in workflows:
        raise HTTPException(status_code=404, detail="Workflow not found")

    workflow = workflows[request.workflow_id]
    background_tasks.add_task(_execute_workflow_steps, workflow, request.inputs)

    return WorkflowExecuteResponse(
        status="accepted",
        message=f"Workflow {request.workflow_id} execution started"
    )

async def _execute_workflow_steps(workflow: Workflow, inputs: Dict[str, Any]) -> None:
    """Execute workflow steps in dependency order"""
    try:
        results = {}

        # Execute steps in dependency order
        for step in sorted(workflow.steps, key=lambda s: len(s.dependencies)):
            # Get input values
            step_inputs = {var: inputs.get(var) for var in step.input_variables}

            # Execute LLM call
            response = await _call_llm(step.llm_type, step.prompt, step_inputs)

            # Store response
            responses[response.response_id] = response

            # Update results
            for var in step.output_variables:
                results[var] = response.content

        # Update workflow status
        workflow.updated_at = datetime.utcnow()

    except Exception as e:
        logger.error(f"Error executing workflow {workflow.workflow_id}: {str(e)}")
        raise

async def _call_llm(llm_type: LLMType, prompt: str, inputs: Dict[str, Any]) -> MCPResponse:
    """Make a call to a specific LLM"""
    if llm_type not in llm_configs:
        raise HTTPException(status_code=404, detail=f"LLM {llm_type} not configured")

    config = llm_configs[llm_type]

    # Format prompt with inputs
    formatted_prompt = prompt.format(**inputs)

    # Make the API call using the registered configuration
    async with httpx.AsyncClient() as client:
        try:
            # Prepare request based on LLM type
            if llm_type == LLMType.GPT:
                headers = {"Authorization": f"Bearer {config.api_key}", "Content-Type": "application/json"}
                data = {
                    "model": config.model,
                    "messages": [{"role": "user", "content": formatted_prompt}],
                    "temperature": config.temperature,
                    "max_tokens": config.max_tokens
                }
                response = await client.post(config.endpoint, headers=headers, json=data)
            elif llm_type == LLMType.ANTHROPIC:
                headers = {
                    "x-api-key": config.api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json"
                }
                data = {
                    "model": config.model,
                    "messages": [{"role": "user", "content": formatted_prompt}],
                    "max_tokens": config.max_tokens,
                    "temperature": config.temperature
                }
                response = await client.post(config.endpoint, headers=headers, json=data)
            elif llm_type == LLMType.GEMINI:
                headers = {"Content-Type": "application/json"}
                data = {
                    "contents": [{"parts": [{"text": formatted_prompt}]}],
                    "generationConfig": {
                        "temperature": config.temperature,
                        "maxOutputTokens": config.max_tokens
                    }
                }
                params = {"key": config.api_key}
                response = await client.post(config.endpoint, headers=headers, params=params, json=data)
            elif llm_type == LLMType.GROK:
                headers = {"Authorization": f"Bearer {config.api_key}", "Content-Type": "application/json"}
                data = {
                    "model": config.model,
                    "messages": [{"role": "user", "content": formatted_prompt}],
                    "temperature": config.temperature,
                    "max_tokens": config.max_tokens
                }
                response = await client.post(config.endpoint, headers=headers, json=data)
            else:
                raise HTTPException(status_code=400, detail=f"Unsupported LLM type: {llm_type}")

            if response.status_code != 200:
                raise HTTPException(
                    status_code=response.status_code,
                    detail=f"LLM API error: {response.text}"
                )

            response_data = response.json()

            # Extract content based on LLM type
            content = ""
            if llm_type == LLMType.GPT:
                content = str(response_data["choices"][0]["message"]["content"])
            elif llm_type == LLMType.ANTHROPIC:
                if "content" in response_data and isinstance(response_data["content"], list):
                    content = str(response_data["content"][0].get("text", ""))
            elif llm_type == LLMType.GEMINI:
                content = str(response_data["candidates"][0]["content"]["parts"][0]["text"])
            elif llm_type == LLMType.GROK:
                content = str(response_data["choices"][0]["message"]["content"])

            return MCPResponse(
                response_id=str(uuid.uuid4()),
                llm_type=llm_type,
                content=content,
                metadata=response_data,
                timestamp=datetime.utcnow()
            )
        except Exception as e:
            logger.error(f"Error calling {llm_type}: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error calling {llm_type}: {str(e)}"
            )

@app.get("/workflow/{workflow_id}")
async def get_workflow(workflow_id: str) -> Workflow:
    """Get a workflow by ID"""
    if workflow_id not in workflows:
        raise HTTPException(status_code=404, detail="Workflow not found")
    return workflows[workflow_id]

@app.get("/response/{response_id}")
async def get_response(response_id: str) -> MCPResponse:
    """Get a response by ID"""
    if response_id not in responses:
        raise HTTPException(status_code=404, detail="Response not found")
    return responses[response_id]

@app.post("/n8n/trigger", response_model=Dict[str, Any])
async def n8n_trigger(request: Request, background_tasks: BackgroundTasks) -> Dict[str, Any]:
    payload = await request.json()
    command = payload.get("command")
    persona_id = payload.get("persona_id")
    provider = payload.get("provider")
    context = payload.get("context", {})
    entropy = context.get("entropy")
    ttl = context.get("ttl")

    if command != "run_persona" or not persona_id or not provider:
        return {"error": "Invalid payload", "status_code": 400}

    prompt = f"Persona {persona_id} (entropy={entropy}, ttl={ttl}): What is your next action?"

    async def call_model(provider_name: str) -> str:
        async with httpx.AsyncClient() as client:
            try:
                if provider_name == "openai":
                    openai_api_key = os.getenv("GPT_API_KEY")
                    openai_url = "https://api.openai.com/v1/chat/completions"
                    headers = {"Authorization": f"Bearer {openai_api_key}", "Content-Type": "application/json"}
                    data = {
                        "model": "gpt-4",
                        "messages": [{"role": "user", "content": prompt}],
                        "max_tokens": 256,
                        "temperature": 0.7
                    }
                    resp = await client.post(openai_url, headers=headers, json=data)
                    if resp.status_code == 200:
                        result = resp.json()
                        content: str = result["choices"][0]["message"]["content"]
                        return content
                    return f"OpenAI error: {resp.text}"
                elif provider_name == "anthropic":
                    anthropic_api_key = os.getenv("ANTHROPIC_API_KEY")
                    anthropic_url = "https://api.anthropic.com/v1/messages"
                    headers = {
                        "x-api-key": str(anthropic_api_key),
                        "anthropic-version": "2023-06-01",
                        "content-type": "application/json"
                    }
                    data = {
                        "model": "claude-3-opus-20240229",
                        "max_tokens": 256,
                        "temperature": 0.7,
                        "messages": [{"role": "user", "content": prompt}]
                    }
                    resp = await client.post(anthropic_url, headers=headers, json=data)
                    if resp.status_code == 200:
                        result = resp.json()
                        content = ""
                        if "content" in result and isinstance(result["content"], list) and result["content"]:
                            content = str(result["content"][0].get("text", ""))
                        return content
                    return f"Anthropic error: {resp.text}"
                elif provider_name == "grok":
                    grok_api_key = os.getenv("GROK_API_KEY")
                    grok_url = os.getenv("GROK_API_URL", "https://api.grok.x.ai/v1/chat/completions")
                    headers = {"Authorization": f"Bearer {grok_api_key}", "Content-Type": "application/json"}
                    data = {"model": "grok-1", "messages": [{"role": "user", "content": prompt}]}
                    resp = await client.post(grok_url, headers=headers, json=data)
                    if resp.status_code == 200:
                        result = resp.json()
                        content: str = result["choices"][0]["message"]["content"]
                        return content
                    return f"Grok error: {resp.text}"
                elif provider_name == "gemini":
                    gemini_api_key = os.getenv("GEMINI_API_KEY")
                    gemini_url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent"
                    headers = {"Content-Type": "application/json"}
                    data = {"contents": [{"parts": [{"text": prompt}]}]}
                    params = {"key": gemini_api_key}
                    resp = await client.post(gemini_url, headers=headers, params=params, json=data)
                    if resp.status_code == 200:
                        result = resp.json()
                        content: str = result["candidates"][0]["content"]["parts"][0]["text"]
                        return content
                    return f"Gemini error: {resp.text}"
                elif provider_name == "wolfram":
                    wolfram_appid = os.getenv("WOLFRAM_APPID")
                    from urllib.parse import quote
                    wolfram_url = f"https://api.wolframalpha.com/v1/result?i={quote(prompt)}&appid={wolfram_appid}"
                    resp = await client.get(wolfram_url)
                    if resp.status_code == 200:
                        return resp.text
                    return f"Wolfram error: {resp.text}"
                elif provider_name == "local_llm1":
                    endpoint = os.getenv("LOCAL_LLM1_ENDPOINT", "http://localhost:8001/generate")
                    resp = await client.post(endpoint, json={"prompt": prompt})
                    if resp.status_code == 200:
                        result = resp.json()
                        return result.get("result", "")
                    return f"Local LLM1 error: {resp.text}"
                elif provider_name == "local_llm2":
                    endpoint = os.getenv("LOCAL_LLM2_ENDPOINT", "http://localhost:8002/generate")
                    resp = await client.post(endpoint, json={"prompt": prompt})
                    if resp.status_code == 200:
                        result = resp.json()
                        return result.get("result", "")
                    return f"Local LLM2 error: {resp.text}"
                elif provider_name == "neural_net":
                    endpoint = os.getenv("NEURAL_NET_ENDPOINT", "http://localhost:8003/predict")
                    resp = await client.post(endpoint, json={"prompt": prompt})
                    if resp.status_code == 200:
                        result = resp.json()
                        return result.get("result", "")
                    return f"Neural Net error: {resp.text}"
                else:
                    return f"Unknown provider: {provider_name}"
            except Exception as e:
                return f"{provider_name} exception: {str(e)}"

    # If provider is 'all', broadcast to all supported models
    supported = [
        "openai", "anthropic", "grok", "gemini", "wolfram", "local_llm1", "local_llm2", "neural_net"
    ]
    if provider == "all":
        import asyncio
        results = await asyncio.gather(*(call_model(p) for p in supported))
        response_map = {p: r for p, r in zip(supported, results)}
        return {
            "persona": persona_id,
            "responses": response_map,
            "prompt": prompt
        }
    else:
        result = await call_model(provider)
        return {
            "persona": persona_id,
            "response": result,
            "prompt": prompt
        }

@app.get("/", response_class=HTMLResponse)
async def landing_page() -> HTMLResponse:
    html_content = """
    <html>
    <head>
        <title>CTAS MCP Server</title>
        <style>
            body { font-family: Arial, sans-serif; background: #181c20; color: #e0e0e0; margin: 0; padding: 0; }
            .container { max-width: 700px; margin: 40px auto; background: #23272b; border-radius: 10px; padding: 32px; box-shadow: 0 2px 12px #0008; }
            h1 { color: #7ecfff; }
            code { background: #222; color: #7ecfff; padding: 2px 6px; border-radius: 4px; }
            a { color: #7ecfff; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>CTAS v6.5.1 MCP Server</h1>
            <p>Welcome to the <b>Model Context Protocol (MCP)</b> server for CTAS.<br>
            This service orchestrates multi-model AI/LLM workflows and agentic automation.</p>
            <h2>Key Endpoints</h2>
            <ul>
                <li><code>POST /n8n/trigger</code> &mdash; Orchestrate persona/model actions (see <a href="/docs">/docs</a> for schema)</li>
                <li><code>POST /llm/register</code> &mdash; Register a new LLM</li>
                <li><code>POST /workflow/create</code> &mdash; Create a workflow</li>
                <li><code>POST /workflow/execute</code> &mdash; Execute a workflow</li>
            </ul>
            <h2>Example: Run Persona</h2>
            <pre>
POST /n8n/trigger
{
  "command": "run_persona",
  "persona_id": "D6.3",
  "provider": "all",
  "context": { "entropy": 0.78, "ttl": 3600 }
}
            </pre>
            <h2>API Docs</h2>
            <ul>
                <li><a href="/docs">Swagger UI</a></li>
                <li><a href="/redoc">ReDoc</a></li>
            </ul>
            <p style="margin-top:2em;font-size:0.9em;color:#888;">&copy; 2024 CTAS Research. All rights reserved.</p>
        </div>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=18000, log_level="info")
