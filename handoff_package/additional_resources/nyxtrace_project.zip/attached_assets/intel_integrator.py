import json
from pathlib import Path
from typing import Dict, List, Any, Optional
import logging
from datetime import datetime
import requests
from dataclasses import dataclass, field
import hashlib
import os
from enum import Enum

class IntelSource(Enum):
    MISP = "misp"
    ALIENVAULT = "alienvault"
    ATTCK = "attck"
    ATOMIC = "atomic"
    CALDERA = "caldera"
    EXPLOITDB = "exploitdb"

@dataclass
class IntelUpdate:
    source: IntelSource
    timestamp: datetime
    data: Dict[str, Any]
    hash: str = field(default_factory=lambda: hashlib.sha256(str(datetime.utcnow()).encode()).hexdigest())

@dataclass
class ToolReference:
    tool_id: str
    intel_id: str
    source: IntelSource
    confidence: float
    last_seen: datetime = field(default_factory=datetime.utcnow)
    references: List[str] = field(default_factory=list)

class IntelIntegrator:
    """Integrates multiple threat intel sources and tool databases"""
    
    def __init__(self, config_path: str = "config/intel_config.json"):
        self.logger = logging.getLogger(__name__)
        self.config = self._load_config(config_path)
        self.base_dir = Path("intel_data")
        self.base_dir.mkdir(exist_ok=True)
        
        # Create directories for each source
        for source in IntelSource:
            (self.base_dir / source.value).mkdir(exist_ok=True)
            
        self.updates: Dict[str, IntelUpdate] = {}
        self.tool_references: Dict[str, List[ToolReference]] = {}
        
    def update_all(self) -> Dict[str, Any]:
        """Update intel from all sources"""
        results = {
            "total_updates": 0,
            "sources": {},
            "errors": []
        }
        
        for source in IntelSource:
            try:
                update_result = self._update_source(source)
                results["sources"][source.value] = update_result
                results["total_updates"] += update_result.get("updates", 0)
            except Exception as e:
                error_msg = f"Error updating {source.value}: {str(e)}"
                self.logger.error(error_msg)
                results["errors"].append(error_msg)
                
        return results
        
    def _update_source(self, source: IntelSource) -> Dict[str, Any]:
        """Update intel from a specific source"""
        if source == IntelSource.MISP:
            return self._update_misp()
        elif source == IntelSource.ALIENVAULT:
            return self._update_alienvault()
        elif source == IntelSource.ATTCK:
            return self._update_attck()
        elif source == IntelSource.ATOMIC:
            return self._update_atomic()
        elif source == IntelSource.CALDERA:
            return self._update_caldera()
        elif source == IntelSource.EXPLOITDB:
            return self._update_exploitdb()
        else:
            raise ValueError(f"Unknown source: {source}")
            
    def _update_misp(self) -> Dict[str, Any]:
        """Update from MISP"""
        try:
            api_key = self.config["misp"]["api_key"]
            url = self.config["misp"]["url"]
            
            headers = {
                "Authorization": api_key,
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
            
            # Get recent events
            response = requests.get(f"{url}/events/index/last:50", headers=headers, verify=False)
            events = response.json()
            
            # Process and store events
            update = IntelUpdate(
                source=IntelSource.MISP,
                timestamp=datetime.utcnow(),
                data=events
            )
            
            self._save_update(update)
            self._process_misp_events(events)
            
            return {
                "updates": len(events),
                "timestamp": update.timestamp.isoformat()
            }
            
        except Exception as e:
            raise Exception(f"MISP update failed: {str(e)}")
            
    def _update_alienvault(self) -> Dict[str, Any]:
        """Update from AlienVault OTX"""
        try:
            api_key = self.config["alienvault"]["api_key"]
            url = "https://otx.alienvault.com/api/v1"
            
            headers = {
                "X-OTX-API-KEY": api_key,
                "Accept": "application/json"
            }
            
            # Get recent pulses
            response = requests.get(f"{url}/pulses/subscribed", headers=headers)
            pulses = response.json()
            
            # Process and store pulses
            update = IntelUpdate(
                source=IntelSource.ALIENVAULT,
                timestamp=datetime.utcnow(),
                data=pulses
            )
            
            self._save_update(update)
            self._process_alienvault_pulses(pulses)
            
            return {
                "updates": len(pulses.get("results", [])),
                "timestamp": update.timestamp.isoformat()
            }
            
        except Exception as e:
            raise Exception(f"AlienVault update failed: {str(e)}")
            
    def _update_attck(self) -> Dict[str, Any]:
        """Update from MITRE ATT&CK"""
        try:
            url = "https://raw.githubusercontent.com/mitre/cti/master/enterprise-attack/enterprise-attack.json"
            response = requests.get(url)
            attck_data = response.json()
            
            update = IntelUpdate(
                source=IntelSource.ATTCK,
                timestamp=datetime.utcnow(),
                data=attck_data
            )
            
            self._save_update(update)
            self._process_attck_data(attck_data)
            
            return {
                "updates": len(attck_data.get("objects", [])),
                "timestamp": update.timestamp.isoformat()
            }
            
        except Exception as e:
            raise Exception(f"ATT&CK update failed: {str(e)}")
            
    def _update_atomic(self) -> Dict[str, Any]:
        """Update from Atomic Red Team"""
        try:
            url = "https://raw.githubusercontent.com/redcanaryco/atomic-red-team/master/atomics"
            response = requests.get(f"{url}/index.yaml")
            index = response.text
            
            atomic_data = {
                "index": index,
                "tests": {}
            }
            
            # Get individual test files
            for line in index.split("\n"):
                if line.strip().startswith("- "):
                    test_path = line.strip()[2:]
                    test_url = f"{url}/{test_path}"
                    test_response = requests.get(test_url)
                    atomic_data["tests"][test_path] = test_response.text
                    
            update = IntelUpdate(
                source=IntelSource.ATOMIC,
                timestamp=datetime.utcnow(),
                data=atomic_data
            )
            
            self._save_update(update)
            self._process_atomic_data(atomic_data)
            
            return {
                "updates": len(atomic_data["tests"]),
                "timestamp": update.timestamp.isoformat()
            }
            
        except Exception as e:
            raise Exception(f"Atomic Red Team update failed: {str(e)}")
            
    def _update_caldera(self) -> Dict[str, Any]:
        """Update from CALDERA"""
        try:
            api_key = self.config["caldera"]["api_key"]
            url = self.config["caldera"]["url"]
            
            headers = {
                "KEY": api_key,
                "Accept": "application/json"
            }
            
            # Get abilities and adversaries
            abilities = requests.get(f"{url}/api/v2/abilities", headers=headers).json()
            adversaries = requests.get(f"{url}/api/v2/adversaries", headers=headers).json()
            
            caldera_data = {
                "abilities": abilities,
                "adversaries": adversaries
            }
            
            update = IntelUpdate(
                source=IntelSource.CALDERA,
                timestamp=datetime.utcnow(),
                data=caldera_data
            )
            
            self._save_update(update)
            self._process_caldera_data(caldera_data)
            
            return {
                "updates": len(abilities) + len(adversaries),
                "timestamp": update.timestamp.isoformat()
            }
            
        except Exception as e:
            raise Exception(f"CALDERA update failed: {str(e)}")
            
    def _update_exploitdb(self) -> Dict[str, Any]:
        """Update from Exploit-DB"""
        try:
            url = "https://raw.githubusercontent.com/offensive-security/exploitdb/master/files_exploits.csv"
            response = requests.get(url)
            exploits_data = response.text
            
            update = IntelUpdate(
                source=IntelSource.EXPLOITDB,
                timestamp=datetime.utcnow(),
                data={"exploits": exploits_data}
            )
            
            self._save_update(update)
            self._process_exploitdb_data(exploits_data)
            
            return {
                "updates": len(exploits_data.split("\n")) - 1,  # Subtract header
                "timestamp": update.timestamp.isoformat()
            }
            
        except Exception as e:
            raise Exception(f"Exploit-DB update failed: {str(e)}")
            
    def _process_misp_events(self, events: Dict[str, Any]) -> None:
        """Process MISP events and link to tools"""
        for event in events:
            # Look for tool references in attributes
            for attribute in event.get("Attribute", []):
                if attribute["type"] in ["filename", "md5", "sha1", "sha256"]:
                    self._add_tool_reference(
                        tool_id=attribute["value"],
                        intel_id=event["uuid"],
                        source=IntelSource.MISP,
                        confidence=0.8
                    )
                    
    def _process_alienvault_pulses(self, pulses: Dict[str, Any]) -> None:
        """Process AlienVault pulses and link to tools"""
        for pulse in pulses.get("results", []):
            # Look for tool references in indicators
            for indicator in pulse.get("indicators", []):
                if indicator["type"] in ["file", "hash"]:
                    self._add_tool_reference(
                        tool_id=indicator["indicator"],
                        intel_id=pulse["id"],
                        source=IntelSource.ALIENVAULT,
                        confidence=0.7
                    )
                    
    def _process_attck_data(self, attck_data: Dict[str, Any]) -> None:
        """Process ATT&CK data and link to tools"""
        for obj in attck_data.get("objects", []):
            if obj["type"] == "tool":
                self._add_tool_reference(
                    tool_id=obj["name"],
                    intel_id=obj["id"],
                    source=IntelSource.ATTCK,
                    confidence=1.0
                )
                
    def _process_atomic_data(self, atomic_data: Dict[str, Any]) -> None:
        """Process Atomic Red Team data and link to tools"""
        for test_path, test_content in atomic_data["tests"].items():
            # Extract tool references from test content
            if "executor" in test_content:
                self._add_tool_reference(
                    tool_id=test_path,
                    intel_id=test_path,
                    source=IntelSource.ATOMIC,
                    confidence=0.9
                )
                
    def _process_caldera_data(self, caldera_data: Dict[str, Any]) -> None:
        """Process CALDERA data and link to tools"""
        for ability in caldera_data["abilities"]:
            self._add_tool_reference(
                tool_id=ability["name"],
                intel_id=ability["ability_id"],
                source=IntelSource.CALDERA,
                confidence=0.9
            )
            
    def _process_exploitdb_data(self, exploits_data: str) -> None:
        """Process Exploit-DB data and link to tools"""
        for line in exploits_data.split("\n")[1:]:  # Skip header
            if line:
                fields = line.split(",")
                self._add_tool_reference(
                    tool_id=fields[2],  # Description field
                    intel_id=fields[0],  # EDB-ID
                    source=IntelSource.EXPLOITDB,
                    confidence=0.8
                )
                
    def _add_tool_reference(self, tool_id: str, intel_id: str, source: IntelSource, confidence: float) -> None:
        """Add a reference between a tool and intel"""
        if tool_id not in self.tool_references:
            self.tool_references[tool_id] = []
            
        reference = ToolReference(
            tool_id=tool_id,
            intel_id=intel_id,
            source=source,
            confidence=confidence
        )
        
        self.tool_references[tool_id].append(reference)
        
    def _save_update(self, update: IntelUpdate) -> None:
        """Save an intel update"""
        update_file = self.base_dir / update.source.value / f"{update.hash}.json"
        with open(update_file, 'w') as f:
            json.dump(update.__dict__, f, indent=2, default=str)
            
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration"""
        if not os.path.exists(config_path):
            config = {
                "misp": {
                    "url": "https://your-misp-instance",
                    "api_key": "your-api-key"
                },
                "alienvault": {
                    "api_key": "your-api-key"
                },
                "caldera": {
                    "url": "https://your-caldera-instance",
                    "api_key": "your-api-key"
                }
            }
            
            os.makedirs(os.path.dirname(config_path), exist_ok=True)
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=2)
                
        with open(config_path) as f:
            return json.load(f)
            
    def export_intel_data(self) -> Dict[str, Any]:
        """Export all intel data"""
        return {
            "updates": {
                update.hash: update.__dict__
                for update in self.updates.values()
            },
            "tool_references": {
                tool_id: [ref.__dict__ for ref in refs]
                for tool_id, refs in self.tool_references.items()
            }
        }

def main():
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    try:
        # Initialize integrator
        integrator = IntelIntegrator()
        
        # Update all sources
        results = integrator.update_all()
        
        # Log results
        logger.info(f"Total updates: {results['total_updates']}")
        for source, result in results["sources"].items():
            logger.info(f"{source}: {result['updates']} updates")
            
        if results["errors"]:
            logger.warning("Errors occurred:")
            for error in results["errors"]:
                logger.error(error)
                
        # Export data
        intel_data = integrator.export_intel_data()
        output_file = Path("intel_export.json")
        with open(output_file, 'w') as f:
            json.dump(intel_data, f, indent=2, default=str)
            
        logger.info(f"Intel data exported to {output_file}")
        
    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
        raise

if __name__ == "__main__":
    main() 