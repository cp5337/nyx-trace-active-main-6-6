"""
Author: Charlie Payne
Date: February 17, 2025
Description: OSINT investigation script to analyze Instagram metadata, check email breaches,
trace IPs, analyze email headers, scan attachments, and gather intelligence on potential threats.
"""

import os
import subprocess
import requests

# ========== FUNCTION DEFINITIONS ==========

def run_command(command):
    """
    Executes a shell command and captures the output.
    Handles execution errors gracefully.
    """
    try:
        result = subprocess.run(command, shell=True, check=True, text=True, capture_output=True)
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        print(f"[!] Error executing {command}: {e.stderr}")

def extract_instagram_metadata(instagram_handle):
    """
    Extract public metadata from an Instagram profile using Instaloader.
    Note: Requires authentication to bypass restrictions.
    """
    print("[*] Extracting Instagram metadata...")
    run_command(f"instaloader --no-pictures --no-videos --no-compress-json --login your_username {instagram_handle}")

def search_email_from_username(instagram_handle):
    """
    Identify potential email addresses linked to the Instagram handle.
    Uses TheHarvester for intelligence gathering.
    """
    print("[*] Searching for email addresses associated with the username...")
    run_command(f"theHarvester -d {instagram_handle} -b all")

def check_breaches(email_address):
    """
    Check if the email appears in any known data breaches.
    Uses h8mail for breach lookups.
    """
    print("[*] Checking data breaches for the email...")
    run_command(f"h8mail -t {email_address}")

def whois_lookup(email_domain):
    """
    Perform a WHOIS lookup on the email domain to gather domain registration details.
    Uses Recon-NG.
    """
    print("[*] Performing WHOIS lookup on the email domain...")
    run_command(f"recon-ng -m recon/domains-contacts/whois_pocs -o SOURCE={email_domain}")

def trace_ip(email_domain):
    """
    Perform IP tracing on the email sender's domain to identify its origin.
    Uses traceroute for network path analysis.
    """
    print("[*] Tracing the sender's IP...")
    run_command(f"traceroute {email_domain}")

def analyze_email_headers(email_address):
    """
    Analyze email headers to extract sender IP and authentication details.
    Uses Spooftooph (for Bluetooth spoofing analysis).
    """
    print("[*] Analyzing email headers...")
    run_command(f"spooftooph -i {email_address}")

def scan_attachment(attachment_path, virustotal_api_key):
    """
    Upload and scan a suspicious email attachment using the VirusTotal API.
    Requires a valid API key.
    """
    print("[*] Scanning email attachment with VirusTotal...")
    
    if not os.path.exists(attachment_path):
        print("[!] Attachment file not found. Skipping scan.")
        return
    
    files = {'file': (attachment_path, open(attachment_path, 'rb'))}
    headers = {'x-apikey': virustotal_api_key}
    
    response = requests.post("https://www.virustotal.com/api/v3/files", files=files, headers=headers)
    
    if response.status_code == 200:
        print("[*] Attachment scan submitted successfully.")
        print(response.json())
    else:
        print("[!] Failed to scan attachment. Check API key or file format.")

def check_suspicious_url(suspicious_url):
    """
    Check if a suspicious URL is linked to phishing campaigns.
    Uses urlcrazy to generate and check for typo-squatted domains.
    """
    print("[*] Checking phishing URL reputation...")
    run_command(f"urlcrazy {suspicious_url}")

def nmap_scan(email_domain):
    """
    Scan the sender's email server for open ports and vulnerabilities.
    Uses Nmap to check mail server security.
    """
    print("[*] Scanning email server with Nmap...")
    run_command(f"nmap -p 25,110,143,465,587,993,995 {email_domain}")

def find_other_accounts(instagram_handle):
    """
    Search for other online accounts linked to the Instagram handle.
    Uses Sherlock and Maigret for username enumeration across platforms.
    """
    print("[*] Searching for other accounts using the Instagram handle...")
    run_command(f"sherlock {instagram_handle}")
    run_command(f"maigret {instagram_handle}")

def extract_exif(attachment_path):
    """
    Extract EXIF metadata from profile pictures or attached files.
    Useful for retrieving geolocation and camera details.
    """
    print("[*] Extracting metadata from profile pictures or attachments...")
    run_command(f"exiftool profile_pic.jpg")
    run_command(f"exiftool {attachment_path}")

# ========== EXECUTE THE WORKFLOW ==========

if __name__ == "__main__":
    print("========== Starting OSINT Investigation ==========")
    
    # Prompt user for required inputs
    instagram_handle = input("Enter Instagram handle: ")
    email_address = input("Enter email address: ")
    email_domain = email_address.split("@")[-1]
    suspicious_url = input("Enter suspicious URL (if any, otherwise press enter): ")
    attachment_path = input("Enter path to attachment file (if any, otherwise press enter): ")
    virustotal_api_key = input("Enter VirusTotal API key: ")
    
    extract_instagram_metadata(instagram_handle)
    search_email_from_username(instagram_handle)
    check_breaches(email_address)
    whois_lookup(email_domain)
    trace_ip(email_domain)
    analyze_email_headers(email_address)
    
    if attachment_path:
        scan_attachment(attachment_path, virustotal_api_key)
    
    if suspicious_url:
        check_suspicious_url(suspicious_url)
    
    nmap_scan(email_domain)
    find_other_accounts(instagram_handle)
    
    if attachment_path:
        extract_exif(attachment_path)
    
    print("========== Investigation Complete ==========")
