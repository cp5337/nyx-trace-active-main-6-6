# Vercel Development Task: Progressive Web Application for NyxTrace

## Project Context
I'm developing "NyxTrace," an advanced geospatial intelligence platform for tracking convergent threats across physical, cyber, and cartel domains. The platform combines OSINT capabilities with interactive visualization to provide comprehensive threat intelligence.

The system follows the "Hunt, Detect, Disrupt, Disable, Dominate" framework derived from FIVE EYES intelligence operations and monitors critical infrastructure across multiple sectors including agriculture/food, chemical, communications, energy, healthcare, and more.

I need to transform the current Streamlit-based application into a full-featured Progressive Web Application (PWA) that can work offline, provide a native-like experience, and be accessible across various devices—all while maintaining the highest security standards.

## Development Request
Please develop a Progressive Web Application framework for the NyxTrace platform with the following capabilities:

### 1. Offline-First Architecture
- Create a service worker implementation for offline capabilities
- Develop offline data sync mechanisms with conflict resolution
- Implement local database storage for offline operation
- Create intelligent caching strategies for different data types
- Develop background sync for queued operations
- Implement bandwidth-aware resource loading
- Create versioned API contracts for frontend-backend compatibility

### 2. Secure Local Storage
- Implement encrypted local storage for sensitive intelligence data
- Create key management for local encryption
- Develop secure indexing for efficient querying of encrypted data
- Implement secure cache invalidation strategies
- Create secure backup and recovery mechanisms
- Develop tamper-evident storage
- Implement secure garbage collection for sensitive data

### 3. Responsive UI Framework
- Create adaptive layouts for different screen sizes and orientations
- Implement touch-optimized controls for mobile devices
- Develop dark mode with high-contrast options for field use
- Create responsive data visualizations that scale appropriately
- Implement progressive loading for large datasets
- Develop optimal rendering strategies for different devices
- Create high-DPI support for detailed visualizations

### 4. Advanced PWA Features
- Implement app installation flow with homescreen icon
- Create push notification infrastructure for alerts
- Develop native sharing capabilities for reports
- Implement background processing for intensive tasks
- Create app update mechanisms with versioning
- Develop deep linking support for specific views
- Implement web bluetooth/USB for optional hardware integration

### 5. Security Enhancements
- Create a secure authentication system with biometric options
- Implement secure storage of authentication tokens
- Develop screen security features (blur when inactive, etc.)
- Create clipboard security controls
- Implement secure screenshot prevention
- Develop secure export controls for data
- Create automatic session termination based on inactivity

## Technical Requirements
- Ensure the PWA works on modern browsers (Chrome, Firefox, Safari, Edge)
- Implement secure coding practices throughout the application
- Create comprehensive error handling for all operations
- Develop performance monitoring and optimization
- Ensure accessibility compliance (WCAG 2.1 AA)
- Create smooth transitions and animations for UI elements
- Implement proper logging and telemetry
- Create a comprehensive test suite for all features

## Architecture Diagram
Please provide a detailed architecture diagram showing:
- Client-side data flow and storage
- Service worker architecture
- Offline synchronization mechanisms
- Authentication and security flow
- Component hierarchy and communication
- Integration with backend services

## Browser Support and Fallbacks
The PWA should target these browsers with appropriate fallbacks:
- Chrome 80+
- Firefox 76+
- Safari 13.1+
- Edge 80+

For older browsers, provide graceful degradation strategies that maintain core functionality.

## Example Implementation
Here's an example of how the service worker implementation might look:

```javascript
// service-worker.js
import { precacheAndRoute } from 'workbox-precaching';
import { registerRoute } from 'workbox-routing';
import { StaleWhileRevalidate, CacheFirst, NetworkFirst } from 'workbox-strategies';
import { ExpirationPlugin } from 'workbox-expiration';
import { CacheableResponsePlugin } from 'workbox-cacheable-response';
import { BackgroundSyncPlugin } from 'workbox-background-sync';
import { openDB } from 'idb';
import { decrypt, encrypt } from './encryption';

// Precache static assets during installation
precacheAndRoute(self.__WB_MANIFEST);

// Initialize IndexedDB for secure data storage
async function initSecureDB() {
  return openDB('nyxtrace-secure-db', 1, {
    upgrade(db) {
      // Create stores for different data types
      const incidentStore = db.createObjectStore('incidents', { keyPath: 'id' });
      incidentStore.createIndex('by-date', 'incident_date');
      incidentStore.createIndex('by-type', 'incident_type');
      
      const osintStore = db.createObjectStore('osint', { keyPath: 'id' });
      osintStore.createIndex('by-date', 'timestamp');
      osintStore.createIndex('by-source', 'source_id');
      
      const encryptedStore = db.createObjectStore('encrypted', { keyPath: 'id' });
      
      // Store for operations that need to be synced when back online
      db.createObjectStore('outbox', { autoIncrement: true });
    }
  });
}

// Initialize DB on activation
self.addEventListener('activate', event => {
  event.waitUntil(initSecureDB());
  
  // Clean up old caches
  event.waitUntil(
    caches.keys()
      .then(cacheNames => {
        return Promise.all(
          cacheNames
            .filter(cacheName => cacheName.startsWith('nyxtrace-') && cacheName !== 'nyxtrace-v1')
            .map(cacheName => caches.delete(cacheName))
        );
      })
  );
  
  // Ensure service worker takes control immediately
  self.clients.claim();
});

// Background sync plugin for offline operations
const bgSyncPlugin = new BackgroundSyncPlugin('nyxtrace-outbox', {
  maxRetentionTime: 24 * 60, // Retry for up to 24 hours (in minutes)
  onSync: async ({queue}) => {
    let entry;
    while ((entry = await queue.shiftRequest())) {
      try {
        const request = entry.request;
        const response = await fetch(request);
        
        if (!response.ok) {
          throw new Error(`Request failed with status ${response.status}`);
        }
        
        const responseData = await response.json();
        
        // Handle successful sync
        const client = await self.clients.get(entry.metadata.clientId);
        if (client) {
          client.postMessage({
            type: 'BACKGROUND_SYNC_COMPLETE',
            payload: {
              operationId: entry.metadata.operationId,
              result: responseData
            }
          });
        }
        
      } catch (err) {
        console.error('Sync failed:', err);
        throw err; // Ensure the entry gets put back in the queue
      }
    }
  }
});

// Cache strategies for different types of resources

// Static assets (images, CSS, JS)
registerRoute(
  ({ request }) => request.destination === 'style' || 
                   request.destination === 'script' ||
                   request.destination === 'image',
  new CacheFirst({
    cacheName: 'nyxtrace-static',
    plugins: [
      new CacheableResponsePlugin({
        statuses: [0, 200]
      }),
      new ExpirationPlugin({
        maxEntries: 100,
        maxAgeSeconds: 30 * 24 * 60 * 60, // 30 days
        purgeOnQuotaError: true
      })
    ]
  })
);

// API responses (threat intelligence data)
registerRoute(
  ({ url }) => url.pathname.startsWith('/api/data'),
  new NetworkFirst({
    cacheName: 'nyxtrace-api-data',
    plugins: [
      new CacheableResponsePlugin({
        statuses: [0, 200]
      }),
      new ExpirationPlugin({
        maxEntries: 50,
        maxAgeSeconds: 60 * 60, // 1 hour
        purgeOnQuotaError: true
      })
    ]
  })
);

// Map tiles with longer cache
registerRoute(
  ({ url }) => url.pathname.includes('/map-tiles/'),
  new StaleWhileRevalidate({
    cacheName: 'nyxtrace-map-tiles',
    plugins: [
      new CacheableResponsePlugin({
        statuses: [0, 200]
      }),
      new ExpirationPlugin({
        maxEntries: 200,
        maxAgeSeconds: 7 * 24 * 60 * 60, // 7 days
        purgeOnQuotaError: true
      })
    ]
  })
);

// Handle API write operations with background sync
registerRoute(
  ({ url }) => url.pathname.startsWith('/api/') && 
              (request.method === 'POST' || request.method === 'PUT' || request.method === 'DELETE'),
  async ({ request, event }) => {
    try {
      // Try to send the request normally
      const response = await fetch(request.clone());
      return response;
    } catch (err) {
      // If offline, queue the request
      const clientId = event.clientId;
      const operationId = Date.now().toString();
      
      await bgSyncPlugin.queue.pushRequest({
        request: request.clone(),
        metadata: { clientId, operationId }
      });
      
      // Return a synthetic response
      return new Response(JSON.stringify({
        status: 'queued',
        operationId,
        timestamp: new Date().toISOString(),
        message: 'Operation queued for background sync'
      }), {
        headers: { 'Content-Type': 'application/json' },
        status: 202
      });
    }
  }
);

// Handle secure data storage
self.addEventListener('message', async (event) => {
  if (!event.data) return;
  
  const db = await initSecureDB();
  
  // Handle different message types
  switch (event.data.type) {
    case 'STORE_ENCRYPTED_DATA': {
      // Store encrypted data
      const { id, encryptedData, metadata } = event.data.payload;
      await db.put('encrypted', {
        id,
        data: encryptedData,
        metadata,
        timestamp: new Date().toISOString()
      });
      
      // Acknowledge storage
      event.source.postMessage({
        type: 'DATA_STORED',
        payload: { id }
      });
      break;
    }
    
    case 'RETRIEVE_ENCRYPTED_DATA': {
      // Retrieve encrypted data
      const { id } = event.data.payload;
      const encryptedRecord = await db.get('encrypted', id);
      
      if (encryptedRecord) {
        event.source.postMessage({
          type: 'DATA_RETRIEVED',
          payload: {
            id,
            encryptedData: encryptedRecord.data,
            metadata: encryptedRecord.metadata,
            timestamp: encryptedRecord.timestamp
          }
        });
      } else {
        event.source.postMessage({
          type: 'DATA_RETRIEVAL_ERROR',
          payload: {
            id,
            error: 'Record not found'
          }
        });
      }
      break;
    }
    
    case 'CLEAR_SENSITIVE_DATA': {
      // Clear sensitive data on logout
      await Promise.all([
        db.clear('incidents'),
        db.clear('osint'),
        db.clear('encrypted')
      ]);
      
      // Clear secure cache
      const cache = await caches.open('nyxtrace-secure');
      await cache.keys().then(requests => Promise.all(
        requests.map(request => cache.delete(request))
      ));
      
      // Acknowledge clearing
      event.source.postMessage({
        type: 'SENSITIVE_DATA_CLEARED'
      });
      break;
    }
  }
});
```

## Frontend Integration
Here's how the PWA functionality might be initialized in the main application:

```javascript
// app.js - Main application entry point
import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { registerServiceWorker } from './serviceWorkerRegistration';
import { initSecureStorage } from './security/secureStorage';

// Initialize the application
async function initializeApp() {
  // Initialize secure storage
  await initSecureStorage();
  
  // Render the app
  ReactDOM.render(
    <React.StrictMode>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </React.StrictMode>,
    document.getElementById('root')
  );
  
  // Register service worker for PWA features
  const registration = await registerServiceWorker();
  
  // Setup push notifications if available
  if (registration && 'PushManager' in window) {
    try {
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(process.env.REACT_APP_VAPID_PUBLIC_KEY)
      });
      
      // Send the subscription to your server
      await fetch('/api/push/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(subscription),
      });
      
      console.log('Push notification subscription successful');
    } catch (err) {
      console.error('Push notification subscription failed:', err);
    }
  }
  
  // Set up app installation prompt
  let deferredPrompt;
  window.addEventListener('beforeinstallprompt', (e) => {
    // Prevent Chrome 67 and earlier from automatically showing the prompt
    e.preventDefault();
    // Stash the event so it can be triggered later
    deferredPrompt = e;
    // Show the install button
    document.getElementById('install-button').style.display = 'block';
  });
  
  // Handle install button click
  document.getElementById('install-button')?.addEventListener('click', async () => {
    if (!deferredPrompt) return;
    
    // Show the install prompt
    deferredPrompt.prompt();
    
    // Wait for the user to respond to the prompt
    const { outcome } = await deferredPrompt.userChoice;
    console.log(`User response to install prompt: ${outcome}`);
    
    // We no longer need the prompt. Clear it up
    deferredPrompt = null;
    
    // Hide the install button
    document.getElementById('install-button').style.display = 'none';
  });
}

// Helper function to convert base64 to Uint8Array for VAPID key
function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/-/g, '+')
    .replace(/_/g, '/');
  
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

// Initialize the application
initializeApp().catch(err => {
  console.error('Application initialization failed:', err);
});
```

## Web App Manifest
Here's an example of how the Web App Manifest might be configured:

```json
{
  "name": "NyxTrace Intelligence Platform",
  "short_name": "NyxTrace",
  "description": "Advanced threat intelligence platform for convergent threats analysis",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#121212",
  "theme_color": "#121212",
  "orientation": "any",
  "icons": [
    {
      "src": "icons/icon-72x72.png",
      "sizes": "72x72",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "icons/icon-96x96.png",
      "sizes": "96x96",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "icons/icon-128x128.png",
      "sizes": "128x128",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "icons/icon-144x144.png",
      "sizes": "144x144",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "icons/icon-152x152.png",
      "sizes": "152x152",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "icons/icon-192x192.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "icons/icon-384x384.png",
      "sizes": "384x384",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "icons/icon-512x512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any maskable"
    }
  ],
  "shortcuts": [
    {
      "name": "Incident Dashboard",
      "url": "/incidents",
      "description": "View active incidents"
    },
    {
      "name": "OSINT Investigation",
      "url": "/osint",
      "description": "Investigate intelligence sources"
    },
    {
      "name": "Threat Map",
      "url": "/map",
      "description": "View geospatial threat data"
    }
  ],
  "categories": ["security", "productivity", "business"],
  "screenshots": [
    {
      "src": "screenshots/dashboard.png",
      "sizes": "1280x720",
      "type": "image/png"
    },
    {
      "src": "screenshots/map-view.png",
      "sizes": "1280x720",
      "type": "image/png"
    },
    {
      "src": "screenshots/intelligence-reports.png",
      "sizes": "1280x720",
      "type": "image/png"
    }
  ],
  "related_applications": [],
  "prefer_related_applications": false
}
```

## Streamlit Integration Considerations
Since the current application is built with Streamlit, there are two approaches to consider:

1. **Hybrid Approach**: Use Streamlit for the core application and integrate PWA capabilities through custom components and a service worker
2. **Full Rewrite**: Rewrite the frontend using React or another framework while keeping the Python backend

For the hybrid approach, you can use Streamlit's component system:

```python
import streamlit as st
import streamlit.components.v1 as components

# Add PWA header elements
pwa_header = """
<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#121212">
<link rel="apple-touch-icon" href="/icons/icon-192x192.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<script>
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
      navigator.serviceWorker.register('/service-worker.js');
    });
  }
</script>
"""

# Inject the PWA headers
st.markdown(pwa_header, unsafe_allow_html=True)

# Create a custom component for offline storage management
def pwa_manager():
    return components.html(
        """
        <div id="pwa-manager"></div>
        <script src="/static/pwa-manager.js"></script>
        """,
        height=0,
    )

# Add the manager to the app
pwa_manager()

# Rest of the Streamlit app remains the same
st.title("NyxTrace Intelligence Platform")
```

## Next Steps and Expansion
After implementing the basic PWA framework, we'll want to:

1. Enhance the offline experience with more sophisticated data synchronization
2. Add support for capturing media (camera, microphone) for field evidence collection
3. Implement hardware integration for specialized equipment
4. Create a mobile-optimized field operations mode

Please develop this PWA framework with a focus on security, performance, and user experience. The solution should provide a native-like experience while maintaining the flexibility of a web application.