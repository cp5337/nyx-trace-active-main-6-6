"""
GIS Module
---------
This module provides geospatial functionality for the NyxTrace platform.
"""