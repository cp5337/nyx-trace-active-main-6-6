"""
NyxTrace Geospatial Intelligence Platform
----------------------------------------
Main entry point for the NyxTrace CTAS Command Center.
Provides access to all intelligence gathering, analysis,
and reporting capabilities across multiple domains.
"""

import streamlit as st
import os
import sys
import logging
from pathlib import Path

# Add current directory to path to ensure imports work correctly
current_dir = Path(__file__).parent
sys.path.append(str(current_dir))

# Import the main dashboard
import main_dashboard

# Run the main dashboard application
if __name__ == "__main__":
    main_dashboard.main()