"""
Sample Threat Intelligence Data
------------------------------
This module provides sample threat intelligence data for demonstration purposes
when offline or when no API keys are available.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Union, Optional, Tuple

def generate_sample_flow_data() -> pd.DataFrame:
    """
    Generate rich sample flow data for cyber threat visualization
    
    Returns:
        DataFrame with sample flow data including source-target relationships
    """
    # Threat actor definitions with realistic details
    threat_actors = [
        {
            "name": "APT28",
            "also_known_as": "Fancy Bear, Sednit, Sofacy",
            "origin": "Russia",
            "lat": 55.7558,
            "lon": 37.6173,
            "target_sectors": ["Government", "Defense", "Election Systems", "Media"],
            "techniques": ["Spear-phishing", "Zero-day exploits", "Custom malware", "Credential theft"]
        },
        {
            "name": "APT29",
            "also_known_as": "Cozy Bear, The Dukes",
            "origin": "Russia",
            "lat": 55.7558,
            "lon": 37.6173,
            "target_sectors": ["Government", "Think Tanks", "Healthcare", "Research"],
            "techniques": ["Supply chain attacks", "Living-off-the-land", "Stealthy operations"]
        },
        {
            "name": "APT41",
            "also_known_as": "Wicked Panda, Barium",
            "origin": "China",
            "lat": 39.9042, 
            "lon": 116.4074,
            "target_sectors": ["Technology", "Healthcare", "Finance", "Gaming"],
            "techniques": ["Supply chain compromises", "Spear-phishing", "Code signing certificates"]
        },
        {
            "name": "Lazarus Group",
            "also_known_as": "Hidden Cobra, Guardians of Peace",
            "origin": "North Korea",
            "lat": 39.0392,
            "lon": 125.7625,
            "target_sectors": ["Financial", "Cryptocurrency", "Defense", "Media"],
            "techniques": ["Watering hole attacks", "Destructive malware", "SWIFT fraud", "Crypto theft"]
        },
        {
            "name": "APT33",
            "also_known_as": "Elfin, Holmium",
            "origin": "Iran",
            "lat": 35.6892,
            "lon": 51.3890,
            "target_sectors": ["Energy", "Aviation", "Government", "Defense"],
            "techniques": ["Password spraying", "Spear-phishing", "Destructive malware"]
        },
        {
            "name": "APT10",
            "also_known_as": "Stone Panda, MenuPass",
            "origin": "China",
            "lat": 39.9042,
            "lon": 116.4074,
            "target_sectors": ["Managed Service Providers", "Healthcare", "Defense", "Maritime"],
            "techniques": ["Spear-phishing", "Data exfiltration", "Custom malware suites"]
        },
        {
            "name": "Sandworm",
            "also_known_as": "Voodoo Bear, BlackEnergy",
            "origin": "Russia",
            "lat": 55.7558,
            "lon": 37.6173,
            "target_sectors": ["Energy", "Government", "Elections", "Media"],
            "techniques": ["Destructive malware", "ICS attacks", "BlackEnergy", "NotPetya", "Olympic Destroyer"]
        },
        {
            "name": "Kimsuky",
            "also_known_as": "Velvet Chollima",
            "origin": "North Korea",
            "lat": 39.0392,
            "lon": 125.7625,
            "target_sectors": ["Government", "Think Tanks", "Research", "Diplomatic"],
            "techniques": ["Spear-phishing", "Social engineering", "Custom malware"]
        },
        {
            "name": "Dragonfly",
            "also_known_as": "Energetic Bear, Crouching Yeti",
            "origin": "Russia",
            "lat": 55.7558,
            "lon": 37.6173,
            "target_sectors": ["Energy", "Industrial Control Systems", "Critical Infrastructure"],
            "techniques": ["Watering hole attacks", "Trojanized software", "Credential theft"]
        },
        {
            "name": "FIN7",
            "also_known_as": "Carbanak",
            "origin": "Russia",
            "lat": 55.7558,
            "lon": 37.6173,
            "target_sectors": ["Financial", "Hospitality", "Retail", "Restaurant"],
            "techniques": ["Spear-phishing", "Point-of-Sale malware", "CARBANAK backdoor"]
        },
        {
            "name": "Equation Group",
            "also_known_as": "Tilded Team",
            "origin": "United States",
            "lat": 38.8951,
            "lon": -77.0364,
            "target_sectors": ["Government", "Telecommunications", "Energy", "Military"],
            "techniques": ["Firmware implants", "Zero-day exploits", "Advanced persistence"]
        },
        {
            "name": "Turla",
            "also_known_as": "Snake, Venomous Bear",
            "origin": "Russia",
            "lat": 55.7558,
            "lon": 37.6173,
            "target_sectors": ["Government", "Embassies", "Military", "Defense"],
            "techniques": ["Satellite hijacking", "Watering hole", "Complex malware"]
        }
    ]
    
    # Target locations with realistic details
    target_locations = [
        {
            "name": "United States",
            "lat": 38.8951,
            "lon": -77.0364,
            "sectors": ["Government", "Defense", "Finance", "Energy", "Technology"]
        },
        {
            "name": "European Union",
            "lat": 50.8503,
            "lon": 4.3517,
            "sectors": ["Government", "Diplomatic", "Finance", "Critical Infrastructure"]
        },
        {
            "name": "Ukraine",
            "lat": 50.4501,
            "lon": 30.5234,
            "sectors": ["Government", "Energy", "Military", "Media"]
        },
        {
            "name": "Taiwan",
            "lat": 25.0330,
            "lon": 121.5654,
            "sectors": ["Technology", "Manufacturing", "Government", "Semiconductor"]
        },
        {
            "name": "Japan",
            "lat": 35.6762,
            "lon": 139.6503,
            "sectors": ["Technology", "Manufacturing", "Government", "Defense"]
        },
        {
            "name": "South Korea",
            "lat": 37.5665,
            "lon": 126.9780,
            "sectors": ["Government", "Defense", "Technology", "Cryptocurrency"]
        },
        {
            "name": "Germany",
            "lat": 52.5200,
            "lon": 13.4050,
            "sectors": ["Government", "Manufacturing", "Defense", "Technology"]
        },
        {
            "name": "United Kingdom",
            "lat": 51.5074,
            "lon": -0.1278,
            "sectors": ["Government", "Finance", "Defense", "Healthcare"]
        },
        {
            "name": "Australia",
            "lat": -35.2809,
            "lon": 149.1300,
            "sectors": ["Government", "Critical Infrastructure", "Defense", "Education"]
        },
        {
            "name": "Israel",
            "lat": 31.7683,
            "lon": 35.2137,
            "sectors": ["Government", "Defense", "Technology", "Healthcare"]
        },
        {
            "name": "Saudi Arabia",
            "lat": 24.7136,
            "lon": 46.6753,
            "sectors": ["Energy", "Government", "Defense", "Finance"]
        },
        {
            "name": "India",
            "lat": 28.6139,
            "lon": 77.2090,
            "sectors": ["Government", "Defense", "Technology", "Energy"]
        }
    ]
    
    # Attack types
    attack_types = [
        {"type": "attack", "weight_range": (3, 5)},
        {"type": "reconnaissance", "weight_range": (1, 3)},
        {"type": "data_exfiltration", "weight_range": (2, 4)},
        {"type": "lateral_movement", "weight_range": (1, 3)},
        {"type": "command_and_control", "weight_range": (1, 2)}
    ]
    
    # Generate realistic campaign descriptions
    campaign_templates = [
        "{actor} conducting {technique} against {sector} organizations in {target}",
        "Operation {codename}: {actor} targeting {target} {sector} infrastructure",
        "{technique} campaign by {actor} focused on {target} {sector} entities",
        "New {actor} activity: {technique} targeting {sector} in {target}",
        "{actor} deploying {malware} malware against {target} {sector} organizations"
    ]
    
    # Malware names for campaigns
    malware_names = [
        "BlackEnergy", "NotPetya", "Industroyer", "WannaCry", "SUNBURST",
        "Conti", "Ryuk", "REvil", "DarkSide", "LockBit",
        "Dridex", "Emotet", "TrickBot", "BazarLoader", "IcedID",
        "CobaltStrike", "Mimikatz", "Gh0st RAT", "PlugX", "BADNEWS"
    ]
    
    # Operation codenames
    operation_names = [
        "Ghostwriter", "Cloud Hopper", "Olympic Games", "Aurora", "Solwind",
        "ShadowHammer", "Soft Cell", "Wocao", "Gothic Panda", "Double Dragon",
        "DarkHotel", "BlackEnergy", "Nitro", "Cobalt Kitty", "Machete"
    ]
    
    # Techniques
    techniques = [
        "spear-phishing", "watering hole", "supply chain", "zero-day exploit",
        "credential theft", "social engineering", "malware deployment", "ransomware",
        "living-off-the-land", "firmware implant", "backdoor installation"
    ]
    
    # Build rich sample data
    data = []
    
    # Start date: 30 days ago
    start_date = datetime.now() - timedelta(days=30)
    
    # Generate flows
    for i in range(50):  # Generate 50 flows for a rich dataset
        # Select random source and target
        source = np.random.choice(threat_actors)
        target = np.random.choice(target_locations)
        
        # Select sector from target's sectors
        sector = np.random.choice(target["sectors"])
        
        # Create attack details
        attack = np.random.choice(attack_types)
        
        # Generate a date within the last 30 days
        days_ago = np.random.randint(0, 30)
        flow_date = datetime.now() - timedelta(days=days_ago)
        
        # Generate campaign description
        template = np.random.choice(campaign_templates)
        codename = np.random.choice(operation_names)
        technique = np.random.choice(techniques)
        malware = np.random.choice(malware_names)
        
        title = template.format(
            actor=source["name"],
            codename=codename,
            technique=technique.title(),
            sector=sector.lower(),
            target=target["name"],
            malware=malware
        )
        
        # Create flow
        flow = {
            'source': source["name"],
            'target': target["name"],
            'source_lat': source["lat"],
            'source_lon': source["lon"],
            'target_lat': target["lat"],
            'target_lon': target["lon"],
            'weight': np.random.uniform(attack["weight_range"][0], attack["weight_range"][1]),
            'type': attack["type"],
            'title': title,
            'date': flow_date,
            'sector': sector,
            'actor_details': source["also_known_as"],
            'confidence': np.random.choice(["High", "Medium", "Low"], p=[0.5, 0.3, 0.2])
        }
        
        data.append(flow)
    
    # Convert to dataframe
    df = pd.DataFrame(data)
    
    # Add a bit of randomness to coordinates to prevent perfect overlaps
    df['source_lat'] += np.random.normal(0, 0.2, len(df))
    df['source_lon'] += np.random.normal(0, 0.2, len(df))
    df['target_lat'] += np.random.normal(0, 0.05, len(df))
    df['target_lon'] += np.random.normal(0, 0.05, len(df))
    
    return df


def generate_sample_iocs() -> List[Dict[str, Any]]:
    """
    Generate sample indicators of compromise (IOCs)
    
    Returns:
        List of IOC dictionaries
    """
    iocs = []
    
    # Sample IP addresses (completely fictional)
    ip_addresses = [
        "185.193.38.24", "45.32.129.185", "194.5.249.157", "31.184.254.18", "149.56.180.102",
        "185.141.63.120", "91.219.236.228", "185.174.102.22", "46.21.147.161", "195.123.208.27",
        "89.34.111.11", "193.42.36.66", "77.220.65.147", "45.153.241.209", "91.245.253.98"
    ]
    
    # Sample domains (completely fictional)
    domains = [
        "securedataupdates.com", "microsoft-verify-auth.com", "googleauth-secure.com", 
        "apple-icloud-verify.net", "update-windows-defender.com", "security-adobe-update.net",
        "aws-console-login.com", "azuresecurelogin.net", "facebook-security-team.com",
        "outlook-attachment-viewer.com", "linkedin-security-alert.net", "zoom-meeting-join.us",
        "adobe-pdf-reader.net", "chrome-browser-update.com", "firefox-secure-update.net"
    ]
    
    # Sample hashes (completely fictional)
    hashes = [
        "8f92fce1c18348a1c91bb5adcd7add7fb97a7e7a", 
        "a3c585680e4b9184ca5fa9843fb035c15b22e537",
        "e8c88612bea7c831a47baeb7a6d7cd9e6f6306ac",
        "d8bc889f5e00b97d13aca7a7a9c488be649bd500",
        "94c571193a629a937b832ce1d49120a134e4a0f9",
        "7b7fcb65154bc743dbe5c6015bac168bd02f1c87",
        "3a98fe3c5d811382873e29b321d65c999ff8a396",
        "f4a192d8c76ef9a281f235e40d8dfabb8e2bd257",
        "c34a5bb596fed24d875ea34a518b54a09845432e",
        "1c7c72d1e7f7f0541b6baf0c41bbbb2e7cc54b94"
    ]
    
    # Sample URLs (completely fictional)
    urls = [
        "https://legitimate-looking-site.com/update.php", 
        "https://real-company-portal.com/login.aspx?token=a1b2c3",
        "https://document-preview.org/statement.docx",
        "https://secure-payment-portal.com/invoice.php?id=123456",
        "https://customer-portal-secure.com/download/statement.zip",
        "https://financial-services-portal.com/documents/2023/q2",
        "https://corporate-sharepoint.com/sites/finance/shared/budgets",
        "https://helpdesk-ticket.com/reset-password?user=admin",
        "https://software-updates.org/patches/security/2023-05",
        "https://document-sharing-portal.net/view?doc=confidential"
    ]
    
    # Sample emails (completely fictional)
    emails = [
        "security-updates@microsoft-verify.com",
        "helpdesk@google-accounts.net",
        "admin@sharepoint-access.com",
        "noreply@amazondelivery-tracking.com",
        "security@paypal-accounts.net",
        "notifications@docusign-documents.com",
        "alerts@banking-secure-login.com",
        "support@office365-team.net",
        "noreply@netflix-billing.com",
        "verification@apple-accounts.net"
    ]
    
    # Generate IOCs
    ioc_types = ["IP", "Domain", "Hash", "URL", "Email"]
    ioc_sources = [ip_addresses, domains, hashes, urls, emails]
    confidence_levels = ["High", "Medium", "Low"]
    confidence_weights = [0.5, 0.3, 0.2]
    
    descriptions = [
        "C2 server for {actor} campaign",
        "Infrastructure associated with {malware} distribution",
        "Used in spear-phishing campaign targeting {sector}",
        "Linked to {actor} operations against {target}",
        "Observed in {malware} infections",
        "Distribution point for {malware} malware",
        "Exfiltration server for data theft campaign",
        "Command and control for {actor} operations",
        "Used in watering hole attack targeting {sector} organizations",
        "Part of {actor} infrastructure targeting {target}"
    ]
    
    actors = ["APT28", "APT29", "Lazarus Group", "APT41", "Sandworm", "APT33", "FIN7", "APT10"]
    malware = ["SUNBURST", "TEARDROP", "Cobalt Strike", "TrickBot", "Emotet", "Ryuk", "BlackEnergy", "NotPetya"]
    sectors = ["Government", "Finance", "Energy", "Healthcare", "Defense", "Technology"]
    targets = ["United States", "European Union", "Ukraine", "Taiwan", "Japan", "South Korea", "Germany"]
    
    # Generate 30 sample IOCs
    for i in range(30):
        ioc_type_idx = np.random.randint(0, len(ioc_types))
        ioc_type = ioc_types[ioc_type_idx]
        
        # Get random value of appropriate type
        value = np.random.choice(ioc_sources[ioc_type_idx])
        
        # Generate description
        desc_template = np.random.choice(descriptions)
        actor = np.random.choice(actors)
        malware_name = np.random.choice(malware)
        sector = np.random.choice(sectors)
        target = np.random.choice(targets)
        
        description = desc_template.format(
            actor=actor,
            malware=malware_name,
            sector=sector,
            target=target
        )
        
        # Generate first seen date
        days_ago = np.random.randint(1, 30)
        first_seen = (datetime.now() - timedelta(days=days_ago)).strftime("%Y-%m-%d")
        
        # Create IOC entry
        ioc = {
            "type": ioc_type,
            "value": value,
            "description": description,
            "confidence": np.random.choice(confidence_levels, p=confidence_weights),
            "first_seen": first_seen,
            "source": "AlienVault OTX",
            "tags": ", ".join(np.random.choice(["APT", "Malware", "Phishing", "Ransomware", "C2", "Exfiltration"], 
                                            size=np.random.randint(1, 4), replace=False)),
            "references": "TR-{}-{}".format(np.random.randint(1000, 9999), datetime.now().year)
        }
        
        iocs.append(ioc)
    
    return iocs


def generate_sample_bulletins() -> List[Dict[str, Any]]:
    """
    Generate sample threat intelligence bulletins
    
    Returns:
        List of bulletin dictionaries
    """
    bulletins = []
    
    # High severity bulletins
    high_bulletins = [
        {
            "level": "high",
            "title": "APT28 Campaign Targeting Energy Infrastructure in Europe",
            "date": (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d"),
            "summary": "New spear-phishing campaign using weaponized Excel documents with malicious macros targeting energy sector employees in multiple European countries. Infection chain includes PowerShell downloaders that deploy custom XTUNNEL malware for persistent access."
        },
        {
            "level": "high",
            "title": "Ransomware Activity Surges Against Healthcare Sector",
            "date": (datetime.now() - timedelta(days=3)).strftime("%Y-%m-%d"),
            "summary": "Multiple healthcare organizations have been targeted by LockBit 3.0 ransomware operators in the past week. Initial access vectors include compromised VPN credentials and exploitation of unpatched FortiOS vulnerabilities (CVE-2022-42475)."
        },
        {
            "level": "high",
            "title": "China-Linked APT41 Targeting Telecommunications Providers",
            "date": (datetime.now() - timedelta(days=5)).strftime("%Y-%m-%d"),
            "summary": "APT41 has been observed targeting telecommunication companies with custom malware designed to intercept SMS communications. The campaign leverages ShadowPad backdoors and previously undisclosed vulnerabilities in network management systems."
        },
        {
            "level": "high",
            "title": "Critical Zero-Day in Widely Used VPN Solution Under Active Exploitation",
            "date": (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d"),
            "summary": "A zero-day vulnerability (CVE-2023-XXXXX) in Pulse Connect Secure VPN is being actively exploited by multiple threat actors. The vulnerability allows remote code execution without authentication. Emergency patches are being deployed."
        }
    ]
    
    # Medium severity bulletins
    medium_bulletins = [
        {
            "level": "medium",
            "title": "New Phishing Campaign Impersonating Financial Institutions",
            "date": (datetime.now() - timedelta(days=4)).strftime("%Y-%m-%d"),
            "summary": "A widespread phishing campaign targeting customers of major banks has been observed using highly convincing templates. The phishing sites implement advanced evasion techniques including geofencing and bot detection to avoid analysis."
        },
        {
            "level": "medium",
            "title": "Kimsuky Group Targeting Academic Research Institutions",
            "date": (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d"),
            "summary": "North Korean threat actor Kimsuky is conducting spear-phishing campaigns against research institutions working on nuclear policy. The attacks use PDF documents with malicious links that lead to credential harvesting pages."
        },
        {
            "level": "medium",
            "title": "Supply Chain Risk: Compromised JavaScript Library in NPM",
            "date": (datetime.now() - timedelta(days=6)).strftime("%Y-%m-%d"),
            "summary": "A popular open-source JavaScript library (with over 8 million weekly downloads) was compromised by inserting malicious code that harvests environment variables including potential API keys and credentials."
        },
        {
            "level": "medium",
            "title": "DDoS Attacks Targeting Financial Services",
            "date": (datetime.now() - timedelta(days=5)).strftime("%Y-%m-%d"),
            "summary": "Multiple financial institutions have experienced sophisticated layer 7 DDoS attacks reaching up to 800 Gbps. The attacks demonstrate advanced techniques including traffic amplification and bypass of standard mitigation systems."
        },
        {
            "level": "medium",
            "title": "Sandworm Deploying Updated Industroyer Malware",
            "date": (datetime.now() - timedelta(days=8)).strftime("%Y-%m-%d"),
            "summary": "Russian threat actor Sandworm has been observed using an updated version of the Industroyer malware targeting industrial control systems (ICS) in European energy facilities. The malware contains enhanced capabilities for targeting specific ICS protocols."
        }
    ]
    
    # Low severity bulletins
    low_bulletins = [
        {
            "level": "low",
            "title": "Information Disclosure Vulnerability in Popular CMS",
            "date": (datetime.now() - timedelta(days=10)).strftime("%Y-%m-%d"),
            "summary": "A moderate severity information disclosure vulnerability has been identified in WordPress 6.1.x. The vulnerability could allow authenticated users with contributor privileges to access certain draft posts from other users."
        },
        {
            "level": "low",
            "title": "New Cryptojacking Campaign Targeting Unpatched Cloud Servers",
            "date": (datetime.now() - timedelta(days=12)).strftime("%Y-%m-%d"),
            "summary": "A cryptojacking campaign targeting exposed Docker APIs has been identified. The attackers deploy XMRig miners configured for optimal performance and minimal detection using various evasion techniques."
        },
        {
            "level": "low",
            "title": "Increase in Brute Force Attacks Against RDP Services",
            "date": (datetime.now() - timedelta(days=9)).strftime("%Y-%m-%d"),
            "summary": "Researchers have observed a 43% increase in brute force attacks targeting Remote Desktop Protocol (RDP) endpoints. Most attacks originate from compromised infrastructure in Eastern Europe and Southeast Asia."
        }
    ]
    
    # Combine all bulletins and sort by date (newest first)
    all_bulletins = high_bulletins + medium_bulletins + low_bulletins
    
    # Sort by date (newest first)
    all_bulletins = sorted(all_bulletins, key=lambda x: datetime.strptime(x["date"], "%Y-%m-%d"), reverse=True)
    
    return all_bulletins


if __name__ == "__main__":
    # Generate sample data
    flow_data = generate_sample_flow_data()
    iocs = generate_sample_iocs()
    bulletins = generate_sample_bulletins()
    
    # Print sample counts
    print(f"Generated {len(flow_data)} sample flows")
    print(f"Generated {len(iocs)} sample IOCs")
    print(f"Generated {len(bulletins)} sample bulletins")