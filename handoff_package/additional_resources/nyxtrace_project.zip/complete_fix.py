import streamlit as st
import time
import json
import re
import os
from datetime import datetime, timedelta
import pickle
import math
import base64
import pandas as pd
import numpy as np
import io
from urllib.parse import urlparse
import plotly.express as px
from PIL import Image
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from data_handler import DataHandler

# Initialize session state variables
if 'dark_mode' not in st.session_state:
    st.session_state.dark_mode = True
if 'data_handler' not in st.session_state:
    st.session_state.data_handler = DataHandler()
if 'excel_osint_data' not in st.session_state:
    st.session_state.excel_osint_data = None
if 'filtered_data' not in st.session_state:
    st.session_state.filtered_data = None
if 'scraper_results' not in st.session_state:
    st.session_state.scraper_results = {}
if 'saved_urls' not in st.session_state:
    st.session_state.saved_urls = []
if 'saved_search_terms' not in st.session_state:
    st.session_state.saved_search_terms = []
if 'search_history' not in st.session_state:
    st.session_state.search_history = []
if 'web_content_cache' not in st.session_state:
    st.session_state.web_content_cache = {}
if 'last_search_time' not in st.session_state:
    st.session_state.last_search_time = {}
if 'collapsed_results' not in st.session_state:
    st.session_state.collapsed_results = set()

# Function to get theme settings
def get_theme_settings():
    """Get the current theme settings based on session state"""
    if st.session_state.dark_mode:
        return {
            'bgcolor': '#0E1117',
            'textcolor': '#FAFAFA',
            'gridcolor': '#1f1f1f',
            'plot_bgcolor': '#262730',
            'paper_bgcolor': '#262730',
        }
    else:
        return {
            'bgcolor': '#FFFFFF',
            'textcolor': '#111111',
            'gridcolor': '#e0e0e0',
            'plot_bgcolor': '#F0F2F6',
            'paper_bgcolor': '#F0F2F6',
        }

# Load sample data for OSINT
sample_data_loaded = False
if 'sample_data_loaded' not in st.session_state:
    st.session_state.sample_data_loaded = False

def create_map(df, zoom=3):
    """Create an interactive map based on dataframe with lat/long coordinates"""
    theme = get_theme_settings()
    
    if 'Latitude' not in df.columns or 'Longitude' not in df.columns:
        st.error("Map data must contain Latitude and Longitude columns")
        return None
    
    # Extract center point for the map
    center_lat = df['Latitude'].mean()
    center_lon = df['Longitude'].mean()
    
    # Create map
    fig = px.scatter_mapbox(
        df, 
        lat='Latitude', 
        lon='Longitude',
        hover_name=df.get('Name', df.index),
        hover_data={col: True for col in df.columns if col not in ['Latitude', 'Longitude']},
        color=df.get('Type', [None] * len(df)) if 'Type' in df.columns else None,
        size=df.get('Activity_Level', [1] * len(df)) if 'Activity_Level' in df.columns else None,
        size_max=15,
        zoom=zoom,
        height=500
    )
    
    # Update map layout with appropriate mapbox style
    fig.update_layout(
        mapbox_style="carto-darkmatter" if st.session_state.dark_mode else "carto-positron",
        mapbox=dict(
            center=dict(lat=center_lat, lon=center_lon),
            zoom=zoom
        ),
        margin={"r":0,"t":0,"l":0,"b":0},
        paper_bgcolor=theme['paper_bgcolor'],
        plot_bgcolor=theme['plot_bgcolor'],
    )
    
    return fig

def display_location_info(location):
    """Display detailed information about a selected location"""
    # Placeholder for detailed location information display
    st.subheader(f"📍 {location}")
    
    # Get data for this location
    data = st.session_state.data_handler.get_filtered_data(location_type=location)
    
    # Display key metrics
    if data is not None and not data.empty:
        col1, col2, col3 = st.columns(3)
        col1.metric("Total Activities", len(data))
        col2.metric("First Recorded", data['Date'].min().strftime('%Y-%m-%d') if 'Date' in data.columns else "N/A")
        col3.metric("Last Updated", data['Date'].max().strftime('%Y-%m-%d') if 'Date' in data.columns else "N/A")
        
        # Show time series data
        st.subheader("Activity Timeline")
        time_series = st.session_state.data_handler.get_time_series_data(city=location)
        fig = create_time_series_plot(time_series, f"Activity in {location} Over Time")
        st.plotly_chart(fig, use_container_width=True)
        
        # Show data table
        with st.expander("View Raw Data"):
            st.dataframe(data)
    else:
        st.info(f"No detailed data available for {location}")

def create_time_series_plot(data, title="Activity Level Over Time"):
    """Create a time series plot for activity levels"""
    theme = get_theme_settings()
    
    fig = go.Figure()
    
    if data is not None and not data.empty and 'Date' in data.columns and 'Activity_Level' in data.columns:
        fig.add_trace(go.Scatter(
            x=data['Date'],
            y=data['Activity_Level'],
            mode='lines+markers',
            name='Activity Level',
            line=dict(color='#00b8ff', width=2),
            marker=dict(size=6, color='#00b8ff')
        ))
        
        # Add trend line
        if len(data) > 1:
            try:
                # Simple moving average
                window_size = max(2, len(data) // 4)
                data['SMA'] = data['Activity_Level'].rolling(window=window_size, min_periods=1).mean()
                
                fig.add_trace(go.Scatter(
                    x=data['Date'],
                    y=data['SMA'],
                    mode='lines',
                    name=f'Trend (MA-{window_size})',
                    line=dict(color='#ff9900', width=2, dash='dot')
                ))
            except:
                # Skip trend line if there's an error
                pass
    else:
        # Sample data for empty state
        dates = [datetime.now() - timedelta(days=x) for x in range(30, 0, -5)]
        values = [0] * len(dates)
        
        fig.add_trace(go.Scatter(
            x=dates,
            y=values,
            mode='lines+markers',
            name='No Data',
            line=dict(color='#888888', width=2),
            marker=dict(size=6, color='#888888')
        ))
    
    # Update layout
    fig.update_layout(
        title=title,
        xaxis_title="Date",
        yaxis_title="Activity Level",
        paper_bgcolor=theme['paper_bgcolor'],
        plot_bgcolor=theme['plot_bgcolor'],
        font=dict(color=theme['textcolor']),
        xaxis=dict(
            showgrid=True,
            gridcolor=theme['gridcolor'],
            tickfont=dict(color=theme['textcolor']),
            title_font=dict(color=theme['textcolor'])
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor=theme['gridcolor'],
            tickfont=dict(color=theme['textcolor']),
            title_font=dict(color=theme['textcolor'])
        ),
        legend=dict(
            font=dict(color=theme['textcolor'])
        ),
        margin=dict(l=10, r=10, t=50, b=10),
        height=300
    )
    
    return fig

def create_download_buttons(data_handler):
    """Create download buttons for various export formats"""
    col1, col2 = st.columns(2)
    
    # CSV download
    csv = data_handler.get_csv()
    csv_b64 = base64.b64encode(csv.encode()).decode()
    col1.download_button(
        label="Download CSV",
        data=csv,
        file_name="location_data.csv",
        mime="text/csv",
    )
    
    # JSON download
    json_data = data_handler.get_json()
    col2.download_button(
        label="Download JSON",
        data=json_data,
        file_name="location_data.json",
        mime="application/json",
    )

# Helper function to convert dataframe to KML file
def dataframe_to_kml(df):
    """Convert dataframe with lat/lon to KML format"""
    # Check if dataframe has the required columns
    if not all(col in df.columns for col in ['Name', 'Latitude', 'Longitude']):
        return "Error: Dataframe must contain Name, Latitude, and Longitude columns"
    
    # Start KML file
    kml = '<?xml version="1.0" encoding="UTF-8"?>\n'
    kml += '<kml xmlns="http://www.opengis.net/kml/2.2">\n'
    kml += '<Document>\n'
    kml += f'<name>Exported Locations</name>\n'
    
    # Add style for placemarks
    kml += '<Style id="locationStyle">\n'
    kml += '  <IconStyle>\n'
    kml += '    <Icon>\n'
    kml += '      <href>http://maps.google.com/mapfiles/kml/pushpin/red-pushpin.png</href>\n'
    kml += '    </Icon>\n'
    kml += '  </IconStyle>\n'
    kml += '</Style>\n'
    
    # Add each placemark
    for _, row in df.iterrows():
        kml += '<Placemark>\n'
        kml += f'  <name>{row["Name"]}</name>\n'
        
        # Add description if available
        if 'Description' in row and pd.notna(row['Description']):
            kml += f'  <description>{row["Description"]}</description>\n'
        
        # Add location type if available
        if 'Type' in row and pd.notna(row['Type']):
            kml += '  <ExtendedData>\n'
            kml += f'    <Data name="Type"><value>{row["Type"]}</value></Data>\n'
            kml += '  </ExtendedData>\n'
        
        # Add style reference
        kml += '  <styleUrl>#locationStyle</styleUrl>\n'
        
        # Add point coordinates
        kml += '  <Point>\n'
        kml += f'    <coordinates>{row["Longitude"]},{row["Latitude"]},0</coordinates>\n'
        kml += '  </Point>\n'
        kml += '</Placemark>\n'
    
    # Close KML file
    kml += '</Document>\n'
    kml += '</kml>'
    
    return kml

# Helper functions for geocoding addresses
def geocode_address(address):
    """Geocode a single address to latitude/longitude coordinates"""
    # This would normally use a real geocoding service
    # For the demo, we'll simulate geocoding with random coordinates
    
    # In a real implementation, we'd use a service like:
    # from geopy.geocoders import Nominatim
    # geolocator = Nominatim(user_agent="location_analyzer")
    # location = geolocator.geocode(address)
    # return (location.latitude, location.longitude) if location else None
    
    # For the demo, return a simulated geocoded result
    if "white house" in address.lower() or "washington" in address.lower():
        return (38.8977, -77.0365)
    elif "new york" in address.lower() or "manhattan" in address.lower():
        return (40.7128, -74.0060)
    elif "los angeles" in address.lower() or "la" in address.lower():
        return (34.0522, -118.2437)
    elif "chicago" in address.lower():
        return (41.8781, -87.6298)
    elif "san francisco" in address.lower():
        return (37.7749, -122.4194)
    elif "seattle" in address.lower():
        return (47.6062, -122.3321)
    elif "austin" in address.lower():
        return (30.2672, -97.7431)
    elif "boston" in address.lower():
        return (42.3601, -71.0589)
    
    # For any other address, generate a random point in the US
    import random
    lat = random.uniform(24.396308, 49.384358)  # US latitude range
    lon = random.uniform(-125.0, -66.0)  # US longitude range
    return (lat, lon)

def batch_geocode_addresses(address_list):
    """Geocode multiple addresses and return as a dataframe"""
    results = []
    
    for address in address_list:
        coords = geocode_address(address)
        if coords:
            lat, lon = coords
            results.append({
                'Address': address,
                'Latitude': lat,
                'Longitude': lon,
                'Status': 'Success'
            })
        else:
            results.append({
                'Address': address,
                'Latitude': None,
                'Longitude': None,
                'Status': 'Failed'
            })
    
    return pd.DataFrame(results)

# Set page config
st.set_page_config(
    page_title="Location Analysis Dashboard",
    page_icon="🌎",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for dark mode toggle
st.markdown("""
<style>
    .dark-mode-toggle {
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 10px;
    }
    .dark-mode-toggle-label {
        display: flex;
        align-items: center;
        cursor: pointer;
    }
    .dark-mode-toggle-switch {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 20px;
        background-color: #ccc;
        border-radius: 20px;
        transition: all 0.3s;
        margin: 0 10px;
    }
    .dark-mode-toggle-switch::after {
        content: '';
        position: absolute;
        width: 18px;
        height: 18px;
        border-radius: 18px;
        background-color: white;
        top: 1px;
        left: 1px;
        transition: all 0.3s;
    }
    input:checked + .dark-mode-toggle-switch::after {
        transform: translateX(20px);
    }
    input:checked + .dark-mode-toggle-switch {
        background-color: #2196F3;
    }
</style>
""", unsafe_allow_html=True)

st.title('🌎 Location Analysis Dashboard')

st.markdown("""
This dashboard analyzes various locations across North America, including
ports, HIDTA regions, and critical infrastructure hubs. Use the filters in the sidebar
to customize the view and explore the data.
""")

###################
# Feature Flags and Demo Settings
###################
# Hidden developer controls (would be removed in production)
dev_features = False
if dev_features:
    st.sidebar.header("Developer Controls")
    new_features_available = st.sidebar.checkbox("Enable New Features", value=True)
    show_demo_content = st.sidebar.checkbox("Show Demo Content", value=True)
else:
    new_features_available = True
    show_demo_content = True

# Sidebar filters and navigation
st.sidebar.header("Navigation")
app_mode = st.sidebar.radio(
    "Select View",
    ["Main Dashboard", "Advanced Analytics", "OSINT Analysis", "Data Sources", "URL Health"],
    key="navigation_radio"
)

# Theme toggle in sidebar
st.sidebar.header("Display Options")
theme_col1, theme_col2 = st.sidebar.columns([1, 1])

with theme_col1:
    st.write("Theme:")
with theme_col2:
    if st.button("🌓 Toggle", key="theme_toggle"):
        st.session_state.dark_mode = not st.session_state.dark_mode
        st.experimental_rerun()
st.sidebar.write("Current: " + ("Dark Mode 🌑" if st.session_state.dark_mode else "Light Mode ☀️"))

# Filter settings in sidebar (when in main dashboard)
if app_mode == "Main Dashboard":
    st.sidebar.header("Filter Data")
    
    # Location type filter
    location_types = st.session_state.data_handler.get_location_types()
    selected_type = st.sidebar.selectbox(
        "Location Type",
        ["All"] + location_types,
        key="location_type_filter"
    )
    
    # Date range filter
    date_range = st.sidebar.date_input(
        "Date Range",
        value=[datetime.now() - timedelta(days=30), datetime.now()],
        key="date_range_filter"
    )
    
    # Activity level filter
    activity_level = st.sidebar.slider(
        "Minimum Activity Level",
        min_value=0,
        max_value=10,
        value=0,
        step=1,
        key="activity_level_filter"
    )

# Main content area
if app_mode == "Main Dashboard":
    # Main dashboard view with map and metrics
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("📍 Location Map")
        
        # Get filtered data based on sidebar selections
        location_filter = None if selected_type == "All" else selected_type
        filtered_data = st.session_state.data_handler.get_filtered_data(location_type=location_filter)
        
        # Save to session state for other views
        st.session_state.filtered_data = filtered_data
        
        if filtered_data is not None and not filtered_data.empty:
            # Create and display the map
            location_map = create_map(filtered_data)
            st.plotly_chart(location_map, use_container_width=True)
        else:
            st.info("No location data matches the current filters")
    
    with col2:
        st.subheader("📊 Summary Metrics")
        
        # Show summary metrics
        if filtered_data is not None and not filtered_data.empty:
            # Show key metrics
            num_locations = filtered_data['Location'].nunique() if 'Location' in filtered_data.columns else 0
            num_records = len(filtered_data)
            avg_activity = filtered_data['Activity_Level'].mean() if 'Activity_Level' in filtered_data.columns else 0
            
            metric_col1, metric_col2, metric_col3 = st.columns(3)
            metric_col1.metric("Locations", num_locations)
            metric_col2.metric("Records", num_records)
            metric_col3.metric("Avg Activity", f"{avg_activity:.1f}")
            
            # Top Locations by Activity
            st.subheader("Top Locations")
            
            if 'Location' in filtered_data.columns and 'Activity_Level' in filtered_data.columns:
                top_locations = filtered_data.groupby('Location')['Activity_Level'].sum().reset_index()
                top_locations = top_locations.sort_values('Activity_Level', ascending=False).head(5)
                
                # Create bar chart for top locations
                fig = px.bar(
                    top_locations, 
                    x='Location', 
                    y='Activity_Level',
                    title="Locations by Activity Level",
                    labels={'Activity_Level': 'Activity', 'Location': 'Location'},
                )
                
                # Set theme-specific colors
                theme = get_theme_settings()
                fig.update_layout(
                    plot_bgcolor=theme['plot_bgcolor'],
                    paper_bgcolor=theme['paper_bgcolor'],
                    font=dict(color=theme['textcolor']),
                    xaxis=dict(gridcolor=theme['gridcolor']),
                    yaxis=dict(gridcolor=theme['gridcolor'])
                )
                
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Location or Activity data not available")
        else:
            st.info("No data available for the selected filters")
    
    # Recent activity section
    st.subheader("📅 Recent Activity Timeline")
    
    # Get time series data
    time_series_data = st.session_state.data_handler.get_time_series_data()
    
    if time_series_data is not None and not time_series_data.empty:
        time_fig = create_time_series_plot(time_series_data, "Activity Level Over Time")
        st.plotly_chart(time_fig, use_container_width=True)
    else:
        st.info("No timeline data available")
    
    # Location details section - only shown when a specific location is selected
    if selected_type != "All" and selected_type in location_types:
        st.subheader(f"📍 {selected_type} Details")
        display_location_info(selected_type)
    
    # Data download section
    with st.expander("Download Data"):
        st.write("Download the filtered data in various formats:")
        create_download_buttons(st.session_state.data_handler)

# Advanced Analytics View
elif app_mode == "Advanced Analytics" and new_features_available:
    st.header("📈 Advanced Analytics")
    
    st.markdown("""
    This section provides advanced analytical tools for examining location data,
    including heatmaps, trend analysis, and statistical summaries.
    """)
    
    # Create tabs for different analytical tools
    analytics_tabs = st.tabs([
        "Heatmaps & Clustering", 
        "Trend Analysis", 
        "Statistical Summary",
        "Comparative Analysis"
    ])
    
    # Get data to analyze
    filtered_data = st.session_state.filtered_data
    if filtered_data is None or filtered_data.empty:
        filtered_data = st.session_state.data_handler.get_filtered_data()
        st.session_state.filtered_data = filtered_data
    
    # Heatmaps & Clustering tab
    with analytics_tabs[0]:
        st.subheader("🔥 Heatmaps & Clustering")
        
        st.markdown("""
        Heatmaps show the density and concentration of activity across different locations.
        Clustering helps identify natural groupings in the data.
        """)
        
        heatmap_col1, heatmap_col2 = st.columns([1, 1])
        
        with heatmap_col1:
            st.subheader("Activity Heatmap")
            
            # Parameters for the heatmap
            heatmap_resolution = st.slider(
                "Heatmap Resolution",
                min_value=50,
                max_value=500,
                value=100,
                step=50,
                help="Higher resolution creates a more detailed heatmap but may be slower to render"
            )
            
            # Create and display the heatmap
            if filtered_data is not None and not filtered_data.empty:
                if all(col in filtered_data.columns for col in ['Latitude', 'Longitude']):
                    heatmap_fig = create_heatmap(filtered_data, resolution=heatmap_resolution)
                    st.plotly_chart(heatmap_fig, use_container_width=True)
                else:
                    st.warning("Heatmap requires location data with Latitude and Longitude coordinates")
            else:
                st.info("No data available for heatmap visualization")
        
        with heatmap_col2:
            st.subheader("Cluster Analysis")
            
            # Parameters for clustering
            num_clusters = st.slider(
                "Number of Clusters",
                min_value=2,
                max_value=10,
                value=5,
                step=1,
                help="Number of clusters to identify in the data"
            )
            
            # Create and display the clustered map
            if filtered_data is not None and not filtered_data.empty:
                if all(col in filtered_data.columns for col in ['Latitude', 'Longitude']):
                    cluster_fig = create_clustered_heatmap(filtered_data, n_clusters=num_clusters)
                    st.plotly_chart(cluster_fig, use_container_width=True)
                else:
                    st.warning("Clustering requires location data with Latitude and Longitude coordinates")
            else:
                st.info("No data available for cluster analysis")
        
        # Time-based heatmap
        st.subheader("Time-Based Activity Heatmap")
        
        # Parameters for time-based heatmap
        time_unit = st.selectbox(
            "Time Unit",
            ["Day", "Week", "Month"],
            index=1,
            help="Time period for aggregating activity"
        )
        
        # Create and display the time-based heatmap
        if filtered_data is not None and not filtered_data.empty:
            if all(col in filtered_data.columns for col in ['Date', 'Location', 'Activity_Level']):
                time_heatmap = create_time_based_heatmap(filtered_data, time_unit=time_unit.lower())
                st.plotly_chart(time_heatmap, use_container_width=True)
            else:
                st.warning("Time-based heatmap requires data with Date, Location, and Activity_Level")
        else:
            st.info("No data available for time-based heatmap visualization")
    
    # Trend Analysis tab
    with analytics_tabs[1]:
        st.subheader("📈 Trend Analysis")
        
        st.markdown("""
        Trend analysis examines how activity levels and patterns change over time,
        helping identify seasonal variations, growth trends, and anomalies.
        """)
        
        trend_col1, trend_col2 = st.columns([1, 1])
        
        with trend_col1:
            # Overall trend analysis
            st.subheader("Overall Activity Trend")
            
            # Parameters for trend analysis
            trend_period = st.selectbox(
                "Analysis Period",
                ["Last 30 days", "Last 90 days", "Last 12 months", "All time"],
                index=2,
                key="trend_period",
                help="Time period for trend analysis"
            )
            
            # Create and display the trend analysis
            if filtered_data is not None and not filtered_data.empty:
                if all(col in filtered_data.columns for col in ['Date', 'Activity_Level']):
                    trend_fig = create_trend_analysis_chart(filtered_data, period=trend_period)
                    st.plotly_chart(trend_fig, use_container_width=True)
                else:
                    st.warning("Trend analysis requires data with Date and Activity_Level")
            else:
                st.info("No data available for trend analysis")
        
        with trend_col2:
            # Location-specific trend analysis
            st.subheader("Location-Specific Trends")
            
            # Location selector
            if filtered_data is not None and not filtered_data.empty and 'Location' in filtered_data.columns:
                locations = filtered_data['Location'].unique()
                selected_location = st.selectbox(
                    "Select Location",
                    locations,
                    index=0,
                    key="trend_location",
                    help="Location for specific trend analysis"
                )
                
                # Filter data for selected location
                location_data = filtered_data[filtered_data['Location'] == selected_location]
                
                # Create and display the location-specific trend
                if not location_data.empty and all(col in location_data.columns for col in ['Date', 'Activity_Level']):
                    loc_trend_fig = create_trend_analysis_chart(
                        location_data, 
                        period=trend_period, 
                        title=f"{selected_location} Activity Trend"
                    )
                    st.plotly_chart(loc_trend_fig, use_container_width=True)
                else:
                    st.warning(f"Insufficient data for trend analysis of {selected_location}")
            else:
                st.info("No location data available for trend analysis")
        
        # Seasonality and patterns
        st.subheader("Seasonality and Patterns")
        
        # Parameters for seasonality analysis
        pattern_type = st.selectbox(
            "Pattern Type",
            ["Daily", "Weekly", "Monthly", "Quarterly"],
            index=1,
            key="pattern_type",
            help="Type of cyclical pattern to analyze"
        )
        
        # Create and display the seasonality analysis
        if filtered_data is not None and not filtered_data.empty:
            if all(col in filtered_data.columns for col in ['Date', 'Activity_Level']):
                # This would be calculated differently based on pattern_type
                # For now, we'll use a simplified approach
                st.info("Seasonality analysis is a premium feature (not implemented in demo)")
                
                # Placeholder for seasonality chart
                st.write("Placeholder for seasonality analysis visualization")
            else:
                st.warning("Seasonality analysis requires data with Date and Activity_Level")
        else:
            st.info("No data available for seasonality analysis")
    
    # Statistical Summary tab
    with analytics_tabs[2]:
        st.subheader("📊 Statistical Summary")
        
        st.markdown("""
        Statistical summaries provide key metrics and distributions that characterize
        the activity patterns across different locations and time periods.
        """)
        
        # Overall statistics
        st.subheader("Overall Statistics")
        
        if filtered_data is not None and not filtered_data.empty:
            if 'Activity_Level' in filtered_data.columns:
                # Basic statistics
                stats = filtered_data['Activity_Level'].describe().to_dict()
                
                # Format statistics for display
                stat_col1, stat_col2, stat_col3, stat_col4 = st.columns(4)
                stat_col1.metric("Mean", f"{stats['mean']:.2f}")
                stat_col2.metric("Median", f"{stats['50%']:.2f}")
                stat_col3.metric("Std Dev", f"{stats['std']:.2f}")
                stat_col4.metric("Max", f"{stats['max']:.2f}")
                
                # Create and display statistical distribution
                stat_fig = create_statistical_summary_chart(filtered_data)
                st.plotly_chart(stat_fig, use_container_width=True)
            else:
                st.warning("Statistical summary requires data with Activity_Level")
        else:
            st.info("No data available for statistical summary")
        
        # Location comparisons
        st.subheader("Location Statistical Comparisons")
        
        if filtered_data is not None and not filtered_data.empty:
            if all(col in filtered_data.columns for col in ['Location', 'Activity_Level']):
                # Group by location and calculate statistics
                loc_stats = filtered_data.groupby('Location')['Activity_Level'].agg(['mean', 'median', 'std', 'max']).reset_index()
                
                # Display statistics table
                st.dataframe(loc_stats.sort_values('mean', ascending=False), use_container_width=True)
                
                # Select locations to compare
                top_locations = loc_stats.nlargest(5, 'mean')['Location'].tolist()
                
                selected_locs = st.multiselect(
                    "Select Locations to Compare",
                    filtered_data['Location'].unique(),
                    default=top_locations[:min(3, len(top_locations))],
                    key="stat_locations",
                    help="Select locations to include in the comparison"
                )
                
                if selected_locs:
                    # Filter data for selected locations
                    comp_data = filtered_data[filtered_data['Location'].isin(selected_locs)]
                    
                    # Create and display comparison chart
                    comp_fig = px.box(
                        comp_data, 
                        x='Location', 
                        y='Activity_Level', 
                        title="Activity Level Distribution by Location",
                        color='Location'
                    )
                    
                    # Set theme-specific colors
                    theme = get_theme_settings()
                    comp_fig.update_layout(
                        plot_bgcolor=theme['plot_bgcolor'],
                        paper_bgcolor=theme['paper_bgcolor'],
                        font=dict(color=theme['textcolor']),
                        xaxis=dict(gridcolor=theme['gridcolor']),
                        yaxis=dict(gridcolor=theme['gridcolor'])
                    )
                    
                    st.plotly_chart(comp_fig, use_container_width=True)
                else:
                    st.info("Select locations to display comparison chart")
            else:
                st.warning("Location comparison requires data with Location and Activity_Level")
        else:
            st.info("No data available for location comparison")
    
    # Comparative Analysis tab
    with analytics_tabs[3]:
        st.subheader("🔍 Comparative Analysis")
        
        st.markdown("""
        Comparative analysis allows you to analyze how different locations or time periods
        compare to each other across various metrics.
        """)
        
        # Select comparison type
        comparison_type = st.selectbox(
            "Comparison Type",
            ["Location vs. Location", "Time Period vs. Time Period", "Metric vs. Metric"],
            index=0,
            key="comparison_type",
            help="Type of comparison to perform"
        )
        
        if comparison_type == "Location vs. Location":
            # Location comparison
            if filtered_data is not None and not filtered_data.empty and 'Location' in filtered_data.columns:
                locations = filtered_data['Location'].unique()
                
                # Select locations to compare
                loc1, loc2 = st.columns(2)
                with loc1:
                    location1 = st.selectbox(
                        "Location 1",
                        locations,
                        index=0,
                        key="comp_loc1"
                    )
                with loc2:
                    # Default to second location or first if only one location
                    default_idx = min(1, len(locations)-1)
                    location2 = st.selectbox(
                        "Location 2",
                        locations,
                        index=default_idx,
                        key="comp_loc2"
                    )
                
                # Create and display comparison chart
                if location1 != location2:
                    loc_comp_fig = create_activity_comparison_chart(
                        filtered_data, 
                        location1, 
                        location2
                    )
                    st.plotly_chart(loc_comp_fig, use_container_width=True)
                else:
                    st.warning("Please select different locations for comparison")
            else:
                st.info("No location data available for comparison")
                
        elif comparison_type == "Time Period vs. Time Period":
            # Time period comparison
            if filtered_data is not None and not filtered_data.empty and 'Date' in filtered_data.columns:
                # Select time periods
                period_options = ["Last 7 days", "Last 30 days", "Last 90 days", "Last 180 days", "Custom"]
                
                selected_period = st.selectbox(
                    "Select Comparison Periods",
                    period_options,
                    index=1,
                    key="comp_period_type"
                )
                
                if selected_period == "Custom":
                    # Custom date ranges
                    period1, period2 = st.columns(2)
                    with period1:
                        st.write("Period 1:")
                        start1 = st.date_input("Start Date 1", value=datetime.now() - timedelta(days=60), key="p1_start")
                        end1 = st.date_input("End Date 1", value=datetime.now() - timedelta(days=30), key="p1_end")
                    
                    with period2:
                        st.write("Period 2:")
                        start2 = st.date_input("Start Date 2", value=datetime.now() - timedelta(days=30), key="p2_start")
                        end2 = st.date_input("End Date 2", value=datetime.now(), key="p2_end")
                else:
                    # Predefined periods
                    if selected_period == "Last 7 days":
                        days = 7
                    elif selected_period == "Last 30 days":
                        days = 30
                    elif selected_period == "Last 90 days":
                        days = 90
                    else:  # Last 180 days
                        days = 180
                    
                    # Set up two consecutive periods of equal length
                    end2 = datetime.now()
                    start2 = end2 - timedelta(days=days)
                    end1 = start2
                    start1 = end1 - timedelta(days=days)
                
                # Convert dates to pandas datetime for filtering
                start1 = pd.to_datetime(start1)
                end1 = pd.to_datetime(end1)
                start2 = pd.to_datetime(start2)
                end2 = pd.to_datetime(end2)
                
                # Filter data for each period
                period1_data = filtered_data[(filtered_data['Date'] >= start1) & (filtered_data['Date'] <= end1)]
                period2_data = filtered_data[(filtered_data['Date'] >= start2) & (filtered_data['Date'] <= end2)]
                
                # Display period information
                st.info(f"Period 1: {start1.strftime('%Y-%m-%d')} to {end1.strftime('%Y-%m-%d')} ({len(period1_data)} records)")
                st.info(f"Period 2: {start2.strftime('%Y-%m-%d')} to {end2.strftime('%Y-%m-%d')} ({len(period2_data)} records)")
                
                # Create and display comparison
                if not period1_data.empty and not period2_data.empty:
                    # Calculate summary statistics for comparison
                    p1_avg = period1_data['Activity_Level'].mean() if 'Activity_Level' in period1_data.columns else 0
                    p2_avg = period2_data['Activity_Level'].mean() if 'Activity_Level' in period2_data.columns else 0
                    
                    # Calculate percent change
                    if p1_avg > 0:
                        pct_change = ((p2_avg - p1_avg) / p1_avg) * 100
                        arrow = "↑" if pct_change >= 0 else "↓"
                        change_color = "green" if pct_change >= 0 else "red"
                    else:
                        pct_change = 0
                        arrow = ""
                        change_color = "gray"
                    
                    # Display metrics
                    col1, col2, col3 = st.columns(3)
                    col1.metric("Period 1 Avg Activity", f"{p1_avg:.2f}")
                    col2.metric("Period 2 Avg Activity", f"{p2_avg:.2f}")
                    col3.markdown(f"<h1 style='text-align: center; color: {change_color};'>{arrow} {abs(pct_change):.1f}%</h1>", unsafe_allow_html=True)
                    
                    # Note: In a real implementation, we would create more detailed comparison visualizations
                    st.write("Additional comparison visualizations would be implemented here")
                else:
                    st.warning("Insufficient data for one or both periods")
            else:
                st.info("No date-based data available for period comparison")
                
        elif comparison_type == "Metric vs. Metric":
            st.info("Metric vs. Metric comparison is a premium feature (not implemented in demo)")
        
        # Additional comparative visualizations could be added here

# OSINT Analysis View
elif app_mode == "OSINT Analysis" and new_features_available:
    st.header("🔍 OSINT Analysis")
    
    st.markdown("""
    This section provides tools for analyzing Open Source Intelligence (OSINT) data,
    including social media monitoring, news sources, and custom data integration.
    """)
    
    # Create tabs for different OSINT tools
    osint_tabs = st.tabs([
        "OSINT Dashboard", 
        "Shodan Infrastructure", 
        "Social Media Monitor",
        "Web Content Analysis"
    ])
    
    # OSINT Dashboard tab
    with osint_tabs[0]:
        st.subheader("🔍 OSINT Dashboard")
        
        st.markdown("""
        The OSINT Dashboard provides an overview of intelligence gathered from various
        open sources, with options to filter and visualize the data.
        """)
        
        # OSINT Filters
        filter_col1, filter_col2, filter_col3 = st.columns(3)
        
        with filter_col1:
            # Excel OSINT data would be loaded here in a real implementation
            # For the demo, we'll just show a sample
            sample_data_loaded = st.checkbox("Load Sample OSINT Data", value=st.session_state.sample_data_loaded)
            
            if sample_data_loaded and not st.session_state.sample_data_loaded:
                # Load sample data when checkbox is first checked
                with st.spinner("Loading sample OSINT data..."):
                    # Create sample OSINT data
                    import random
                    
                    # Locations
                    locations = [
                        "New York, NY", "Los Angeles, CA", "Chicago, IL", "Houston, TX", 
                        "Miami, FL", "Seattle, WA", "Boston, MA", "San Francisco, CA",
                        "Denver, CO", "Atlanta, GA", "Dallas, TX", "Phoenix, AZ"
                    ]
                    
                    # Incident types
                    incident_types = [
                        "Infrastructure Outage", "Natural Disaster", "Security Incident",
                        "Transportation Disruption", "Public Event", "Regulatory Change",
                        "Supply Chain Issue", "Market Disruption"
                    ]
                    
                    # Generate dates in the last 90 days
                    end_date = datetime.now()
                    start_date = end_date - timedelta(days=90)
                    date_range = (end_date - start_date).days
                    
                    # Generate sample data
                    num_records = 200
                    data = []
                    
                    for i in range(num_records):
                        # Random date in the range
                        record_date = start_date + timedelta(days=random.randint(0, date_range))
                        
                        # Random location
                        location = random.choice(locations)
                        
                        # Split location into city and state
                        city, state = location.split(", ")
                        
                        # Random incident type
                        incident_type = random.choice(incident_types)
                        
                        # Random metrics
                        activity_level = random.randint(1, 10)
                        
                        # Random numbers of people affected
                        injured = random.randint(0, 5) if random.random() < 0.3 else 0
                        dead = random.randint(0, 2) if random.random() < 0.1 else 0
                        arrested = random.randint(0, 3) if random.random() < 0.2 else 0
                        
                        # Generate sample content
                        content = f"A {incident_type.lower()} was reported in {location} on {record_date.strftime('%Y-%m-%d')}. "
                        if injured > 0:
                            content += f"{injured} people were reported injured. "
                        if dead > 0:
                            content += f"{dead} fatalities were reported. "
                        if arrested > 0:
                            content += f"{arrested} people were arrested. "
                        
                        # Random coordinates near the city
                        # These are very approximate for demo purposes
                        base_coords = {
                            "New York": (40.7128, -74.0060),
                            "Los Angeles": (34.0522, -118.2437),
                            "Chicago": (41.8781, -87.6298),
                            "Houston": (29.7604, -95.3698),
                            "Miami": (25.7617, -80.1918),
                            "Seattle": (47.6062, -122.3321),
                            "Boston": (42.3601, -71.0589),
                            "San Francisco": (37.7749, -122.4194),
                            "Denver": (39.7392, -104.9903),
                            "Atlanta": (33.7490, -84.3880),
                            "Dallas": (32.7767, -96.7970),
                            "Phoenix": (33.4484, -112.0740)
                        }
                        
                        base_lat, base_lon = base_coords.get(city, (0, 0))
                        lat_offset = random.uniform(-0.1, 0.1)
                        lon_offset = random.uniform(-0.1, 0.1)
                        latitude = base_lat + lat_offset
                        longitude = base_lon + lon_offset
                        
                        # Add the record
                        data.append({
                            "Date": record_date,
                            "Source": "Sample OSINT",
                            "Location": location,
                            "City": city,
                            "State": state,
                            "Country": "USA",
                            "osint_incident type": incident_type,
                            "Content": content,
                            "osint_latitude": latitude,
                            "osint_longitude": longitude,
                            "Activity_Level": activity_level,
                            "osint_injured": injured,
                            "osint_dead": dead,
                            "osint_arrested": arrested
                        })
                    
                    # Create DataFrame
                    osint_df = pd.DataFrame(data)
                    
                    # Sort by date
                    osint_df.sort_values("Date", ascending=False, inplace=True)
                    
                    # Store in session state
                    st.session_state.excel_osint_data = osint_df
                    st.session_state.sample_data_loaded = True
                    
                    st.success(f"Loaded {len(osint_df)} sample OSINT records")
                
            elif not sample_data_loaded:
                st.session_state.sample_data_loaded = False
                st.session_state.excel_osint_data = None
        
        with filter_col2:
            # Location filter
            if st.session_state.excel_osint_data is not None:
                locations = st.session_state.excel_osint_data['City'].unique()
                selected_city = st.selectbox(
                    "Filter by City",
                    ["All Cities"] + list(locations),
                    index=0,
                    key="osint_city_filter"
                )
            else:
                st.info("Load OSINT data to enable location filtering")
                selected_city = "All Cities"
        
        with filter_col3:
            # Date range filter
            if st.session_state.excel_osint_data is not None:
                date_options = ["Last 7 days", "Last 30 days", "Last 90 days", "All time", "Custom range"]
                date_filter = st.selectbox(
                    "Date Range",
                    date_options,
                    index=1,
                    key="osint_date_filter"
                )
                
                if date_filter == "Custom range":
                    # Custom date picker
                    min_date = st.session_state.excel_osint_data['Date'].min().date()
                    max_date = st.session_state.excel_osint_data['Date'].max().date()
                    
                    custom_dates = st.date_input(
                        "Select date range",
                        value=[min_date, max_date],
                        min_value=min_date,
                        max_value=max_date,
                        key="osint_custom_dates"
                    )
                    
                    if len(custom_dates) == 2:
                        start_date = pd.to_datetime(custom_dates[0])
                        end_date = pd.to_datetime(custom_dates[1])
                    else:
                        start_date = pd.to_datetime(min_date)
                        end_date = pd.to_datetime(max_date)
                else:
                    # Predefined ranges
                    end_date = pd.to_datetime(datetime.now())
                    
                    if date_filter == "Last 7 days":
                        start_date = end_date - timedelta(days=7)
                    elif date_filter == "Last 30 days":
                        start_date = end_date - timedelta(days=30)
                    elif date_filter == "Last 90 days":
                        start_date = end_date - timedelta(days=90)
                    else:  # All time
                        start_date = pd.to_datetime(st.session_state.excel_osint_data['Date'].min())
            else:
                start_date = None
                end_date = None
                st.info("Load OSINT data to enable date filtering")
        
        # OSINT Dashboard content
        if st.session_state.excel_osint_data is not None and not st.session_state.excel_osint_data.empty:
            # Filter the data based on selections
            filtered_osint = st.session_state.excel_osint_data.copy()
            
            if selected_city != "All Cities":
                filtered_osint = filtered_osint[filtered_osint['City'] == selected_city]
            
            if start_date is not None and end_date is not None:
                filtered_osint = filtered_osint[(filtered_osint['Date'] >= start_date) & (filtered_osint['Date'] <= end_date)]
            
            # Display summary metrics
            metrics_col1, metrics_col2, metrics_col3, metrics_col4 = st.columns(4)
            
            metrics_col1.metric("Total Incidents", len(filtered_osint))
            
            # Calculate total incidents by type
            if not filtered_osint.empty and 'osint_incident type' in filtered_osint.columns:
                top_type = filtered_osint['osint_incident type'].value_counts().idxmax()
                type_count = filtered_osint['osint_incident type'].value_counts().max()
                metrics_col2.metric("Top Incident Type", f"{top_type} ({type_count})")
            else:
                metrics_col2.metric("Top Incident Type", "N/A")
            
            # Calculate total affected people
            if not filtered_osint.empty:
                total_injured = filtered_osint['osint_injured'].sum() if 'osint_injured' in filtered_osint.columns else 0
                total_casualties = filtered_osint['osint_dead'].sum() if 'osint_dead' in filtered_osint.columns else 0
                metrics_col3.metric("Total Injured", total_injured)
                metrics_col4.metric("Total Casualties", total_casualties)
            else:
                metrics_col3.metric("Total Injured", 0)
                metrics_col4.metric("Total Casualties", 0)
            
            # Create OSINT dashboard
            st.write("### OSINT Map and Analysis")
            
            # Create map and charts
            osint_col1, osint_col2 = st.columns([3, 2])
            
            with osint_col1:
                if not filtered_osint.empty and all(col in filtered_osint.columns for col in ['osint_latitude', 'osint_longitude']):
                    map_data = filtered_osint.copy()
                    map_data['Latitude'] = pd.to_numeric(map_data['osint_latitude'], errors='coerce')
                    map_data['Longitude'] = pd.to_numeric(map_data['osint_longitude'], errors='coerce')
                    map_data = map_data.dropna(subset=['Latitude', 'Longitude'])
                    
                    # For hover info, make sure all necessary columns exist
                    for col in ['Date', 'Location', 'osint_incident type']:
                        if col not in map_data.columns:
                            map_data[col] = "Unknown"
                    
                    # Add hover text
                    map_data['hover_text'] = map_data.apply(
                        lambda row: f"{row['Location']}<br>{row['Date'].strftime('%Y-%m-%d')}<br>{row['osint_incident type']}",
                        axis=1
                    )
                    
                    # Create and display the map
                    osint_map = px.scatter_mapbox(
                        map_data, 
                        lat='Latitude', 
                        lon='Longitude',
                        hover_name='Location',
                        hover_data={'Latitude': False, 'Longitude': False, 'hover_text': True},
                        color='osint_incident type' if 'osint_incident type' in map_data.columns else None,
                        size='Activity_Level' if 'Activity_Level' in map_data.columns else None,
                        size_max=15,
                        zoom=3,
                        height=500
                    )
                    
                    # Update map layout
                    theme = get_theme_settings()
                    osint_map.update_layout(
                        mapbox_style="carto-darkmatter" if st.session_state.dark_mode else "carto-positron",
                        margin={"r":0,"t":0,"l":0,"b":0},
                        paper_bgcolor=theme['paper_bgcolor'],
                        hoverlabel=dict(
                            bgcolor="#1f1f1f" if st.session_state.dark_mode else "white",
                            font_size=12,
                            font_family="Arial"
                        )
                    )
                    
                    st.plotly_chart(osint_map, use_container_width=True)
                else:
                    st.warning("OSINT data does not contain valid location coordinates")
            
            with osint_col2:
                if not filtered_osint.empty:
                    # Incident type breakdown
                    if 'osint_incident type' in filtered_osint.columns:
                        type_counts = filtered_osint['osint_incident type'].value_counts().reset_index()
                        type_counts.columns = ['Type', 'Count']
                        
                        # Create pie chart
                        theme = get_theme_settings()
                        type_fig = px.pie(
                            type_counts, 
                            values='Count', 
                            names='Type',
                            title='Incident Types',
                            hole=0.4
                        )
                        
                        type_fig.update_layout(
                            paper_bgcolor=theme['paper_bgcolor'],
                            plot_bgcolor=theme['plot_bgcolor'],
                            font=dict(color=theme['textcolor']),
                            margin=dict(l=10, r=10, t=40, b=10),
                            legend=dict(
                                orientation="h",
                                yanchor="bottom",
                                y=-0.3,
                                xanchor="center",
                                x=0.5
                            )
                        )
                        
                        st.plotly_chart(type_fig, use_container_width=True)
                    
                    # Incidents over time
                    if 'Date' in filtered_osint.columns:
                        # Group by date and count incidents
                        time_data = filtered_osint.copy()
                        time_data['Date'] = pd.to_datetime(time_data['Date']).dt.date
                        daily_counts = time_data.groupby('Date').size().reset_index(name='Count')
                        daily_counts['Date'] = pd.to_datetime(daily_counts['Date'])
                        
                        # Create line chart
                        theme = get_theme_settings()
                        time_fig = px.line(
                            daily_counts, 
                            x='Date', 
                            y='Count',
                            title='Incidents Over Time'
                        )
                        
                        time_fig.update_layout(
                            paper_bgcolor=theme['paper_bgcolor'],
                            plot_bgcolor=theme['plot_bgcolor'],
                            font=dict(color=theme['textcolor']),
                            xaxis=dict(gridcolor=theme['gridcolor']),
                            yaxis=dict(gridcolor=theme['gridcolor']),
                            margin=dict(l=10, r=10, t=40, b=10)
                        )
                        
                        st.plotly_chart(time_fig, use_container_width=True)
                else:
                    st.info("No data available for the selected filters")
            
            # Data table with pagination
            st.write("### OSINT Data Records")
            
            if not filtered_osint.empty:
                # Set up pagination
                page_size = 10
                total_pages = len(filtered_osint) // page_size + (1 if len(filtered_osint) % page_size > 0 else 0)
                
                # Create three columns for pagination controls
                pg_col1, pg_col2, pg_col3 = st.columns([1, 3, 1])
                
                # Previous button
                if 'osint_page' not in st.session_state:
                    st.session_state.osint_page = 1
                
                with pg_col1:
                    if st.button("◀ Previous", key="osint_prev", disabled=st.session_state.osint_page <= 1):
                        st.session_state.osint_page -= 1
                
                # Page selector
                with pg_col2:
                    page_options = [f"Page {i+1} of {total_pages}" for i in range(total_pages)]
                    page_index = st.session_state.osint_page - 1
                    
                    if page_index >= len(page_options):
                        page_index = 0
                        st.session_state.osint_page = 1
                    
                    selected_page = st.selectbox(
                        "",
                        page_options,
                        index=page_index,
                        key="osint_page_select"
                    )
                    
                    # Update page based on selection
                    new_page = int(selected_page.split(" ")[1])
                    if new_page != st.session_state.osint_page:
                        st.session_state.osint_page = new_page
                
                # Next button
                with pg_col3:
                    if st.button("Next ▶", key="osint_next", disabled=st.session_state.osint_page >= total_pages):
                        st.session_state.osint_page += 1
                
                # Get paginated data
                start_idx = (st.session_state.osint_page - 1) * page_size
                end_idx = start_idx + page_size
                paginated_data = filtered_osint.iloc[start_idx:end_idx].copy()
                
                # Format date column for display
                if 'Date' in paginated_data.columns:
                    paginated_data['Date'] = paginated_data['Date'].dt.strftime('%Y-%m-%d')
                
                # Choose columns to display
                display_cols = [
                    'Date', 'Location', 'osint_incident type', 'Content',
                    'osint_injured', 'osint_dead', 'osint_arrested'
                ]
                
                # Filter to only include columns that exist
                display_cols = [col for col in display_cols if col in paginated_data.columns]
                
                # Rename columns for display
                display_data = paginated_data[display_cols].copy()
                display_data.columns = [col.replace('osint_', '').title() for col in display_cols]
                
                # Show the data
                st.dataframe(display_data, use_container_width=True)
                
                # Export options
                export_col1, export_col2 = st.columns(2)
                
                with export_col1:
                    # Export to CSV
                    csv_data = filtered_osint.to_csv(index=False)
                    st.download_button(
                        "Export to CSV",
                        data=csv_data,
                        file_name="osint_data.csv",
                        mime="text/csv"
                    )
                
                with export_col2:
                    # Export to JSON
                    json_data = filtered_osint.to_json(orient="records", date_format="iso")
                    st.download_button(
                        "Export to JSON",
                        data=json_data,
                        file_name="osint_data.json",
                        mime="application/json"
                    )
            else:
                st.info("No data available for the selected filters")
        else:
            st.info("Load OSINT data to view the dashboard")
            
            # Show sample screenshot
            st.write("### Sample OSINT Dashboard")
            st.info("The OSINT dashboard provides powerful tools for analyzing open-source intelligence data, including interactive maps, charts, and data tables.")
            
            # In a real implementation, you would include a sample screenshot here
            st.image("attached_assets/image_1746616764975.png", caption="Sample OSINT Dashboard (for illustration only)")
    
    # Shodan Infrastructure tab
    with osint_tabs[1]:
        st.subheader("🌐 Shodan Infrastructure Analysis")
        
        st.markdown("""
        Shodan infrastructure analysis provides insights into internet-connected devices, servers,
        and services within specific geographic areas or organizations.
        """)
        
        # Shodan setup
        shodan_col1, shodan_col2 = st.columns([1, 2])
        
        with shodan_col1:
            st.write("### Shodan API Setup")
            
            # API Key input
            shodan_api_key = st.text_input(
                "Shodan API Key",
                type="password",
                help="Enter your Shodan API key to access infrastructure data"
            )
            
            if shodan_api_key:
                try:
                    # Initialize Shodan API client
                    shodan_client = ShodanIntegration()
                    
                    # Configure with API key
                    if shodan_client.configure(shodan_api_key):
                        st.success("Shodan API configured successfully")
                    else:
                        st.error("Failed to configure Shodan API client")
                except Exception as e:
                    st.error(f"Error initializing Shodan client: {str(e)}")
                    shodan_client = None
            else:
                st.info("Enter a Shodan API key to access infrastructure data")
                shodan_client = None
            
            # Location input for search
            st.write("### Location Search")
            shodan_city = st.text_input("City", placeholder="e.g., New York")
            shodan_state = st.text_input("State", placeholder="e.g., NY")
            shodan_country = st.text_input("Country", value="US")
            
            # Search button
            if st.button("Search Shodan", disabled=shodan_client is None or not shodan_city):
                if shodan_client is not None and shodan_city:
                    try:
                        with st.spinner(f"Searching Shodan for infrastructure in {shodan_city}..."):
                            # This would use the actual Shodan API in a real implementation
                            # For the demo, we'll just show a placeholder message
                            st.info("This is a demo. In a real implementation, this would search Shodan for infrastructure information.")
                            
                            # Analyze infrastructure
                            infrastructure_analysis = shodan_client.analyze_infrastructure(
                                city=shodan_city,
                                state=shodan_state,
                                country=shodan_country
                            )
                            
                            if infrastructure_analysis:
                                st.session_state.shodan_results = infrastructure_analysis
                                st.success(f"Found infrastructure information for {shodan_city}")
                            else:
                                st.warning(f"No results found for {shodan_city}")
                                st.session_state.shodan_results = None
                    except Exception as e:
                        st.error(f"Error searching Shodan: {str(e)}")
                        st.session_state.shodan_results = None
        
        with shodan_col2:
            st.write("### Infrastructure Insights")
            
            if 'shodan_results' in st.session_state and st.session_state.shodan_results:
                # Create visualizations from the results
                result_city = shodan_city or "the selected location"
                visualizations = create_shodan_visualization(st.session_state.shodan_results, result_city)
                
                # Display the visualizations
                if visualizations:
                    for viz_name, fig in visualizations.items():
                        st.write(f"#### {viz_name}")
                        st.plotly_chart(fig, use_container_width=True)
                else:
                    st.info("No visualization data available")
                
                # Display raw results in an expandable section
                with st.expander("Raw Shodan Data"):
                    st.json(st.session_state.shodan_results)
            else:
                st.info("Search for a location to view infrastructure insights")
                
                # Show sample results for demonstration
                st.write("#### Sample Infrastructure Visualization")
                st.image("attached_assets/image_1746618988366.png", caption="Sample Shodan Infrastructure Analysis")
    
    # Social Media Monitor tab
    with osint_tabs[2]:
        st.subheader("📱 Social Media Monitoring")
        
        st.markdown("""
        Social media monitoring allows you to track mentions, hashtags, and discussions
        related to specific locations or topics across various social platforms.
        """)
        
        # API configuration section
        st.write("### API Configuration")
        api_tabs = st.tabs(["Twitter API", "Other Platforms"])
        
        with api_tabs[0]:
            st.write("#### Twitter API Setup")
            
            twitter_col1, twitter_col2 = st.columns(2)
            
            with twitter_col1:
                twitter_api_key = st.text_input("Twitter API Key", type="password")
                twitter_api_secret = st.text_input("Twitter API Secret", type="password")
            
            with twitter_col2:
                twitter_access_token = st.text_input("Access Token", type="password")
                twitter_access_secret = st.text_input("Access Token Secret", type="password")
            
            if all([twitter_api_key, twitter_api_secret, twitter_access_token, twitter_access_secret]):
                st.success("Twitter API credentials entered. Ready to use Twitter monitoring.")
            else:
                st.info("Enter Twitter API credentials to enable social media monitoring")
        
        with api_tabs[1]:
            st.info("Configuration for additional social media platforms will be available in future updates")
        
        # Search and monitor section
        st.write("### Search and Monitor")
        
        social_col1, social_col2 = st.columns([1, 1])
        
        with social_col1:
            search_term = st.text_input("Search Term or Hashtag", placeholder="e.g., #Chicago or 'New York infrastructure'")
            search_platform = st.selectbox("Platform", ["Twitter", "All Platforms"])
            
            # Date range for search
            search_period = st.selectbox("Time Period", ["Last 24 hours", "Last 7 days", "Last 30 days"])
            
            if st.button("Search Social Media", disabled=not search_term):
                # This would use actual API calls in a real implementation
                st.info("This is a demo. In a real implementation, this would search social media platforms.")
                
                # For demo purposes, show a sample result
                if search_term:
                    # Create a sample result set
                    st.session_state.social_results = {
                        "term": search_term,
                        "platform": search_platform,
                        "period": search_period,
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "message": "Sample search results would appear here."
                    }
                    
                    st.success(f"Search completed for '{search_term}'")
                else:
                    st.warning("Please enter a search term")
        
        with social_col2:
            st.write("#### Saved Searches")
            
            # Display saved searches
            if 'saved_search_terms' in st.session_state and st.session_state.saved_search_terms:
                for i, term in enumerate(st.session_state.saved_search_terms):
                    col1, col2 = st.columns([3, 1])
                    with col1:
                        st.write(f"• {term}")
                    with col2:
                        if st.button("Remove", key=f"remove_search_{i}"):
                            st.session_state.saved_search_terms.remove(term)
                            st.experimental_rerun()
            else:
                st.info("No saved searches")
            
            # Save current search
            if search_term and st.button("Save This Search"):
                if search_term not in st.session_state.saved_search_terms:
                    st.session_state.saved_search_terms.append(search_term)
                    st.success(f"Saved search for '{search_term}'")
                else:
                    st.info(f"'{search_term}' is already saved")
        
        # Results display
        st.write("### Monitoring Results")
        
        if 'social_results' in st.session_state and st.session_state.social_results:
            # Display search information
            result_info = st.session_state.social_results
            st.info(f"Results for '{result_info['term']}' on {result_info['platform']} ({result_info['period']})")
            
            # In a real implementation, this would display actual social media posts
            st.write("#### Sample Search Results")
            
            # Show sample results for demonstration
            st.image("attached_assets/image_1746619098839.png", caption="Sample Social Media Monitoring Dashboard")
        else:
            st.info("Perform a search to view social media monitoring results")
    
    # Web Content Analysis tab
    with osint_tabs[3]:
        st.subheader("🌐 Web Content Analysis")
        
        st.markdown("""
        Web content analysis allows you to extract, process, and analyze content from
        websites relevant to your locations of interest.
        """)
        
        # Web scraper initialization
        if 'web_scraper' not in st.session_state:
            try:
                # Initialize the web scraper
                st.session_state.web_scraper = WebScraperDataSource()
                
                # Initialize OSINT analyzer
                st.session_state.osint_analyzer = OSINTAnalyzer()
            except Exception as e:
                st.error(f"Error initializing web scraper: {str(e)}")
                st.session_state.web_scraper = None
                st.session_state.osint_analyzer = None
        
        # Web content analysis interface
        web_col1, web_col2 = st.columns([2, 1])
        
        with web_col1:
            st.write("### URL Analysis")
            
            # URL input
            url_to_analyze = st.text_input("Enter URL to analyze", placeholder="https://example.com/news/article")
            
            # Analysis options
            analysis_options = st.multiselect(
                "Analysis Options",
                ["Extract main content", "Analyze sentiment", "Identify entities", "Resolve redirects"],
                default=["Extract main content", "Analyze sentiment"]
            )
            
            # Process button
            if st.button("Analyze URL", disabled=not url_to_analyze):
                if url_to_analyze and st.session_state.web_scraper:
                    try:
                        with st.spinner(f"Analyzing {url_to_analyze}..."):
                            # Call web scraper to get content
                            scraper_result = st.session_state.web_scraper.get_website_content(url_to_analyze)
                            
                            if scraper_result and scraper_result.get('content'):
                                # Store in session state
                                st.session_state.scraper_results[url_to_analyze] = scraper_result
                                
                                # Also add to saved URLs if not already there
                                if url_to_analyze not in st.session_state.saved_urls:
                                    st.session_state.saved_urls.append(url_to_analyze)
                                
                                # Add to search history with timestamp
                                st.session_state.search_history.append({
                                    'url': url_to_analyze,
                                    'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                    'title': scraper_result.get('title', 'Unknown')
                                })
                                
                                # Update last search time
                                st.session_state.last_search_time[url_to_analyze] = datetime.now()
                                
                                st.success(f"Successfully analyzed {url_to_analyze}")
                                
                                # If sentiment analysis was requested, perform it
                                if "Analyze sentiment" in analysis_options and st.session_state.osint_analyzer:
                                    with st.spinner("Performing sentiment analysis..."):
                                        # Analyze the content
                                        content_text = scraper_result.get('content', '')
                                        analysis_result = st.session_state.osint_analyzer.analyze_text(content_text)
                                        
                                        # Add to scraper results
                                        st.session_state.scraper_results[url_to_analyze]['analysis'] = analysis_result
                            else:
                                st.warning(f"No content found at {url_to_analyze}")
                    except Exception as e:
                        st.error(f"Error analyzing URL: {str(e)}")
            
            # Display results if available
            if url_to_analyze in st.session_state.scraper_results:
                result = st.session_state.scraper_results[url_to_analyze]
                
                # Display basic info
                st.write(f"### Analysis Results for: {result.get('title', url_to_analyze)}")
                
                # Meta information
                meta_col1, meta_col2, meta_col3 = st.columns(3)
                with meta_col1:
                    st.metric("Content Length", f"{len(result.get('content', ''))} chars")
                with meta_col2:
                    st.metric("Final URL", result.get('final_url', url_to_analyze).split('/')[2])
                with meta_col3:
                    if 'analysis' in result and 'sentiment_score' in result['analysis']:
                        sentiment = result['analysis']['sentiment_score']
                        st.metric("Sentiment", f"{sentiment:.2f}")
                    else:
                        st.metric("Sentiment", "N/A")
                
                # Content tabs
                result_tabs = st.tabs(["Content", "Metadata", "Analysis"])
                
                with result_tabs[0]:
                    # Main content
                    st.write("#### Extracted Content")
                    st.markdown(f"<div style='height: 300px; overflow-y: auto; padding: 10px; border: 1px solid #ddd; border-radius: 5px;'>{result.get('content', 'No content found')}</div>", unsafe_allow_html=True)
                
                with result_tabs[1]:
                    # Metadata information
                    st.write("#### Page Metadata")
                    
                    # Display metadata as a table
                    if 'metadata' in result:
                        metadata = result['metadata']
                        meta_df = pd.DataFrame(list(metadata.items()), columns=['Property', 'Value'])
                        st.dataframe(meta_df, use_container_width=True)
                    else:
                        st.info("No metadata available")
                
                with result_tabs[2]:
                    # Analysis results
                    st.write("#### Content Analysis")
                    
                    if 'analysis' in result:
                        analysis = result['analysis']
                        
                        # Sentiment visualization
                        if 'sentiment_score' in analysis:
                            sentiment = analysis['sentiment_score']
                            
                            # Create a gauge chart for sentiment
                            theme = get_theme_settings()
                            sentiment_fig = go.Figure(go.Indicator(
                                mode = "gauge+number",
                                value = sentiment,
                                domain = {'x': [0, 1], 'y': [0, 1]},
                                title = {'text': "Sentiment Score"},
                                gauge = {
                                    'axis': {'range': [-1, 1]},
                                    'bar': {'color': "blue"},
                                    'steps': [
                                        {'range': [-1, -0.5], 'color': "red"},
                                        {'range': [-0.5, 0], 'color': "orange"},
                                        {'range': [0, 0.5], 'color': "lightgreen"},
                                        {'range': [0.5, 1], 'color': "green"}
                                    ]
                                }
                            ))
                            
                            sentiment_fig.update_layout(
                                paper_bgcolor=theme['paper_bgcolor'],
                                font=dict(color=theme['textcolor']),
                                height=250
                            )
                            
                            st.plotly_chart(sentiment_fig, use_container_width=True)
                        
                        # Key entities
                        if 'entities' in analysis and analysis['entities']:
                            st.write("#### Identified Entities")
                            entities = analysis['entities']
                            
                            # Format entities into a displayable format
                            entities_df = pd.DataFrame(entities)
                            st.dataframe(entities_df, use_container_width=True)
                        
                        # Key phrases
                        if 'key_phrases' in analysis and analysis['key_phrases']:
                            st.write("#### Key Phrases")
                            phrases = analysis['key_phrases']
                            
                            # Display as pills/tags
                            html_tags = ""
                            for phrase in phrases:
                                html_tags += f'<span style="background-color: {"#1f1f1f" if st.session_state.dark_mode else "#f0f0f0"}; padding: 5px 10px; margin: 5px; border-radius: 15px; display: inline-block;">{phrase}</span>'
                            
                            st.markdown(f"<div style='margin: 10px 0;'>{html_tags}</div>", unsafe_allow_html=True)
                    else:
                        st.info("No analysis results available")
        
        with web_col2:
            st.write("### Saved URLs")
            
            # Display saved URLs
            if st.session_state.saved_urls:
                for i, url in enumerate(st.session_state.saved_urls):
                    # Get title if available
                    title = None
                    if url in st.session_state.scraper_results:
                        title = st.session_state.scraper_results[url].get('title')
                    
                    # Create an expandable section for each URL
                    with st.expander(title or url, expanded=False):
                        st.write(f"**URL:** {url}")
                        
                        # Show last analyzed time if available
                        if url in st.session_state.last_search_time:
                            last_time = st.session_state.last_search_time[url]
                            st.write(f"**Last analyzed:** {last_time.strftime('%Y-%m-%d %H:%M:%S')}")
                        
                        # Show analyze button
                        if st.button("Analyze Again", key=f"reanalyze_{i}"):
                            # Set the URL in the main input field and trigger a rerun
                            # In a real app, we would use JavaScript to update the input field
                            st.session_state.reanalyze_url = url
                            st.experimental_rerun()
                        
                        # Show remove button
                        if st.button("Remove URL", key=f"remove_url_{i}"):
                            st.session_state.saved_urls.remove(url)
                            if url in st.session_state.scraper_results:
                                del st.session_state.scraper_results[url]
                            st.experimental_rerun()
            else:
                st.info("No saved URLs")
            
            # Display search history
            st.write("### Recent Searches")
            
            if st.session_state.search_history:
                # Show the most recent searches (limit to last 5)
                recent_searches = st.session_state.search_history[-5:]
                for search in reversed(recent_searches):
                    st.write(f"• {search['title'] or search['url']} ({search['timestamp']})")
            else:
                st.info("No search history")
            
            # Clear history button
            if st.button("Clear History") and st.session_state.search_history:
                st.session_state.search_history = []
                st.success("Search history cleared")
    
    # Download OSINT data
    st.write("### Export OSINT Data")
    
    export_col1, export_col2 = st.columns(2)
    
    with export_col1:
        if st.session_state.excel_osint_data is not None and not st.session_state.excel_osint_data.empty:
            # Export to CSV
            csv_data = st.session_state.excel_osint_data.to_csv(index=False)
            st.download_button(
                "Export All OSINT Data (CSV)",
                data=csv_data,
                file_name="osint_data_export.csv",
                mime="text/csv"
            )
        else:
            st.info("No OSINT data available to export")
    
    with export_col2:
        if 'web_content_cache' in st.session_state and st.session_state.web_content_cache:
            # Export web content cache
            json_data = json.dumps({
                'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                'content_cache': str(st.session_state.web_content_cache)
            })
            st.download_button(
                "Export Web Analysis Cache (JSON)",
                data=json_data,
                file_name="web_analysis_cache.json",
                mime="application/json"
            )
        else:
            st.info("No web content analysis data to export")

# Data Sources Management
elif app_mode == "Data Sources" and new_features_available:
    st.header("📊 Data Sources Management")
    
    st.markdown("""
    This module allows you to manage and configure different data sources for your location analysis,
    including Excel files, web scraping, social media monitoring, and external APIs.
    """)
    
    # Import the KML handler module for Data Sources tabs
    from utils.kml_handler import (
        kml_to_dataframe, 
        dataframe_to_kml, 
        batch_geocode_addresses,
        geocode_address
    )
    
    # Initialize KML and address-related session state variables
    if 'kml_data' not in st.session_state:
        st.session_state.kml_data = None
    if 'address_data' not in st.session_state:
        st.session_state.address_data = None
    
    # Create tabs for different data sources
    data_sources_tabs = st.tabs([
        "Excel OSINT Data", 
        "KML Files", 
        "Address Geocoding", 
        "External APIs"
    ])
    
    with data_sources_tabs[0]:
        st.subheader("📁 Excel OSINT Data")
    
    with data_sources_tabs[1]:
        st.subheader("🌎 KML Files")
        
        st.markdown("""
        This section allows you to import and export location data in KML format, which is compatible with 
        Google Earth and other GIS applications. You can upload KML files to visualize location data on our maps,
        or export your data to KML format.
        """)
        
        # Upload KML file
        kml_tabs = st.tabs(["Import KML", "Export to KML"])
        
        with kml_tabs[0]:
            st.subheader("Import KML File")
            
            # Upload file
            st.info("In a production implementation, file upload would be enabled here")
            # In a real implementation, we would allow file upload:
            # uploaded_kml = st.file_uploader("Upload KML File", type=["kml"])
            
            # Instead, let's provide an example button
            if st.button("Load Sample KML Data"):
                # Create sample data
                sample_data = pd.DataFrame({
                    'Name': ['Port of Los Angeles', 'Port of Oakland', 'Port of Seattle'],
                    'Description': [
                        'Major port in Southern California',
                        'Major port in Northern California',
                        'Major port in Washington state'
                    ],
                    'Type': ['Port', 'Port', 'Port'],
                    'Latitude': [33.7395, 37.8044, 47.6062],
                    'Longitude': [-118.2610, -122.2711, -122.3321]
                })
                
                # Store in session state
                st.session_state.kml_data = sample_data
                st.success("Sample KML data loaded")
            
            # Display KML data if available
            if st.session_state.kml_data is not None:
                st.subheader("Imported Location Data")
                st.dataframe(st.session_state.kml_data, use_container_width=True)
                
                # Show on map
                if 'Latitude' in st.session_state.kml_data.columns and 'Longitude' in st.session_state.kml_data.columns:
                    st.subheader("Map View")
                    kml_map = create_map(st.session_state.kml_data)
                    st.plotly_chart(kml_map, use_container_width=True)
                    
        with kml_tabs[1]:
            st.subheader("Export Data to KML")
            
            export_options = st.radio(
                "Select data to export",
                ["Sample location data", "Current visible locations"],
                key="kml_export_option"
            )
            
            export_data = None
            
            if export_options == "Sample location data":
                # Use sample data
                if st.session_state.kml_data is None:
                    # Create sample data if none exists
                    export_data = pd.DataFrame({
                        'Name': ['Port of Los Angeles', 'Port of Oakland', 'Port of Seattle'],
                        'Description': [
                            'Major port in Southern California',
                            'Major port in Northern California',
                            'Major port in Washington state'
                        ],
                        'Type': ['Port', 'Port', 'Port'],
                        'Latitude': [33.7395, 37.8044, 47.6062],
                        'Longitude': [-118.2610, -122.2711, -122.3321]
                    })
                else:
                    export_data = st.session_state.kml_data
            else:
                # Use current visible locations (simplified for demo)
                if st.session_state.excel_osint_data is not None and not st.session_state.excel_osint_data.empty:
                    # Try to extract location data
                    excel_data = st.session_state.excel_osint_data
                    
                    if all(col in excel_data.columns for col in ['osint_latitude', 'osint_longitude']):
                        export_data = pd.DataFrame({
                            'Name': excel_data['Location'],
                            'Description': excel_data.get('Content', ''),
                            'Type': excel_data.get('osint_incident type', 'Incident'),
                            'Latitude': pd.to_numeric(excel_data['osint_latitude'], errors='coerce'),
                            'Longitude': pd.to_numeric(excel_data['osint_longitude'], errors='coerce')
                        })
                        export_data = export_data.dropna(subset=['Latitude', 'Longitude'])
            
            if export_data is not None and not export_data.empty:
                st.dataframe(export_data, use_container_width=True)
                
                # Generate KML button
                if st.button("Generate KML"):
                    # Would normally save to file, but for demo we'll just show success
                    kml_string = dataframe_to_kml(export_data)
                    
                    # In a real implementation, we would offer a download link:
                    # st.download_button("Download KML", kml_string, "locations.kml", "text/xml")
                    
                    # For the demo, just show success
                    st.success("KML file generated successfully")
                    
                    # Show a sample of the KML
                    with st.expander("View KML Sample"):
                        st.code(kml_string[:500] + "...", language="xml")
            else:
                st.warning("No location data available for export")
    
    with data_sources_tabs[2]:
        st.subheader("🧭 Address Geocoding")
        
        st.markdown("""
        This section allows you to convert addresses to geographic coordinates (latitude/longitude) and
        plot them on a map or export them as KML files for use in Google Earth. You can enter individual 
        addresses or paste a list of multiple addresses.
        """)
        
        # Create tabs for different geocoding options
        geocoding_tabs = st.tabs(["Single Address", "Multiple Addresses"])
        
        with geocoding_tabs[0]:
            st.subheader("Single Address Geocoding")
            
            # Input field for address
            address = st.text_input(
                "Enter an address to geocode",
                placeholder="e.g., 1600 Pennsylvania Ave NW, Washington, DC 20500"
            )
            
            if st.button("Geocode Address"):
                if address:
                    with st.spinner("Geocoding address..."):
                        # Geocode the address
                        coords = geocode_address(address)
                        
                        if coords:
                            lat, lon = coords
                            
                            # Create a dataframe for the map
                            address_df = pd.DataFrame({
                                'Name': ['Geocoded Address'],
                                'Description': [address],
                                'Type': ['Address'],
                                'Latitude': [lat],
                                'Longitude': [lon]
                            })
                            
                            # Store in session state
                            st.session_state.address_data = address_df
                            
                            # Show results
                            st.success(f"Address geocoded successfully: {lat}, {lon}")
                            
                            # Display on map
                            st.subheader("Map View")
                            address_map = create_map(address_df, zoom=10)
                            st.plotly_chart(address_map, use_container_width=True)
                            
                            # Option to export to KML
                            if st.button("Export to KML"):
                                kml_string = dataframe_to_kml(address_df)
                                
                                # In a real implementation, we would offer a download link:
                                # st.download_button("Download KML", kml_string, "address.kml", "text/xml")
                                
                                # For the demo, just show success
                                st.success("KML file generated for the address")
                                
                                # Show a sample of the KML
                                with st.expander("View KML Sample"):
                                    st.code(kml_string[:500] + "...", language="xml")
                        else:
                            st.error("Could not geocode the address. Please check the address and try again.")
                else:
                    st.warning("Please enter an address to geocode.")
                    
        with geocoding_tabs[1]:
            st.subheader("Batch Address Geocoding")
            
            # Text area for multiple addresses
            addresses_text = st.text_area(
                "Enter addresses (one per line)",
                placeholder="1600 Pennsylvania Ave NW, Washington, DC 20500\n123 Main St, Anytown, USA\n456 Oak Ave, Somewhere, ST 12345"
            )
            
            # Sample addresses button
            if st.button("Use Sample Addresses"):
                sample_addresses = """1600 Pennsylvania Ave NW, Washington, DC 20500
350 Fifth Avenue, New York, NY 10118
151 3rd St, San Francisco, CA 94103
100 Universal City Plaza, Universal City, CA 91608
401 Congress Ave, Austin, TX 78701"""
                # Use st.session_state to update the text area (in a real app would need JavaScript)
                st.session_state.sample_addresses = sample_addresses
                st.experimental_rerun()
            
            # Check if we have sample addresses in session state
            if "sample_addresses" in st.session_state:
                addresses_text = st.session_state.sample_addresses
            
            # Process button
            if st.button("Process Addresses"):
                if addresses_text:
                    # Split addresses into list
                    address_list = [addr.strip() for addr in addresses_text.split('\n') if addr.strip()]
                    
                    if address_list:
                        with st.spinner(f"Geocoding {len(address_list)} addresses..."):
                            # Geocode the addresses
                            geocoded_df = batch_geocode_addresses(address_list)
                            
                            # Store in session state
                            st.session_state.address_data = geocoded_df
                            
                            # Show results
                            st.success(f"Successfully geocoded {geocoded_df.dropna().shape[0]} out of {len(address_list)} addresses")
                            
                            # Show the dataframe
                            st.dataframe(geocoded_df, use_container_width=True)
                            
                            # Filter out failed geocodes
                            valid_df = geocoded_df.dropna(subset=['Latitude', 'Longitude'])
                            
                            if not valid_df.empty:
                                # Prepare for map
                                map_df = pd.DataFrame({
                                    'Name': [f"Location {i+1}" for i in range(len(valid_df))],
                                    'Description': valid_df['Address'],
                                    'Type': ['Address'] * len(valid_df),
                                    'Latitude': valid_df['Latitude'],
                                    'Longitude': valid_df['Longitude']
                                })
                                
                                # Display on map
                                st.subheader("Map View")
                                batch_map = create_map(map_df, zoom=3)
                                st.plotly_chart(batch_map, use_container_width=True)
                                
                                # Option to export to KML
                                if st.button("Export Batch to KML"):
                                    kml_string = dataframe_to_kml(map_df)
                                    
                                    # In a real implementation, we would offer a download link:
                                    # st.download_button("Download KML", kml_string, "batch_addresses.kml", "text/xml")
                                    
                                    # For the demo, just show success
                                    st.success("KML file generated for batch addresses")
                                    
                                    # Show a sample of the KML
                                    with st.expander("View KML Sample"):
                                        st.code(kml_string[:500] + "...", language="xml")
                    else:
                        st.warning("No addresses found in the input")
                else:
                    st.warning("Please enter at least one address")
    
    with data_sources_tabs[3]:
        st.subheader("🔌 External APIs")
        
        st.markdown("""
        Configure and manage external API connections for enhanced location analysis.
        This section allows you to set up and test various API integrations.
        """)
        
        # Create tabs for different API options
        api_tabs = st.tabs(["News API", "Twitter API", "Shodan API", "OpenCellID API"])
        
        with api_tabs[0]:
            st.subheader("📰 News API Integration")
            
            st.markdown("""
            Connect to news sources to gather location-relevant articles and information.
            """)
            
            # News API settings
            news_api_key = st.text_input("News API Key", type="password", help="Enter your News API key")
            
            # Test connection button
            if st.button("Test News API Connection", disabled=not news_api_key):
                if news_api_key:
                    with st.spinner("Testing News API connection..."):
                        # Simulate testing connection
                        st.success("Successfully connected to News API")
                        
                        # Store key in session state
                        if 'api_keys' not in st.session_state:
                            st.session_state.api_keys = {}
                        st.session_state.api_keys['news_api'] = news_api_key
                else:
                    st.warning("Please enter a News API key")
            
            # Sample search if key is configured
            if 'api_keys' in st.session_state and 'news_api' in st.session_state.api_keys:
                st.write("### Test News API Search")
                
                news_query = st.text_input("Search Term", placeholder="e.g., 'Chicago infrastructure'")
                
                if st.button("Search News", disabled=not news_query):
                    with st.spinner(f"Searching for news about '{news_query}'..."):
                        # This would use the actual News API in a real implementation
                        # For the demo, just show a placeholder message
                        st.info("This is a demo. In a real implementation, this would return news articles.")
                        
                        # Display some sample results
                        st.write("#### Sample Results")
                        st.json([
                            {
                                "title": f"Sample article about {news_query}",
                                "description": f"This is a sample news article description related to {news_query}.",
                                "url": "https://example.com/news/article1",
                                "publishedAt": "2023-04-15T12:30:45Z"
                            },
                            {
                                "title": f"Another article mentioning {news_query}",
                                "description": f"Second sample description for {news_query} with different details.",
                                "url": "https://example.com/news/article2",
                                "publishedAt": "2023-04-14T08:15:30Z"
                            }
                        ])
        
        with api_tabs[1]:
            st.subheader("🐦 Twitter API Integration")
            
            st.markdown("""
            Connect to Twitter to monitor location-specific hashtags, mentions, and discussions.
            """)
            
            # Twitter API settings
            twitter_col1, twitter_col2 = st.columns(2)
            
            with twitter_col1:
                twitter_api_key = st.text_input("Twitter API Key", type="password")
                twitter_api_secret = st.text_input("Twitter API Secret", type="password")
            
            with twitter_col2:
                twitter_access_token = st.text_input("Access Token", type="password")
                twitter_access_secret = st.text_input("Access Token Secret", type="password")
            
            # Test connection button
            if st.button("Test Twitter API Connection", disabled=not all([twitter_api_key, twitter_api_secret, twitter_access_token, twitter_access_secret])):
                if all([twitter_api_key, twitter_api_secret, twitter_access_token, twitter_access_secret]):
                    with st.spinner("Testing Twitter API connection..."):
                        # Simulate testing connection
                        st.success("Successfully connected to Twitter API")
                        
                        # Store keys in session state
                        if 'api_keys' not in st.session_state:
                            st.session_state.api_keys = {}
                        st.session_state.api_keys['twitter'] = {
                            'api_key': twitter_api_key,
                            'api_secret': twitter_api_secret,
                            'access_token': twitter_access_token,
                            'access_secret': twitter_access_secret
                        }
                else:
                    st.warning("Please enter all Twitter API credentials")
        
        with api_tabs[2]:
            st.subheader("🌐 Shodan API Integration")
            
            st.markdown("""
            Connect to Shodan to analyze internet infrastructure in specific locations.
            """)
            
            # Shodan API settings
            shodan_api_key = st.text_input("Shodan API Key", type="password", help="Enter your Shodan API key")
            
            # Test connection button
            if st.button("Test Shodan API Connection", disabled=not shodan_api_key):
                if shodan_api_key:
                    with st.spinner("Testing Shodan API connection..."):
                        # Simulate testing connection
                        st.success("Successfully connected to Shodan API")
                        
                        # Store key in session state
                        if 'api_keys' not in st.session_state:
                            st.session_state.api_keys = {}
                        st.session_state.api_keys['shodan'] = shodan_api_key
                else:
                    st.warning("Please enter a Shodan API key")
        
        with api_tabs[3]:
            st.subheader("📱 OpenCellID API Integration")
            
            st.markdown("""
            Connect to OpenCellID to map cellular network infrastructure and coverage areas.
            """)
            
            # OpenCellID API settings
            opencellid_api_key = st.text_input("OpenCellID API Key", type="password", help="Enter your OpenCellID API key")
            
            # Test connection button
            if st.button("Test OpenCellID API Connection", disabled=not opencellid_api_key):
                if opencellid_api_key:
                    with st.spinner("Testing OpenCellID API connection..."):
                        # Simulate testing connection
                        st.success("Successfully connected to OpenCellID API")
                        
                        # Store key in session state
                        if 'api_keys' not in st.session_state:
                            st.session_state.api_keys = {}
                        st.session_state.api_keys['opencellid'] = opencellid_api_key
                else:
                    st.warning("Please enter an OpenCellID API key")
        
        # API key management
        st.write("### API Key Management")
        
        # Display configured API keys
        if 'api_keys' in st.session_state and st.session_state.api_keys:
            st.write("#### Configured API Keys")
            
            for api_name, key_data in st.session_state.api_keys.items():
                # Create a row for each API
                api_col1, api_col2, api_col3 = st.columns([2, 3, 1])
                
                with api_col1:
                    st.write(f"**{api_name.replace('_', ' ').title()}**")
                
                with api_col2:
                    # Show masked key
                    if isinstance(key_data, dict):
                        # For APIs with multiple credentials
                        st.write("*Multiple credentials configured*")
                    else:
                        # For APIs with single key
                        masked_key = key_data[:4] + "*" * (len(key_data) - 4)
                        st.write(f"Key: {masked_key}")
                
                with api_col3:
                    # Remove button
                    if st.button("Remove", key=f"remove_{api_name}"):
                        # Remove key
                        del st.session_state.api_keys[api_name]
                        st.success(f"Removed {api_name} API key")
                        st.experimental_rerun()
        else:
            st.info("No API keys configured")
        
        # API key export/import
        api_exp_col1, api_exp_col2 = st.columns(2)
        
        with api_exp_col1:
            if 'api_keys' in st.session_state and st.session_state.api_keys:
                # Export button (in a real app, would be encrypted)
                if st.button("Export API Configuration"):
                    # Create a JSON representation of the API keys
                    # WARNING: In a real app, this would need encryption and better security
                    api_json = json.dumps({"message": "API keys export would be implemented with encryption for a real application"})
                    
                    st.download_button(
                        "Download Configuration",
                        data=api_json,
                        file_name="api_config.json",
                        mime="application/json"
                    )
        
        with api_exp_col2:
            # Import button (placeholder - would need file uploader in real app)
            st.info("API configuration import would be implemented with encryption for a real application")

# URL HEALTH DASHBOARD
#########################
elif app_mode == "URL Health":
    st.title("🔗 URL Health Dashboard")
    st.write("Monitoring real-time link reliability and accessibility metrics.")
    
    # Import the URL health dashboard functionality from pages module
    try:
        import importlib
        url_health_module = importlib.import_module("pages.url_health_dashboard")
        
        # We don't need to call any functions here as the module will execute on import
        # and render its content to the Streamlit app
        st.success("URL Health Dashboard loaded successfully")
    except Exception as e:
        st.error(f"Error loading URL Health Dashboard: {str(e)}")
        st.info("Try selecting 'URL Health' from the sidebar navigation directly.")
else:
    st.warning("You need to enable new features to access this section")
    
    if dev_features:
        st.info("Enable new features in the Developer Controls sidebar")
    else:
        st.info("This dashboard is running in compatibility mode")
