# Code Standards Analysis: core

## Summary
- **Files analyzed**: 89
- **Files meeting comment standard**: 89 (100.0%)
- **Files with oversized functions**: 68 (76.4%)
- **Total oversized functions**: 568
- **Average comment ratio**: 99.6%

## Files Needing More Comments
All files meet the comment density standard.

## Files With Oversized Functions
### core/registry.py: 27 oversized functions
- class **FeatureRegistry**: 587 lines (exceeds by 557 lines)
- class **Registry**: 582 lines (exceeds by 552 lines)
- class **ServiceLocator**: 454 lines (exceeds by 424 lines)
- function **list_services**: 100 lines (exceeds by 70 lines)
- function **get_service**: 71 lines (exceeds by 41 lines)
- function **list_features**: 68 lines (exceeds by 38 lines)
- function **search**: 67 lines (exceeds by 37 lines)
- function **remove_service**: 65 lines (exceeds by 35 lines)
- function **search_features**: 61 lines (exceeds by 31 lines)
- function **get_by_tag**: 53 lines (exceeds by 23 lines)
- function **get_by_category**: 53 lines (exceeds by 23 lines)
- function **unregister**: 51 lines (exceeds by 21 lines)
- function **register**: 46 lines (exceeds by 16 lines)
- function **initialize**: 45 lines (exceeds by 15 lines)
- function **initialize**: 42 lines (exceeds by 12 lines)
- function **unregister_feature**: 42 lines (exceeds by 12 lines)
- function **require**: 39 lines (exceeds by 9 lines)
- function **set_metadata**: 39 lines (exceeds by 9 lines)
- function **register_service**: 35 lines (exceeds by 5 lines)
- class **FeatureMetadata**: 33 lines (exceeds by 3 lines)
- function **get_features_by_category**: 33 lines (exceeds by 3 lines)
- function **__init__**: 32 lines (exceeds by 2 lines)
- function **__init__**: 32 lines (exceeds by 2 lines)
- function **register_feature**: 32 lines (exceeds by 2 lines)
- function **clear**: 32 lines (exceeds by 2 lines)
- function **register_provider**: 31 lines (exceeds by 1 lines)
- function **get_features_by_tag**: 31 lines (exceeds by 1 lines)

### core/mcp_server.py: 26 oversized functions
- function **_add_example_data**: 170 lines (exceeds by 140 lines)
- function **call_llm**: 159 lines (exceeds by 129 lines)
- function **landing_page**: 111 lines (exceeds by 81 lines)
- function **stream_llm**: 103 lines (exceeds by 73 lines)
- function **generate_workflow_results**: 65 lines (exceeds by 35 lines)
- function **generate**: 63 lines (exceeds by 33 lines)
- class **MCPRequest**: 59 lines (exceeds by 29 lines)
- function **calculate_transition_readiness**: 53 lines (exceeds by 23 lines)
- function **login_for_access_token**: 53 lines (exceeds by 23 lines)
- class **WorkflowStep**: 52 lines (exceeds by 22 lines)
- class **MCPResponse**: 51 lines (exceeds by 21 lines)
- class **PromptLibraryEntry**: 49 lines (exceeds by 19 lines)
- class **Tool**: 48 lines (exceeds by 18 lines)
- function **execute_tool**: 47 lines (exceeds by 17 lines)
- class **Workflow**: 45 lines (exceeds by 15 lines)
- function **execute_workflow**: 42 lines (exceeds by 12 lines)
- class **LLMConfig**: 37 lines (exceeds by 7 lines)
- function **get_current_user**: 37 lines (exceeds by 7 lines)
- function **update_prompt**: 37 lines (exceeds by 7 lines)
- function **calculate_entropy**: 36 lines (exceeds by 6 lines)
- function **list_workflows**: 36 lines (exceeds by 6 lines)
- function **rate_limit**: 35 lines (exceeds by 5 lines)
- class **WorkflowExecutionResult**: 34 lines (exceeds by 4 lines)
- function **_execute_workflow_background**: 33 lines (exceeds by 3 lines)
- function **create_workflow**: 32 lines (exceeds by 2 lines)
- function **create_prompt**: 31 lines (exceeds by 1 lines)

### core/integrations/satellite/google_earth_integration.py: 20 oversized functions
- class **GoogleEarthManager**: 1675 lines (exceeds by 1645 lines)
- function **dataframe_to_kml**: 248 lines (exceeds by 218 lines)
- class **GoogleEarthPlugin**: 170 lines (exceeds by 140 lines)
- function **extract_features**: 153 lines (exceeds by 123 lines)
- function **kml_to_dataframe**: 144 lines (exceeds by 114 lines)
- function **_parse_kml_styles**: 141 lines (exceeds by 111 lines)
- function **add_polygon**: 132 lines (exceeds by 102 lines)
- function **add_linestring**: 112 lines (exceeds by 82 lines)
- function **load_kml**: 109 lines (exceeds by 79 lines)
- function **_load_styles**: 101 lines (exceeds by 71 lines)
- function **add_point**: 87 lines (exceeds by 57 lines)
- function **save_kml**: 67 lines (exceeds by 37 lines)
- function **__init__**: 63 lines (exceeds by 33 lines)
- function **_apply_style**: 62 lines (exceeds by 32 lines)
- function **initialize**: 54 lines (exceeds by 24 lines)
- function **create_kml**: 46 lines (exceeds by 16 lines)
- function **_extract_extended_data**: 44 lines (exceeds by 14 lines)
- function **get_capabilities**: 41 lines (exceeds by 11 lines)
- function **add_folder**: 37 lines (exceeds by 7 lines)
- function **_iterate_features**: 36 lines (exceeds by 6 lines)

### core/periodic_table/registry.py: 20 oversized functions
- class **PeriodicTableRegistry**: 1064 lines (exceeds by 1034 lines)
- function **_initialize_schema**: 121 lines (exceeds by 91 lines)
- function **load_from_file**: 65 lines (exceeds by 35 lines)
- function **get_element**: 61 lines (exceeds by 31 lines)
- function **add_relationship**: 55 lines (exceeds by 25 lines)
- function **add_element**: 49 lines (exceeds by 19 lines)
- function **load_relationships_from_db**: 48 lines (exceeds by 18 lines)
- function **get_group**: 43 lines (exceeds by 13 lines)
- function **get_category**: 43 lines (exceeds by 13 lines)
- function **remove_element**: 42 lines (exceeds by 12 lines)
- function **get_period**: 41 lines (exceeds by 11 lines)
- function **add_group**: 39 lines (exceeds by 9 lines)
- function **get_all_groups**: 39 lines (exceeds by 9 lines)
- function **add_category**: 39 lines (exceeds by 9 lines)
- function **get_all_categories**: 39 lines (exceeds by 9 lines)
- function **add_period**: 37 lines (exceeds by 7 lines)
- function **get_all_periods**: 37 lines (exceeds by 7 lines)
- function **save_to_file**: 37 lines (exceeds by 7 lines)
- function **get_element_by_atomic_number**: 34 lines (exceeds by 4 lines)
- function **get_element_by_symbol**: 32 lines (exceeds by 2 lines)

### core/integrations/graph_db/neo4j_connector.py: 19 oversized functions
- class **Neo4jConnector**: 1155 lines (exceeds by 1125 lines)
- class **Neo4jPlugin**: 185 lines (exceeds by 155 lines)
- function **create_relationships**: 111 lines (exceeds by 81 lines)
- function **import_dataframe**: 101 lines (exceeds by 71 lines)
- function **create_nodes**: 100 lines (exceeds by 70 lines)
- function **shortest_path**: 88 lines (exceeds by 58 lines)
- function **execute_query**: 79 lines (exceeds by 49 lines)
- function **_connect**: 78 lines (exceeds by 48 lines)
- function **distance_query**: 75 lines (exceeds by 45 lines)
- function **create_index**: 73 lines (exceeds by 43 lines)
- function **create_constraint**: 72 lines (exceeds by 42 lines)
- function **__init__**: 68 lines (exceeds by 38 lines)
- function **initialize**: 61 lines (exceeds by 31 lines)
- function **query_to_dataframe**: 43 lines (exceeds by 13 lines)
- function **session**: 41 lines (exceeds by 11 lines)
- function **_execute_read**: 38 lines (exceeds by 8 lines)
- function **_execute_write**: 38 lines (exceeds by 8 lines)
- function **get_capabilities**: 38 lines (exceeds by 8 lines)
- function **close**: 31 lines (exceeds by 1 lines)

### core/web_intelligence/media_outlets_processor.py: 19 oversized functions
- class **MediaOutletsProcessor**: 1561 lines (exceeds by 1531 lines)
- function **extract_content_from_url**: 184 lines (exceeds by 154 lines)
- function **_initialize_database**: 127 lines (exceeds by 97 lines)
- function **import_outlets_from_excel**: 125 lines (exceeds by 95 lines)
- function **save_outlet**: 111 lines (exceeds by 81 lines)
- function **export_content_matches**: 103 lines (exceeds by 73 lines)
- function **scan_content_for_keywords**: 93 lines (exceeds by 63 lines)
- function **get_content_matches**: 91 lines (exceeds by 61 lines)
- function **get_outlet**: 89 lines (exceeds by 59 lines)
- function **discover_related_outlets**: 87 lines (exceeds by 57 lines)
- function **batch_monitor_outlets**: 74 lines (exceeds by 44 lines)
- function **get_monitoring_keywords**: 70 lines (exceeds by 40 lines)
- function **search_outlets**: 53 lines (exceeds by 23 lines)
- function **add_monitoring_keyword**: 49 lines (exceeds by 19 lines)
- function **_save_content_match**: 48 lines (exceeds by 18 lines)
- function **__init__**: 45 lines (exceeds by 15 lines)
- function **get_all_outlets**: 43 lines (exceeds by 13 lines)
- function **usage_example**: 37 lines (exceeds by 7 lines)
- function **_mark_matches_as_exported**: 32 lines (exceeds by 2 lines)

### core/darkweb_analyzer/darkweb_intelligence.py: 18 oversized functions
- class **DarkwebIntelligenceEngine**: 1118 lines (exceeds by 1088 lines)
- function **extract_content**: 132 lines (exceeds by 102 lines)
- function **_initialize_database**: 112 lines (exceeds by 82 lines)
- function **__init__**: 88 lines (exceeds by 58 lines)
- function **search_darkweb_content**: 88 lines (exceeds by 58 lines)
- function **_save_to_database**: 86 lines (exceeds by 56 lines)
- function **get_alerts**: 80 lines (exceeds by 50 lines)
- function **monitor_targets**: 78 lines (exceeds by 48 lines)
- function **add_monitoring_target**: 73 lines (exceeds by 43 lines)
- function **get_monitoring_targets**: 64 lines (exceeds by 34 lines)
- function **_save_alert**: 49 lines (exceeds by 19 lines)
- function **setup_tor_connection**: 43 lines (exceeds by 13 lines)
- function **_extract_marketplace_data**: 41 lines (exceeds by 11 lines)
- function **scan_for_keywords**: 41 lines (exceeds by 11 lines)
- function **_determine_site_type**: 39 lines (exceeds by 9 lines)
- function **is_onion_url**: 35 lines (exceeds by 5 lines)
- function **_save_content_to_cache**: 34 lines (exceeds by 4 lines)
- function **_update_target_last_checked**: 32 lines (exceeds by 2 lines)

### core/algorithms/hexagonal_grid.py: 16 oversized functions
- class **HexagonalGrid**: 771 lines (exceeds by 741 lines)
- function **hexbin_dataframe**: 107 lines (exceeds by 77 lines)
- function **hierarchical_clustering**: 65 lines (exceeds by 35 lines)
- function **create_hex_grid**: 64 lines (exceeds by 34 lines)
- function **polygon_to_h3**: 47 lines (exceeds by 17 lines)
- function **point_to_h3**: 40 lines (exceeds by 10 lines)
- function **uncompact**: 39 lines (exceeds by 9 lines)
- function **get_parent**: 39 lines (exceeds by 9 lines)
- function **get_children**: 39 lines (exceeds by 9 lines)
- function **k_ring**: 37 lines (exceeds by 7 lines)
- function **hex_ring**: 35 lines (exceeds by 5 lines)
- function **h3_distance**: 34 lines (exceeds by 4 lines)
- function **h3_to_polygon**: 32 lines (exceeds by 2 lines)
- function **compact**: 32 lines (exceeds by 2 lines)
- function **get_resolution**: 32 lines (exceeds by 2 lines)
- function **is_valid**: 31 lines (exceeds by 1 lines)

### core/cyberwarfare/tool_manager.py: 16 oversized functions
- class **ToolManager**: 713 lines (exceeds by 683 lines)
- class **CyberTool**: 201 lines (exceeds by 171 lines)
- function **_load_configurations**: 131 lines (exceeds by 101 lines)
- function **save_configurations**: 129 lines (exceeds by 99 lines)
- function **execute_template**: 93 lines (exceeds by 63 lines)
- function **get_help**: 62 lines (exceeds by 32 lines)
- function **execute_template**: 60 lines (exceeds by 30 lines)
- function **remove_tool**: 54 lines (exceeds by 24 lines)
- function **execute_tool**: 47 lines (exceeds by 17 lines)
- class **CommandTemplate**: 46 lines (exceeds by 16 lines)
- function **__init__**: 42 lines (exceeds by 12 lines)
- function **add_tool**: 40 lines (exceeds by 10 lines)
- function **add_template**: 40 lines (exceeds by 10 lines)
- function **search_tools**: 38 lines (exceeds by 8 lines)
- function **execute**: 33 lines (exceeds by 3 lines)
- function **format_command_template**: 31 lines (exceeds by 1 lines)

### core/security/kali_integrator.py: 15 oversized functions
- class **KaliIntegrator**: 760 lines (exceeds by 730 lines)
- function **_determine_category**: 158 lines (exceeds by 128 lines)
- function **execute_command**: 91 lines (exceeds by 61 lines)
- function **get_tools**: 80 lines (exceeds by 50 lines)
- function **_load_tools_inventory**: 68 lines (exceeds by 38 lines)
- function **get_tool_help**: 65 lines (exceeds by 35 lines)
- function **_build_tools_inventory**: 62 lines (exceeds by 32 lines)
- function **parse_command_output**: 48 lines (exceeds by 18 lines)
- function **__init__**: 43 lines (exceeds by 13 lines)
- function **_build_category_map**: 43 lines (exceeds by 13 lines)
- function **update_inventory**: 43 lines (exceeds by 13 lines)
- function **get_available_tools**: 41 lines (exceeds by 11 lines)
- function **_get_package_description**: 39 lines (exceeds by 9 lines)
- function **execute_tool**: 32 lines (exceeds by 2 lines)
- function **get_tool_by_name**: 31 lines (exceeds by 1 lines)

### core/cyberwarfare/kali_integrator.py: 15 oversized functions
- class **KaliIntegrator**: 760 lines (exceeds by 730 lines)
- function **_determine_category**: 158 lines (exceeds by 128 lines)
- function **execute_command**: 91 lines (exceeds by 61 lines)
- function **get_tools**: 80 lines (exceeds by 50 lines)
- function **_load_tools_inventory**: 68 lines (exceeds by 38 lines)
- function **get_tool_help**: 65 lines (exceeds by 35 lines)
- function **_build_tools_inventory**: 62 lines (exceeds by 32 lines)
- function **parse_command_output**: 48 lines (exceeds by 18 lines)
- function **__init__**: 43 lines (exceeds by 13 lines)
- function **_build_category_map**: 43 lines (exceeds by 13 lines)
- function **update_inventory**: 43 lines (exceeds by 13 lines)
- function **get_available_tools**: 41 lines (exceeds by 11 lines)
- function **_get_package_description**: 39 lines (exceeds by 9 lines)
- function **execute_tool**: 32 lines (exceeds by 2 lines)
- function **get_tool_by_name**: 31 lines (exceeds by 1 lines)

### core/mathematics/monte_carlo/integration.py: 14 oversized functions
- class **MCIntegration**: 862 lines (exceeds by 832 lines)
- function **_stratified_sampling_parallel**: 119 lines (exceeds by 89 lines)
- function **stratified_sampling**: 111 lines (exceeds by 81 lines)
- function **_integrate_importance_parallel**: 105 lines (exceeds by 75 lines)
- function **_integrate_uniform_parallel**: 101 lines (exceeds by 71 lines)
- function **integrate_uniform**: 77 lines (exceeds by 47 lines)
- function **integrate_importance**: 76 lines (exceeds by 46 lines)
- function **_stratified_sampling_sequential**: 74 lines (exceeds by 44 lines)
- function **_integrate_importance_sequential**: 51 lines (exceeds by 21 lines)
- function **_integrate_uniform_sequential**: 47 lines (exceeds by 17 lines)
- function **worker_func**: 47 lines (exceeds by 17 lines)
- class **IntegrationResult**: 35 lines (exceeds by 5 lines)
- function **_get_stratum_bounds**: 34 lines (exceeds by 4 lines)
- function **_generate_strata_indices**: 31 lines (exceeds by 1 lines)

### core/gnn/gnn_model.py: 12 oversized functions
- class **CTASGraphData**: 220 lines (exceeds by 190 lines)
- class **CTASGraphBuilder**: 207 lines (exceeds by 177 lines)
- class **GNNModel**: 198 lines (exceeds by 168 lines)
- function **_extract_task_features**: 70 lines (exceeds by 40 lines)
- function **build_from_matroid**: 45 lines (exceeds by 15 lines)
- function **to_torch_geometric**: 39 lines (exceeds by 9 lines)
- function **_initialize_model**: 39 lines (exceeds by 9 lines)
- function **save_model**: 39 lines (exceeds by 9 lines)
- function **load_model**: 38 lines (exceeds by 8 lines)
- function **encode_graph**: 37 lines (exceeds by 7 lines)
- function **build_from_tasks**: 36 lines (exceeds by 6 lines)
- function **__init__**: 34 lines (exceeds by 4 lines)

### core/algorithms/distance_calculator.py: 12 oversized functions
- class **DistanceCalculator**: 802 lines (exceeds by 772 lines)
- function **vincenty_distance**: 147 lines (exceeds by 117 lines)
- function **geodesic_distance**: 121 lines (exceeds by 91 lines)
- function **great_circle_points**: 70 lines (exceeds by 40 lines)
- function **rhumb_distance**: 69 lines (exceeds by 39 lines)
- function **frechet_distance**: 59 lines (exceeds by 29 lines)
- function **haversine_distance**: 51 lines (exceeds by 21 lines)
- function **hausdorff_distance**: 51 lines (exceeds by 21 lines)
- function **midpoint**: 48 lines (exceeds by 18 lines)
- function **destination_point**: 47 lines (exceeds by 17 lines)
- function **haversine_distance_vectorized**: 45 lines (exceeds by 15 lines)
- function **bearing**: 44 lines (exceeds by 14 lines)

### core/storyteller/workflow_progress.py: 12 oversized functions
- class **WorkflowProgressStoryteller**: 1276 lines (exceeds by 1246 lines)
- function **_create_timeline_figure**: 287 lines (exceeds by 257 lines)
- function **create_timeline_editor**: 228 lines (exceeds by 198 lines)
- function **display_timeline_summary**: 156 lines (exceeds by 126 lines)
- function **_display_element_details**: 130 lines (exceeds by 100 lines)
- function **list_timelines**: 59 lines (exceeds by 29 lines)
- function **display_timeline_visualization**: 54 lines (exceeds by 24 lines)
- function **__init__**: 48 lines (exceeds by 18 lines)
- function **save_timeline**: 43 lines (exceeds by 13 lines)
- function **create_storyteller_dashboard**: 40 lines (exceeds by 10 lines)
- function **add_milestone**: 39 lines (exceeds by 9 lines)
- function **load_timeline**: 36 lines (exceeds by 6 lines)

### core/matroid/spatial_matroid.py: 11 oversized functions
- class **SpatialMatroid**: 263 lines (exceeds by 233 lines)
- class **SpatioTemporalMatroid**: 224 lines (exceeds by 194 lines)
- class **GraphMatroid**: 175 lines (exceeds by 145 lines)
- function **find_temporal_clusters**: 58 lines (exceeds by 28 lines)
- function **find_optimal_coverage**: 54 lines (exceeds by 24 lines)
- function **_check_independence**: 49 lines (exceeds by 19 lines)
- function **_check_independence**: 46 lines (exceeds by 16 lines)
- function **from_dict**: 43 lines (exceeds by 13 lines)
- function **find_minimum_spanning_tree**: 36 lines (exceeds by 6 lines)
- function **_check_independence**: 35 lines (exceeds by 5 lines)
- function **from_dict**: 31 lines (exceeds by 1 lines)

### core/web_intelligence/news_scraper.py: 11 oversized functions
- class **NewsScraper**: 712 lines (exceeds by 682 lines)
- function **extract_article_content**: 199 lines (exceeds by 169 lines)
- function **analyze_news_source**: 89 lines (exceeds by 59 lines)
- function **_load_news_sources**: 81 lines (exceeds by 51 lines)
- function **discover_articles**: 68 lines (exceeds by 38 lines)
- function **_is_likely_article**: 44 lines (exceeds by 14 lines)
- function **batch_extract_articles**: 42 lines (exceeds by 12 lines)
- function **_save_article_to_cache**: 38 lines (exceeds by 8 lines)
- function **__init__**: 37 lines (exceeds by 7 lines)
- function **_extract_domain**: 35 lines (exceeds by 5 lines)
- function **create_news_organization_database**: 33 lines (exceeds by 3 lines)

### core/mathematics/optimization/genetic_algorithm.py: 11 oversized functions
- class **GeneticAlgorithm**: 567 lines (exceeds by 537 lines)
- function **_evolve_parallel**: 219 lines (exceeds by 189 lines)
- function **evolve**: 197 lines (exceeds by 167 lines)
- class **BinaryGenomeOps**: 150 lines (exceeds by 120 lines)
- class **EvolutionResult**: 109 lines (exceeds by 79 lines)
- class **GenomeOperations**: 99 lines (exceeds by 69 lines)
- function **_select_individual**: 88 lines (exceeds by 58 lines)
- function **plot_fitness_history**: 71 lines (exceeds by 41 lines)
- function **_crossover**: 34 lines (exceeds by 4 lines)
- class **GeneticConfig**: 33 lines (exceeds by 3 lines)
- function **calculate_diversity**: 32 lines (exceeds by 2 lines)

### core/periodic_table/task_registry.py: 11 oversized functions
- class **TaskRegistry**: 664 lines (exceeds by 634 lines)
- function **_initialize_schema**: 71 lines (exceeds by 41 lines)
- function **add_relationship**: 55 lines (exceeds by 25 lines)
- function **load_relationships_from_db**: 50 lines (exceeds by 20 lines)
- function **add_task**: 48 lines (exceeds by 18 lines)
- function **remove_task**: 46 lines (exceeds by 16 lines)
- function **get_task**: 43 lines (exceeds by 13 lines)
- function **__init__**: 38 lines (exceeds by 8 lines)
- function **get_task_by_hash_id**: 37 lines (exceeds by 7 lines)
- function **get_task_by_task_id**: 37 lines (exceeds by 7 lines)
- function **get_all_tasks**: 34 lines (exceeds by 4 lines)

### core/mcp_client.py: 10 oversized functions
- class **MCPClient**: 564 lines (exceeds by 534 lines)
- function **_prepare_request**: 105 lines (exceeds by 75 lines)
- function **call_llm**: 87 lines (exceeds by 57 lines)
- function **_calculate_transition_readiness**: 66 lines (exceeds by 36 lines)
- function **_make_request_with_retries**: 55 lines (exceeds by 25 lines)
- function **_extract_content**: 43 lines (exceeds by 13 lines)
- class **PromptTemplate**: 41 lines (exceeds by 11 lines)
- function **_calculate_entropy**: 39 lines (exceeds by 9 lines)
- class **MCPResponse**: 34 lines (exceeds by 4 lines)
- function **__init__**: 34 lines (exceeds by 4 lines)

### core/algorithms/spatial_join.py: 10 oversized functions
- class **SpatialJoin**: 627 lines (exceeds by 597 lines)
- function **proximity_join**: 79 lines (exceeds by 49 lines)
- function **spatial_join_dataframes**: 77 lines (exceeds by 47 lines)
- function **point_in_polygon_query**: 72 lines (exceeds by 42 lines)
- function **create_voronoi_diagram**: 72 lines (exceeds by 42 lines)
- function **create_delaunay_triangulation**: 64 lines (exceeds by 34 lines)
- function **create_rtree_index**: 63 lines (exceeds by 33 lines)
- function **find_nearest_points**: 62 lines (exceeds by 32 lines)
- function **dissolve_polygons**: 51 lines (exceeds by 21 lines)
- function **buffer_polygons**: 50 lines (exceeds by 20 lines)

### core/algorithms/hotspot_analysis.py: 10 oversized functions
- class **HotspotAnalysis**: 921 lines (exceeds by 891 lines)
- function **space_time_scan**: 192 lines (exceeds by 162 lines)
- function **kernel_density_estimation**: 110 lines (exceeds by 80 lines)
- function **global_moran_i**: 106 lines (exceeds by 76 lines)
- function **create_weight_matrix**: 103 lines (exceeds by 73 lines)
- function **getis_ord_g_star**: 97 lines (exceeds by 67 lines)
- function **local_moran_i**: 86 lines (exceeds by 56 lines)
- function **optimize_hotspot_threshold**: 80 lines (exceeds by 50 lines)
- function **dbscan_clusters**: 64 lines (exceeds by 34 lines)
- function **calculate_distance_matrix**: 44 lines (exceeds by 14 lines)

### core/plugins/plugin_base.py: 10 oversized functions
- class **PluginManager**: 477 lines (exceeds by 447 lines)
- function **discover_plugins**: 146 lines (exceeds by 116 lines)
- class **PluginMetadata**: 112 lines (exceeds by 82 lines)
- function **activate_plugin**: 105 lines (exceeds by 75 lines)
- class **PluginBase**: 93 lines (exceeds by 63 lines)
- function **deactivate_plugin**: 74 lines (exceeds by 44 lines)
- function **get_plugins_by_type**: 48 lines (exceeds by 18 lines)
- function **_validate_version**: 38 lines (exceeds by 8 lines)
- function **__init__**: 34 lines (exceeds by 4 lines)
- function **validate**: 33 lines (exceeds by 3 lines)

### core/drone/simulation.py: 10 oversized functions
- class **DroneSimulator**: 1213 lines (exceeds by 1183 lines)
- function **update_simulation**: 150 lines (exceeds by 120 lines)
- function **create_drone**: 143 lines (exceeds by 113 lines)
- function **assign_mission**: 139 lines (exceeds by 109 lines)
- function **assign_squadron_formation**: 128 lines (exceeds by 98 lines)
- function **_simulate_random_events**: 97 lines (exceeds by 67 lines)
- function **export_telemetry**: 77 lines (exceeds by 47 lines)
- function **_update_telemetry**: 71 lines (exceeds by 41 lines)
- function **create_squadron**: 50 lines (exceeds by 20 lines)
- function **_update_resources**: 46 lines (exceeds by 16 lines)

### core/periodic_table/table.py: 10 oversized functions
- class **PeriodicTable**: 702 lines (exceeds by 672 lines)
- function **create_network_graph**: 168 lines (exceeds by 138 lines)
- function **create_plotly_table**: 151 lines (exceeds by 121 lines)
- class **ElementSymbol**: 148 lines (exceeds by 118 lines)
- function **_force_atlas2_layout**: 120 lines (exceeds by 90 lines)
- function **create_element_detail_plot**: 110 lines (exceeds by 80 lines)
- function **get_node_card**: 97 lines (exceeds by 67 lines)
- function **get_table_data**: 68 lines (exceeds by 38 lines)
- function **add_element_to_graph**: 45 lines (exceeds by 15 lines)
- function **format_symbol**: 39 lines (exceeds by 9 lines)

### core/cyberwarfare/tool_scraper.py: 9 oversized functions
- class **ToolScraper**: 897 lines (exceeds by 867 lines)
- function **get_tool_details**: 253 lines (exceeds by 223 lines)
- function **get_tool_list**: 171 lines (exceeds by 141 lines)
- function **scrape_all_tools**: 158 lines (exceeds by 128 lines)
- function **export_tools_data**: 95 lines (exceeds by 65 lines)
- function **_fetch_html**: 61 lines (exceeds by 31 lines)
- function **__init__**: 52 lines (exceeds by 22 lines)
- function **_get_cached_data**: 50 lines (exceeds by 20 lines)
- function **_save_cached_data**: 41 lines (exceeds by 11 lines)

### core/mathematics/monte_carlo/simulation.py: 9 oversized functions
- class **MCSimulation**: 371 lines (exceeds by 341 lines)
- class **SimulationResult**: 220 lines (exceeds by 190 lines)
- function **plot_histogram**: 98 lines (exceeds by 68 lines)
- function **plot_sensitivity_analysis**: 83 lines (exceeds by 53 lines)
- function **sensitivity_analysis**: 58 lines (exceeds by 28 lines)
- function **run_simulation**: 57 lines (exceeds by 27 lines)
- function **_run_parallel**: 57 lines (exceeds by 27 lines)
- function **scenario_analysis**: 50 lines (exceeds by 20 lines)
- function **_run_sequential**: 34 lines (exceeds by 4 lines)

### core/mathematics/las_vegas/framework.py: 9 oversized functions
- class **AdaptiveSearchStrategy**: 142 lines (exceeds by 112 lines)
- class **ProgressiveRefinementStrategy**: 87 lines (exceeds by 57 lines)
- class **CompositeSearchStrategy**: 79 lines (exceeds by 49 lines)
- class **SequentialSearchStrategy**: 69 lines (exceeds by 39 lines)
- class **AbstractLasVegasStrategy**: 62 lines (exceeds by 32 lines)
- class **SearchStrategy**: 44 lines (exceeds by 14 lines)
- function **search**: 39 lines (exceeds by 9 lines)
- function **__init__**: 38 lines (exceeds by 8 lines)
- function **search**: 35 lines (exceeds by 5 lines)

### core/mathematics/optimization/particle_swarm.py: 9 oversized functions
- class **ParticleSwarmOptimization**: 707 lines (exceeds by 677 lines)
- function **_optimize_parallel**: 219 lines (exceeds by 189 lines)
- function **optimize**: 217 lines (exceeds by 187 lines)
- class **PSOResult**: 105 lines (exceeds by 75 lines)
- function **_initialize_topology**: 86 lines (exceeds by 56 lines)
- function **plot_history**: 69 lines (exceeds by 39 lines)
- function **evaluate_particles**: 63 lines (exceeds by 33 lines)
- function **_initialize_swarm**: 52 lines (exceeds by 22 lines)
- function **_get_neighborhood_best**: 47 lines (exceeds by 17 lines)

### core/periodic_table/relationships.py: 9 oversized functions
- class **RelationshipManager**: 337 lines (exceeds by 307 lines)
- class **Relationship**: 164 lines (exceeds by 134 lines)
- class **RelationshipType**: 63 lines (exceeds by 33 lines)
- function **add_relationship**: 55 lines (exceeds by 25 lines)
- function **get_inverse_type**: 44 lines (exceeds by 14 lines)
- function **get_path**: 44 lines (exceeds by 14 lines)
- function **remove_relationship**: 41 lines (exceeds by 11 lines)
- function **from_dict**: 36 lines (exceeds by 6 lines)
- function **from_dict**: 31 lines (exceeds by 1 lines)

### core/interfaces/analyzers.py: 8 oversized functions
- class **AnalysisResult**: 111 lines (exceeds by 81 lines)
- class **ThreatAnalyzer**: 76 lines (exceeds by 46 lines)
- class **PatternAnalyzer**: 76 lines (exceeds by 46 lines)
- class **AnomalyAnalyzer**: 76 lines (exceeds by 46 lines)
- class **AnalyzerParams**: 69 lines (exceeds by 39 lines)
- class **Analyzer**: 67 lines (exceeds by 37 lines)
- class **PredictiveAnalyzer**: 64 lines (exceeds by 34 lines)
- function **__init__**: 48 lines (exceeds by 18 lines)

### core/media_analysis/analyzer.py: 8 oversized functions
- class **MediaAnalyzer**: 580 lines (exceeds by 550 lines)
- function **extract_metadata**: 88 lines (exceeds by 58 lines)
- function **analyze_url_media**: 80 lines (exceeds by 50 lines)
- function **analyze_video**: 74 lines (exceeds by 44 lines)
- function **analyze_image**: 60 lines (exceeds by 30 lines)
- function **_extract_dominant_colors**: 58 lines (exceeds by 28 lines)
- function **_parse_gps_info**: 39 lines (exceeds by 9 lines)
- function **_detect_faces**: 38 lines (exceeds by 8 lines)

### core/mathematics/optimization/simulated_annealing.py: 8 oversized functions
- class **SimulatedAnnealing**: 512 lines (exceeds by 482 lines)
- function **_optimize_parallel**: 243 lines (exceeds by 213 lines)
- function **optimize**: 186 lines (exceeds by 156 lines)
- class **AnnealingResult**: 108 lines (exceeds by 78 lines)
- function **plot_energy_history**: 71 lines (exceeds by 41 lines)
- function **_update_temperature**: 55 lines (exceeds by 25 lines)
- function **worker_func**: 48 lines (exceeds by 18 lines)
- function **example_neighbor_function**: 31 lines (exceeds by 1 lines)

### core/plugin_loader.py: 7 oversized functions
- class **PluginRegistry**: 577 lines (exceeds by 547 lines)
- function **initialize**: 93 lines (exceeds by 63 lines)
- function **activate_plugin**: 87 lines (exceeds by 57 lines)
- function **get_plugins_by_capability**: 83 lines (exceeds by 53 lines)
- function **_has_capability**: 68 lines (exceeds by 38 lines)
- function **deactivate_plugin**: 65 lines (exceeds by 35 lines)
- function **list_discovered_plugins**: 48 lines (exceeds by 18 lines)

### core/matroid/base.py: 7 oversized functions
- class **Matroid**: 271 lines (exceeds by 241 lines)
- class **TaskMatroid**: 197 lines (exceeds by 167 lines)
- class **RankMatroid**: 51 lines (exceeds by 21 lines)
- function **optimize_allocation**: 45 lines (exceeds by 15 lines)
- function **add_independent_set**: 39 lines (exceeds by 9 lines)
- function **_check_independence**: 35 lines (exceeds by 5 lines)
- class **IndependenceMatroid**: 34 lines (exceeds by 4 lines)

### core/storyteller/real_time_tracker.py: 7 oversized functions
- class **RealTimeWorkflowTracker**: 605 lines (exceeds by 575 lines)
- function **_create_timeline_visualization**: 176 lines (exceeds by 146 lines)
- function **create_workflow_metrics_dashboard**: 111 lines (exceeds by 81 lines)
- function **create_live_timeline_visualization**: 90 lines (exceeds by 60 lines)
- function **create_workflow_activity_feed**: 81 lines (exceeds by 51 lines)
- function **_create_elements_dataframe**: 55 lines (exceeds by 25 lines)
- function **__init__**: 48 lines (exceeds by 18 lines)

### core/geospatial/reporting.py: 7 oversized functions
- function **display_report_summary**: 137 lines (exceeds by 107 lines)
- function **create_threat_time_series**: 124 lines (exceeds by 94 lines)
- function **generate_threat_summary**: 98 lines (exceeds by 68 lines)
- function **generate_geospatial_report**: 96 lines (exceeds by 66 lines)
- function **create_threat_histogram**: 70 lines (exceeds by 40 lines)
- function **get_report_download_link**: 45 lines (exceeds by 15 lines)
- function **export_report_as_json**: 32 lines (exceeds by 2 lines)

### core/mathematics/las_vegas/algorithm.py: 7 oversized functions
- class **LasVegasAlgorithm**: 435 lines (exceeds by 405 lines)
- function **_run_parallel**: 177 lines (exceeds by 147 lines)
- function **adaptive_restart**: 93 lines (exceeds by 63 lines)
- function **_run_sequential**: 81 lines (exceeds by 51 lines)
- function **run**: 55 lines (exceeds by 25 lines)
- class **LasVegasSolution**: 48 lines (exceeds by 18 lines)
- function **worker_func**: 48 lines (exceeds by 18 lines)

### core/cyberwarfare/results_parser.py: 6 oversized functions
- function **_parse_nmap_xml**: 118 lines (exceeds by 88 lines)
- function **parse_whatweb_results**: 95 lines (exceeds by 65 lines)
- function **parse_nmap_results**: 68 lines (exceeds by 38 lines)
- function **parse_nikto_results**: 61 lines (exceeds by 31 lines)
- function **parse_dirb_results**: 52 lines (exceeds by 22 lines)
- function **parse_gobuster_results**: 46 lines (exceeds by 16 lines)

### core/triptych/client.py: 5 oversized functions
- class **TriptychClient**: 414 lines (exceeds by 384 lines)
- function **create_identity**: 45 lines (exceeds by 15 lines)
- function **create_sch**: 44 lines (exceeds by 14 lines)
- function **create_cuid**: 42 lines (exceeds by 12 lines)
- function **create_uuid**: 37 lines (exceeds by 7 lines)

### core/algorithms/geospatial_utils.py: 5 oversized functions
- function **get_bounding_box**: 69 lines (exceeds by 39 lines)
- function **cartesian_to_geodetic**: 63 lines (exceeds by 33 lines)
- function **interpolate_points**: 42 lines (exceeds by 12 lines)
- function **fix_invalid_geometry**: 38 lines (exceeds by 8 lines)
- function **geodetic_to_cartesian**: 36 lines (exceeds by 6 lines)

### core/cyberwarfare/assessment_reporting.py: 5 oversized functions
- class **CyberReport**: 127 lines (exceeds by 97 lines)
- function **export_report**: 79 lines (exceeds by 49 lines)
- function **create_vulnerability_report**: 69 lines (exceeds by 39 lines)
- function **add_finding**: 47 lines (exceeds by 17 lines)
- function **generate_report_summary**: 46 lines (exceeds by 16 lines)

### core/database/utils.py: 5 oversized functions
- class **DatabaseManager**: 357 lines (exceeds by 327 lines)
- function **create_relationship**: 101 lines (exceeds by 71 lines)
- function **update_entity**: 64 lines (exceeds by 34 lines)
- function **get_entity**: 59 lines (exceeds by 29 lines)
- function **store_entity**: 58 lines (exceeds by 28 lines)

### core/database/supabase/connector.py: 5 oversized functions
- class **SupabaseConnector**: 320 lines (exceeds by 290 lines)
- function **update**: 49 lines (exceeds by 19 lines)
- function **execute_select**: 39 lines (exceeds by 9 lines)
- function **insert**: 38 lines (exceeds by 8 lines)
- function **delete**: 32 lines (exceeds by 2 lines)

### core/periodic_table/element.py: 5 oversized functions
- class **Element**: 280 lines (exceeds by 250 lines)
- class **ElementProperty**: 64 lines (exceeds by 34 lines)
- function **from_dict**: 45 lines (exceeds by 15 lines)
- function **to_dict**: 33 lines (exceeds by 3 lines)
- function **__post_init__**: 31 lines (exceeds by 1 lines)

### core/triptych/models.py: 4 oversized functions
- class **SCH**: 150 lines (exceeds by 120 lines)
- class **UUID**: 125 lines (exceeds by 95 lines)
- class **CUID**: 112 lines (exceeds by 82 lines)
- class **TriptychIdentity**: 87 lines (exceeds by 57 lines)

### core/storyteller/story_elements.py: 4 oversized functions
- class **StoryTimeline**: 186 lines (exceeds by 156 lines)
- class **StoryElement**: 75 lines (exceeds by 45 lines)
- function **from_dict**: 44 lines (exceeds by 14 lines)
- function **from_dict**: 34 lines (exceeds by 4 lines)

### core/geospatial/base_maps.py: 4 oversized functions
- function **create_advanced_map**: 137 lines (exceeds by 107 lines)
- function **add_legend**: 90 lines (exceeds by 60 lines)
- function **add_tile_layers**: 61 lines (exceeds by 31 lines)
- function **create_base_map**: 59 lines (exceeds by 29 lines)

### core/database/mongodb/connector.py: 4 oversized functions
- class **MongoDBConnector**: 453 lines (exceeds by 423 lines)
- function **find**: 43 lines (exceeds by 13 lines)
- function **update_one**: 34 lines (exceeds by 4 lines)
- function **update_many**: 34 lines (exceeds by 4 lines)

### core/periodic_table/simple_relationships.py: 4 oversized functions
- class **RelationshipManager**: 224 lines (exceeds by 194 lines)
- class **Relationship**: 81 lines (exceeds by 51 lines)
- function **add_relationship**: 75 lines (exceeds by 45 lines)
- function **get_relationships**: 61 lines (exceeds by 31 lines)

### core/periodic_table/task_loader.py: 4 oversized functions
- function **load_task_from_json**: 62 lines (exceeds by 32 lines)
- function **create_demo_tasks**: 60 lines (exceeds by 30 lines)
- function **load_tasks_from_directory**: 34 lines (exceeds by 4 lines)
- function **get_category_from_hash_id**: 31 lines (exceeds by 1 lines)

### core/drone/flight_profiles.py: 3 oversized functions
- class **DroneFlightProfiles**: 231 lines (exceeds by 201 lines)
- function **_grid_search_pattern**: 42 lines (exceeds by 12 lines)
- function **_spiral_pattern**: 33 lines (exceeds by 3 lines)

### core/geospatial/data_preparation.py: 3 oversized functions
- function **prepare_geospatial_data**: 101 lines (exceeds by 71 lines)
- function **extract_coordinates**: 55 lines (exceeds by 25 lines)
- function **convert_to_geodataframe**: 49 lines (exceeds by 19 lines)

### core/geospatial/threat_analysis.py: 3 oversized functions
- function **identify_threat_hotspots**: 166 lines (exceeds by 136 lines)
- function **calculate_threat_score**: 137 lines (exceeds by 107 lines)
- function **calculate_proximity_risk**: 114 lines (exceeds by 84 lines)

### core/geospatial/visualizers/markers.py: 3 oversized functions
- function **add_markers**: 124 lines (exceeds by 94 lines)
- function **create_marker_clusters**: 86 lines (exceeds by 56 lines)
- function **add_boat_markers**: 64 lines (exceeds by 34 lines)

### core/geospatial/visualizers/choropleths.py: 3 oversized functions
- function **create_binned_choropleth**: 196 lines (exceeds by 166 lines)
- function **create_choropleth**: 125 lines (exceeds by 95 lines)
- function **get_color**: 60 lines (exceeds by 30 lines)

### core/geospatial/visualizers/heatmap.py: 3 oversized functions
- function **create_heatmap**: 94 lines (exceeds by 64 lines)
- function **create_threat_heatmap**: 64 lines (exceeds by 34 lines)
- function **render_heatmap**: 51 lines (exceeds by 21 lines)

### core/database/neo4j/connector.py: 3 oversized functions
- class **Neo4jConnector**: 365 lines (exceeds by 335 lines)
- function **create_relationship**: 56 lines (exceeds by 26 lines)
- function **merge_node**: 55 lines (exceeds by 25 lines)

### core/periodic_table/group.py: 3 oversized functions
- class **Category**: 64 lines (exceeds by 34 lines)
- class **Group**: 62 lines (exceeds by 32 lines)
- class **Period**: 56 lines (exceeds by 26 lines)

### core/interfaces/base.py: 2 oversized functions
- class **EventEmitter**: 39 lines (exceeds by 9 lines)
- class **CTASIntegrated**: 34 lines (exceeds by 4 lines)

### core/interfaces/collectors.py: 2 oversized functions
- class **EEI**: 50 lines (exceeds by 20 lines)
- class **Collector**: 41 lines (exceeds by 11 lines)

### core/interfaces/processors.py: 2 oversized functions
- class **ProcessedIntelligence**: 82 lines (exceeds by 52 lines)
- class **Processor**: 59 lines (exceeds by 29 lines)

### core/geospatial/plugin_manager.py: 2 oversized functions
- function **initialize_plugins**: 117 lines (exceeds by 87 lines)
- function **get_plugin_status**: 46 lines (exceeds by 16 lines)

### core/database/factory.py: 2 oversized functions
- class **DatabaseFactory**: 126 lines (exceeds by 96 lines)
- function **get_connector**: 43 lines (exceeds by 13 lines)

### core/periodic_table/adversary_task.py: 2 oversized functions
- class **AdversaryTask**: 209 lines (exceeds by 179 lines)
- function **from_dict**: 37 lines (exceeds by 7 lines)

### core/geospatial/visualizers/networks.py: 1 oversized functions
- function **create_network_graph**: 313 lines (exceeds by 283 lines)

### core/database/config.py: 1 oversized functions
- class **DatabaseConfig**: 103 lines (exceeds by 73 lines)

### core/periodic_table/cache_manager.py: 1 oversized functions
- class **CacheManager**: 342 lines (exceeds by 312 lines)

