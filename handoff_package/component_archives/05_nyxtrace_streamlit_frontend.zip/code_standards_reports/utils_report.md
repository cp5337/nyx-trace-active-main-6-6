# Code Standards Analysis: utils

## Summary
- **Files analyzed**: 8
- **Files meeting comment standard**: 8 (100.0%)
- **Files with oversized functions**: 6 (75.0%)
- **Total oversized functions**: 41
- **Average comment ratio**: 98.3%

## Files Needing More Comments
All files meet the comment density standard.

## Files With Oversized Functions
### utils/kali_integrator.py: 13 oversized functions
- class **KaliIntegrator**: 883 lines (exceeds by 853 lines)
- function **_generate_simulated_output**: 148 lines (exceeds by 118 lines)
- function **run_chain**: 104 lines (exceeds by 74 lines)
- function **_create_default_tools**: 89 lines (exceeds by 59 lines)
- class **Tool**: 78 lines (exceeds by 48 lines)
- function **execute_tool**: 71 lines (exceeds by 41 lines)
- class **ToolChain**: 63 lines (exceeds by 33 lines)
- function **_create_default_chains**: 62 lines (exceeds by 32 lines)
- function **_build_command**: 61 lines (exceeds by 31 lines)
- function **get_execution_history**: 47 lines (exceeds by 17 lines)
- function **update_chain**: 37 lines (exceeds by 7 lines)
- function **install_tool**: 32 lines (exceeds by 2 lines)
- function **uninstall_tool**: 32 lines (exceeds by 2 lines)

### utils/security_tools_utils.py: 9 oversized functions
- function **execute_command_async**: 71 lines (exceeds by 41 lines)
- function **format_command_output**: 69 lines (exceeds by 39 lines)
- function **build_command**: 59 lines (exceeds by 29 lines)
- function **execute_command**: 58 lines (exceeds by 28 lines)
- function **download_kali_tool_image**: 51 lines (exceeds by 21 lines)
- function **execute_docker_command**: 47 lines (exceeds by 17 lines)
- function **execute_remote_command**: 47 lines (exceeds by 17 lines)
- function **parse_nmap_output**: 39 lines (exceeds by 9 lines)
- function **save_command_result**: 36 lines (exceeds by 6 lines)

### utils/opsec_manager.py: 8 oversized functions
- class **OpsecManager**: 513 lines (exceeds by 483 lines)
- class **OperationalProfile**: 102 lines (exceeds by 72 lines)
- function **update_profile**: 69 lines (exceeds by 39 lines)
- function **create_profile**: 59 lines (exceeds by 29 lines)
- function **__init__**: 58 lines (exceeds by 28 lines)
- function **get_opsec_guidelines**: 35 lines (exceeds by 5 lines)
- function **_check_security_status**: 33 lines (exceeds by 3 lines)
- function **_create_default_profiles**: 31 lines (exceeds by 1 lines)

### utils/url_health_monitor.py: 7 oversized functions
- class **URLHealthMonitor**: 350 lines (exceeds by 320 lines)
- function **check_url_health**: 75 lines (exceeds by 45 lines)
- function **create_availability_chart**: 75 lines (exceeds by 45 lines)
- function **create_response_time_chart**: 44 lines (exceeds by 14 lines)
- function **create_summary_chart**: 39 lines (exceeds by 9 lines)
- class **URLHealthStatus**: 31 lines (exceeds by 1 lines)
- function **check_urls_health**: 31 lines (exceeds by 1 lines)

### utils/ctas_headers.py: 2 oversized functions
- function **generate_ctas_header**: 64 lines (exceeds by 34 lines)
- function **apply_header_to_file**: 54 lines (exceeds by 24 lines)

### utils/kml_handler.py: 2 oversized functions
- function **dataframe_to_kml**: 123 lines (exceeds by 93 lines)
- function **kml_to_dataframe**: 56 lines (exceeds by 26 lines)

