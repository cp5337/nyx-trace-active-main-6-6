"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-VISUALIZATION-LOADERS-INIT-0001     │
// │ 📁 domain       : Data, IO, Visualization                  │
// │ 🧠 description  : Data loader package                       │
// │                  Source data loading and preparation        │
// │ 🕸️ hash_type    : UUID → CUID-linked module                │
// │ 🔄 parent_node  : NODE_VISUALIZATION                       │
// │ 🧩 dependencies : pandas, streamlit, numpy                 │
// │ 🔧 tool_usage   : Data Processing, Visualization           │
// │ 📡 input_type   : Data sources, files, APIs                │
// │ 🧪 test_status  : stable                                   │
// │ 🧠 cognitive_fn : data aggregation, normalization          │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

Data Loading Package
------------------
This package provides functions for loading and preparing data from various
sources for use in geospatial visualizations. It handles data validation,
transformation, and normalization to ensure compatibility with visualization
components.
"""

# Export the main interface functions
from .interface import load_data_sources
from .file_loader import handle_file_upload
from .system_intelligence import load_system_intelligence
from .sample_mini_generator import create_sample_data_mini