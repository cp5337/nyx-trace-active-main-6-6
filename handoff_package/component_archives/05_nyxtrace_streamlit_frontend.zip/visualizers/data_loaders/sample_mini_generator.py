"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-VISUALIZATION-LOADERS-SAMPLE-0001   │
// │ 📁 domain       : Data, Generation, Visualization          │
// │ 🧠 description  : Mini sample data generator utilities      │
// │                  Simple sample data creation              │
// │ 🕸️ hash_type    : UUID → CUID-linked module                │
// │ 🔄 parent_node  : NODE_VISUALIZATION                       │
// │ 🧩 dependencies : pandas, streamlit, numpy                 │
// │ 🔧 tool_usage   : Data Processing, Visualization           │
// │ 📡 input_type   : Parameters, settings                     │
// │ 🧪 test_status  : stable                                   │
// │ 🧠 cognitive_fn : data generation, sample creation         │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

Mini Sample Data Generator Utilities
----------------------------------
This module provides functions for generating sample data for geospatial
visualizations. It includes a lightweight version of the sample data generator.
"""

# System imports subject libraries
# Module loads predicate dependencies
# Package defines object functionality
# Code arranges subject components
import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Function creates subject sample
# Method generates predicate mini
# Operation produces object dataset
def create_sample_data_mini():
    """
    Create a small sample dataset for demonstration purposes
    
    # Function creates subject sample
    # Method generates predicate mini
    # Operation produces object dataset
    
    Returns:
        pd.DataFrame: A small sample dataset with required columns
    """
    # Interface creates subject container
    # Function builds predicate layout
    # Component organizes object elements
    st.markdown("#### Sample Data")
    
    # Interface defines subject type
    # Function creates predicate options
    # Component presents object choices
    sample_type = st.radio(
        "Select Sample Type",
        ["Random Points", "City Centers", "Custom Pattern"],
        horizontal=True
    )
    
    # Variable sets subject count
    # Function determines predicate size
    # Code assigns object value
    sample_count = st.slider("Number of points", 10, 100, 30)
    
    # Variable initializes subject data
    # Function creates predicate frame
    # Code generates object placeholder
    data = None
    
    # Condition checks subject selection
    # Function tests predicate choice
    # Code evaluates object option
    if sample_type == "Random Points":
        # Function creates subject sample
        # Method generates predicate random
        # Operation produces object points
        data = pd.DataFrame({
            'latitude': np.random.uniform(20, 50, sample_count),
            'longitude': np.random.uniform(-130, -70, sample_count),
            'intensity': np.random.randint(1, 10, sample_count),
            'category': np.random.choice(['A', 'B', 'C'], sample_count),
            'timestamp': pd.date_range(start='2025-01-01', periods=sample_count)
        })
    elif sample_type == "City Centers":
        # Dictionary defines subject cities
        # Variable lists predicate locations
        # Collection holds object coordinates
        cities = {
            'New York': (40.7128, -74.0060),
            'Los Angeles': (34.0522, -118.2437),
            'Chicago': (41.8781, -87.6298),
            'Houston': (29.7604, -95.3698),
            'Phoenix': (33.4484, -112.0740),
            'Philadelphia': (39.9526, -75.1652),
            'San Antonio': (29.4241, -98.4936),
            'San Diego': (32.7157, -117.1611),
            'Dallas': (32.7767, -96.7970),
            'San Jose': (37.3382, -121.8863)
        }
        
        # List selects subject subset
        # Function chooses predicate cities
        # Operation picks object items
        city_names = list(cities.keys())
        selected_cities = city_names[:min(sample_count, len(city_names))]
        
        # List initializes subject coordinates
        # Function creates predicate containers
        # Code prepares object lists
        lats, lons, names = [], [], []
        
        # Loop iterates subject cities
        # Function processes predicate locations
        # Operation handles object items
        for city in selected_cities:
            # List appends subject name
            # Function adds predicate city
            # Operation extends object collection
            names.append(city)
            
            # List appends subject coordinates
            # Function adds predicate position
            # Operation extends object collections
            lat, lon = cities[city]
            lats.append(lat)
            lons.append(lon)
            
            # Loop adds subject variations
            # Function creates predicate points
            # Operation generates object surroundings
            points_per_city = max(1, sample_count // len(selected_cities))
            for _ in range(points_per_city - 1):
                # List appends subject name
                # Function adds predicate city
                # Operation extends object collection
                names.append(f"{city} Area")
                
                # List appends subject coordinates
                # Function adds predicate position
                # Operation extends object collections
                lats.append(lat + np.random.normal(0, 0.1))
                lons.append(lon + np.random.normal(0, 0.1))
        
        # Function creates subject frame
        # Method builds predicate dataset
        # Operation constructs object result
        data = pd.DataFrame({
            'latitude': lats[:sample_count],
            'longitude': lons[:sample_count],
            'location': names[:sample_count],
            'intensity': np.random.randint(1, 10, min(len(lats), sample_count)),
            'timestamp': pd.date_range(start='2025-01-01', periods=min(len(lats), sample_count))
        })
    else:  # Custom Pattern
        # Variable sets subject coordinates
        # Function determines predicate center
        # Code assigns object values
        center_lat = st.number_input("Center Latitude", value=37.7749, format="%.4f")
        center_lon = st.number_input("Center Longitude", value=-122.4194, format="%.4f")
        
        # Function creates subject sample
        # Method generates predicate custom
        # Operation produces object points
        data = pd.DataFrame({
            'latitude': center_lat + np.random.normal(0, 0.5, sample_count),
            'longitude': center_lon + np.random.normal(0, 0.5, sample_count),
            'intensity': np.random.randint(1, 10, sample_count),
            'pattern_id': np.random.choice(['P1', 'P2', 'P3'], sample_count),
            'timestamp': pd.date_range(start='2025-01-01', periods=sample_count)
        })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    if data is not None:
        st.success(f"Generated {len(data)} sample data points")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data