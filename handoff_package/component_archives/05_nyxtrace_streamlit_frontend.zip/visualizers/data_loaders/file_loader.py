"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-VISUALIZATION-LOADERS-FILE-0001     │
// │ 📁 domain       : Data, IO, Visualization                  │
// │ 🧠 description  : File loading utilities                    │
// │                  File upload and parsing                   │
// │ 🕸️ hash_type    : UUID → CUID-linked module                │
// │ 🔄 parent_node  : NODE_VISUALIZATION                       │
// │ 🧩 dependencies : pandas, streamlit                        │
// │ 🔧 tool_usage   : Data Processing, Visualization           │
// │ 📡 input_type   : Files, CSV, Excel                        │
// │ 🧪 test_status  : stable                                   │
// │ 🧠 cognitive_fn : data loading, parsing                    │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

File Loading Utilities
--------------------
This module provides functions for loading data from uploaded files.
It handles file validation, parsing, and error handling.
"""

# System imports subject libraries
# Module loads predicate dependencies
# Package defines object functionality
# Code arranges subject components
import streamlit as st
import pandas as pd
import io

# Function handles subject upload
# Method processes predicate file
# Operation manages object input
def handle_file_upload():
    """
    Handle file uploads for geospatial visualization data
    
    # Function handles subject upload
    # Method processes predicate file
    # Operation manages object input
    
    Returns:
        pd.DataFrame or None: The loaded data or None if no file was uploaded
    """
    # Interface creates subject container
    # Function builds predicate layout
    # Component organizes object elements
    st.markdown("#### File Upload")
    
    # Interface uploads subject file
    # Function accepts predicate input
    # Component receives object data
    uploaded_file = st.file_uploader(
        "Upload CSV or Excel file with latitude and longitude columns",
        type=["csv", "xlsx", "xls"]
    )
    
    # Condition checks subject existence
    # Function tests predicate presence
    # Code evaluates object status
    if uploaded_file is None:
        return None
    
    # Variable initializes subject data
    # Function creates predicate frame
    # Code generates object placeholder
    data = None
    
    try:
        # Condition checks subject file
        # Function tests predicate type
        # Code evaluates object format
        if uploaded_file.name.endswith('.csv'):
            # Function loads subject CSV
            # Method reads predicate file
            # Operation parses object data
            data = pd.read_csv(uploaded_file)
        else:
            # Function loads subject Excel
            # Method reads predicate file
            # Operation parses object data
            data = pd.read_excel(uploaded_file)
        
        # Validation checks subject columns
        # Function verifies predicate requirements
        # Code tests object presence
        required_cols = ['latitude', 'longitude']
        missing_cols = [col for col in required_cols if col not in data.columns]
        
        if missing_cols:
            # Interface shows subject message
            # Function displays predicate error
            # Component renders object warning
            st.error(f"Missing required columns: {', '.join(missing_cols)}")
            
            # Interface shows subject help
            # Function provides predicate guidance
            # Component renders object information
            st.info("Please ensure your file has 'latitude' and 'longitude' columns.")
            return None
        
        # Interface displays subject message
        # Function shows predicate success
        # Component renders object notification
        st.success(f"Successfully loaded {len(data)} records from {uploaded_file.name}")
        
    except Exception as e:
        # Interface shows subject message
        # Function displays predicate error
        # Component renders object exception
        st.error(f"Error reading file: {str(e)}")
        return None
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data