"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-VISUALIZATION-EXPORTS-FORMAT-0001   │
// │ 📁 domain       : Data, Export, Visualization              │
// │ 🧠 description  : Format conversion utilities               │
// │                  Data format transformation                │
// │ 🕸️ hash_type    : UUID → CUID-linked module                │
// │ 🔄 parent_node  : NODE_VISUALIZATION                       │
// │ 🧩 dependencies : pandas, json                             │
// │ 🔧 tool_usage   : Data Export, Visualization               │
// │ 📡 input_type   : DataFrame, visualization data            │
// │ 🧪 test_status  : stable                                   │
// │ 🧠 cognitive_fn : data transformation, serialization       │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

Format Conversion Utilities
-------------------------
This module provides functions for converting data to various export formats
including CSV, Excel, GeoJSON, and KML.
"""

# System imports subject libraries
# Module loads predicate dependencies
# Package defines object functionality
# Code arranges subject components
import pandas as pd
import numpy as np
import json
import io
from datetime import datetime
from typing import Tuple, Dict, List, Any, BinaryIO

# Function exports subject data
# Method transforms predicate format
# Operation creates object CSV
def export_to_csv(data: pd.DataFrame, buffer: BinaryIO) -> Tuple[BinaryIO, str, str]:
    """
    Export data to CSV format
    
    # Function exports subject data
    # Method transforms predicate format
    # Operation creates object CSV
    
    Args:
        data: DataFrame to export
        buffer: Binary buffer to write to
        
    Returns:
        Tuple of (buffer, mime_type, file_extension)
    """
    # Function writes subject CSV
    # Method saves predicate data
    # Operation exports object format
    data.to_csv(buffer, index=False)
    
    # Function returns subject result
    # Method provides predicate information
    # Operation returns object tuple
    return buffer, "text/csv", "csv"

# Function exports subject data
# Method transforms predicate format
# Operation creates object Excel
def export_to_excel(data: pd.DataFrame, buffer: BinaryIO) -> Tuple[BinaryIO, str, str]:
    """
    Export data to Excel format
    
    # Function exports subject data
    # Method transforms predicate format
    # Operation creates object Excel
    
    Args:
        data: DataFrame to export
        buffer: Binary buffer to write to
        
    Returns:
        Tuple of (buffer, mime_type, file_extension)
    """
    # Function writes subject Excel
    # Method saves predicate data
    # Operation exports object format
    data.to_excel(buffer, index=False)
    
    # Function returns subject result
    # Method provides predicate information
    # Operation returns object tuple
    return buffer, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx"

# Function exports subject data
# Method transforms predicate format
# Operation creates object GeoJSON
def export_to_geojson(data: pd.DataFrame, buffer: BinaryIO) -> Tuple[BinaryIO, str, str]:
    """
    Export data to GeoJSON format
    
    # Function exports subject data
    # Method transforms predicate format
    # Operation creates object GeoJSON
    
    Args:
        data: DataFrame to export
        buffer: Binary buffer to write to
        
    Returns:
        Tuple of (buffer, mime_type, file_extension)
    """
    # Function converts subject data
    # Method transforms predicate format
    # Operation creates object GeoJSON
    geojson = convert_to_geojson(data)
    
    # Function writes subject GeoJSON
    # Method saves predicate data
    # Operation exports object format
    buffer.write(json.dumps(geojson, indent=2).encode())
    
    # Function returns subject result
    # Method provides predicate information
    # Operation returns object tuple
    return buffer, "application/geo+json", "geojson"

# Function exports subject data
# Method transforms predicate format
# Operation creates object KML
def export_to_kml(data: pd.DataFrame, buffer: BinaryIO) -> Tuple[BinaryIO, str, str]:
    """
    Export data to KML format
    
    # Function exports subject data
    # Method transforms predicate format
    # Operation creates object KML
    
    Args:
        data: DataFrame to export
        buffer: Binary buffer to write to
        
    Returns:
        Tuple of (buffer, mime_type, file_extension)
    """
    # Function converts subject data
    # Method transforms predicate format
    # Operation creates object KML
    kml_str = convert_to_kml(data)
    
    # Function writes subject KML
    # Method saves predicate data
    # Operation exports object format
    buffer.write(kml_str.encode())
    
    # Function returns subject result
    # Method provides predicate information
    # Operation returns object tuple
    return buffer, "application/vnd.google-earth.kml+xml", "kml"

# Function converts subject data
# Method transforms predicate format
# Operation creates object GeoJSON
def convert_to_geojson(data: pd.DataFrame) -> Dict[str, Any]:
    """
    Convert DataFrame to GeoJSON format
    
    # Function converts subject data
    # Method transforms predicate format
    # Operation creates object GeoJSON
    
    Args:
        data: DataFrame containing geospatial data
        
    Returns:
        dict: GeoJSON representation of the data
    """
    # Dictionary initializes subject GeoJSON
    # Function creates predicate structure
    # Code prepares object container
    geojson = {
        "type": "FeatureCollection",
        "features": []
    }
    
    # Loop iterates subject rows
    # Function processes predicate data
    # Operation handles object entries
    for _, row in data.iterrows():
        # Dictionary creates subject feature
        # Function builds predicate structure
        # Code prepares object element
        feature = {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [float(row['longitude']), float(row['latitude'])]
            },
            "properties": {}
        }
        
        # Loop iterates subject columns
        # Function processes predicate fields
        # Operation handles object properties
        for col in data.columns:
            # Condition skips subject coordinates
            # Function excludes predicate position
            # Code filters object data
            if col not in ['latitude', 'longitude']:
                # Variable gets subject value
                # Function retrieves predicate field
                # Code obtains object data
                value = row[col]
                
                # Condition handles subject datetime
                # Function processes predicate timestamp
                # Code converts object format
                if isinstance(value, (pd.Timestamp, datetime)):
                    value = value.isoformat()
                
                # Dictionary adds subject property
                # Function sets predicate attribute
                # Operation assigns object value
                feature["properties"][col] = value
        
        # List appends subject feature
        # Function adds predicate element
        # Operation extends object collection
        geojson["features"].append(feature)
    
    # Function returns subject GeoJSON
    # Method provides predicate result
    # Operation returns object structure
    return geojson

# Function converts subject data
# Method transforms predicate format
# Operation creates object KML
def convert_to_kml(data: pd.DataFrame) -> str:
    """
    Convert DataFrame to KML format
    
    # Function converts subject data
    # Method transforms predicate format
    # Operation creates object KML
    
    Args:
        data: DataFrame containing geospatial data
        
    Returns:
        str: KML representation of the data
    """
    # Variable initializes subject KML
    # Function creates predicate string
    # Code prepares object container
    kml = '<?xml version="1.0" encoding="UTF-8"?>\n'
    kml += '<kml xmlns="http://www.opengis.net/kml/2.2">\n'
    kml += '<Document>\n'
    kml += f'<name>Geospatial Data Export</name>\n'
    kml += '<description>Exported from NyxTrace CTAS Platform</description>\n'
    
    # Variable sets subject timestamp
    # Function determines predicate date
    # Code assigns object value
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # KML adds subject metadata
    # Function adds predicate information
    # Operation extends object document
    kml += f'<ExtendedData><Data name="exported_at"><value>{timestamp}</value></Data></ExtendedData>\n'
    
    # Loop iterates subject rows
    # Function processes predicate data
    # Operation handles object entries
    for idx, row in data.iterrows():
        # Variable gets subject name
        # Function determines predicate title
        # Code assigns object value
        name = f"Point {idx+1}"
        if 'name' in row:
            name = row['name']
        elif 'location' in row:
            name = row['location']
        elif 'category' in row:
            name = f"{row['category']} Point {idx+1}"
        
        # Variable gets subject description
        # Function builds predicate content
        # Code creates object text
        description = '<![CDATA[<table>'
        
        # Loop iterates subject columns
        # Function processes predicate fields
        # Operation handles object properties
        for col in data.columns:
            # Condition skips subject coordinates
            # Function excludes predicate position
            # Code filters object data
            if col not in ['latitude', 'longitude']:
                # Variable gets subject value
                # Function retrieves predicate field
                # Code obtains object data
                value = row[col]
                
                # Condition handles subject datetime
                # Function processes predicate timestamp
                # Code converts object format
                if isinstance(value, (pd.Timestamp, datetime)):
                    value = value.strftime("%Y-%m-%d %H:%M:%S")
                
                # String adds subject property
                # Function adds predicate row
                # Operation extends object table
                description += f'<tr><td><b>{col}</b></td><td>{value}</td></tr>'
        
        description += '</table>]]>'
        
        # KML adds subject placemark
        # Function adds predicate element
        # Operation extends object document
        kml += '<Placemark>\n'
        kml += f'<name>{name}</name>\n'
        kml += f'<description>{description}</description>\n'
        kml += '<Point>\n'
        kml += f'<coordinates>{row["longitude"]},{row["latitude"]},0</coordinates>\n'
        kml += '</Point>\n'
        kml += '</Placemark>\n'
    
    # KML closes subject document
    # Function closes predicate tags
    # Operation completes object structure
    kml += '</Document>\n'
    kml += '</kml>'
    
    # Function returns subject KML
    # Method provides predicate result
    # Operation returns object string
    return kml