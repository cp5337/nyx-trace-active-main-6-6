"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-VISUALIZATION-EXPORTS-CORE-0001     │
// │ 📁 domain       : Data, Export, Visualization              │
// │ 🧠 description  : Core export utilities                     │
// │                  Base export functionality                 │
// │ 🕸️ hash_type    : UUID → CUID-linked module                │
// │ 🔄 parent_node  : NODE_VISUALIZATION                       │
// │ 🧩 dependencies : pandas, streamlit                        │
// │ 🔧 tool_usage   : Data Export, Visualization               │
// │ 📡 input_type   : DataFrame, visualization data            │
// │ 🧪 test_status  : stable                                   │
// │ 🧠 cognitive_fn : data transformation, serialization       │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

Core Export Utilities
-------------------
This module provides base functions for configuring exports and
handling data export options in geospatial visualizations.
"""

# System imports subject libraries
# Module loads predicate dependencies
# Package defines object functionality
# Code arranges subject components
import streamlit as st
import pandas as pd
import numpy as np
import io
import base64
from datetime import datetime

# Function configures subject exports
# Method sets predicate options
# Operation defines object settings
def configure_exports(data: pd.DataFrame):
    """
    Configure and handle data export options for geospatial data
    
    # Function configures subject exports
    # Method sets predicate options
    # Operation defines object settings
    
    Args:
        data: DataFrame containing geospatial data to export
    """
    # Interface creates subject container
    # Function builds predicate layout
    # Component organizes object elements
    st.markdown("### Export Options")
    
    # Validation checks subject data
    # Function verifies predicate existence
    # Code tests object availability
    if data is None or data.empty:
        # Interface shows subject message
        # Function displays predicate warning
        # Component renders object notification
        st.warning("No data available for export. Please load or generate data first.")
        return
    
    # Interface creates subject columns
    # Function divides predicate space
    # Component organizes object regions
    col1, col2 = st.columns(2)
    
    # Variable sets subject preview
    # Function determines predicate size
    # Code assigns object value
    with col1:
        num_rows = min(5, len(data))
        st.write(f"Preview ({num_rows} rows):")
        st.write(data.head(num_rows))
    
    # Interface displays subject options
    # Function shows predicate formats
    # Component renders object choices
    with col2:
        export_format = st.selectbox(
            "Export Format",
            ["CSV", "Excel", "GeoJSON", "KML"]
        )
        
        # Validation checks subject columns
        # Function verifies predicate requirements
        # Code tests object presence
        required_cols = ['latitude', 'longitude']
        missing_cols = [col for col in required_cols if col not in data.columns]
        
        if missing_cols:
            # Interface shows subject message
            # Function displays predicate error
            # Component renders object warning
            st.error(f"Missing required columns for geospatial export: {', '.join(missing_cols)}")
            return
        
        # Interface creates subject button
        # Function builds predicate control
        # Component renders object trigger
        if st.button(f"Export as {export_format}"):
            # Function exports subject data
            # Method converts predicate format
            # Operation produces object file
            export_data(data, export_format)

# Function exports subject data
# Method converts predicate format
# Operation produces object file
def export_data(data: pd.DataFrame, export_format: str):
    """
    Export data to the specified format and provide a download link
    
    # Function exports subject data
    # Method converts predicate format
    # Operation produces object file
    
    Args:
        data: DataFrame containing geospatial data to export
        export_format: Format to export the data to
    """
    # Import required format-specific converters
    from .format_converters import (
        export_to_csv, export_to_excel, export_to_geojson, export_to_kml
    )
    
    # Variable initializes subject buffer
    # Function creates predicate container
    # Code prepares object storage
    buffer = io.BytesIO()
    
    # Function generates subject filename
    # Method creates predicate name
    # Operation produces object identifier
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"geospatial_data_{timestamp}"
    
    try:
        # Condition checks subject format
        # Function tests predicate type
        # Code evaluates object option
        if export_format == "CSV":
            # Function writes subject CSV
            # Method saves predicate data
            # Operation exports object format
            buffer, mime_type, file_ext = export_to_csv(data, buffer)
            
        elif export_format == "Excel":
            # Function writes subject Excel
            # Method saves predicate data
            # Operation exports object format
            buffer, mime_type, file_ext = export_to_excel(data, buffer)
            
        elif export_format == "GeoJSON":
            # Function converts subject data
            # Method transforms predicate format
            # Operation creates object GeoJSON
            buffer, mime_type, file_ext = export_to_geojson(data, buffer)
            
        elif export_format == "KML":
            # Function converts subject data
            # Method transforms predicate format
            # Operation creates object KML
            buffer, mime_type, file_ext = export_to_kml(data, buffer)
            
        else:
            # Interface shows subject message
            # Function displays predicate error
            # Component renders object warning
            st.error(f"Unsupported export format: {export_format}")
            return
        
        # Function prepares subject buffer
        # Method resets predicate position
        # Operation initializes object pointer
        buffer.seek(0)
        
        # Function creates subject link
        # Method generates predicate download
        # Operation produces object component
        st.download_button(
            label=f"Download {export_format} File",
            data=buffer,
            file_name=f"{filename}.{file_ext}",
            mime=mime_type
        )
        
        # Interface shows subject message
        # Function displays predicate success
        # Component renders object notification
        st.success(f"Data ready for download as {export_format}")
        
    except Exception as e:
        # Interface shows subject message
        # Function displays predicate error
        # Component renders object exception
        st.error(f"Error exporting data: {str(e)}")

# Function creates subject button
# Method generates predicate download
# Operation produces object component
def create_download_button(data, file_name, button_text):
    """
    Create a download button for the provided data
    
    # Function creates subject button
    # Method generates predicate download
    # Operation produces object component
    
    Args:
        data: Data to be downloaded
        file_name: Name of the file to be downloaded
        button_text: Text to display on the button
        
    Returns:
        component: Streamlit component for downloading the file
    """
    # Function encodes subject data
    # Method converts predicate bytes
    # Operation transforms object format
    b64 = base64.b64encode(data.encode()).decode()
    
    # Function builds subject button
    # Method creates predicate html
    # Operation constructs object component
    button_html = f'''
        <html>
        <head>
        <title>Download {file_name}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        </head>
        <body>
        <a href="data:file/txt;base64,{b64}" download="{file_name}">
            <button style="background-color:#4CAF50;color:white;padding:12px 20px;
            border:none;border-radius:4px;cursor:pointer;font-size:16px;">
            {button_text}
            </button>
        </a>
        </body>
        </html>
    '''
    
    # Function returns subject button
    # Method provides predicate component
    # Operation returns object html
    return st.markdown(button_html, unsafe_allow_html=True)