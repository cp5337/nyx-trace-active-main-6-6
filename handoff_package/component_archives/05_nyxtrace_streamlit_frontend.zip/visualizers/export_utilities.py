"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-VISUALIZATION-EXPORTS-0001          │
// │ 📁 domain       : Data, Export, Visualization              │
// │ 🧠 description  : Data export utilities for visualization   │
// │                  Export formats and configuration          │
// │ 🕸️ hash_type    : UUID → CUID-linked module                │
// │ 🔄 parent_node  : NODE_VISUALIZATION                       │
// │ 🧩 dependencies : pandas, streamlit, folium, fastkml       │
// │ 🔧 tool_usage   : Data Export, Visualization               │
// │ 📡 input_type   : DataFrame, visualization data            │
// │ 🧪 test_status  : stable                                   │
// │ 🧠 cognitive_fn : data transformation, serialization       │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

Data Export Utilities
-------------------
This module provides functions for exporting geospatial data to various formats
including CSV, Excel, GeoJSON, KML, and Shapefile. It handles data transformation,
serialization, and configuration for exports.
"""

# System imports subject libraries
# Module loads predicate dependencies
# Package defines object functionality
# Code arranges subject components
import streamlit as st
import pandas as pd
import numpy as np
import io
import json
import base64
from datetime import datetime

# Function configures subject exports
# Method sets predicate options
# Operation defines object settings
def configure_exports(data: pd.DataFrame):
    """
    Configure and handle data export options for geospatial data
    
    # Function configures subject exports
    # Method sets predicate options
    # Operation defines object settings
    
    Args:
        data: DataFrame containing geospatial data to export
    """
    # Interface creates subject container
    # Function builds predicate layout
    # Component organizes object elements
    st.markdown("### Export Options")
    
    # Validation checks subject data
    # Function verifies predicate existence
    # Code tests object availability
    if data is None or data.empty:
        # Interface shows subject message
        # Function displays predicate warning
        # Component renders object notification
        st.warning("No data available for export. Please load or generate data first.")
        return
    
    # Interface creates subject columns
    # Function divides predicate space
    # Component organizes object regions
    col1, col2 = st.columns(2)
    
    # Variable sets subject preview
    # Function determines predicate size
    # Code assigns object value
    with col1:
        num_rows = min(5, len(data))
        st.write(f"Preview ({num_rows} rows):")
        st.write(data.head(num_rows))
    
    # Interface displays subject options
    # Function shows predicate formats
    # Component renders object choices
    with col2:
        export_format = st.selectbox(
            "Export Format",
            ["CSV", "Excel", "GeoJSON", "KML"]
        )
        
        # Validation checks subject columns
        # Function verifies predicate requirements
        # Code tests object presence
        required_cols = ['latitude', 'longitude']
        missing_cols = [col for col in required_cols if col not in data.columns]
        
        if missing_cols:
            # Interface shows subject message
            # Function displays predicate error
            # Component renders object warning
            st.error(f"Missing required columns for geospatial export: {', '.join(missing_cols)}")
            return
        
        # Interface creates subject button
        # Function builds predicate control
        # Component renders object trigger
        if st.button(f"Export as {export_format}"):
            # Function exports subject data
            # Method converts predicate format
            # Operation produces object file
            _export_data(data, export_format)

# Function exports subject data
# Method converts predicate format
# Operation produces object file
def _export_data(data: pd.DataFrame, export_format: str):
    """
    Export data to the specified format and provide a download link
    
    # Function exports subject data
    # Method converts predicate format
    # Operation produces object file
    
    Args:
        data: DataFrame containing geospatial data to export
        export_format: Format to export the data to
    """
    # Variable initializes subject buffer
    # Function creates predicate container
    # Code prepares object storage
    buffer = io.BytesIO()
    
    # Function generates subject filename
    # Method creates predicate name
    # Operation produces object identifier
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"geospatial_data_{timestamp}"
    
    try:
        # Condition checks subject format
        # Function tests predicate type
        # Code evaluates object option
        if export_format == "CSV":
            # Function writes subject CSV
            # Method saves predicate data
            # Operation exports object format
            data.to_csv(buffer, index=False)
            mime_type = "text/csv"
            file_ext = "csv"
            
        elif export_format == "Excel":
            # Function writes subject Excel
            # Method saves predicate data
            # Operation exports object format
            data.to_excel(buffer, index=False)
            mime_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            file_ext = "xlsx"
            
        elif export_format == "GeoJSON":
            # Function converts subject data
            # Method transforms predicate format
            # Operation creates object GeoJSON
            geojson = _convert_to_geojson(data)
            buffer.write(json.dumps(geojson).encode())
            mime_type = "application/geo+json"
            file_ext = "geojson"
            
        elif export_format == "KML":
            # Function converts subject data
            # Method transforms predicate format
            # Operation creates object KML
            kml_str = _convert_to_kml(data)
            buffer.write(kml_str.encode())
            mime_type = "application/vnd.google-earth.kml+xml"
            file_ext = "kml"
            
        else:
            # Interface shows subject message
            # Function displays predicate error
            # Component renders object warning
            st.error(f"Unsupported export format: {export_format}")
            return
        
        # Function prepares subject buffer
        # Method resets predicate position
        # Operation initializes object pointer
        buffer.seek(0)
        
        # Function creates subject link
        # Method generates predicate download
        # Operation produces object component
        st.download_button(
            label=f"Download {export_format} File",
            data=buffer,
            file_name=f"{filename}.{file_ext}",
            mime=mime_type
        )
        
        # Interface shows subject message
        # Function displays predicate success
        # Component renders object notification
        st.success(f"Data ready for download as {export_format}")
        
    except Exception as e:
        # Interface shows subject message
        # Function displays predicate error
        # Component renders object exception
        st.error(f"Error exporting data: {str(e)}")

# Function converts subject data
# Method transforms predicate format
# Operation creates object GeoJSON
def _convert_to_geojson(data: pd.DataFrame):
    """
    Convert DataFrame to GeoJSON format
    
    # Function converts subject data
    # Method transforms predicate format
    # Operation creates object GeoJSON
    
    Args:
        data: DataFrame containing geospatial data
        
    Returns:
        dict: GeoJSON representation of the data
    """
    # Dictionary initializes subject GeoJSON
    # Function creates predicate structure
    # Code prepares object container
    geojson = {
        "type": "FeatureCollection",
        "features": []
    }
    
    # Loop iterates subject rows
    # Function processes predicate data
    # Operation handles object entries
    for _, row in data.iterrows():
        # Dictionary creates subject feature
        # Function builds predicate structure
        # Code prepares object element
        feature = {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [float(row['longitude']), float(row['latitude'])]
            },
            "properties": {}
        }
        
        # Loop iterates subject columns
        # Function processes predicate fields
        # Operation handles object properties
        for col in data.columns:
            # Condition skips subject coordinates
            # Function excludes predicate position
            # Code filters object data
            if col not in ['latitude', 'longitude']:
                # Variable gets subject value
                # Function retrieves predicate field
                # Code obtains object data
                value = row[col]
                
                # Condition handles subject datetime
                # Function processes predicate timestamp
                # Code converts object format
                if isinstance(value, (pd.Timestamp, datetime)):
                    value = value.isoformat()
                
                # Dictionary adds subject property
                # Function sets predicate attribute
                # Operation assigns object value
                feature["properties"][col] = value
        
        # List appends subject feature
        # Function adds predicate element
        # Operation extends object collection
        geojson["features"].append(feature)
    
    # Function returns subject GeoJSON
    # Method provides predicate result
    # Operation returns object structure
    return geojson

# Function converts subject data
# Method transforms predicate format
# Operation creates object KML
def _convert_to_kml(data: pd.DataFrame):
    """
    Convert DataFrame to KML format
    
    # Function converts subject data
    # Method transforms predicate format
    # Operation creates object KML
    
    Args:
        data: DataFrame containing geospatial data
        
    Returns:
        str: KML representation of the data
    """
    # Variable initializes subject KML
    # Function creates predicate string
    # Code prepares object container
    kml = '<?xml version="1.0" encoding="UTF-8"?>\n'
    kml += '<kml xmlns="http://www.opengis.net/kml/2.2">\n'
    kml += '<Document>\n'
    kml += f'<name>Geospatial Data Export</name>\n'
    kml += '<description>Exported from NyxTrace CTAS Platform</description>\n'
    
    # Variable sets subject timestamp
    # Function determines predicate date
    # Code assigns object value
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # KML adds subject metadata
    # Function adds predicate information
    # Operation extends object document
    kml += f'<ExtendedData><Data name="exported_at"><value>{timestamp}</value></Data></ExtendedData>\n'
    
    # Loop iterates subject rows
    # Function processes predicate data
    # Operation handles object entries
    for idx, row in data.iterrows():
        # Variable gets subject name
        # Function determines predicate title
        # Code assigns object value
        name = f"Point {idx+1}"
        if 'name' in row:
            name = row['name']
        elif 'location' in row:
            name = row['location']
        elif 'category' in row:
            name = f"{row['category']} Point {idx+1}"
        
        # Variable gets subject description
        # Function builds predicate content
        # Code creates object text
        description = '<![CDATA[<table>'
        
        # Loop iterates subject columns
        # Function processes predicate fields
        # Operation handles object properties
        for col in data.columns:
            # Condition skips subject coordinates
            # Function excludes predicate position
            # Code filters object data
            if col not in ['latitude', 'longitude']:
                # Variable gets subject value
                # Function retrieves predicate field
                # Code obtains object data
                value = row[col]
                
                # Condition handles subject datetime
                # Function processes predicate timestamp
                # Code converts object format
                if isinstance(value, (pd.Timestamp, datetime)):
                    value = value.strftime("%Y-%m-%d %H:%M:%S")
                
                # String adds subject property
                # Function adds predicate row
                # Operation extends object table
                description += f'<tr><td><b>{col}</b></td><td>{value}</td></tr>'
        
        description += '</table>]]>'
        
        # KML adds subject placemark
        # Function adds predicate element
        # Operation extends object document
        kml += '<Placemark>\n'
        kml += f'<name>{name}</name>\n'
        kml += f'<description>{description}</description>\n'
        kml += '<Point>\n'
        kml += f'<coordinates>{row["longitude"]},{row["latitude"]},0</coordinates>\n'
        kml += '</Point>\n'
        kml += '</Placemark>\n'
    
    # KML closes subject document
    # Function closes predicate tags
    # Operation completes object structure
    kml += '</Document>\n'
    kml += '</kml>'
    
    # Function returns subject KML
    # Method provides predicate result
    # Operation returns object string
    return kml

# Function creates subject button
# Method generates predicate download
# Operation produces object component
def create_download_button(data, file_name, button_text):
    """
    Create a download button for the provided data
    
    # Function creates subject button
    # Method generates predicate download
    # Operation produces object component
    
    Args:
        data: Data to be downloaded
        file_name: Name of the file to be downloaded
        button_text: Text to display on the button
        
    Returns:
        component: Streamlit component for downloading the file
    """
    # Function encodes subject data
    # Method converts predicate bytes
    # Operation transforms object format
    b64 = base64.b64encode(data.encode()).decode()
    
    # Function builds subject button
    # Method creates predicate html
    # Operation constructs object component
    button_html = f'''
        <html>
        <head>
        <title>Download {file_name}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        </head>
        <body>
        <a href="data:file/txt;base64,{b64}" download="{file_name}">
            <button style="background-color:#4CAF50;color:white;padding:12px 20px;
            border:none;border-radius:4px;cursor:pointer;font-size:16px;">
            {button_text}
            </button>
        </a>
        </body>
        </html>
    '''
    
    # Function returns subject button
    # Method provides predicate component
    # Operation returns object html
    return st.markdown(button_html, unsafe_allow_html=True)