"""
URL Context Card Visualizer
--------------------------
Visualizer for displaying URL context data in a card format.
This component renders the URL metadata, screenshot, and analysis
as an interactive context card with emoji-based summaries.
"""

import base64
import datetime
import io
import json
import logging
import re
import uuid
from typing import Dict, Any, List, Optional, Tuple, Set, Union

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from PIL import Image

from core.interfaces.visualizers import VisualizerParams, Visualizer

logger = logging.getLogger(__name__)

class URLContextCardVisualizer(Visualizer):
    """
    Visualizer for URL context data.
    
    This visualizer renders URL metadata and analysis as an interactive
    context card with emoji-based summaries and insights.
    """
    
    def __init__(self, visualizer_id: Optional[str] = None):
        """
        Initialize the visualizer
        
        Args:
            visualizer_id: Optional visualizer ID
        """
        self._id = visualizer_id or f"url_context_card_visualizer-{uuid.uuid4()}"
        self._metadata = {
            "version": "1.0",
            "capabilities": {
                "interactive": True,
                "exportable": True,
                "responsive": True
            }
        }
        self._activation_params = {
            "entropy": 0.7,
            "transition_readiness": 0.8
        }
        
        # Theme settings
        self._theme = {
            "light": {
                "card_bg": "#FFFFFF",
                "header_bg": "#F5F7F9",
                "border": "#E0E5EC",
                "text": "#2D3748",
                "accent": "#4F46E5",
                "success": "#10B981",
                "warning": "#F59E0B",
                "danger": "#EF4444"
            },
            "dark": {
                "card_bg": "#1E293B",
                "header_bg": "#0F172A",
                "border": "#334155",
                "text": "#E2E8F0",
                "accent": "#818CF8",
                "success": "#34D399",
                "warning": "#FBBF24",
                "danger": "#F87171"
            }
        }
        
        logger.info(f"URL Context Card Visualizer initialized with ID {self._id}")
        
    def get_id(self) -> str:
        """Get the component's unique identifier"""
        return self._id
        
    def get_metadata(self) -> Dict[str, Any]:
        """Get the component's metadata"""
        return self._metadata
        
    def get_activation_parameters(self) -> Dict[str, float]:
        """Get the component's activation parameters"""
        return self._activation_params
        
    def is_activated(self) -> bool:
        """Check if the component is currently activated"""
        # In a real implementation, this would check with the registry
        return True
        
    def visualize(self, data: Any, params: Optional[VisualizerParams] = None) -> None:
        """
        Visualize the data as a URL context card
        
        Args:
            data: URL data to visualize
            params: Visualization parameters
        """
        # Extract theme preference
        theme = "light"
        if params and "theme" in params.custom_params:
            theme = params.custom_params["theme"]
            
        # Get theme colors
        colors = self._theme.get(theme, self._theme["light"])
        
        # Determine container width
        container_width = "wide"
        if params and "container_width" in params.custom_params:
            container_width = params.custom_params["container_width"]
            
        # Set default container styling
        st.markdown(f"""
        <style>
        .url-context-card {{
            border: 1px solid {colors['border']};
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 20px;
            background-color: {colors['card_bg']};
        }}
        .url-context-header {{
            background-color: {colors['header_bg']};
            padding: 12px 16px;
            border-bottom: 1px solid {colors['border']};
        }}
        .url-context-body {{
            padding: 16px;
        }}
        .url-context-footer {{
            padding: 12px 16px;
            border-top: 1px solid {colors['border']};
            font-size: 12px;
        }}
        .emoji-chip {{
            display: inline-block;
            padding: 4px 8px;
            border-radius: 16px;
            margin-right: 8px;
            margin-bottom: 8px;
            background-color: {colors['header_bg']};
            font-size: 14px;
        }}
        </style>
        """, unsafe_allow_html=True)
        
        # Support multiple formats of data
        url_data = {}
        if isinstance(data, dict):
            if "processed_data" in data:
                # This is ProcessedIntelligence
                url_data = data["processed_data"]
            else:
                # Direct URL data
                url_data = data
        else:
            logger.warning(f"Unknown data format: {type(data)}")
            st.error("Invalid data format for URL context card")
            return
            
        # Render the context card
        with st.container():
            self._render_context_card(url_data, colors)
        
    def _render_context_card(self, url_data: Dict[str, Any], colors: Dict[str, str]) -> None:
        """
        Render the URL context card
        
        Args:
            url_data: URL data to render
            colors: Theme colors
        """
        # Extract basic info
        url = url_data.get("url", "")
        title = url_data.get("title", "No title")
        domain = url_data.get("domain", "")
        screenshot = url_data.get("screenshot")
        
        # Render header
        st.markdown(f"<div class='url-context-card'>", unsafe_allow_html=True)
        st.markdown(f"<div class='url-context-header'>", unsafe_allow_html=True)
        
        cols = st.columns([3, 1])
        with cols[0]:
            st.markdown(f"<h3 style='margin:0; color:{colors['text']};'>{title}</h3>", unsafe_allow_html=True)
            st.markdown(f"<a href='{url}' target='_blank' style='color:{colors['accent']};'>{url}</a>", unsafe_allow_html=True)
            
        with cols[1]:
            # Render favicon if available
            favicon = url_data.get("favicon", "")
            if favicon:
                st.markdown(f"<img src='{favicon}' style='height:24px; float:right;' />", unsafe_allow_html=True)
                
        st.markdown("</div>", unsafe_allow_html=True)
        
        # Render emoji summary
        emoji_summary = url_data.get("emoji_summary", {})
        if emoji_summary:
            st.markdown("<div style='padding:8px 16px; border-bottom:1px solid " + colors['border'] + ";'>", unsafe_allow_html=True)
            
            # Create emoji chips
            emoji_html = ""
            for key, emoji in emoji_summary.items():
                label = key.replace('_', ' ').title()
                emoji_html += f"<div class='emoji-chip'>{emoji} {label}</div>"
                
            st.markdown(emoji_html, unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)
        
        # Render body
        st.markdown("<div class='url-context-body'>", unsafe_allow_html=True)
        
        # Two-column layout for screenshot and details
        cols = st.columns([1, 1])
        
        with cols[0]:
            # Display screenshot if available
            if screenshot:
                try:
                    image_data = base64.b64decode(screenshot)
                    image = Image.open(io.BytesIO(image_data))
                    st.image(image, caption="Website Screenshot", use_column_width=True)
                except Exception as e:
                    logger.error(f"Error displaying screenshot: {str(e)}")
                    st.warning("Screenshot not available")
            else:
                st.info("Screenshot not available")
                
        with cols[1]:
            # Display details
            security_indicators = url_data.get("security_indicators", {})
            tech_stack = url_data.get("technology_stack", {})
            
            st.markdown(f"### Website Overview")
            
            # Key metrics
            metrics_cols = st.columns(2)
            
            with metrics_cols[0]:
                response_time = url_data.get("response_time_ms", 0)
                st.metric("Response Time", f"{response_time} ms")
                
            with metrics_cols[1]:
                security_score = security_indicators.get("score", 0)
                st.metric("Security Score", f"{security_score:.2f}")
                
            # Security info
            st.markdown("#### Security")
            security_items = []
            
            # HTTPS
            https = security_indicators.get("https", False)
            https_icon = "✅" if https else "❌"
            security_items.append(f"{https_icon} HTTPS: {'Enabled' if https else 'Disabled'}")
            
            # Content Security Policy
            csp = security_indicators.get("csp", False)
            csp_icon = "✅" if csp else "❌"
            security_items.append(f"{csp_icon} Content Security Policy: {'Present' if csp else 'Missing'}")
            
            # XSS Protection
            xss = security_indicators.get("xss_protection", False)
            xss_icon = "✅" if xss else "❌"
            security_items.append(f"{xss_icon} XSS Protection: {'Enabled' if xss else 'Disabled'}")
            
            for item in security_items:
                st.markdown(item)
                
            # Technology stack
            st.markdown("#### Technology")
            
            tech_items = []
            for tech, present in tech_stack.items():
                if present and tech not in ["server", "php_session", "asp_session", "jsessionid"]:
                    tech_items.append(f"✅ {tech.title()}")
                    
            if tech_items:
                for item in tech_items:
                    st.markdown(item)
            else:
                st.markdown("No technologies detected")
                
        # Display content summary
        st.markdown("### Content Summary")
        
        # Process content metrics
        content_metrics = url_data.get("content_metrics", {})
        if content_metrics:
            cols = st.columns(4)
            
            with cols[0]:
                st.metric("Words", content_metrics.get("word_count", 0))
                
            with cols[1]:
                st.metric("Chars", content_metrics.get("char_count", 0))
                
            with cols[2]:
                st.metric("Sentences", content_metrics.get("sentence_count", 0))
                
            with cols[3]:
                st.metric("Paragraphs", content_metrics.get("paragraph_count", 0))
                
        # Display links summary
        links = url_data.get("links", [])
        if links:
            st.markdown(f"#### Links ({len(links)})")
            
            # Sample of links
            link_sample = links[:5]
            link_df = pd.DataFrame([
                {"Text": l.get("text", "No text"), "URL": l.get("url", "")} 
                for l in link_sample
            ])
            
            st.dataframe(link_df, use_container_width=True)
            
            if len(links) > 5:
                st.caption(f"Showing 5 of {len(links)} links")
                
        # Display main content preview
        main_content = url_data.get("main_content", "")
        if main_content:
            st.markdown("#### Content Preview")
            
            # Truncate long content
            if len(main_content) > 500:
                preview = main_content[:500] + "..."
            else:
                preview = main_content
                
            st.text_area("", preview, height=150)
            
        st.markdown("</div>", unsafe_allow_html=True)
        
        # Render footer
        st.markdown("<div class='url-context-footer'>", unsafe_allow_html=True)
        
        fetch_time = None
        if "fetch_time" in url_data:
            try:
                fetch_time = datetime.datetime.fromisoformat(url_data["fetch_time"])
            except (ValueError, TypeError):
                pass
                
        if fetch_time:
            st.markdown(f"Data collected on {fetch_time.strftime('%Y-%m-%d %H:%M:%S')}", unsafe_allow_html=True)
        else:
            st.markdown("Data collection time unknown", unsafe_allow_html=True)
            
        st.markdown("</div>", unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)
        
    def render_export_options(self, data: Any, params: Optional[VisualizerParams] = None) -> None:
        """
        Render export options for the URL data
        
        Args:
            data: URL data to export
            params: Visualization parameters
        """
        st.markdown("### Export Options")
        
        cols = st.columns(3)
        
        with cols[0]:
            if st.button("Export as JSON"):
                # Convert to JSON
                json_data = json.dumps(data, indent=2)
                
                # Create download link
                st.download_button(
                    label="Download JSON",
                    data=json_data,
                    file_name="url_context.json",
                    mime="application/json"
                )
                
        with cols[1]:
            if st.button("Export as HTML"):
                # Generate HTML report
                html = self._generate_html_report(data)
                
                # Create download link
                st.download_button(
                    label="Download HTML",
                    data=html,
                    file_name="url_context.html",
                    mime="text/html"
                )
                
        with cols[2]:
            if st.button("Export Screenshot"):
                screenshot = data.get("screenshot")
                
                if screenshot:
                    try:
                        # Decode screenshot
                        screenshot_data = base64.b64decode(screenshot)
                        
                        # Create download link
                        st.download_button(
                            label="Download Screenshot",
                            data=screenshot_data,
                            file_name="screenshot.jpg",
                            mime="image/jpeg"
                        )
                    except Exception as e:
                        logger.error(f"Error exporting screenshot: {str(e)}")
                        st.error("Error exporting screenshot")
                else:
                    st.error("No screenshot available to export")
        
    def _generate_html_report(self, data: Dict[str, Any]) -> str:
        """
        Generate an HTML report for the URL data
        
        Args:
            data: URL data for the report
            
        Returns:
            HTML report as a string
        """
        url = data.get("url", "")
        title = data.get("title", "No title")
        domain = data.get("domain", "")
        description = data.get("description", "")
        screenshot = data.get("screenshot", "")
        
        # Start HTML
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>URL Context Report: {title}</title>
            <style>
                body {{
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    max-width: 800px;
                    margin: 0 auto;
                    padding: 20px;
                }}
                .card {{
                    border: 1px solid #e0e0e0;
                    border-radius: 8px;
                    overflow: hidden;
                    margin-bottom: 20px;
                }}
                .card-header {{
                    background-color: #f5f5f5;
                    padding: 12px 16px;
                    border-bottom: 1px solid #e0e0e0;
                }}
                .card-body {{
                    padding: 16px;
                }}
                .card-footer {{
                    padding: 12px 16px;
                    border-top: 1px solid #e0e0e0;
                    font-size: 12px;
                    color: #666;
                }}
                h1, h2, h3, h4, h5, h6 {{
                    margin-top: 0;
                }}
                img.screenshot {{
                    max-width: 100%;
                    border: 1px solid #e0e0e0;
                    border-radius: 4px;
                }}
                .emoji-chip {{
                    display: inline-block;
                    padding: 4px 8px;
                    border-radius: 16px;
                    margin-right: 8px;
                    margin-bottom: 8px;
                    background-color: #f5f5f5;
                    font-size: 14px;
                }}
                .metrics {{
                    display: flex;
                    flex-wrap: wrap;
                    gap: 16px;
                    margin-bottom: 16px;
                }}
                .metric {{
                    flex: 1;
                    min-width: 120px;
                    padding: 12px;
                    border: 1px solid #e0e0e0;
                    border-radius: 4px;
                    text-align: center;
                }}
                .metric .value {{
                    font-size: 24px;
                    font-weight: bold;
                }}
                .metric .label {{
                    font-size: 12px;
                    color: #666;
                }}
                table {{
                    width: 100%;
                    border-collapse: collapse;
                }}
                table th, table td {{
                    text-align: left;
                    padding: 8px;
                    border-bottom: 1px solid #e0e0e0;
                }}
                table th {{
                    background-color: #f5f5f5;
                }}
            </style>
        </head>
        <body>
            <div class="card">
                <div class="card-header">
                    <h2>{title}</h2>
                    <a href="{url}" target="_blank">{url}</a>
                </div>
        """
        
        # Emoji summary
        emoji_summary = data.get("emoji_summary", {})
        if emoji_summary:
            html += '<div style="padding: 8px 16px; border-bottom: 1px solid #e0e0e0;">'
            
            for key, emoji in emoji_summary.items():
                label = key.replace('_', ' ').title()
                html += f'<div class="emoji-chip">{emoji} {label}</div>'
                
            html += '</div>'
            
        # Card body
        html += '<div class="card-body">'
        
        # Screenshot
        if screenshot:
            html += f"""
            <h3>Screenshot</h3>
            <img class="screenshot" src="data:image/jpeg;base64,{screenshot}" alt="Website Screenshot">
            """
            
        # Website Overview
        html += '<h3>Website Overview</h3>'
        
        # Key metrics
        content_metrics = data.get("content_metrics", {})
        if content_metrics:
            html += '<div class="metrics">'
            
            metrics = [
                {"label": "Words", "value": content_metrics.get("word_count", 0)},
                {"label": "Characters", "value": content_metrics.get("char_count", 0)},
                {"label": "Sentences", "value": content_metrics.get("sentence_count", 0)},
                {"label": "Paragraphs", "value": content_metrics.get("paragraph_count", 0)}
            ]
            
            for metric in metrics:
                html += f"""
                <div class="metric">
                    <div class="value">{metric['value']}</div>
                    <div class="label">{metric['label']}</div>
                </div>
                """
                
            html += '</div>'
            
        # Security info
        security_indicators = data.get("security_indicators", {})
        html += '<h3>Security</h3>'
        
        html += '<ul>'
        
        # HTTPS
        https = security_indicators.get("https", False)
        https_icon = "✅" if https else "❌"
        html += f"<li>{https_icon} HTTPS: {'Enabled' if https else 'Disabled'}</li>"
        
        # Content Security Policy
        csp = security_indicators.get("csp", False)
        csp_icon = "✅" if csp else "❌"
        html += f"<li>{csp_icon} Content Security Policy: {'Present' if csp else 'Missing'}</li>"
        
        # XSS Protection
        xss = security_indicators.get("xss_protection", False)
        xss_icon = "✅" if xss else "❌"
        html += f"<li>{xss_icon} XSS Protection: {'Enabled' if xss else 'Disabled'}</li>"
        
        html += '</ul>'
        
        # Technology stack
        tech_stack = data.get("technology_stack", {})
        html += '<h3>Technology</h3>'
        
        html += '<ul>'
        
        tech_items = []
        for tech, present in tech_stack.items():
            if present and tech not in ["server", "php_session", "asp_session", "jsessionid"]:
                html += f"<li>✅ {tech.title()}</li>"
                
        if not tech_items:
            html += "<li>No technologies detected</li>"
            
        html += '</ul>'
        
        # Links
        links = data.get("links", [])
        if links:
            html += f'<h3>Links ({len(links)})</h3>'
            
            link_sample = links[:10]
            
            html += '<table>'
            html += '<tr><th>Text</th><th>URL</th></tr>'
            
            for link in link_sample:
                text = link.get("text", "No text")
                url = link.get("url", "")
                html += f'<tr><td>{text}</td><td><a href="{url}" target="_blank">{url}</a></td></tr>'
                
            html += '</table>'
            
            if len(links) > 10:
                html += f'<p><em>Showing 10 of {len(links)} links</em></p>'
                
        # Content preview
        main_content = data.get("main_content", "")
        if main_content:
            html += '<h3>Content Preview</h3>'
            
            # Truncate long content
            if len(main_content) > 1000:
                preview = main_content[:1000] + "..."
            else:
                preview = main_content
                
            html += f'<pre style="background-color: #f5f5f5; padding: 12px; border-radius: 4px; overflow: auto;">{preview}</pre>'
            
        html += '</div>'  # End card-body
        
        # Footer
        html += '<div class="card-footer">'
        
        fetch_time = None
        if "fetch_time" in data:
            try:
                fetch_time = datetime.datetime.fromisoformat(data["fetch_time"])
                html += f'Data collected on {fetch_time.strftime("%Y-%m-%d %H:%M:%S")}'
            except (ValueError, TypeError):
                html += 'Data collection time unknown'
        else:
            html += 'Data collection time unknown'
            
        html += '</div>'  # End card-footer
        html += '</div>'  # End card
        
        # Report generation info
        html += f"""
        <p style="text-align: center; font-size: 12px; color: #666;">
            Report generated by NyxTrace OSINT Platform on {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        </p>
        </body>
        </html>
        """
        
        return html
        
    def get_visualization_domain(self) -> str:
        """Get the domain this visualizer operates in"""
        return "url_context"
        
    def get_visualization_capabilities(self) -> Dict[str, Any]:
        """Get the capabilities of this visualizer"""
        return self._metadata["capabilities"]
        
    def register(self, registry: Any) -> str:
        """Register with a registry"""
        # This would use the registry's register method
        # For now, just return the ID
        return self._id
        
    def unregister(self, registry: Any) -> bool:
        """Unregister from a registry"""
        # This would use the registry's unregister method
        # For now, just return True
        return True