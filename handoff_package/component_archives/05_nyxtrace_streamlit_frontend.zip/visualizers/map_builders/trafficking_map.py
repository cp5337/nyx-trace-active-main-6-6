"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-MAPBUILDER-TRAFFICKING-0001         │
// │ 📁 domain       : Visualization, Geospatial, Intelligence   │
// │ 🧠 description  : Trafficking routes map builder            │
// │                  for intel analysis and route visualization │
// │ 🕸️ hash_type    : UUID → CUID-linked module                 │
// │ 🔄 parent_node  : NODE_VISUALIZATION                       │
// │ 🧩 dependencies : streamlit, folium, pandas                 │
// │ 🔧 tool_usage   : Visualization, Analysis                  │
// │ 📡 input_type   : Geospatial data, coordinates              │
// │ 🧪 test_status  : stable                                   │
// │ 🧠 cognitive_fn : pattern detection, route mapping          │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

Trafficking Routes Map Builder
-----------------------------
This module provides specialized visualization capabilities for
trafficking routes, patterns, and related geospatial analysis.
"""

import streamlit as st
import folium
import pandas as pd
import numpy as np
from streamlit_folium import st_folium
from visualizers.tile_utils import get_tile_with_attribution

# Function creates subject samples
# Method generates predicate data
# Operation produces object coordinates
def get_sample_trafficking_data():
    """
    Generate sample trafficking route data with the required
    latitude and longitude columns
    
    # Function creates subject samples
    # Method generates predicate data
    # Operation produces object coordinates
    
    Returns:
        DataFrame with trafficking route data including lat/lon coordinates
    """
    # Generate sample data with lat/lon
    data = pd.DataFrame({
        'latitude': np.array([
            33.7490, 34.0522, 37.7749, 47.6062, 41.8781, 
            25.7617, 19.4326, 4.7110, -33.8688, 51.5074
        ]),
        'longitude': np.array([
            -84.3880, -118.2437, -122.4194, -122.3321, -87.6298,
            -80.1918, -99.1332, -74.0721, 151.2093, -0.1278
        ]),
        'route_name': [
            'Eastern US', 'Pacific Coast', 'Northern Route', 'Northwest Passage',
            'Central Corridor', 'Caribbean', 'Mesoamerican', 'South American',
            'Pacific Transit', 'European Gateway'
        ],
        'risk_level': [
            'High', 'Medium', 'Medium', 'Low', 'High',
            'Critical', 'High', 'Critical', 'Medium', 'Low'
        ],
        'activity_type': [
            'Narcotics', 'Human', 'Narcotics', 'Smuggling', 'Multiple',
            'Narcotics', 'Multiple', 'Narcotics', 'Human', 'Smuggling'
        ]
    })
    
    return data

# Function renders subject visualization
# Method displays predicate map
# Operation presents object routes
def render_trafficking_routes(data=None):
    """
    Render the trafficking routes visualization
    
    # Function renders subject visualization
    # Method displays predicate map
    # Operation presents object routes
    
    Args:
        data: Optional DataFrame with trafficking route data.
              If None, sample data will be used.
    """
    st.markdown("### Trafficking Routes")
    
    # Use provided data or generate sample data
    if data is None or data.empty:
        data = get_sample_trafficking_data()
    
    # Verify the data has required columns
    required_cols = ['latitude', 'longitude']
    if not all(col in data.columns for col in required_cols):
        st.error(f"Required columns (latitude, longitude) must be included for geospatial visualization.")
        # Replace with sample data if latitude/longitude are missing
        data = get_sample_trafficking_data()
    
    # Create map
    tile, attr = get_tile_with_attribution("OpenStreetMap")
    
    # Calculate map center based on data or use default
    if not data.empty:
        center_lat = data['latitude'].mean()
        center_lon = data['longitude'].mean()
        m = folium.Map(location=[center_lat, center_lon], zoom_start=2, tiles=tile, attr=attr)
        
        # Add route points
        for _, row in data.iterrows():
            color = 'red' if row.get('risk_level') == 'Critical' else 'orange' if row.get('risk_level') == 'High' else 'blue'
            popup_content = f"""
                <b>{row.get('route_name', 'Route')}</b><br>
                Risk: {row.get('risk_level', 'Unknown')}<br>
                Type: {row.get('activity_type', 'Unknown')}<br>
                Coordinates: {row['latitude']:.4f}, {row['longitude']:.4f}
            """
            folium.CircleMarker(
                location=[row['latitude'], row['longitude']],
                radius=7,
                color=color,
                fill=True,
                fill_opacity=0.7,
                popup=folium.Popup(popup_content, max_width=250)
            ).add_to(m)
    else:
        # Fallback to default view if no data
        m = folium.Map(location=[0, 0], zoom_start=2, tiles=tile, attr=attr)
        
    # Display the map
    st_folium(m, width=1400, height=800)