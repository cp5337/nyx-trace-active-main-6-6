"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-MAPBUILDER-TRANSPORT-0001           │
// │ 📁 domain       : Visualization, Geospatial, Intelligence   │
// │ 🧠 description  : Transport tracking map builder            │
// │                  for intel analysis and fleet visualization │
// │ 🕸️ hash_type    : UUID → CUID-linked module                 │
// │ 🔄 parent_node  : NODE_VISUALIZATION                       │
// │ 🧩 dependencies : streamlit, folium, pandas                 │
// │ 🔧 tool_usage   : Visualization, Analysis                  │
// │ 📡 input_type   : Geospatial data, coordinates              │
// │ 🧪 test_status  : stable                                   │
// │ 🧠 cognitive_fn : pattern detection, transport tracking     │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

Transport Tracking Map Builder
-----------------------------
This module provides specialized visualization capabilities for
transport tracking, fleet monitoring, and related geospatial analysis.
"""

import streamlit as st
import folium
import pandas as pd
import numpy as np
from streamlit_folium import st_folium
from visualizers.tile_utils import get_tile_with_attribution

# Function creates subject samples
# Method generates predicate data
# Operation produces object coordinates
def get_sample_transport_data():
    """
    Generate sample transport tracking data with required
    latitude and longitude columns
    
    # Function creates subject samples
    # Method generates predicate data
    # Operation produces object coordinates
    
    Returns:
        DataFrame with transport tracking data including lat/lon coordinates
    """
    # Generate sample data with lat/lon
    data = pd.DataFrame({
        'latitude': np.array([
            40.7128, 34.0522, 41.8781, 29.7604, 37.7749, 
            51.5074, 48.8566, 35.6762, 55.7558, 52.5200
        ]),
        'longitude': np.array([
            -74.0060, -118.2437, -87.6298, -95.3698, -122.4194,
            -0.1278, 2.3522, 139.6503, 37.6176, 13.4050
        ]),
        'vehicle_id': [
            'TRK-001', 'TRK-002', 'TRK-003', 'TRK-004', 'TRK-005',
            'VAN-001', 'VAN-002', 'VAN-003', 'SUV-001', 'SUV-002'
        ],
        'status': [
            'En Route', 'Loading', 'Stopped', 'En Route', 'Unloading',
            'Maintenance', 'En Route', 'Loading', 'Stopped', 'En Route'
        ],
        'cargo_type': [
            'Commercial', 'Perishable', 'Industrial', 'Retail', 'Hazardous',
            'Medical', 'Commercial', 'Retail', 'Special', 'Industrial'
        ]
    })
    
    return data

# Function renders subject visualization
# Method displays predicate map
# Operation presents object transports
def render_transport_tracking(data=None):
    """
    Render the transport tracking visualization
    
    # Function renders subject visualization
    # Method displays predicate map
    # Operation presents object transports
    
    Args:
        data: Optional DataFrame with transport tracking data.
              If None, sample data will be used.
    """
    st.markdown("### Transport Tracking")
    
    # Use provided data or generate sample data
    if data is None or data.empty:
        data = get_sample_transport_data()
    
    # Verify the data has required columns
    required_cols = ['latitude', 'longitude']
    if not all(col in data.columns for col in required_cols):
        st.error(f"Required columns (latitude, longitude) must be included for geospatial visualization.")
        # Replace with sample data if latitude/longitude are missing
        data = get_sample_transport_data()
    
    # Create map
    tile, attr = get_tile_with_attribution("CartoDB positron")
    
    # Calculate map center based on data or use default
    if not data.empty:
        center_lat = data['latitude'].mean()
        center_lon = data['longitude'].mean()
        m = folium.Map(location=[center_lat, center_lon], zoom_start=2, tiles=tile, attr=attr)
        
        # Add transport points
        for _, row in data.iterrows():
            # Determine icon and color based on status
            if row.get('status') == 'En Route':
                icon = 'truck'
                color = 'green'
            elif row.get('status') == 'Stopped':
                icon = 'truck'
                color = 'red'
            elif row.get('status') == 'Loading':
                icon = 'exchange'
                color = 'blue'
            elif row.get('status') == 'Unloading':
                icon = 'exchange'
                color = 'orange'
            else:
                icon = 'truck'
                color = 'gray'
                
            popup_content = f"""
                <b>{row.get('vehicle_id', 'Vehicle')}</b><br>
                Status: {row.get('status', 'Unknown')}<br>
                Cargo: {row.get('cargo_type', 'Unknown')}<br>
                Coordinates: {row['latitude']:.4f}, {row['longitude']:.4f}
            """
            folium.Marker(
                location=[row['latitude'], row['longitude']],
                icon=folium.Icon(icon=icon, color=color, prefix='fa'),
                popup=folium.Popup(popup_content, max_width=250)
            ).add_to(m)
    else:
        # Fallback to default view if no data
        m = folium.Map(location=[0, 0], zoom_start=2, tiles=tile, attr=attr)
        
    # Display the map
    st_folium(m, width=1400, height=800)