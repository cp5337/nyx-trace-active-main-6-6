"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-MAPBUILDER-INFRASTRUCTURE-0001      │
// │ 📁 domain       : Visualization, Geospatial, Intelligence   │
// │ 🧠 description  : Infrastructure targeting map builder      │
// │                  for intel analysis and targeting           │
// │ 🕸️ hash_type    : UUID → CUID-linked module                 │
// │ 🔄 parent_node  : NODE_VISUALIZATION                       │
// │ 🧩 dependencies : streamlit, folium, pandas                 │
// │ 🔧 tool_usage   : Visualization, Analysis                  │
// │ 📡 input_type   : Geospatial data, coordinates              │
// │ 🧪 test_status  : stable                                   │
// │ 🧠 cognitive_fn : pattern detection, infrastructure analysis │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

Infrastructure Targeting Map Builder
-----------------------------------
This module provides specialized visualization capabilities for
infrastructure targeting, facility analysis, and critical asset mapping.
"""

import streamlit as st
import folium
import pandas as pd
import numpy as np
from streamlit_folium import st_folium
from visualizers.tile_utils import get_tile_with_attribution

# Function creates subject samples
# Method generates predicate data
# Operation produces object coordinates
def get_sample_infrastructure_data():
    """
    Generate sample infrastructure targeting data with the required
    latitude and longitude columns
    
    # Function creates subject samples
    # Method generates predicate data
    # Operation produces object coordinates
    
    Returns:
        DataFrame with infrastructure data including lat/lon coordinates
    """
    # Generate sample data with lat/lon
    data = pd.DataFrame({
        'latitude': np.array([
            38.8977, 40.7128, 34.0522, 41.8781, 39.9526, 
            48.8566, 52.5200, 35.6762, 37.7749, 29.7604
        ]),
        'longitude': np.array([
            -77.0365, -74.0060, -118.2437, -87.6298, -75.1652,
            2.3522, 13.4050, 139.6503, -122.4194, -95.3698
        ]),
        'facility_name': [
            'Government Center Alpha', 'Financial Hub', 'West Coast Command', 
            'Central Operations', 'East Regional Facility',
            'European Gateway', 'Continental HQ', 'Pacific Hub',
            'Tech Nexus', 'Southern Operations'
        ],
        'facility_type': [
            'Government', 'Financial', 'Military', 'Industrial', 'Government',
            'Diplomatic', 'Administrative', 'Technological', 'Communications', 'Energy'
        ],
        'criticality': [
            'High', 'Critical', 'High', 'Medium', 'High',
            'Medium', 'High', 'Critical', 'Critical', 'High'
        ],
        'security_level': [
            'Level 4', 'Level 5', 'Level 4', 'Level 3', 'Level 4',
            'Level 3', 'Level 4', 'Level 5', 'Level 5', 'Level 4'
        ]
    })
    
    return data

# Function renders subject visualization
# Method displays predicate map
# Operation presents object infrastructure
def render_infrastructure_targets(data=None):
    """
    Render the infrastructure targeting visualization
    
    # Function renders subject visualization
    # Method displays predicate map
    # Operation presents object infrastructure
    
    Args:
        data: Optional DataFrame with infrastructure data.
              If None, sample data will be used.
    """
    st.markdown("### Infrastructure Targeting")
    
    # Use provided data or generate sample data
    if data is None or data.empty:
        data = get_sample_infrastructure_data()
    
    # Verify the data has required columns
    required_cols = ['latitude', 'longitude']
    if not all(col in data.columns for col in required_cols):
        st.error(f"Required columns (latitude, longitude) must be included for geospatial visualization.")
        # Replace with sample data if latitude/longitude are missing
        data = get_sample_infrastructure_data()
    
    # Create map - Use CartoDB.DarkMatter as fallback for Stamen Toner
    try:
        tile, attr = get_tile_with_attribution("CartoDB.DarkMatter")
    except:
        # Fallback to a known working tile
        tile = "CartoDB dark_matter"
        attr = 'CartoDB'
    
    # Calculate map center based on data or use default
    if not data.empty:
        center_lat = data['latitude'].mean()
        center_lon = data['longitude'].mean()
        m = folium.Map(location=[center_lat, center_lon], zoom_start=2, tiles=tile, attr=attr)
        
        # Add infrastructure points
        for _, row in data.iterrows():
            # Determine icon and color based on criticality
            if row.get('criticality') == 'Critical':
                color = 'red'
                radius = 8
            elif row.get('criticality') == 'High':
                color = 'orange'
                radius = 6
            else:
                color = 'blue'
                radius = 5
                
            popup_content = f"""
                <b>{row.get('facility_name', 'Facility')}</b><br>
                Type: {row.get('facility_type', 'Unknown')}<br>
                Criticality: {row.get('criticality', 'Unknown')}<br>
                Security: {row.get('security_level', 'Unknown')}<br>
                Coordinates: {row['latitude']:.4f}, {row['longitude']:.4f}
            """
            folium.CircleMarker(
                location=[row['latitude'], row['longitude']],
                radius=radius,
                color=color,
                fill=True,
                fill_opacity=0.7,
                popup=folium.Popup(popup_content, max_width=250)
            ).add_to(m)
    else:
        # Fallback to default view if no data
        m = folium.Map(location=[0, 0], zoom_start=2, tiles=tile, attr=attr)
        
    # Display the map
    st_folium(m, width=1400, height=800)