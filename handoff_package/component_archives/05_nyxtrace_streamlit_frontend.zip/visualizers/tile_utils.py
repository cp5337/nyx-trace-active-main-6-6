def get_tile_with_attribution(tile_name):
    tile_attr = {
        "OpenStreetMap": "© OpenStreetMap contributors",
        "CartoDB positron": "© CartoDB, © OpenStreetMap contributors",
        "Stamen Terrain": "Map tiles by Stamen Design, CC BY 3.0 — Map data © OpenStreetMap contributors",
        "Stamen Toner": "Map tiles by Stamen Design, CC BY 3.0 — Map data © OpenStreetMap contributors",
    }
    return tile_name, tile_attr.get(tile_name, "© Map contributors")