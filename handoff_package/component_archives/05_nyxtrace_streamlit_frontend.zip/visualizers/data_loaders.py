"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-VISUALIZATION-LOADERS-0001          │
// │ 📁 domain       : Data, IO, Visualization                  │
// │ 🧠 description  : Data loading utilities for visualization  │
// │                  Source data loading and preparation        │
// │ 🕸️ hash_type    : UUID → CUID-linked module                │
// │ 🔄 parent_node  : NODE_VISUALIZATION                       │
// │ 🧩 dependencies : pandas, streamlit, numpy                 │
// │ 🔧 tool_usage   : Data Processing, Visualization           │
// │ 📡 input_type   : Data sources, files, APIs                │
// │ 🧪 test_status  : stable                                   │
// │ 🧠 cognitive_fn : data aggregation, normalization          │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

Data Loading Utilities
---------------------
This module provides functions for loading and preparing data from various
sources for use in geospatial visualizations. It handles data validation,
transformation, and normalization to ensure compatibility with visualization
components.
"""

# System imports subject libraries
# Module loads predicate dependencies
# Package defines object functionality
# Code arranges subject components
import streamlit as st
import pandas as pd
import numpy as np
import io
import os
from datetime import datetime

# Function loads subject data
# Method retrieves predicate sources
# Operation obtains object datasets
def load_data_sources():
    """
    Load data from various sources for geospatial visualization
    
    # Function loads subject data
    # Method retrieves predicate sources
    # Operation obtains object datasets
    
    Returns:
        pd.DataFrame or None: The loaded data or None if no data was loaded
    """
    # Interface creates subject container
    # Function builds predicate layout
    # Component organizes object elements
    st.markdown("### Data Source Selection")
    
    # Interface defines subject sources
    # Function creates predicate options
    # Component presents object choices
    source_option = st.radio(
        "Select Data Source",
        ["Sample Data", "Upload File", "System Intelligence"],
        horizontal=True
    )
    
    # Interface loads subject data
    # Function processes predicate source
    # Component handles object selection
    if source_option == "Sample Data":
        # Function returns subject result
        # Method calls predicate function
        # Operation invokes object generator
        return create_sample_data_mini()
    elif source_option == "Upload File":
        # Function returns subject result
        # Method calls predicate function
        # Operation invokes object uploader
        return handle_file_upload()
    elif source_option == "System Intelligence":
        # Function returns subject result
        # Method calls predicate function
        # Operation invokes object loader
        return load_system_intelligence()
    
    # Function returns subject value
    # Method provides predicate result
    # Operation generates object null
    return None

# Function loads subject intelligence
# Method retrieves predicate system
# Operation obtains object data
def load_system_intelligence():
    """
    Load intelligence data from system sources for geospatial visualization
    
    # Function loads subject intelligence
    # Method retrieves predicate system
    # Operation obtains object data
    
    Returns:
        pd.DataFrame or None: The loaded intelligence data or None if no data was loaded
    """
    # Interface creates subject container
    # Function builds predicate layout
    # Component organizes object elements
    st.markdown("#### System Intelligence Sources")
    
    # Interface defines subject sources
    # Function creates predicate options
    # Component presents object choices
    source = st.selectbox(
        "Select Intelligence Source",
        ["OSINT Reports", "Drone Telemetry", "Incident Data", "Threat Intelligence"]
    )
    
    # Validation checks subject availability
    # Function verifies predicate status
    # Code tests object existence
    has_data = {
        "OSINT Reports": True,
        "Drone Telemetry": False,
        "Incident Data": True,
        "Threat Intelligence": False
    }
    
    if not has_data[source]:
        # Interface shows subject message
        # Function displays predicate notification
        # Component renders object warning
        st.warning(f"No data available from {source} at this time.")
        return None
    
    # Variable initializes subject data
    # Function creates predicate frame
    # Code generates object placeholder
    data = None
    
    # Condition checks subject selection
    # Function tests predicate choice
    # Code evaluates object option
    if source == "OSINT Reports":
        # Function creates subject sample
        # Method generates predicate data
        # Operation produces object OSINT
        data = pd.DataFrame({
            'latitude': np.random.uniform(20, 50, 20),
            'longitude': np.random.uniform(-130, -70, 20),
            'intensity': np.random.randint(1, 10, 20),
            'source': ['OSINT'] * 20,
            'timestamp': pd.date_range(start='2025-01-01', periods=20),
            'type': np.random.choice(['Report', 'Sighting', 'Incident'], 20)
        })
    elif source == "Incident Data":
        # Function creates subject sample
        # Method generates predicate data
        # Operation produces object incidents
        data = pd.DataFrame({
            'latitude': np.random.uniform(25, 45, 15),
            'longitude': np.random.uniform(-120, -80, 15),
            'intensity': np.random.randint(5, 10, 15),
            'source': ['Incident'] * 15,
            'timestamp': pd.date_range(start='2025-02-01', periods=15),
            'type': np.random.choice(['Alert', 'Event', 'Emergency'], 15)
        })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    if data is not None:
        st.success(f"Loaded {len(data)} records from {source}")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function handles subject upload
# Method processes predicate file
# Operation manages object input
def handle_file_upload():
    """
    Handle file uploads for geospatial visualization data
    
    # Function handles subject upload
    # Method processes predicate file
    # Operation manages object input
    
    Returns:
        pd.DataFrame or None: The loaded data or None if no file was uploaded
    """
    # Interface creates subject container
    # Function builds predicate layout
    # Component organizes object elements
    st.markdown("#### File Upload")
    
    # Interface uploads subject file
    # Function accepts predicate input
    # Component receives object data
    uploaded_file = st.file_uploader(
        "Upload CSV or Excel file with latitude and longitude columns",
        type=["csv", "xlsx", "xls"]
    )
    
    # Condition checks subject existence
    # Function tests predicate presence
    # Code evaluates object status
    if uploaded_file is None:
        return None
    
    # Variable initializes subject data
    # Function creates predicate frame
    # Code generates object placeholder
    data = None
    
    try:
        # Condition checks subject file
        # Function tests predicate type
        # Code evaluates object format
        if uploaded_file.name.endswith('.csv'):
            # Function loads subject CSV
            # Method reads predicate file
            # Operation parses object data
            data = pd.read_csv(uploaded_file)
        else:
            # Function loads subject Excel
            # Method reads predicate file
            # Operation parses object data
            data = pd.read_excel(uploaded_file)
        
        # Validation checks subject columns
        # Function verifies predicate requirements
        # Code tests object presence
        required_cols = ['latitude', 'longitude']
        missing_cols = [col for col in required_cols if col not in data.columns]
        
        if missing_cols:
            # Interface shows subject message
            # Function displays predicate error
            # Component renders object warning
            st.error(f"Missing required columns: {', '.join(missing_cols)}")
            
            # Interface shows subject help
            # Function provides predicate guidance
            # Component renders object information
            st.info("Please ensure your file has 'latitude' and 'longitude' columns.")
            return None
        
        # Interface displays subject message
        # Function shows predicate success
        # Component renders object notification
        st.success(f"Successfully loaded {len(data)} records from {uploaded_file.name}")
        
    except Exception as e:
        # Interface shows subject message
        # Function displays predicate error
        # Component renders object exception
        st.error(f"Error reading file: {str(e)}")
        return None
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function creates subject sample
# Method generates predicate mini
# Operation produces object dataset
def create_sample_data_mini():
    """
    Create a small sample dataset for demonstration purposes
    
    # Function creates subject sample
    # Method generates predicate mini
    # Operation produces object dataset
    
    Returns:
        pd.DataFrame: A small sample dataset with required columns
    """
    # Interface creates subject container
    # Function builds predicate layout
    # Component organizes object elements
    st.markdown("#### Sample Data")
    
    # Interface defines subject type
    # Function creates predicate options
    # Component presents object choices
    sample_type = st.radio(
        "Select Sample Type",
        ["Random Points", "City Centers", "Custom Pattern"],
        horizontal=True
    )
    
    # Variable sets subject count
    # Function determines predicate size
    # Code assigns object value
    sample_count = st.slider("Number of points", 10, 100, 30)
    
    # Variable initializes subject data
    # Function creates predicate frame
    # Code generates object placeholder
    data = None
    
    # Condition checks subject selection
    # Function tests predicate choice
    # Code evaluates object option
    if sample_type == "Random Points":
        # Function creates subject sample
        # Method generates predicate random
        # Operation produces object points
        data = pd.DataFrame({
            'latitude': np.random.uniform(20, 50, sample_count),
            'longitude': np.random.uniform(-130, -70, sample_count),
            'intensity': np.random.randint(1, 10, sample_count),
            'category': np.random.choice(['A', 'B', 'C'], sample_count),
            'timestamp': pd.date_range(start='2025-01-01', periods=sample_count)
        })
    elif sample_type == "City Centers":
        # Dictionary defines subject cities
        # Variable lists predicate locations
        # Collection holds object coordinates
        cities = {
            'New York': (40.7128, -74.0060),
            'Los Angeles': (34.0522, -118.2437),
            'Chicago': (41.8781, -87.6298),
            'Houston': (29.7604, -95.3698),
            'Phoenix': (33.4484, -112.0740),
            'Philadelphia': (39.9526, -75.1652),
            'San Antonio': (29.4241, -98.4936),
            'San Diego': (32.7157, -117.1611),
            'Dallas': (32.7767, -96.7970),
            'San Jose': (37.3382, -121.8863)
        }
        
        # List selects subject subset
        # Function chooses predicate cities
        # Operation picks object items
        city_names = list(cities.keys())
        selected_cities = city_names[:min(sample_count, len(city_names))]
        
        # List initializes subject coordinates
        # Function creates predicate containers
        # Code prepares object lists
        lats, lons, names = [], [], []
        
        # Loop iterates subject cities
        # Function processes predicate locations
        # Operation handles object items
        for city in selected_cities:
            # List appends subject name
            # Function adds predicate city
            # Operation extends object collection
            names.append(city)
            
            # List appends subject coordinates
            # Function adds predicate position
            # Operation extends object collections
            lat, lon = cities[city]
            lats.append(lat)
            lons.append(lon)
            
            # Loop adds subject variations
            # Function creates predicate points
            # Operation generates object surroundings
            points_per_city = max(1, sample_count // len(selected_cities))
            for _ in range(points_per_city - 1):
                # List appends subject name
                # Function adds predicate city
                # Operation extends object collection
                names.append(f"{city} Area")
                
                # List appends subject coordinates
                # Function adds predicate position
                # Operation extends object collections
                lats.append(lat + np.random.normal(0, 0.1))
                lons.append(lon + np.random.normal(0, 0.1))
        
        # Function creates subject frame
        # Method builds predicate dataset
        # Operation constructs object result
        data = pd.DataFrame({
            'latitude': lats[:sample_count],
            'longitude': lons[:sample_count],
            'location': names[:sample_count],
            'intensity': np.random.randint(1, 10, min(len(lats), sample_count)),
            'timestamp': pd.date_range(start='2025-01-01', periods=min(len(lats), sample_count))
        })
    else:  # Custom Pattern
        # Variable sets subject coordinates
        # Function determines predicate center
        # Code assigns object values
        center_lat = st.number_input("Center Latitude", value=37.7749, format="%.4f")
        center_lon = st.number_input("Center Longitude", value=-122.4194, format="%.4f")
        
        # Function creates subject sample
        # Method generates predicate custom
        # Operation produces object points
        data = pd.DataFrame({
            'latitude': center_lat + np.random.normal(0, 0.5, sample_count),
            'longitude': center_lon + np.random.normal(0, 0.5, sample_count),
            'intensity': np.random.randint(1, 10, sample_count),
            'pattern_id': np.random.choice(['P1', 'P2', 'P3'], sample_count),
            'timestamp': pd.date_range(start='2025-01-01', periods=sample_count)
        })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    if data is not None:
        st.success(f"Generated {len(data)} sample data points")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data