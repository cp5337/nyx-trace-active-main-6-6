"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-VISUALIZATION-SAMPLES-PATTERN-0001  │
// │ 📁 domain       : Data, Generation, Visualization          │
// │ 🧠 description  : Pattern-based sample data generators      │
// │                  Structured pattern generation             │
// │ 🕸️ hash_type    : UUID → CUID-linked module                │
// │ 🔄 parent_node  : NODE_VISUALIZATION                       │
// │ 🧩 dependencies : pandas, streamlit, numpy                 │
// │ 🔧 tool_usage   : Data Generation, Visualization           │
// │ 📡 input_type   : Parameters, settings                     │
// │ 🧪 test_status  : stable                                   │
// │ 🧠 cognitive_fn : pattern generation, structure creation   │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

Pattern-based Sample Data Generators
----------------------------------
This module provides functions for generating structured sample data patterns
for geospatial visualizations including linear, grid, and radial patterns.
"""

# System imports subject libraries
# Module loads predicate dependencies
# Package defines object functionality
# Code arranges subject components
import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import math

# Function creates subject dataset
# Method generates predicate linear
# Operation produces object pattern
def create_linear_pattern(sample_count, min_intensity, max_intensity):
    """
    Create a sample dataset with points following linear paths
    
    # Function creates subject dataset
    # Method generates predicate linear
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A dataset with points following linear paths
    """
    # Variable sets subject lines
    # Function determines predicate count
    # Code assigns object value
    num_lines = min(3, max(1, sample_count // 20))
    
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons, intensities, categories, line_ids = [], [], [], [], []
    
    # Loop iterates subject lines
    # Function processes predicate paths
    # Operation handles object routes
    for i in range(num_lines):
        # Variable sets subject endpoints
        # Function determines predicate coordinates
        # Code assigns object positions
        start_lat = np.random.uniform(30, 45)
        start_lon = np.random.uniform(-120, -75)
        end_lat = start_lat + np.random.uniform(-5, 5)
        end_lon = start_lon + np.random.uniform(-10, 10)
        
        # Variable sets subject count
        # Function determines predicate size
        # Code assigns object value
        line_size = max(5, sample_count // num_lines)
        
        # Variable sets subject category
        # Function selects predicate label
        # Code chooses object option
        line_id = f"Line-{chr(65+i)}"  # Line-A, Line-B, etc.
        
        # Loop creates subject points
        # Function generates predicate path
        # Operation produces object members
        for j in range(line_size):
            # Variable calculates subject position
            # Function computes predicate fraction
            # Code determines object location
            t = j / (line_size - 1) if line_size > 1 else 0
            
            # List appends subject coordinates
            # Function adds predicate position
            # Operation extends object collections
            # Line interpolation with slight randomness
            lats.append(start_lat + t * (end_lat - start_lat) + np.random.normal(0, 0.1))
            lons.append(start_lon + t * (end_lon - start_lon) + np.random.normal(0, 0.1))
            
            # List appends subject properties
            # Function adds predicate attributes
            # Operation extends object collections
            intensities.append(np.random.randint(min_intensity, max_intensity + 1))
            categories.append(f"Segment-{j//5 + 1}")
            line_ids.append(line_id)
    
    # Function limits subject size
    # Method restricts predicate count
    # Operation trims object excess
    sample_count = min(sample_count, len(lats))
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats[:sample_count],
        'longitude': lons[:sample_count],
        'intensity': intensities[:sample_count],
        'timestamp': pd.date_range(start='2025-01-01', periods=sample_count),
        'category': categories[:sample_count],
        'line_id': line_ids[:sample_count]
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {sample_count} data points along {num_lines} linear paths")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function creates subject dataset
# Method generates predicate grid
# Operation produces object pattern
def create_grid_pattern(sample_count, min_intensity, max_intensity):
    """
    Create a sample dataset with points arranged in a grid pattern
    
    # Function creates subject dataset
    # Method generates predicate grid
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A dataset with points arranged in a grid pattern
    """
    # Variable calculates subject dimensions
    # Function determines predicate grid
    # Code computes object size
    grid_size = int(np.sqrt(sample_count))
    
    # Variable sets subject center
    # Function determines predicate location
    # Code assigns object coordinates
    center_lat = np.random.uniform(35, 42)
    center_lon = np.random.uniform(-100, -80)
    
    # Variable sets subject span
    # Function determines predicate coverage
    # Code assigns object range
    span = max(1, min(5, grid_size / 2))
    
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons, intensities, grid_rows, grid_cols = [], [], [], [], []
    
    # Loop creates subject grid
    # Function generates predicate rows
    # Operation produces object structure
    for i in range(grid_size):
        # Loop creates subject columns
        # Function generates predicate positions
        # Operation produces object grid
        for j in range(grid_size):
            # List appends subject coordinates
            # Function adds predicate position
            # Operation extends object collections
            lat = center_lat + (i - grid_size/2) * span/grid_size + np.random.normal(0, 0.02)
            lon = center_lon + (j - grid_size/2) * span/grid_size + np.random.normal(0, 0.02)
            lats.append(lat)
            lons.append(lon)
            
            # List appends subject properties
            # Function adds predicate attributes
            # Operation extends object collections
            intensities.append(np.random.randint(min_intensity, max_intensity + 1))
            grid_rows.append(i)
            grid_cols.append(j)
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats[:sample_count],
        'longitude': lons[:sample_count],
        'intensity': intensities[:sample_count],
        'timestamp': pd.date_range(start='2025-01-01', periods=min(len(lats), sample_count)),
        'grid_row': grid_rows[:sample_count],
        'grid_col': grid_cols[:sample_count],
        'grid_id': [f"Cell-{r}-{c}" for r, c in zip(grid_rows, grid_cols)][:sample_count]
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {len(data)} data points in a {grid_size}x{grid_size} grid")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function creates subject dataset
# Method generates predicate radial
# Operation produces object pattern
def create_radial_pattern(sample_count, min_intensity, max_intensity):
    """
    Create a sample dataset with points arranged in a radial pattern
    
    # Function creates subject dataset
    # Method generates predicate radial
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A dataset with points arranged in a radial pattern
    """
    # Variable sets subject center
    # Function determines predicate location
    # Code assigns object coordinates
    center_lat = np.random.uniform(35, 42)
    center_lon = np.random.uniform(-100, -80)
    
    # Variable sets subject rings
    # Function determines predicate count
    # Code assigns object value
    num_rings = min(5, max(2, sample_count // 10))
    
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons, intensities, ring_ids, angles = [], [], [], [], []
    
    # Loop iterates subject rings
    # Function processes predicate circles
    # Operation handles object layers
    for ring in range(num_rings):
        # Variable sets subject radius
        # Function determines predicate distance
        # Code assigns object value
        radius = (ring + 1) * 0.2  # Increasing radius for each ring
        
        # Variable sets subject points
        # Function determines predicate count
        # Code assigns object value
        points_in_ring = max(4, sample_count // num_rings)
        
        # Loop creates subject points
        # Function generates predicate ring
        # Operation produces object members
        for i in range(points_in_ring):
            # Variable calculates subject angle
            # Function computes predicate position
            # Code determines object location
            angle_deg = (i / points_in_ring) * 360
            angle_rad = math.radians(angle_deg)
            
            # List appends subject coordinates
            # Function adds predicate position
            # Operation extends object collections
            lat = center_lat + radius * math.sin(angle_rad) + np.random.normal(0, 0.02)
            lon = center_lon + radius * math.cos(angle_rad) + np.random.normal(0, 0.02)
            lats.append(lat)
            lons.append(lon)
            
            # List appends subject properties
            # Function adds predicate attributes
            # Operation extends object collections
            intensities.append(max_intensity - ring + np.random.randint(-1, 2))  # Higher intensity in center
            ring_ids.append(f"Ring-{ring+1}")
            angles.append(angle_deg)
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats[:sample_count],
        'longitude': lons[:sample_count],
        'intensity': intensities[:sample_count],
        'timestamp': pd.date_range(start='2025-01-01', periods=min(len(lats), sample_count)),
        'ring_id': ring_ids[:sample_count],
        'angle': angles[:sample_count]
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {len(data)} data points in {num_rings} concentric rings")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data