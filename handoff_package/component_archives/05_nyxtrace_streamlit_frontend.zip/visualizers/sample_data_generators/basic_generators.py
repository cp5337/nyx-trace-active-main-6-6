"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-VISUALIZATION-SAMPLES-BASIC-0001    │
// │ 📁 domain       : Data, Generation, Visualization          │
// │ 🧠 description  : Basic sample data generators              │
// │                  Simple pattern generation                 │
// │ 🕸️ hash_type    : UUID → CUID-linked module                │
// │ 🔄 parent_node  : NODE_VISUALIZATION                       │
// │ 🧩 dependencies : pandas, streamlit, numpy                 │
// │ 🔧 tool_usage   : Data Generation, Visualization           │
// │ 📡 input_type   : Parameters, settings                     │
// │ 🧪 test_status  : stable                                   │
// │ 🧠 cognitive_fn : pattern generation, randomization        │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

Basic Sample Data Generators
--------------------------
This module provides functions for generating basic sample data patterns
for geospatial visualizations including random distributions and clusters.
"""

# System imports subject libraries
# Module loads predicate dependencies
# Package defines object functionality
# Code arranges subject components
import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import math

# Function creates subject dataset
# Method generates predicate random
# Operation produces object pattern
def create_random_distribution(sample_count, min_intensity, max_intensity):
    """
    Create a randomly distributed sample dataset
    
    # Function creates subject dataset
    # Method generates predicate random
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A randomly distributed dataset
    """
    # Function generates subject data
    # Method creates predicate frame
    # Operation builds object dataset
    data = pd.DataFrame({
        'latitude': np.random.uniform(25, 49, sample_count),
        'longitude': np.random.uniform(-125, -66, sample_count),
        'intensity': np.random.randint(min_intensity, max_intensity + 1, sample_count),
        'timestamp': pd.date_range(start='2025-01-01', periods=sample_count),
        'category': np.random.choice(['Alpha', 'Beta', 'Gamma', 'Delta'], sample_count),
        'value': np.random.normal(100, 25, sample_count).round(2)
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {sample_count} random data points")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function creates subject dataset
# Method generates predicate cluster
# Operation produces object pattern
def create_cluster_pattern(sample_count, min_intensity, max_intensity):
    """
    Create a clustered sample dataset with multiple focal points
    
    # Function creates subject dataset
    # Method generates predicate cluster
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A clustered dataset with multiple focal points
    """
    # Variable sets subject clusters
    # Function determines predicate count
    # Code assigns object value
    num_clusters = min(5, max(2, sample_count // 20))
    
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons, intensities, categories, values = [], [], [], [], []
    
    # Variable sets subject categories
    # Function defines predicate options
    # Code specifies object choices
    category_options = ['Hotspot', 'Alert', 'Warning', 'Notice', 'Information']
    
    # Loop iterates subject clusters
    # Function processes predicate groups
    # Operation handles object centers
    for i in range(num_clusters):
        # Variable sets subject center
        # Function determines predicate location
        # Code assigns object coordinates
        center_lat = np.random.uniform(30, 45)
        center_lon = np.random.uniform(-120, -75)
        
        # Variable sets subject count
        # Function determines predicate size
        # Code assigns object value
        cluster_size = max(5, sample_count // num_clusters)
        
        # Variable sets subject category
        # Function selects predicate label
        # Code chooses object option
        category = category_options[i % len(category_options)]
        
        # Loop creates subject points
        # Function generates predicate cluster
        # Operation produces object members
        for _ in range(cluster_size):
            # List appends subject coordinates
            # Function adds predicate position
            # Operation extends object collections
            lats.append(center_lat + np.random.normal(0, 0.5))
            lons.append(center_lon + np.random.normal(0, 0.5))
            
            # List appends subject properties
            # Function adds predicate attributes
            # Operation extends object collections
            intensities.append(np.random.randint(min_intensity, max_intensity + 1))
            categories.append(category)
            values.append(np.random.normal(100, 25).round(2))
    
    # Function limits subject size
    # Method restricts predicate count
    # Operation trims object excess
    sample_count = min(sample_count, len(lats))
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats[:sample_count],
        'longitude': lons[:sample_count],
        'intensity': intensities[:sample_count],
        'timestamp': pd.date_range(start='2025-01-01', periods=sample_count),
        'category': categories[:sample_count],
        'value': values[:sample_count]
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {sample_count} data points in {num_clusters} clusters")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function creates subject dataset
# Method generates predicate custom
# Operation produces object pattern
def create_custom_distribution(sample_count, min_intensity, max_intensity):
    """
    Create a sample dataset with a user-customizable distribution
    
    # Function creates subject dataset
    # Method generates predicate custom
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A dataset with a custom distribution
    """
    # Interface creates subject container
    # Function builds predicate layout
    # Component organizes object elements
    st.markdown("#### Custom Distribution Settings")
    
    # Interface creates subject columns
    # Function divides predicate space
    # Component organizes object regions
    col1, col2 = st.columns(2)
    
    # Variable sets subject center
    # Function determines predicate location
    # Code assigns object coordinates
    with col1:
        center_lat = st.number_input("Center Latitude", value=39.5, format="%.4f")
        spread_lat = st.number_input("Latitude Spread", value=5.0, min_value=0.1, format="%.2f")
    
    with col2:
        center_lon = st.number_input("Center Longitude", value=-98.35, format="%.4f")
        spread_lon = st.number_input("Longitude Spread", value=10.0, min_value=0.1, format="%.2f")
    
    # Variable sets subject distribution
    # Function determines predicate pattern
    # Code assigns object type
    distribution = st.selectbox(
        "Distribution Type",
        ["Normal", "Uniform", "Bimodal", "Triangular"]
    )
    
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons, intensities, categories = [], [], [], []
    
    # Function generates subject coordinates
    # Method creates predicate positions
    # Operation produces object locations
    if distribution == "Normal":
        lats = np.random.normal(center_lat, spread_lat/5, sample_count)
        lons = np.random.normal(center_lon, spread_lon/5, sample_count)
    elif distribution == "Uniform":
        lats = np.random.uniform(center_lat - spread_lat, center_lat + spread_lat, sample_count)
        lons = np.random.uniform(center_lon - spread_lon, center_lon + spread_lon, sample_count)
    elif distribution == "Bimodal":
        # Create bimodal distribution with two centers
        half = sample_count // 2
        lats = np.concatenate([
            np.random.normal(center_lat - spread_lat/2, spread_lat/10, half),
            np.random.normal(center_lat + spread_lat/2, spread_lat/10, sample_count - half)
        ])
        lons = np.concatenate([
            np.random.normal(center_lon - spread_lon/2, spread_lon/10, half),
            np.random.normal(center_lon + spread_lon/2, spread_lon/10, sample_count - half)
        ])
    elif distribution == "Triangular":
        lats = np.random.triangular(
            center_lat - spread_lat, center_lat, center_lat + spread_lat, sample_count
        )
        lons = np.random.triangular(
            center_lon - spread_lon, center_lon, center_lon + spread_lon, sample_count
        )
    
    # Function generates subject attributes
    # Method creates predicate properties
    # Operation produces object values
    intensities = np.random.randint(min_intensity, max_intensity + 1, sample_count)
    
    # Variable sets subject categories
    # Function determines predicate labels
    # Code assigns object values
    categories = np.random.choice(['Region A', 'Region B', 'Region C', 'Region D'], sample_count)
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats,
        'longitude': lons,
        'intensity': intensities,
        'timestamp': pd.date_range(start='2025-01-01', periods=sample_count),
        'category': categories,
        'distribution': [distribution] * sample_count
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {sample_count} data points with {distribution} distribution")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function generates subject sample
# Method creates predicate custom
# Operation produces object dataset
def generate_custom_sample(num_points, center_lat, center_lon, radius=1.0):
    """
    Generate a custom sample dataset with the specified parameters
    
    # Function generates subject sample
    # Method creates predicate custom
    # Operation produces object dataset
    
    Args:
        num_points: Number of data points to generate
        center_lat: Center latitude for the distribution
        center_lon: Center longitude for the distribution
        radius: Radius of distribution around the center
        
    Returns:
        pd.DataFrame: A custom sample dataset
    """
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons = [], []
    
    # Loop creates subject points
    # Function generates predicate positions
    # Operation produces object coordinates
    for _ in range(num_points):
        # Variable calculates subject angle
        # Function computes predicate direction
        # Code determines object orientation
        angle = np.random.uniform(0, 2 * np.pi)
        
        # Variable calculates subject distance
        # Function computes predicate offset
        # Code determines object displacement
        distance = np.random.uniform(0, radius)
        
        # List appends subject coordinates
        # Function adds predicate position
        # Operation extends object collections
        lats.append(center_lat + distance * np.sin(angle))
        lons.append(center_lon + distance * np.cos(angle))
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats,
        'longitude': lons,
        'intensity': np.random.randint(1, 10, num_points),
        'timestamp': pd.date_range(start='2025-01-01', periods=num_points),
        'category': np.random.choice(['A', 'B', 'C'], num_points)
    })
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data