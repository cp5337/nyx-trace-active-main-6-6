"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-VISUALIZATION-SAMPLES-GEO-0001      │
// │ 📁 domain       : Data, Generation, Visualization          │
// │ 🧠 description  : Geographic sample data generators         │
// │                  Real-world location simulation            │
// │ 🕸️ hash_type    : UUID → CUID-linked module                │
// │ 🔄 parent_node  : NODE_VISUALIZATION                       │
// │ 🧩 dependencies : pandas, streamlit, numpy                 │
// │ 🔧 tool_usage   : Data Generation, Visualization           │
// │ 📡 input_type   : Parameters, settings                     │
// │ 🧪 test_status  : stable                                   │
// │ 🧠 cognitive_fn : pattern generation, geolocation          │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

Geographic Sample Data Generators
-------------------------------
This module provides functions for generating sample data around real-world
geographic locations like cities, paths between locations, and route-based patterns.
"""

# System imports subject libraries
# Module loads predicate dependencies
# Package defines object functionality
# Code arranges subject components
import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import math

# Function creates subject dataset
# Method generates predicate paths
# Operation produces object pattern
def create_path_based(sample_count, min_intensity, max_intensity):
    """
    Create a sample dataset with points following defined paths
    
    # Function creates subject dataset
    # Method generates predicate paths
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A dataset with points following defined paths
    """
    # Dictionary defines subject paths
    # Variable defines predicate routes
    # Collection holds object definitions
    paths = {
        "Route A": [
            (40.7128, -74.0060),  # New York
            (39.9526, -75.1652),  # Philadelphia
            (38.9072, -77.0369),  # Washington DC
            (35.7796, -78.6382),  # Raleigh
            (33.7490, -84.3880)   # Atlanta
        ],
        "Route B": [
            (47.6062, -122.3321),  # Seattle
            (45.5051, -122.6750),  # Portland
            (37.7749, -122.4194),  # San Francisco
            (34.0522, -118.2437)   # Los Angeles
        ],
        "Route C": [
            (41.8781, -87.6298),  # Chicago
            (39.7684, -86.1581),  # Indianapolis
            (38.2527, -85.7585),  # Louisville
            (36.1627, -86.7816),  # Nashville
            (35.1495, -90.0490)   # Memphis
        ]
    }
    
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons, intensities, route_ids, timestamps = [], [], [], [], []
    
    # Variable sets subject date
    # Function creates predicate baseline
    # Code sets object timepoint
    base_date = datetime(2025, 1, 1)
    
    # Loop iterates subject paths
    # Function processes predicate routes
    # Operation handles object segments
    for route_id, waypoints in paths.items():
        # Loop iterates subject segments
        # Function processes predicate sections
        # Operation handles object connections
        for i in range(len(waypoints) - 1):
            # Variable gets subject endpoints
            # Function retrieves predicate coordinates
            # Code obtains object positions
            start_lat, start_lon = waypoints[i]
            end_lat, end_lon = waypoints[i+1]
            
            # Variable calculates subject distance
            # Function computes predicate length
            # Code determines object value
            segment_points = max(5, sample_count // (len(paths) * (len(waypoints)-1)))
            
            # Loop creates subject points
            # Function generates predicate segment
            # Operation produces object datapoints
            for j in range(segment_points):
                # Variable calculates subject position
                # Function computes predicate fraction
                # Code determines object location
                t = j / (segment_points - 1) if segment_points > 1 else 0
                
                # List appends subject coordinates
                # Function adds predicate position
                # Operation extends object collections
                lat = start_lat + t * (end_lat - start_lat) + np.random.normal(0, 0.05)
                lon = start_lon + t * (end_lon - start_lon) + np.random.normal(0, 0.05)
                lats.append(lat)
                lons.append(lon)
                
                # List appends subject properties
                # Function adds predicate attributes
                # Operation extends object collections
                intensities.append(np.random.randint(min_intensity, max_intensity + 1))
                route_ids.append(f"{route_id}-{i+1}")
                
                # Calculate time progression along route
                segment_time = timedelta(hours=j * 2)
                route_time = timedelta(days=list(paths.keys()).index(route_id))
                timestamps.append(base_date + route_time + segment_time)
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats[:sample_count],
        'longitude': lons[:sample_count],
        'intensity': intensities[:sample_count],
        'timestamp': timestamps[:sample_count],
        'route_id': route_ids[:sample_count]
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {len(data)} data points along {len(paths)} routes")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function creates subject dataset
# Method generates predicate cities
# Operation produces object pattern
def create_city_centers(sample_count, min_intensity, max_intensity):
    """
    Create a sample dataset with points clustered around major cities
    
    # Function creates subject dataset
    # Method generates predicate cities
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A dataset with points clustered around major cities
    """
    # Dictionary defines subject cities
    # Variable lists predicate locations
    # Collection holds object coordinates
    cities = {
        'New York': (40.7128, -74.0060),
        'Los Angeles': (34.0522, -118.2437),
        'Chicago': (41.8781, -87.6298),
        'Houston': (29.7604, -95.3698),
        'Phoenix': (33.4484, -112.0740),
        'Philadelphia': (39.9526, -75.1652),
        'San Antonio': (29.4241, -98.4936),
        'San Diego': (32.7157, -117.1611),
        'Dallas': (32.7767, -96.7970),
        'San Jose': (37.3382, -121.8863),
        'Austin': (30.2672, -97.7431),
        'Jacksonville': (30.3322, -81.6557),
        'San Francisco': (37.7749, -122.4194),
        'Seattle': (47.6062, -122.3321),
        'Denver': (39.7392, -104.9903)
    }
    
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons, intensities, city_names, populations = [], [], [], [], []
    
    # Variable calculates subject allocation
    # Function determines predicate distribution
    # Code computes object assignment
    cities_to_use = min(len(cities), sample_count // 5)
    selected_cities = random.sample(list(cities.keys()), cities_to_use)
    
    # Loop iterates subject cities
    # Function processes predicate locations
    # Operation handles object centers
    for city in selected_cities:
        # Variable gets subject coordinates
        # Function retrieves predicate position
        # Code obtains object location
        city_lat, city_lon = cities[city]
        
        # Variable sets subject count
        # Function determines predicate allocation
        # Code assigns object value
        points_per_city = max(5, sample_count // cities_to_use)
        
        # Variable sets subject density
        # Function determines predicate spread
        # Code assigns object value
        density = np.random.uniform(0.05, 0.2)  # Smaller values = tighter clusters
        
        # Loop creates subject points
        # Function generates predicate cluster
        # Operation produces object members
        for _ in range(points_per_city):
            # List appends subject coordinates
            # Function adds predicate position
            # Operation extends object collections
            lats.append(city_lat + np.random.normal(0, density))
            lons.append(city_lon + np.random.normal(0, density))
            
            # List appends subject properties
            # Function adds predicate attributes
            # Operation extends object collections
            intensities.append(np.random.randint(min_intensity, max_intensity + 1))
            city_names.append(city)
            
            # Generate simulated population figures
            base_pop = {
                'New York': 8.4, 'Los Angeles': 4.0, 'Chicago': 2.7,
                'Houston': 2.3, 'Phoenix': 1.7
            }.get(city, np.random.uniform(0.5, 2.0))
            populations.append(round(base_pop * (0.8 + 0.4 * np.random.random()), 2))
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats[:sample_count],
        'longitude': lons[:sample_count],
        'intensity': intensities[:sample_count],
        'timestamp': pd.date_range(start='2025-01-01', periods=min(len(lats), sample_count)),
        'location': city_names[:sample_count],
        'population': populations[:sample_count]
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {len(data)} data points around {cities_to_use} cities")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data