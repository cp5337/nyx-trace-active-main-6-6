"""
// ┌─────────────────────────────────────────────────────────────┐
// │ █████████████████ CTAS USIM HEADER ███████████████████████ │
// ├─────────────────────────────────────────────────────────────┤
// │ 🔖 hash_id      : USIM-VISUALIZATION-SAMPLES-0001          │
// │ 📁 domain       : Data, Generation, Visualization          │
// │ 🧠 description  : Sample data generators for visualization  │
// │                  Generation of example datasets            │
// │ 🕸️ hash_type    : UUID → CUID-linked module                │
// │ 🔄 parent_node  : NODE_VISUALIZATION                       │
// │ 🧩 dependencies : pandas, streamlit, numpy                 │
// │ 🔧 tool_usage   : Data Generation, Visualization           │
// │ 📡 input_type   : Parameters, settings                     │
// │ 🧪 test_status  : stable                                   │
// │ 🧠 cognitive_fn : pattern generation, randomization        │
// │ ⌛ TTL Policy   : 6.5 Persistent                           │
// └─────────────────────────────────────────────────────────────┘

Sample Data Generators
--------------------
This module provides functions for generating sample data for geospatial
visualizations. It includes various patterns and data distributions to
demonstrate different visualization capabilities.
"""

# System imports subject libraries
# Module loads predicate dependencies
# Package defines object functionality
# Code arranges subject components
import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import math

# Function creates subject sample
# Method generates predicate dataset
# Operation produces object data
def create_sample_data():
    """
    Create a configurable sample dataset for geospatial visualization
    
    # Function creates subject sample
    # Method generates predicate dataset
    # Operation produces object data
    
    Returns:
        pd.DataFrame: A sample dataset with required columns
    """
    # Interface creates subject container
    # Function builds predicate layout
    # Component organizes object elements
    st.markdown("#### Sample Data Generator")
    
    # Interface defines subject type
    # Function creates predicate options
    # Component presents object choices
    pattern = st.selectbox(
        "Select Pattern Type",
        ["Random Distribution", "Cluster Pattern", "Linear Pattern", 
         "Grid Pattern", "Radial Pattern", "Path-based", "City Centers",
         "Custom Distribution"]
    )
    
    # Interface creates subject container
    # Function builds predicate layout
    # Component organizes object elements
    col1, col2 = st.columns(2)
    
    # Variable sets subject count
    # Function determines predicate size
    # Code assigns object value
    with col1:
        sample_count = st.slider("Number of points", 10, 200, 50)
    
    # Variable sets subject intensity
    # Function determines predicate range
    # Code assigns object values
    with col2:
        min_intensity = st.slider("Minimum intensity", 1, 10, 1)
        max_intensity = st.slider("Maximum intensity", min_intensity, 20, 10)
    
    # Function creates subject dataset
    # Method applies predicate pattern
    # Operation generates object data
    if pattern == "Random Distribution":
        return _create_random_distribution(sample_count, min_intensity, max_intensity)
    elif pattern == "Cluster Pattern":
        return _create_cluster_pattern(sample_count, min_intensity, max_intensity)
    elif pattern == "Linear Pattern":
        return _create_linear_pattern(sample_count, min_intensity, max_intensity)
    elif pattern == "Grid Pattern":
        return _create_grid_pattern(sample_count, min_intensity, max_intensity)
    elif pattern == "Radial Pattern":
        return _create_radial_pattern(sample_count, min_intensity, max_intensity)
    elif pattern == "Path-based":
        return _create_path_based(sample_count, min_intensity, max_intensity)
    elif pattern == "City Centers":
        return _create_city_centers(sample_count, min_intensity, max_intensity)
    elif pattern == "Custom Distribution":
        return _create_custom_distribution(sample_count, min_intensity, max_intensity)
    
    # Function handles subject default
    # Method creates predicate fallback
    # Operation produces object random
    return _create_random_distribution(sample_count, min_intensity, max_intensity)

# Function creates subject dataset
# Method generates predicate random
# Operation produces object pattern
def _create_random_distribution(sample_count, min_intensity, max_intensity):
    """
    Create a randomly distributed sample dataset
    
    # Function creates subject dataset
    # Method generates predicate random
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A randomly distributed dataset
    """
    # Function generates subject data
    # Method creates predicate frame
    # Operation builds object dataset
    data = pd.DataFrame({
        'latitude': np.random.uniform(25, 49, sample_count),
        'longitude': np.random.uniform(-125, -66, sample_count),
        'intensity': np.random.randint(min_intensity, max_intensity + 1, sample_count),
        'timestamp': pd.date_range(start='2025-01-01', periods=sample_count),
        'category': np.random.choice(['Alpha', 'Beta', 'Gamma', 'Delta'], sample_count),
        'value': np.random.normal(100, 25, sample_count).round(2)
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {sample_count} random data points")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function creates subject dataset
# Method generates predicate cluster
# Operation produces object pattern
def _create_cluster_pattern(sample_count, min_intensity, max_intensity):
    """
    Create a clustered sample dataset with multiple focal points
    
    # Function creates subject dataset
    # Method generates predicate cluster
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A clustered dataset with multiple focal points
    """
    # Variable sets subject clusters
    # Function determines predicate count
    # Code assigns object value
    num_clusters = min(5, max(2, sample_count // 20))
    
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons, intensities, categories, values = [], [], [], [], []
    
    # Variable sets subject categories
    # Function defines predicate options
    # Code specifies object choices
    category_options = ['Hotspot', 'Alert', 'Warning', 'Notice', 'Information']
    
    # Loop iterates subject clusters
    # Function processes predicate groups
    # Operation handles object centers
    for i in range(num_clusters):
        # Variable sets subject center
        # Function determines predicate location
        # Code assigns object coordinates
        center_lat = np.random.uniform(30, 45)
        center_lon = np.random.uniform(-120, -75)
        
        # Variable sets subject count
        # Function determines predicate size
        # Code assigns object value
        cluster_size = max(5, sample_count // num_clusters)
        
        # Variable sets subject category
        # Function selects predicate label
        # Code chooses object option
        category = category_options[i % len(category_options)]
        
        # Loop creates subject points
        # Function generates predicate cluster
        # Operation produces object members
        for _ in range(cluster_size):
            # List appends subject coordinates
            # Function adds predicate position
            # Operation extends object collections
            lats.append(center_lat + np.random.normal(0, 0.5))
            lons.append(center_lon + np.random.normal(0, 0.5))
            
            # List appends subject properties
            # Function adds predicate attributes
            # Operation extends object collections
            intensities.append(np.random.randint(min_intensity, max_intensity + 1))
            categories.append(category)
            values.append(np.random.normal(100, 25).round(2))
    
    # Function limits subject size
    # Method restricts predicate count
    # Operation trims object excess
    sample_count = min(sample_count, len(lats))
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats[:sample_count],
        'longitude': lons[:sample_count],
        'intensity': intensities[:sample_count],
        'timestamp': pd.date_range(start='2025-01-01', periods=sample_count),
        'category': categories[:sample_count],
        'value': values[:sample_count]
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {sample_count} data points in {num_clusters} clusters")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function creates subject dataset
# Method generates predicate linear
# Operation produces object pattern
def _create_linear_pattern(sample_count, min_intensity, max_intensity):
    """
    Create a sample dataset with points following linear paths
    
    # Function creates subject dataset
    # Method generates predicate linear
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A dataset with points following linear paths
    """
    # Variable sets subject lines
    # Function determines predicate count
    # Code assigns object value
    num_lines = min(3, max(1, sample_count // 20))
    
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons, intensities, categories, line_ids = [], [], [], [], []
    
    # Loop iterates subject lines
    # Function processes predicate paths
    # Operation handles object routes
    for i in range(num_lines):
        # Variable sets subject endpoints
        # Function determines predicate coordinates
        # Code assigns object positions
        start_lat = np.random.uniform(30, 45)
        start_lon = np.random.uniform(-120, -75)
        end_lat = start_lat + np.random.uniform(-5, 5)
        end_lon = start_lon + np.random.uniform(-10, 10)
        
        # Variable sets subject count
        # Function determines predicate size
        # Code assigns object value
        line_size = max(5, sample_count // num_lines)
        
        # Variable sets subject category
        # Function selects predicate label
        # Code chooses object option
        line_id = f"Line-{chr(65+i)}"  # Line-A, Line-B, etc.
        
        # Loop creates subject points
        # Function generates predicate path
        # Operation produces object members
        for j in range(line_size):
            # Variable calculates subject position
            # Function computes predicate fraction
            # Code determines object location
            t = j / (line_size - 1) if line_size > 1 else 0
            
            # List appends subject coordinates
            # Function adds predicate position
            # Operation extends object collections
            # Line interpolation with slight randomness
            lats.append(start_lat + t * (end_lat - start_lat) + np.random.normal(0, 0.1))
            lons.append(start_lon + t * (end_lon - start_lon) + np.random.normal(0, 0.1))
            
            # List appends subject properties
            # Function adds predicate attributes
            # Operation extends object collections
            intensities.append(np.random.randint(min_intensity, max_intensity + 1))
            categories.append(f"Segment-{j//5 + 1}")
            line_ids.append(line_id)
    
    # Function limits subject size
    # Method restricts predicate count
    # Operation trims object excess
    sample_count = min(sample_count, len(lats))
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats[:sample_count],
        'longitude': lons[:sample_count],
        'intensity': intensities[:sample_count],
        'timestamp': pd.date_range(start='2025-01-01', periods=sample_count),
        'category': categories[:sample_count],
        'line_id': line_ids[:sample_count]
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {sample_count} data points along {num_lines} linear paths")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function creates subject dataset
# Method generates predicate grid
# Operation produces object pattern
def _create_grid_pattern(sample_count, min_intensity, max_intensity):
    """
    Create a sample dataset with points arranged in a grid pattern
    
    # Function creates subject dataset
    # Method generates predicate grid
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A dataset with points arranged in a grid pattern
    """
    # Variable calculates subject dimensions
    # Function determines predicate grid
    # Code computes object size
    grid_size = int(np.sqrt(sample_count))
    
    # Variable sets subject center
    # Function determines predicate location
    # Code assigns object coordinates
    center_lat = np.random.uniform(35, 42)
    center_lon = np.random.uniform(-100, -80)
    
    # Variable sets subject span
    # Function determines predicate coverage
    # Code assigns object range
    span = max(1, min(5, grid_size / 2))
    
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons, intensities, grid_rows, grid_cols = [], [], [], [], []
    
    # Loop creates subject grid
    # Function generates predicate rows
    # Operation produces object structure
    for i in range(grid_size):
        # Loop creates subject columns
        # Function generates predicate positions
        # Operation produces object grid
        for j in range(grid_size):
            # List appends subject coordinates
            # Function adds predicate position
            # Operation extends object collections
            lat = center_lat + (i - grid_size/2) * span/grid_size + np.random.normal(0, 0.02)
            lon = center_lon + (j - grid_size/2) * span/grid_size + np.random.normal(0, 0.02)
            lats.append(lat)
            lons.append(lon)
            
            # List appends subject properties
            # Function adds predicate attributes
            # Operation extends object collections
            intensities.append(np.random.randint(min_intensity, max_intensity + 1))
            grid_rows.append(i)
            grid_cols.append(j)
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats[:sample_count],
        'longitude': lons[:sample_count],
        'intensity': intensities[:sample_count],
        'timestamp': pd.date_range(start='2025-01-01', periods=min(len(lats), sample_count)),
        'grid_row': grid_rows[:sample_count],
        'grid_col': grid_cols[:sample_count],
        'grid_id': [f"Cell-{r}-{c}" for r, c in zip(grid_rows, grid_cols)][:sample_count]
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {len(data)} data points in a {grid_size}x{grid_size} grid")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function creates subject dataset
# Method generates predicate radial
# Operation produces object pattern
def _create_radial_pattern(sample_count, min_intensity, max_intensity):
    """
    Create a sample dataset with points arranged in a radial pattern
    
    # Function creates subject dataset
    # Method generates predicate radial
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A dataset with points arranged in a radial pattern
    """
    # Variable sets subject center
    # Function determines predicate location
    # Code assigns object coordinates
    center_lat = np.random.uniform(35, 42)
    center_lon = np.random.uniform(-100, -80)
    
    # Variable sets subject rings
    # Function determines predicate count
    # Code assigns object value
    num_rings = min(5, max(2, sample_count // 10))
    
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons, intensities, ring_ids, angles = [], [], [], [], []
    
    # Loop iterates subject rings
    # Function processes predicate circles
    # Operation handles object layers
    for ring in range(num_rings):
        # Variable sets subject radius
        # Function determines predicate distance
        # Code assigns object value
        radius = (ring + 1) * 0.2  # Increasing radius for each ring
        
        # Variable sets subject points
        # Function determines predicate count
        # Code assigns object value
        points_in_ring = max(4, sample_count // num_rings)
        
        # Loop creates subject points
        # Function generates predicate ring
        # Operation produces object members
        for i in range(points_in_ring):
            # Variable calculates subject angle
            # Function computes predicate position
            # Code determines object location
            angle_deg = (i / points_in_ring) * 360
            angle_rad = math.radians(angle_deg)
            
            # List appends subject coordinates
            # Function adds predicate position
            # Operation extends object collections
            lat = center_lat + radius * math.sin(angle_rad) + np.random.normal(0, 0.02)
            lon = center_lon + radius * math.cos(angle_rad) + np.random.normal(0, 0.02)
            lats.append(lat)
            lons.append(lon)
            
            # List appends subject properties
            # Function adds predicate attributes
            # Operation extends object collections
            intensities.append(max_intensity - ring + np.random.randint(-1, 2))  # Higher intensity in center
            ring_ids.append(f"Ring-{ring+1}")
            angles.append(angle_deg)
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats[:sample_count],
        'longitude': lons[:sample_count],
        'intensity': intensities[:sample_count],
        'timestamp': pd.date_range(start='2025-01-01', periods=min(len(lats), sample_count)),
        'ring_id': ring_ids[:sample_count],
        'angle': angles[:sample_count]
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {len(data)} data points in {num_rings} concentric rings")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function creates subject dataset
# Method generates predicate paths
# Operation produces object pattern
def _create_path_based(sample_count, min_intensity, max_intensity):
    """
    Create a sample dataset with points following defined paths
    
    # Function creates subject dataset
    # Method generates predicate paths
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A dataset with points following defined paths
    """
    # Dictionary defines subject paths
    # Variable defines predicate routes
    # Collection holds object definitions
    paths = {
        "Route A": [
            (40.7128, -74.0060),  # New York
            (39.9526, -75.1652),  # Philadelphia
            (38.9072, -77.0369),  # Washington DC
            (35.7796, -78.6382),  # Raleigh
            (33.7490, -84.3880)   # Atlanta
        ],
        "Route B": [
            (47.6062, -122.3321),  # Seattle
            (45.5051, -122.6750),  # Portland
            (37.7749, -122.4194),  # San Francisco
            (34.0522, -118.2437)   # Los Angeles
        ],
        "Route C": [
            (41.8781, -87.6298),  # Chicago
            (39.7684, -86.1581),  # Indianapolis
            (38.2527, -85.7585),  # Louisville
            (36.1627, -86.7816),  # Nashville
            (35.1495, -90.0490)   # Memphis
        ]
    }
    
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons, intensities, route_ids, timestamps = [], [], [], [], []
    
    # Variable sets subject date
    # Function creates predicate baseline
    # Code sets object timepoint
    base_date = datetime(2025, 1, 1)
    
    # Loop iterates subject paths
    # Function processes predicate routes
    # Operation handles object segments
    for route_id, waypoints in paths.items():
        # Loop iterates subject segments
        # Function processes predicate sections
        # Operation handles object connections
        for i in range(len(waypoints) - 1):
            # Variable gets subject endpoints
            # Function retrieves predicate coordinates
            # Code obtains object positions
            start_lat, start_lon = waypoints[i]
            end_lat, end_lon = waypoints[i+1]
            
            # Variable calculates subject distance
            # Function computes predicate length
            # Code determines object value
            segment_points = max(5, sample_count // (len(paths) * (len(waypoints)-1)))
            
            # Loop creates subject points
            # Function generates predicate segment
            # Operation produces object datapoints
            for j in range(segment_points):
                # Variable calculates subject position
                # Function computes predicate fraction
                # Code determines object location
                t = j / (segment_points - 1) if segment_points > 1 else 0
                
                # List appends subject coordinates
                # Function adds predicate position
                # Operation extends object collections
                lat = start_lat + t * (end_lat - start_lat) + np.random.normal(0, 0.05)
                lon = start_lon + t * (end_lon - start_lon) + np.random.normal(0, 0.05)
                lats.append(lat)
                lons.append(lon)
                
                # List appends subject properties
                # Function adds predicate attributes
                # Operation extends object collections
                intensities.append(np.random.randint(min_intensity, max_intensity + 1))
                route_ids.append(f"{route_id}-{i+1}")
                
                # Calculate time progression along route
                segment_time = timedelta(hours=j * 2)
                route_time = timedelta(days=list(paths.keys()).index(route_id))
                timestamps.append(base_date + route_time + segment_time)
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats[:sample_count],
        'longitude': lons[:sample_count],
        'intensity': intensities[:sample_count],
        'timestamp': timestamps[:sample_count],
        'route_id': route_ids[:sample_count]
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {len(data)} data points along {len(paths)} routes")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function creates subject dataset
# Method generates predicate cities
# Operation produces object pattern
def _create_city_centers(sample_count, min_intensity, max_intensity):
    """
    Create a sample dataset with points clustered around major cities
    
    # Function creates subject dataset
    # Method generates predicate cities
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A dataset with points clustered around major cities
    """
    # Dictionary defines subject cities
    # Variable lists predicate locations
    # Collection holds object coordinates
    cities = {
        'New York': (40.7128, -74.0060),
        'Los Angeles': (34.0522, -118.2437),
        'Chicago': (41.8781, -87.6298),
        'Houston': (29.7604, -95.3698),
        'Phoenix': (33.4484, -112.0740),
        'Philadelphia': (39.9526, -75.1652),
        'San Antonio': (29.4241, -98.4936),
        'San Diego': (32.7157, -117.1611),
        'Dallas': (32.7767, -96.7970),
        'San Jose': (37.3382, -121.8863),
        'Austin': (30.2672, -97.7431),
        'Jacksonville': (30.3322, -81.6557),
        'San Francisco': (37.7749, -122.4194),
        'Seattle': (47.6062, -122.3321),
        'Denver': (39.7392, -104.9903)
    }
    
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons, intensities, city_names, populations = [], [], [], [], []
    
    # Variable calculates subject allocation
    # Function determines predicate distribution
    # Code computes object assignment
    cities_to_use = min(len(cities), sample_count // 5)
    selected_cities = random.sample(list(cities.keys()), cities_to_use)
    
    # Loop iterates subject cities
    # Function processes predicate locations
    # Operation handles object centers
    for city in selected_cities:
        # Variable gets subject coordinates
        # Function retrieves predicate position
        # Code obtains object location
        city_lat, city_lon = cities[city]
        
        # Variable sets subject count
        # Function determines predicate allocation
        # Code assigns object value
        points_per_city = max(5, sample_count // cities_to_use)
        
        # Variable sets subject density
        # Function determines predicate spread
        # Code assigns object value
        density = np.random.uniform(0.05, 0.2)  # Smaller values = tighter clusters
        
        # Loop creates subject points
        # Function generates predicate cluster
        # Operation produces object members
        for _ in range(points_per_city):
            # List appends subject coordinates
            # Function adds predicate position
            # Operation extends object collections
            lats.append(city_lat + np.random.normal(0, density))
            lons.append(city_lon + np.random.normal(0, density))
            
            # List appends subject properties
            # Function adds predicate attributes
            # Operation extends object collections
            intensities.append(np.random.randint(min_intensity, max_intensity + 1))
            city_names.append(city)
            
            # Generate simulated population figures
            base_pop = {
                'New York': 8.4, 'Los Angeles': 4.0, 'Chicago': 2.7,
                'Houston': 2.3, 'Phoenix': 1.7
            }.get(city, np.random.uniform(0.5, 2.0))
            populations.append(round(base_pop * (0.8 + 0.4 * np.random.random()), 2))
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats[:sample_count],
        'longitude': lons[:sample_count],
        'intensity': intensities[:sample_count],
        'timestamp': pd.date_range(start='2025-01-01', periods=min(len(lats), sample_count)),
        'location': city_names[:sample_count],
        'population': populations[:sample_count]
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {len(data)} data points around {cities_to_use} cities")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function creates subject dataset
# Method generates predicate custom
# Operation produces object pattern
def _create_custom_distribution(sample_count, min_intensity, max_intensity):
    """
    Create a sample dataset with a user-customizable distribution
    
    # Function creates subject dataset
    # Method generates predicate custom
    # Operation produces object pattern
    
    Args:
        sample_count: Number of data points to generate
        min_intensity: Minimum intensity value
        max_intensity: Maximum intensity value
        
    Returns:
        pd.DataFrame: A dataset with a custom distribution
    """
    # Interface creates subject container
    # Function builds predicate layout
    # Component organizes object elements
    st.markdown("#### Custom Distribution Settings")
    
    # Interface creates subject columns
    # Function divides predicate space
    # Component organizes object regions
    col1, col2 = st.columns(2)
    
    # Variable sets subject center
    # Function determines predicate location
    # Code assigns object coordinates
    with col1:
        center_lat = st.number_input("Center Latitude", value=39.5, format="%.4f")
        spread_lat = st.number_input("Latitude Spread", value=5.0, min_value=0.1, format="%.2f")
    
    with col2:
        center_lon = st.number_input("Center Longitude", value=-98.35, format="%.4f")
        spread_lon = st.number_input("Longitude Spread", value=10.0, min_value=0.1, format="%.2f")
    
    # Variable sets subject distribution
    # Function determines predicate pattern
    # Code assigns object type
    distribution = st.selectbox(
        "Distribution Type",
        ["Normal", "Uniform", "Bimodal", "Triangular"]
    )
    
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons, intensities, categories = [], [], [], []
    
    # Function generates subject coordinates
    # Method creates predicate positions
    # Operation produces object locations
    if distribution == "Normal":
        lats = np.random.normal(center_lat, spread_lat/5, sample_count)
        lons = np.random.normal(center_lon, spread_lon/5, sample_count)
    elif distribution == "Uniform":
        lats = np.random.uniform(center_lat - spread_lat, center_lat + spread_lat, sample_count)
        lons = np.random.uniform(center_lon - spread_lon, center_lon + spread_lon, sample_count)
    elif distribution == "Bimodal":
        # Create bimodal distribution with two centers
        half = sample_count // 2
        lats = np.concatenate([
            np.random.normal(center_lat - spread_lat/2, spread_lat/10, half),
            np.random.normal(center_lat + spread_lat/2, spread_lat/10, sample_count - half)
        ])
        lons = np.concatenate([
            np.random.normal(center_lon - spread_lon/2, spread_lon/10, half),
            np.random.normal(center_lon + spread_lon/2, spread_lon/10, sample_count - half)
        ])
    elif distribution == "Triangular":
        lats = np.random.triangular(
            center_lat - spread_lat, center_lat, center_lat + spread_lat, sample_count
        )
        lons = np.random.triangular(
            center_lon - spread_lon, center_lon, center_lon + spread_lon, sample_count
        )
    
    # Function generates subject attributes
    # Method creates predicate properties
    # Operation produces object values
    intensities = np.random.randint(min_intensity, max_intensity + 1, sample_count)
    
    # Variable sets subject categories
    # Function determines predicate labels
    # Code assigns object values
    categories = np.random.choice(['Region A', 'Region B', 'Region C', 'Region D'], sample_count)
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats,
        'longitude': lons,
        'intensity': intensities,
        'timestamp': pd.date_range(start='2025-01-01', periods=sample_count),
        'category': categories,
        'distribution': [distribution] * sample_count
    })
    
    # Interface displays subject message
    # Function shows predicate success
    # Component renders object notification
    st.success(f"Generated {sample_count} data points with {distribution} distribution")
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data

# Function generates subject sample
# Method creates predicate custom
# Operation produces object dataset
def generate_custom_sample(num_points, center_lat, center_lon, radius=1.0):
    """
    Generate a custom sample dataset with the specified parameters
    
    # Function generates subject sample
    # Method creates predicate custom
    # Operation produces object dataset
    
    Args:
        num_points: Number of data points to generate
        center_lat: Center latitude for the distribution
        center_lon: Center longitude for the distribution
        radius: Radius of distribution around the center
        
    Returns:
        pd.DataFrame: A custom sample dataset
    """
    # List initializes subject containers
    # Function creates predicate lists
    # Code prepares object storage
    lats, lons = [], []
    
    # Loop creates subject points
    # Function generates predicate positions
    # Operation produces object coordinates
    for _ in range(num_points):
        # Variable calculates subject angle
        # Function computes predicate direction
        # Code determines object orientation
        angle = np.random.uniform(0, 2 * np.pi)
        
        # Variable calculates subject distance
        # Function computes predicate offset
        # Code determines object displacement
        distance = np.random.uniform(0, radius)
        
        # List appends subject coordinates
        # Function adds predicate position
        # Operation extends object collections
        lats.append(center_lat + distance * np.sin(angle))
        lons.append(center_lon + distance * np.cos(angle))
    
    # Function creates subject frame
    # Method builds predicate dataset
    # Operation constructs object result
    data = pd.DataFrame({
        'latitude': lats,
        'longitude': lons,
        'intensity': np.random.randint(1, 10, num_points),
        'timestamp': pd.date_range(start='2025-01-01', periods=num_points),
        'category': np.random.choice(['A', 'B', 'C'], num_points)
    })
    
    # Function returns subject data
    # Method provides predicate result
    # Operation returns object frame
    return data