
# Code Standards Compliance Report

## Summary
- **Files processed**: 8
- **Black formatting successful**: 7 (87.5%)
- **Comment standard met**: 8 (100.0%)
- **Files with oversize modules**: 6 (75.0%)
- **Total module size violations**: 41

## Files Needing Attention

### Low Comment Density
Files with comment ratio below 15.0%:

### Module Size Violations
Files with functions/classes exceeding the maximum size:
- ./utils/kali_integrator.py: 13 violations
  - Tool: 78 lines
  - ToolChain: 63 lines
  - KaliIntegrator: 883 lines
  - ... and 10 more
- ./utils/security_tools_utils.py: 9 violations
  - execute_command_async: 71 lines
  - execute_command: 58 lines
  - execute_docker_command: 47 lines
  - ... and 6 more
- ./utils/opsec_manager.py: 8 violations
  - OperationalProfile: 102 lines
  - OpsecManager: 513 lines
  - __init__: 58 lines
  - ... and 5 more
- ./utils/url_health_monitor.py: 7 violations
  - URLHealthStatus: 31 lines
  - URLHealthMonitor: 350 lines
  - check_url_health: 75 lines
  - ... and 4 more
- ./utils/ctas_headers.py: 2 violations
  - generate_ctas_header: 64 lines
  - apply_header_to_file: 54 lines
- ./utils/kml_handler.py: 2 violations
  - kml_to_dataframe: 56 lines
  - dataframe_to_kml: 123 lines
