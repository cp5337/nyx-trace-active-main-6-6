# NyxTrace Project Refactoring Inventory

## Overview

This document provides an inventory of the NyxTrace project components, highlighting what has been refactored and what remains to be refactored according to our code standards.

## Core Components

### Refactored Components

✅ **core/registry.py**
- Refactoring Status: Partially Complete
- Improvements:
  - Split large methods into smaller, focused functions
  - Added helper methods to reduce code duplication
  - Improved thread-safety with consistent lock usage
  - Enhanced error handling patterns
- Remaining Work:
  - Complete refactoring of Service Locator section
  - Add comprehensive docstrings to all methods
  - Add typing hints to all parameters

### Components Requiring Refactoring

❌ **core/database/** 
- Current Issues:
  - Thread-safety concerns with Streamlit
  - Lack of connection pooling
  - Inconsistent error handling
  - Large method sizes
- Priority: High

❌ **core/periodic_table/** 
- Current Issues:
  - Complex visualization logic
  - Large class and method sizes
  - Mixed concerns (data and visualization)
- Priority: Medium

❌ **core/mcp_server.py**
- Current Issues:
  - Monolithic design (2110 lines)
  - Complex threading model
  - Mixed concerns
- Priority: High

❌ **core/geospatial/**
- Current Issues:
  - Duplicate algorithm implementations
  - Lack of standardized interfaces
  - Large method sizes
- Priority: Medium

## Page Components

### Refactored Components

None yet.

### Components Requiring Refactoring

❌ **pages/geospatial_intelligence.py**
- Current Issues:
  - Monolithic design (3372 lines)
  - UI and business logic mixed
  - Complex state management
- Priority: High

❌ **pages/optimization_demo.py**
- Current Issues:
  - Large file size (2657 lines)
  - Mixed concerns
  - Complex visualization logic
- Priority: Medium

❌ **main_dashboard.py**
- Current Issues:
  - Large file size (2229 lines)
  - Complex navigation logic
  - Mixed concerns
- Priority: High

❌ **pages/simple_node_viewer.py**
- Current Issues:
  - SQLite threading issues with Streamlit
  - Mixed concerns
- Priority: Medium

## Data Sources

### Refactored Components

None yet.

### Components Requiring Refactoring

❌ **data_sources/network_analysis_core.py**
- Current Issues:
  - Large file size (2579 lines)
  - Complex algorithm implementations
  - Lack of modularization
- Priority: High

❌ **data_sources/base_source.py**
- Current Issues:
  - Inconsistent interface design
  - Lack of thread-safety
- Priority: Medium

❌ **data_sources/excel_osint_source.py**
- Current Issues:
  - Large method sizes
  - Mixed concerns
- Priority: Low

## Utility Components

### Refactored Components

None yet.

### Components Requiring Refactoring

❌ **utils/ctas_repo_analyzer.py**
- Current Issues:
  - Large method sizes
  - Complex analysis logic
- Priority: Low

❌ **utils/url_health_monitor.py**
- Current Issues:
  - Thread-safety concerns
  - Complex monitoring logic
- Priority: Medium

## Visualization Components

### Refactored Components

None yet.

### Components Requiring Refactoring

❌ **visualizers/geospatial_heatmap.py**
- Current Issues:
  - Complex visualization logic
  - Large method sizes
- Priority: Medium

❌ **visualization/heatmap.py**
- Current Issues:
  - Duplicate functionality with geospatial_heatmap.py
  - Large method sizes
- Priority: Medium

## New Directory Structure

We've established a new organization pattern in `core/new/` with these subdirectories:
- `core/new/models/` - For data models
- `core/new/registry/` - For registry operations
- `core/new/database/` - For database connectors
- `core/new/services/` - For business logic
- `core/new/utils/` - For utility functions

## Next Steps

Based on this inventory, the next recommended components to refactor are:

1. **Database Layer** (core/database/*)
   - Create thread-safe database adapters
   - Implement connection pooling
   - Standardize error handling

2. **MCP Server** (core/mcp_server.py)
   - Break down into smaller components
   - Create clear interfaces between components

3. **Geospatial Intelligence Page** (pages/geospatial_intelligence.py)
   - Extract UI components
   - Separate business logic from presentation
   - Implement consistent state management