# NyxTrace Multi-Database Integration Guide

This document outlines the architecture and usage patterns for the multi-database integration in NyxTrace. The system supports three complementary database technologies:

1. **Supabase/PostgreSQL** - Relational database for structured data
2. **Neo4j** - Graph database for network analysis and relationships
3. **MongoDB** - Document database for flexible, schema-less data storage

## Architecture Overview

NyxTrace uses a layered architecture for database access:

```
┌───────────────────────────────────────────────────┐
│                Application Layer                  │
└─────────────────────┬─────────────────────────────┘
                      │
┌─────────────────────▼─────────────────────────────┐
│             Database Manager Layer                │
└──┬────────────────────┬───────────────────────┬───┘
   │                    │                       │
┌──▼───────┐      ┌─────▼────┐           ┌─────▼─────┐
│ Supabase │      │  Neo4j   │           │  MongoDB  │
│Connector │      │Connector │           │ Connector │
└──────────┘      └──────────┘           └───────────┘
```

## Configuration

Each database requires specific environment variables to be configured:

### Supabase Configuration

```
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_KEY=your-supabase-api-key
DATABASE_URL=postgresql://postgres:password@db.your-project.supabase.co:5432/postgres
SUPABASE_SCHEMA=public
```

### Neo4j Configuration

```
NEO4J_URI=bolt://localhost:7687
NEO4J_USERNAME=neo4j
NEO4J_PASSWORD=password
NEO4J_DATABASE=neo4j
```

### MongoDB Configuration

```
MONGODB_URI=mongodb://username:password@localhost:27017/
MONGODB_DATABASE=nyxtrace
```

## Usage Examples

### Initializing the Database Manager

```python
from core.database.utils import get_database_manager

# Get the database manager singleton
db_manager = get_database_manager()

# Check which databases are available
available_dbs = db_manager.get_available_databases()
print(f"Available databases: {available_dbs}")
```

### Storing Entities

The system supports storing entities across multiple databases simultaneously:

```python
# Create entity data
entity_data = {
    "id": "12345",
    "name": "Suspicious Location",
    "latitude": 37.7749,
    "longitude": -122.4194,
    "threat_level": "medium",
    "tags": ["surveillance", "intelligence"]
}

# Store entity in all available databases
results = db_manager.store_entity("location", entity_data)
```

### Retrieving Entities

Entities can be retrieved from any available database:

```python
# Get entity from any available database
entity = db_manager.get_entity("location", "12345")

# Get entity with preference for a specific database
from core.database.config import DatabaseType
entity = db_manager.get_entity("location", "12345", preferred_db=DatabaseType.MONGODB)
```

### Creating Relationships (Graph Data)

Relationships between entities are stored in Neo4j and represented in other databases:

```python
# Create a relationship between two entities
db_manager.create_relationship(
    from_type="person",
    from_id="person123",
    to_type="location",
    to_id="loc456",
    rel_type="VISITED",
    rel_props={"date": "2025-05-19", "confidence": 0.85}
)
```

## Direct Database Access

For specialized operations, you can access individual database connectors directly:

### Supabase/PostgreSQL

```python
from core.database.factory import DatabaseFactory
from core.database.config import DatabaseType

factory = DatabaseFactory()
supabase = factory.get_connector(DatabaseType.SUPABASE)

# Execute SQL query
results = supabase.execute_query(
    "SELECT * FROM locations WHERE threat_level = :level",
    {"level": "high"}
)
```

### Neo4j

```python
neo4j = factory.get_connector(DatabaseType.NEO4J)

# Execute Cypher query
results = neo4j.execute_query(
    "MATCH (p:Person)-[r:VISITED]->(l:Location) WHERE l.threat_level = $level RETURN p, r, l",
    {"level": "high"}
)
```

### MongoDB

```python
mongodb = factory.get_connector(DatabaseType.MONGODB)

# Find documents matching criteria
results = mongodb.find(
    "intelligence_reports",
    {"source": "OSINT", "confidence": {"$gt": 0.7}},
    limit=10
)
```

## Schema Design Recommendations

### Supabase/PostgreSQL

Use relational design principles with these recommended tables:

- `entities` - Base table for all entity types
- `locations` - Geographic locations with coordinates
- `persons` - Person entities with attributes
- `organizations` - Organization details
- `events` - Temporal events
- `relationships` - Cross-references for relationships

### Neo4j

Use a labeled property graph model:

- Nodes with entity type labels (`:Person`, `:Location`, etc.)
- Relationships with meaningful types (`VISITED`, `AFFILIATED_WITH`, etc.)
- Properties on both nodes and relationships

### MongoDB

Use a document model with flexible schemas:

- Collection per entity type
- Embedded documents for related information
- JSON/BSON for storing complex data structures

## Best Practices

1. **Use the Database Manager** - For most operations, use the Database Manager to ensure data consistency across databases.

2. **Choose the Right Database** - Leverage each database for its strengths:
   - PostgreSQL for structured data and complex queries
   - Neo4j for relationship analysis and graph algorithms
   - MongoDB for unstructured data and flexible schemas

3. **Handle Transactions** - For operations that need ACID properties, use PostgreSQL.

4. **Close Connections** - Always close database connections when done:
   ```python
   db_manager.close_connections()
   ```

5. **Error Handling** - All database operations should be wrapped in try/except blocks.

## Data Migration Between Databases

To ensure all databases have consistent data, use the migration utilities:

```python
# Example: Sync entities from PostgreSQL to MongoDB
from core.database.migration import sync_entities_to_mongodb

sync_entities_to_mongodb("locations")
```

## Securing Database Connections

Always store database credentials as environment variables, never in code. Use a `.env` file for local development, and proper secret management in production environments.

## Performance Considerations

- Use connection pooling for PostgreSQL and MongoDB
- For Neo4j, minimize the number of open sessions
- Cache frequently accessed data
- Use appropriate indexes for each database type