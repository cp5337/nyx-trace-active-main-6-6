# NyxTrace Codebase Standardization Implementation Plan

## Current Status
Our initial analysis shows that while the codebase has excellent commenting (100% of files meet comment standards), **76.3% of files contain functions that exceed our 30-line limit**. We've identified 609 functions that need refactoring across the core and utils directories.

## Refactoring Priority List

### Phase 1: Critical Infrastructure Files
These are the foundation of the application and should be refactored first:

1. **Registry System**
   - core/registry.py (27 oversized functions)
   - core/periodic_table/registry.py (20 oversized functions)
   
2. **Server Components**
   - core/mcp_server.py (26 oversized functions)
   - core/triptych/client.py

3. **Data Model Core**
   - core/periodic_table/element.py
   - core/periodic_table/table.py

### Phase 2: Critical UI Components
These directly impact user experience:

1. **Dashboard Components**
   - main_dashboard.py
   - pages/simple_node_viewer.py (already started)
   - pages/node_card_viewer.py

2. **Visualization Components**
   - visualizers/geospatial_heatmap.py
   - core/geospatial/visualizers/* (multiple files)

### Phase 3: Key Data Processing Components
These handle the core data operations:

1. **Data Sources**
   - data_sources/base_source.py
   - data_sources/excel_osint_source.py
   - data_sources/multi_model_processor.py

2. **Algorithms**
   - core/algorithms/distance_calculator.py
   - core/algorithms/hexagonal_grid.py (16 oversized functions)
   - core/algorithms/hotspot_analysis.py

### Phase 4: Integration Components
These connect to external systems:

1. **Database Connectors**
   - core/database/supabase/connector.py
   - core/database/neo4j/connector.py
   - core/integrations/graph_db/neo4j_connector.py (19 oversized functions)

2. **External Tools**
   - utils/kali_integrator.py (13 oversized functions)
   - core/cyberwarfare/tool_manager.py (16 oversized functions)

### Phase 5: Remaining Components
Complete refactoring of all remaining files based on usage frequency.

## Refactoring Approach for Large Classes

For extremely large classes like those identified below, we'll use a more aggressive decomposition approach:

1. **KaliIntegrator (883 lines)**
   - Extract separate classes for tool management, execution, and output parsing
   - Create utility functions for command generation and formatting

2. **PeriodicTableRegistry (1064 lines)**
   - Extract specialized registry components for elements, groups, and relationships
   - Create helper classes for database operations

3. **Neo4jConnector (1155 lines)**
   - Split into query management, data conversion, and connection management
   - Extract specialized components for different graph operations

4. **GoogleEarthManager (1675 lines)**
   - Create separate components for KML parsing, feature extraction, and visualization
   - Develop utility classes for style management and coordinates

## Implementation Steps for Each File

1. **Function Analysis**
   - Identify logical segments within oversized functions
   - Find common patterns that can be extracted

2. **Extraction & Decomposition**
   - Create helper functions for repeated code blocks
   - Extract complex operations into specialized methods
   - Build utility classes for related functionality

3. **Interface Preservation**
   - Maintain backward compatibility with existing interfaces
   - Document any necessary changes to signatures

4. **Testing & Validation**
   - Verify that functionality remains identical
   - Ensure no regressions in behavior

## SQLite Threading Resolution

For the SQLite threading issues with Streamlit, we'll implement:

1. Connection pooling with thread-local storage
2. Async-compatible database access patterns
3. Request-scoped connection management

## Progress Tracking

We'll track refactoring progress with a CSV file that includes:
- File path
- Original function count
- Original oversized function count
- Remaining oversized functions
- Completion percentage

## Quality Assurance

Each refactored file will be verified against:
- Functionality preservation
- Style consistency (via Black)
- Documentation standards
- Module size limits
- Type hints correctness (via mypy)