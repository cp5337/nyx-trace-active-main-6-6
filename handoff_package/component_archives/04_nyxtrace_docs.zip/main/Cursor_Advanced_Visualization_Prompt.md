# Cursor Development Task: Advanced Visualization Framework for NyxTrace

## Project Context
I'm developing "NyxTrace," an advanced geospatial intelligence platform for tracking convergent threats across physical, cyber, and cartel domains. The platform combines OSINT capabilities with interactive visualization to provide comprehensive threat intelligence.

The system follows the "Hunt, Detect, Disrupt, Disable, Dominate" framework derived from FIVE EYES intelligence operations and monitors critical infrastructure across multiple sectors.

I've already built core modules for incident reporting, OSINT investigation, operational security, data source integration, and security tool integration. Now I need sophisticated visualization capabilities to bring these components together.

## Development Request
Please develop an advanced visualization framework for the NyxTrace platform with the following capabilities:

### 1. Geospatial Visualization Components
- Create interactive maps using Plotly for displaying incident locations, infrastructure sites, and activity patterns
- Implement heatmap overlays for showing concentration of activities
- Add support for displaying movement patterns and routes
- Include time-based filtering and animation capabilities
- Ensure support for multiple base map styles (satellite, terrain, street)
- Implement clustering for dense data points

### 2. Network Graph Visualization
- Develop force-directed graph visualizations for entity relationships
- Support for multiple node types (people, organizations, infrastructure, digital assets)
- Include interactive capabilities (filtering, zooming, selecting)
- Implement community detection algorithms for identifying clusters
- Add node and edge highlighting features for path analysis
- Create time-based evolution visualization for networks

### 3. Timeline Visualization
- Build interactive timeline visualizations for temporal analysis
- Support for various temporal scales (hours to years)
- Include capability to show relationships between events
- Add filtering by event types, entities, and locations
- Create comparative timeline visualization for different threat types
- Implement anomaly detection and highlighting

### 4. Dashboard Integration Components
- Develop components that can be embedded within Streamlit dashboards
- Create consistent styling with dark theme
- Implement responsive layouts that work across different devices
- Add export capabilities for visualizations (PNG, SVG, interactive HTML)
- Support for both static and real-time updating visualizations

## Technical Requirements
- Use Python-compatible visualization libraries (Plotly, NetworkX, etc.)
- Ensure compatibility with Streamlit framework
- Optimize for performance with large datasets
- Implement efficient data structures for visualization data
- Create reusable components with clear APIs
- Maintain a consistent visual language across all visualizations
- Support for dark mode and high-contrast options

## Code Structure
The visualization components should be organized in a modular fashion:

```
visualization/
├── map_visualizer.py     # Geospatial visualization components
├── network_visualizer.py # Network graph visualization components
├── timeline_visualizer.py # Timeline visualization components
├── heatmap_visualizer.py # Heatmap and concentration analysis
├── dashboard_components.py # Reusable dashboard elements
├── themes.py            # Styling and theme configurations
└── utils/               # Utility functions for data preparation
    ├── geo_utils.py     # Geospatial data processing utilities
    ├── network_utils.py # Network data processing utilities
    └── time_utils.py    # Temporal data processing utilities
```

## Data Formats
The visualization components should accept standardized data formats:

**Geospatial Data**:
```python
{
    "points": [
        {
            "lat": 40.7128,
            "lon": -74.0060,
            "name": "Incident A",
            "type": "cyber",
            "severity": "high",
            "timestamp": "2023-05-01T14:30:00Z",
            "details": {...}
        },
        # More points...
    ],
    "areas": [
        {
            "coordinates": [[lat1, lon1], [lat2, lon2], ...],  # Polygon coordinates
            "name": "Affected Region B",
            "type": "physical",
            "intensity": 0.75,
            "details": {...}
        },
        # More areas...
    ],
    "paths": [
        {
            "coordinates": [[lat1, lon1], [lat2, lon2], ...],  # Path coordinates
            "name": "Movement Pattern C",
            "direction": "bidirectional",
            "intensity": 0.5,
            "timestamps": ["2023-05-01T14:30:00Z", ...],
            "details": {...}
        },
        # More paths...
    ]
}
```

**Network Data**:
```python
{
    "nodes": [
        {
            "id": "node1",
            "type": "person",
            "name": "John Doe",
            "attributes": {...},
            "metrics": {"centrality": 0.8, ...}
        },
        # More nodes...
    ],
    "edges": [
        {
            "source": "node1",
            "target": "node2",
            "type": "communication",
            "weight": 0.7,
            "directed": True,
            "timestamps": ["2023-05-01T14:30:00Z", ...],
            "attributes": {...}
        },
        # More edges...
    ],
    "communities": [
        {
            "nodes": ["node1", "node3", ...],
            "name": "Group A",
            "type": "cartel",
            "metrics": {"cohesion": 0.9, ...}
        },
        # More communities...
    ]
}
```

**Timeline Data**:
```python
{
    "events": [
        {
            "id": "event1",
            "name": "System Breach",
            "timestamp": "2023-05-01T14:30:00Z",
            "end_timestamp": "2023-05-01T18:45:00Z",  # Optional for duration
            "type": "cyber",
            "severity": "critical",
            "entities": ["entity1", "entity2"],
            "location": {"lat": 40.7128, "lon": -74.0060, "name": "NYC"},
            "details": {...}
        },
        # More events...
    ],
    "relationships": [
        {
            "source": "event1",
            "target": "event2",
            "type": "caused",
            "confidence": 0.85
        },
        # More relationships...
    ],
    "periods": [
        {
            "name": "Operation BlackOut",
            "start": "2023-05-01T00:00:00Z",
            "end": "2023-05-15T00:00:00Z",
            "type": "campaign",
            "events": ["event1", "event3", ...],
            "details": {...}
        },
        # More periods...
    ]
}
```

## Example Implementation
Here's an example implementation of a basic map visualization component:

```python
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import streamlit as st

def create_incident_map(incidents_data, map_style="dark"):
    """
    Create an interactive map of incidents
    
    Args:
        incidents_data: Dictionary with geospatial incident data
        map_style: Map style (dark, light, satellite, etc.)
        
    Returns:
        Plotly figure object
    """
    # Convert points to DataFrame for plotting
    if "points" in incidents_data and incidents_data["points"]:
        df = pd.DataFrame(incidents_data["points"])
        
        # Create base map
        fig = px.scatter_mapbox(
            df,
            lat="lat",
            lon="lon",
            color="type",
            size="severity_score",
            hover_name="name",
            hover_data=["timestamp", "details"],
            zoom=3,
            mapbox_style=map_style
        )
        
        # Add areas if present
        if "areas" in incidents_data and incidents_data["areas"]:
            for area in incidents_data["areas"]:
                fig.add_trace(
                    go.Scattermapbox(
                        lat=[coord[0] for coord in area["coordinates"]],
                        lon=[coord[1] for coord in area["coordinates"]],
                        mode="lines",
                        fill="toself",
                        fillcolor=f"rgba(255, 0, 0, {area['intensity']})",
                        line=dict(color="red"),
                        name=area["name"]
                    )
                )
        
        # Add paths if present
        if "paths" in incidents_data and incidents_data["paths"]:
            for path in incidents_data["paths"]:
                fig.add_trace(
                    go.Scattermapbox(
                        lat=[coord[0] for coord in path["coordinates"]],
                        lon=[coord[1] for coord in path["coordinates"]],
                        mode="lines",
                        line=dict(width=3, color="yellow"),
                        name=path["name"]
                    )
                )
        
        # Update layout
        fig.update_layout(
            margin=dict(l=0, r=0, t=0, b=0),
            mapbox=dict(
                center=dict(lat=df["lat"].mean(), lon=df["lon"].mean()),
                zoom=3
            )
        )
        
        return fig
    
    return None

# Example Streamlit integration
def display_incident_map(incidents_data):
    """Display incident map in Streamlit"""
    fig = create_incident_map(incidents_data)
    if fig:
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning("No incident data available for mapping")
```

## Next Steps and Expansion
Once the basic visualization components are implemented, I'll want to:

1. Integrate real-time data updates
2. Add more advanced analytics visualizations
3. Implement predictive visualization capabilities
4. Create specialized views for different types of analysis

Please develop these visualization components as modular, reusable elements that can be integrated into the larger NyxTrace platform. Prioritize performance, aesthetics, and usability in the implementation.