# CTAS Code Refactoring Analysis Report
Generated: 2025-05-21 11:26:22

## Summary
- Total Python files analyzed: 227
- Files exceeding size limit (300 lines): 121
- Functions exceeding size limit (40 lines): 708
- Total lines of Python code: 110446

## Refactoring Priority List
Files are sorted by line count (largest first):

| File | Lines | Status | Large Functions | Complex Functions |
|------|-------|--------|-----------------|------------------|
| ./pages/geospatial_intelligence.py | 3372 | Critical | 3 | 2 |
| ./backup_files/algorithms/geospatial_algorithms.py | 2728 | Critical | 22 | 3 |
| ./pages/optimization_demo.py | 2657 | Critical | 10 | 3 |
| ./data_sources/network_analysis_core.py | 2579 | Critical | 19 | 12 |
| ./backup_files/complete_fix.py | 2442 | Critical | 2 | 0 |
| ./main_dashboard.py | 2229 | Critical | 8 | 3 |
| ./core/mcp_server.py | 2110 | Critical | 8 | 1 |
| ./data_sources/criminal_network_analyzer.py | 1878 | Critical | 0 | 0 |
| ./core/integrations/satellite/google_earth_integration.py | 1847 | Critical | 16 | 7 |
| ./core/registry.py | 1744 | Critical | 13 | 0 |
| ./core/web_intelligence/media_outlets_processor.py | 1551 | Critical | 15 | 3 |
| ./pages/cyberwarfare_tools.py | 1516 | Critical | 11 | 2 |
| ./data_sources/target_analyzer.py | 1459 | Critical | 10 | 5 |
| ./pages/media_outlets_monitoring.py | 1414 | Critical | 5 | 3 |
| ./data_sources/infrastructure_scanner.py | 1391 | Critical | 0 | 0 |
| ./core/integrations/graph_db/neo4j_connector.py | 1390 | Critical | 13 | 0 |
| ./core/storyteller/workflow_progress.py | 1266 | Critical | 8 | 4 |
| ./core/drone/simulation.py | 1144 | Critical | 8 | 1 |
| ./data_sources/airspace_api_source.py | 1137 | Critical | 9 | 4 |
| ./core/darkweb_analyzer/darkweb_intelligence.py | 1117 | Critical | 12 | 2 |
| ./pages/adversary_task_viewer.py | 1103 | Critical | 4 | 3 |
| ./core/cyberwarfare/tool_manager.py | 1053 | Critical | 7 | 0 |
| ./utils/kali_integrator.py | 1029 | Critical | 7 | 1 |
| ./processors/osint_data_processor.py | 1004 | Critical | 12 | 6 |
| ./pages/drone_operations.py | 1000 | Critical | 5 | 3 |
| ./core/periodic_table/registry.py | 994 | Critical | 5 | 0 |
| ./visualization/analytics/ai_gis_integration.py | 974 | Critical | 11 | 4 |
| ./visualization/gis/mapbox_integration.py | 968 | Critical | 5 | 3 |
| ./pages/advanced_osint_suite.py | 956 | Critical | 9 | 4 |
| ./utils/ctas_repo_analyzer.py | 951 | Critical | 0 | 0 |
| ./core/security/kali_integrator.py | 945 | Critical | 9 | 0 |
| ./core/cyberwarfare/kali_integrator.py | 945 | Critical | 9 | 0 |
| ./visualizers/sample_data_generators.py | 941 | Critical | 9 | 0 |
| ./data_sources/traffic_camera_source.py | 931 | Critical | 11 | 2 |
| ./core/cyberwarfare/tool_scraper.py | 923 | Critical | 8 | 1 |
| ./core/mathematics/optimization/genetic_algorithm.py | 917 | Critical | 4 | 3 |
| ./data_sources/incident_reporter.py | 906 | Critical | 9 | 2 |
| ./core/algorithms/hotspot_analysis.py | 869 | Critical | 9 | 1 |
| ./core/periodic_table/table.py | 861 | Critical | 6 | 2 |
| ./pages/node_card_viewer.py | 855 | Critical | 3 | 1 |
| ./data_sources/multi_model_processor.py | 848 | Critical | 6 | 1 |
| ./core/mathematics/monte_carlo/integration.py | 845 | Critical | 10 | 0 |
| ./core/mathematics/optimization/particle_swarm.py | 841 | Critical | 7 | 3 |
| ./core/plugins/plugin_base.py | 796 | Critical | 4 | 0 |
| ./visualization/gis/geo_processor.py | 770 | Critical | 5 | 1 |
| ./core/algorithms/hexagonal_grid.py | 770 | Critical | 4 | 0 |
| ./visualization/gis/whitebox_tools.py | 768 | Critical | 9 | 0 |
| ./main.py | 765 | Critical | 6 | 0 |
| ./core/algorithms/distance_calculator.py | 764 | Critical | 11 | 1 |
| ./core/web_intelligence/news_scraper.py | 764 | Critical | 5 | 2 |
| ./data_sources/data_source_integrator.py | 722 | Critical | 5 | 1 |
| ./visualization/gis/geojson_utils.py | 706 | Critical | 6 | 3 |
| ./visualizers/url_context_card.py | 701 | Critical | 5 | 2 |
| ./core/mathematics/optimization/simulated_annealing.py | 668 | Critical | 4 | 2 |
| ./collectors/url_context_collector.py | 659 | Critical | 3 | 3 |
| ./visualization/gis/postgis_integration.py | 655 | Critical | 6 | 0 |
| ./core/matroid/spatial_matroid.py | 644 | Critical | 5 | 2 |
| ./core/periodic_table/task_registry.py | 644 | Critical | 3 | 0 |
| ./pages/periodic_table_demo.py | 640 | Critical | 3 | 1 |
| ./pages/url_health.py | 639 | Critical | 2 | 1 |
| ./core/algorithms/spatial_join.py | 639 | Critical | 9 | 1 |
| ./core/plugin_loader.py | 633 | Critical | 6 | 0 |
| ./core/gnn/gnn_model.py | 627 | Critical | 2 | 0 |
| ./core/media_analysis/analyzer.py | 624 | Critical | 5 | 2 |
| ./core/geospatial/reporting.py | 622 | Critical | 6 | 1 |
| ./utils/opsec_manager.py | 617 | Critical | 3 | 1 |
| ./processors/geo_resolver.py | 615 | Critical | 7 | 1 |
| ./visualization/threat_flow_visualization.py | 612 | Critical | 4 | 1 |
| ./core/storyteller/real_time_tracker.py | 610 | Critical | 6 | 2 |
| ./core/mcp_client.py | 589 | Warning | 3 | 1 |
| ./core/mathematics/monte_carlo/simulation.py | 570 | Warning | 6 | 1 |
| ./data/sample_threat_intel.py | 562 | Warning | 3 | 0 |
| ./core/periodic_table/relationships.py | 559 | Warning | 4 | 0 |
| ./core/matroid/base.py | 556 | Warning | 1 | 0 |
| ./data_sources/osint_investigation.py | 546 | Warning | 4 | 0 |
| ./utils/security_tools_utils.py | 543 | Warning | 7 | 0 |
| ./pages/threat_intelligence.py | 542 | Warning | 5 | 0 |
| ./core/algorithms/geospatial_utils.py | 536 | Warning | 2 | 0 |
| ./core/interfaces/analyzers.py | 512 | Warning | 1 | 0 |
| ./core/mathematics/las_vegas/algorithm.py | 512 | Warning | 5 | 1 |
| ./core/mathematics/las_vegas/framework.py | 504 | Warning | 0 | 0 |
| ./pages/url_intelligence.py | 494 | Warning | 4 | 0 |
| ./pages/enhanced_workflow_storyteller.py | 491 | Warning | 3 | 0 |
| ./core/database/mongodb/connector.py | 486 | Warning | 0 | 0 |
| ./core/triptych/models.py | 484 | Warning | 0 | 0 |
| ./data_sources/plugins/social_monitoring_source.py | 480 | Warning | 5 | 1 |
| ./processors/url_context_processor.py | 470 | Warning | 6 | 2 |
| ./core/database/utils.py | 462 | Warning | 4 | 0 |
| ./visualization/osint_visualizer.py | 460 | Warning | 6 | 3 |
| ./core/cyberwarfare/results_parser.py | 448 | Warning | 6 | 0 |
| ./pages/url_health_monitoring.py | 444 | Warning | 0 | 0 |
| ./collectors/kali_tools_collector.py | 434 | Warning | 5 | 1 |
| ./visualizers/export_utilities.py | 434 | Warning | 5 | 0 |
| ./core/geospatial/threat_analysis.py | 433 | Warning | 3 | 0 |
| ./data_sources/web_scraper.py | 431 | Warning | 4 | 3 |
| ./data_sources/news_monitor.py | 430 | Warning | 4 | 1 |
| ./visualizers/data_loaders.py | 415 | Warning | 4 | 0 |
| ./pages/kali_tools_explorer.py | 414 | Warning | 3 | 1 |
| ./core/triptych/client.py | 408 | Warning | 2 | 0 |
| ./pages/workflow_storyteller.py | 407 | Warning | 2 | 0 |
| ./code_analyzer.py | 400 | Warning | 0 | 0 |
| ./pages/simple_node_viewer.py | 396 | Warning | 3 | 1 |
| ./pages/drone_operations/components/mission_planning.py | 393 | Warning | 4 | 2 |
| ./core/geospatial/base_maps.py | 387 | Warning | 4 | 0 |
| ./core/geospatial/visualizers/choropleths.py | 383 | Warning | 3 | 1 |
| ./pages/drone_operations/utils/mission_patterns.py | 380 | Warning | 5 | 0 |
| ./utils/url_health_monitor.py | 378 | Warning | 2 | 0 |
| ./core/database/neo4j/connector.py | 375 | Warning | 2 | 0 |
| ./core/storyteller/story_elements.py | 366 | Warning | 1 | 0 |
| ./core/periodic_table/element.py | 361 | Warning | 1 | 0 |
| ./data_sources/excel_osint_source.py | 359 | Warning | 2 | 2 |
| ./visualizers/sample_data_generators/basic_generators.py | 347 | Warning | 3 | 0 |
| ./core/cyberwarfare/assessment_reporting.py | 344 | Warning | 4 | 1 |
| ./core/database/supabase/connector.py | 338 | Warning | 1 | 0 |
| ./visualizers/export_utilities/format_converters.py | 335 | Warning | 2 | 0 |
| ./core/geospatial/visualizers/networks.py | 320 | Warning | 1 | 1 |
| ./visualizers/sample_data_generators/pattern_generators.py | 317 | Warning | 3 | 0 |
| ./scripts/import_outlets_from_excel.py | 315 | Warning | 4 | 0 |
| ./core/periodic_table/task_loader.py | 311 | Warning | 2 | 0 |
| ./data_sources/shodan_integration.py | 307 | Warning | 3 | 1 |
| ./core/periodic_table/simple_relationships.py | 302 | Warning | 2 | 1 |
| ./core/geospatial/visualizers/markers.py | 300 | OK | 3 | 1 |
| ./data_sources/osint_analyzer.py | 294 | OK | 3 | 3 |
| ./core/interfaces/base.py | 285 | OK | 0 | 0 |
| ./visualization/advanced_charts.py | 281 | OK | 3 | 0 |
| ./core/drone/flight_profiles.py | 275 | OK | 0 | 0 |
| ./refactor_analyzer.py | 274 | OK | 2 | 1 |
| ./data_sources/plugins/news_api_source.py | 273 | OK | 2 | 0 |
| ./core/geospatial/plugin_manager.py | 273 | OK | 2 | 0 |
| ./visualizers/sample_data_generators/geographic_generators.py | 272 | OK | 2 | 0 |
| ./visualization/heatmap.py | 257 | OK | 3 | 0 |
| ./code_size_analyzer.py | 256 | OK | 1 | 1 |
| ./pages/database_integration_demo.py | 256 | OK | 2 | 1 |
| ./core/periodic_table/group.py | 250 | OK | 0 | 0 |
| ./visualizers/geospatial_heatmap.py | 250 | OK | 2 | 0 |
| ./utils/kml_handler.py | 249 | OK | 2 | 0 |
| ./visualizers/export_utilities/export_core.py | 248 | OK | 3 | 0 |
| ./core/database/config.py | 243 | OK | 0 | 0 |
| ./pages/threat_intel.py | 239 | OK | 1 | 1 |
| ./core/geospatial/data_preparation.py | 239 | OK | 3 | 1 |
| ./utils.py | 236 | OK | 2 | 0 |
| ./core/geospatial/visualizers/heatmap.py | 234 | OK | 3 | 0 |
| ./core/periodic_table/adversary_task.py | 222 | OK | 0 | 0 |
| ./pages/url_health_dashboard.py | 219 | OK | 0 | 0 |
| ./data_handler.py | 203 | OK | 0 | 0 |
| ./apply_ctas_headers.py | 194 | OK | 0 | 0 |
| ./pages/drone_operations/components/squadron_monitor.py | 191 | OK | 1 | 1 |
| ./collectors/drone_telemetry_collector.py | 189 | OK | 1 | 0 |
| ./scripts/analyze_excel.py | 189 | OK | 1 | 0 |
| ./visualizers/data_loaders/sample_mini_generator.py | 183 | OK | 1 | 0 |
| ./pages/drone_operations/components/telemetry_feed.py | 178 | OK | 1 | 1 |
| ./pages/geospatial_heatmap.py | 171 | OK | 1 | 0 |
| ./core/interfaces/processors.py | 163 | OK | 0 | 0 |
| ./core/database/factory.py | 159 | OK | 0 | 0 |
| ./utils/ctas_headers.py | 154 | OK | 2 | 0 |
| ./visualizers/map_builders/infrastructure_map.py | 154 | OK | 2 | 0 |
| ./pages/drone_operations/models/mission.py | 149 | OK | 0 | 0 |
| ./code_check.py | 145 | OK | 0 | 0 |
| ./visualizers/map_builders/transport_map.py | 145 | OK | 1 | 0 |
| ./data_sources/source_manager.py | 138 | OK | 0 | 0 |
| ./pages/drone_operations/components/airspace_monitor.py | 134 | OK | 1 | 0 |
| ./visualizers/map_builders/trafficking_map.py | 133 | OK | 1 | 0 |
| ./visualizers/sample_data_generators/__init__.py | 124 | OK | 1 | 0 |
| ./core/interfaces/collectors.py | 122 | OK | 0 | 0 |
| ./visualizers/data_loaders/system_intelligence.py | 120 | OK | 1 | 0 |
| ./visualizers/data_loaders/file_loader.py | 119 | OK | 1 | 0 |
| ./data_sources/twitter_source.py | 110 | OK | 0 | 0 |
| ./pages/drone_operations/utils/map_utils.py | 101 | OK | 0 | 0 |
| ./core/algorithms/geospatial_algorithms.py | 101 | OK | 0 | 0 |
| ./data_sources/news_api_source.py | 98 | OK | 0 | 0 |
| ./data_sources/plugins/__init__.py | 98 | OK | 0 | 0 |
| ./pages/drone_operations/models/telemetry.py | 98 | OK | 0 | 0 |
| ./pages/drone_operations/dashboard.py | 94 | OK | 1 | 0 |
| ./visualizers/data_loaders/interface.py | 91 | OK | 1 | 0 |
| ./core/algorithms/__init__.py | 88 | OK | 0 | 0 |
| ./data_sources/base_source.py | 81 | OK | 0 | 0 |
| ./core/geospatial/__init__.py | 72 | OK | 0 | 0 |
| ./pages/drone_operations/components/traffic_camera.py | 66 | OK | 0 | 0 |
| ./core/cyberwarfare/__init__.py | 66 | OK | 0 | 0 |
| ./core/interfaces/visualizers.py | 65 | OK | 0 | 0 |
| ./backup_files/inspect_excel.py | 63 | OK | 1 | 0 |
| ./pages/download.py | 62 | OK | 0 | 0 |
| ./core/interfaces/__init__.py | 58 | OK | 0 | 0 |
| ./core/security/__init__.py | 57 | OK | 0 | 0 |
| ./core/mathematics/__init__.py | 49 | OK | 0 | 0 |
| ./core/storyteller/__init__.py | 46 | OK | 0 | 0 |
| ./pages/drone_operations/__init__.py | 42 | OK | 0 | 0 |
| ./pages/drone_operations_refactored.py | 40 | OK | 0 | 0 |
| ./pages/drone_operations/utils/__init__.py | 40 | OK | 0 | 0 |
| ./pages/drone_operations/components/__init__.py | 36 | OK | 0 | 0 |
| ./core/periodic_table/__init__.py | 35 | OK | 0 | 0 |
| ./pages/drone_operations/models/__init__.py | 34 | OK | 0 | 0 |
| ./visualizers/export_utilities/__init__.py | 33 | OK | 0 | 0 |
| ./drone_modules/collectors/drone_telemetry_collector.py | 32 | OK | 0 | 0 |
| ./core/mathematics/monte_carlo/__init__.py | 31 | OK | 0 | 0 |
| ./visualizers/data_loaders/__init__.py | 31 | OK | 0 | 0 |
| ./core/mathematics/las_vegas/__init__.py | 30 | OK | 0 | 0 |
| ./core/mathematics/optimization/__init__.py | 30 | OK | 0 | 0 |
| ./core/geospatial/visualizers/__init__.py | 28 | OK | 0 | 0 |
| ./core/database/__init__.py | 28 | OK | 0 | 0 |
| ./core/database/supabase/__init__.py | 25 | OK | 0 | 0 |
| ./core/database/neo4j/__init__.py | 25 | OK | 0 | 0 |
| ./core/database/mongodb/__init__.py | 25 | OK | 0 | 0 |
| ./temp_extract/visualizers/geospatial_heatmap.py | 18 | OK | 0 | 0 |
| ./core/triptych/__init__.py | 17 | OK | 0 | 0 |
| ./backup_files/url_health_only.py | 17 | OK | 0 | 0 |
| ./backup_files/url_health_section.py | 16 | OK | 0 | 0 |
| ./drone_modules/core/drone/flight_profiles.py | 13 | OK | 0 | 0 |
| ./visualization/gis/drone_mapper.py | 12 | OK | 0 | 0 |
| ./drone_modules/visualization/gis/drone_mapper.py | 12 | OK | 0 | 0 |
| ./drone_modules/pages/drone_operations.py | 12 | OK | 0 | 0 |
| ./temp_extract/visualizers/map_builders/trafficking_map.py | 10 | OK | 0 | 0 |
| ./temp_extract/visualizers/map_builders/transport_map.py | 10 | OK | 0 | 0 |
| ./temp_extract/visualizers/map_builders/infrastructure_map.py | 10 | OK | 0 | 0 |
| ./visualizers/tile_utils.py | 8 | OK | 0 | 0 |
| ./temp_extract/visualizers/tile_utils.py | 8 | OK | 0 | 0 |
| ./visualization/analytics/__init__.py | 6 | OK | 0 | 0 |
| ./utils/__init__.py | 6 | OK | 0 | 0 |
| ./data_sources/__init__.py | 1 | OK | 0 | 0 |
| ./visualization/__init__.py | 1 | OK | 0 | 0 |
| ./visualization/gis/__init__.py | 1 | OK | 0 | 0 |
| ./core/__init__.py | 1 | OK | 0 | 0 |
| ./core/drone/__init__.py | 1 | OK | 0 | 0 |
| ./collectors/__init__.py | 1 | OK | 0 | 0 |
| ./visualizers/map_builders/__init__.py | 0 | OK | 0 | 0 |
| ./backup_files/exec_code.py | 0 | OK | 0 | 0 |
| ./temp_extract/visualizers/map_builders/__init__.py | 0 | OK | 0 | 0 |

## Detailed Function Analysis
Here are the specific functions that exceed our guidelines:

### ./backup_files/algorithms/geospatial_algorithms.py
- `haversine_distance` (line 101): 55 lines (exceeds 40)
- `vincenty_distance` (line 158): 165 lines (exceeds 40)
- `rhumb_distance` (line 325): 76 lines (exceeds 40)
- `bearing` (line 403): 66 lines (exceeds 40)
- `midpoint` (line 471): 76 lines (exceeds 40)
- `destination_point` (line 549): 71 lines (exceeds 40)
- `intersection_point` (line 622): 125 lines (exceeds 40)
- `get_neighbors` (line 924): 47 lines (exceeds 40)
- `polygon_to_cells` (line 972): 52 lines (exceeds 40)
- `hexagon_to_geojson` (line 1025): 55 lines (exceeds 40)
- `get_cell_area` (line 1081): 45 lines (exceeds 40)
- `distance_between_cells` (line 1127): 41 lines (exceeds 40)
- `cells_to_dataframe` (line 1169): 96 lines (exceeds 40)
- `point_in_polygon_join` (line 1308): 173 lines (exceeds 40)
- `point_in_polygon_join` (line 1308): complexity score 15 (exceeds 10)
- `nearest_neighbor_join` (line 1482): 106 lines (exceeds 40)
- `buffer_join` (line 1589): 90 lines (exceeds 40)
- `spatial_aggregate` (line 1680): 133 lines (exceeds 40)
- `getis_ord_g` (line 1863): 150 lines (exceeds 40)
- `local_morans_i` (line 2014): 188 lines (exceeds 40)
- `local_morans_i` (line 2014): complexity score 15 (exceeds 10)
- `kernel_density` (line 2203): 157 lines (exceeds 40)
- `dbscan_clustering` (line 2361): 210 lines (exceeds 40)
- `dbscan_clustering` (line 2361): complexity score 15 (exceeds 10)
- `get_capabilities` (line 2681): 48 lines (exceeds 40)

### ./backup_files/complete_fix.py
- `create_time_series_plot` (line 136): 75 lines (exceeds 40)
- `dataframe_to_kml` (line 236): 50 lines (exceeds 40)

### ./backup_files/inspect_excel.py
- `inspect_excel_file` (line 5): 55 lines (exceeds 40)

### ./code_size_analyzer.py
- `scan_directory` (line 138): 56 lines (exceeds 40)
- `scan_directory` (line 138): complexity score 12 (exceeds 10)

### ./collectors/drone_telemetry_collector.py
- `simulate` (line 67): 59 lines (exceeds 40)

### ./collectors/kali_tools_collector.py
- `collect_tools` (line 76): 96 lines (exceeds 40)
- `get_tool_details` (line 173): 86 lines (exceeds 40)
- `get_tool_details` (line 173): complexity score 12 (exceeds 10)
- `collect_all_tool_details` (line 260): 65 lines (exceeds 40)
- `search_tools` (line 326): 52 lines (exceeds 40)
- `categorize_tools` (line 379): 44 lines (exceeds 40)

### ./collectors/url_context_collector.py
- `collect` (line 172): 49 lines (exceeds 40)
- `collect_url_context` (line 244): 154 lines (exceeds 40)
- `collect_url_context` (line 244): complexity score 20 (exceeds 10)
- `_extract_technology_stack` (line 433): complexity score 11 (exceeds 10)
- `_generate_emoji_summary` (line 473): 111 lines (exceeds 40)
- `_generate_emoji_summary` (line 473): complexity score 40 (exceeds 10)

### ./core/algorithms/distance_calculator.py
- `haversine_distance` (line 82): 46 lines (exceeds 40)
- `vincenty_distance` (line 130): 120 lines (exceeds 40)
- `rhumb_distance` (line 252): 62 lines (exceeds 40)
- `bearing` (line 316): 42 lines (exceeds 40)
- `midpoint` (line 360): 44 lines (exceeds 40)
- `destination_point` (line 406): 42 lines (exceeds 40)
- `great_circle_points` (line 450): 56 lines (exceeds 40)
- `frechet_distance` (line 508): 54 lines (exceeds 40)
- `hausdorff_distance` (line 564): 48 lines (exceeds 40)
- `haversine_distance_vectorized` (line 614): 41 lines (exceeds 40)
- `geodesic_distance` (line 657): 108 lines (exceeds 40)
- `geodesic_distance` (line 657): complexity score 15 (exceeds 10)

### ./core/algorithms/geospatial_utils.py
- `cartesian_to_geodetic` (line 163): 62 lines (exceeds 40)
- `get_bounding_box` (line 231): 65 lines (exceeds 40)

### ./core/algorithms/hexagonal_grid.py
- `polygon_to_h3` (line 187): 43 lines (exceeds 40)
- `hexbin_dataframe` (line 558): 92 lines (exceeds 40)
- `create_hex_grid` (line 652): 54 lines (exceeds 40)
- `hierarchical_clustering` (line 708): 63 lines (exceeds 40)

### ./core/algorithms/hotspot_analysis.py
- `calculate_distance_matrix` (line 73): 44 lines (exceeds 40)
- `create_weight_matrix` (line 119): 93 lines (exceeds 40)
- `getis_ord_g_star` (line 214): 83 lines (exceeds 40)
- `local_moran_i` (line 299): 80 lines (exceeds 40)
- `global_moran_i` (line 381): 89 lines (exceeds 40)
- `kernel_density_estimation` (line 472): 94 lines (exceeds 40)
- `dbscan_clusters` (line 568): 60 lines (exceeds 40)
- `space_time_scan` (line 630): 165 lines (exceeds 40)
- `space_time_scan` (line 630): complexity score 25 (exceeds 10)
- `optimize_hotspot_threshold` (line 797): 73 lines (exceeds 40)

### ./core/algorithms/spatial_join.py
- `create_rtree_index` (line 70): 59 lines (exceeds 40)
- `point_in_polygon_query` (line 131): 65 lines (exceeds 40)
- `spatial_join_dataframes` (line 198): 64 lines (exceeds 40)
- `proximity_join` (line 264): 76 lines (exceeds 40)
- `proximity_join` (line 264): complexity score 11 (exceeds 10)
- `create_voronoi_diagram` (line 342): 72 lines (exceeds 40)
- `create_delaunay_triangulation` (line 416): 58 lines (exceeds 40)
- `buffer_polygons` (line 476): 49 lines (exceeds 40)
- `dissolve_polygons` (line 527): 51 lines (exceeds 40)
- `find_nearest_points` (line 580): 60 lines (exceeds 40)

### ./core/cyberwarfare/assessment_reporting.py
- `add_finding` (line 70): 45 lines (exceeds 40)
- `create_vulnerability_report` (line 159): 66 lines (exceeds 40)
- `create_vulnerability_report` (line 159): complexity score 12 (exceeds 10)
- `export_report` (line 227): 71 lines (exceeds 40)
- `generate_report_summary` (line 300): 45 lines (exceeds 40)

### ./core/cyberwarfare/kali_integrator.py
- `_load_tools_inventory` (line 132): 68 lines (exceeds 40)
- `_build_tools_inventory` (line 201): 60 lines (exceeds 40)
- `_determine_category` (line 291): 66 lines (exceeds 40)
- `_build_category_map` (line 444): 43 lines (exceeds 40)
- `get_tools` (line 488): 77 lines (exceeds 40)
- `get_tool_help` (line 600): 65 lines (exceeds 40)
- `update_inventory` (line 698): 43 lines (exceeds 40)
- `execute_command` (line 742): 91 lines (exceeds 40)
- `parse_command_output` (line 834): 48 lines (exceeds 40)

### ./core/cyberwarfare/results_parser.py
- `parse_nmap_results` (line 36): 63 lines (exceeds 40)
- `_parse_nmap_xml` (line 101): 96 lines (exceeds 40)
- `parse_dirb_results` (line 199): 48 lines (exceeds 40)
- `parse_nikto_results` (line 249): 55 lines (exceeds 40)
- `parse_gobuster_results` (line 306): 46 lines (exceeds 40)
- `parse_whatweb_results` (line 354): 95 lines (exceeds 40)

### ./core/cyberwarfare/tool_manager.py
- `get_help` (line 134): 62 lines (exceeds 40)
- `execute_template` (line 229): 59 lines (exceeds 40)
- `_load_configurations` (line 339): 129 lines (exceeds 40)
- `save_configurations` (line 469): 129 lines (exceeds 40)
- `remove_tool` (line 640): 54 lines (exceeds 40)
- `execute_tool` (line 850): 46 lines (exceeds 40)
- `execute_template` (line 897): 89 lines (exceeds 40)

### ./core/cyberwarfare/tool_scraper.py
- `__init__` (line 93): 48 lines (exceeds 40)
- `_get_cached_data` (line 142): 48 lines (exceeds 40)
- `_save_cached_data` (line 191): 41 lines (exceeds 40)
- `_fetch_html` (line 233): 59 lines (exceeds 40)
- `get_tool_list` (line 293): 165 lines (exceeds 40)
- `get_tool_details` (line 459): 221 lines (exceeds 40)
- `get_tool_details` (line 459): complexity score 14 (exceeds 10)
- `scrape_all_tools` (line 681): 150 lines (exceeds 40)
- `export_tools_data` (line 832): 92 lines (exceeds 40)

### ./core/darkweb_analyzer/darkweb_intelligence.py
- `__init__` (line 105): 55 lines (exceeds 40)
- `_initialize_database` (line 161): 100 lines (exceeds 40)
- `extract_content` (line 292): 114 lines (exceeds 40)
- `extract_content` (line 292): complexity score 12 (exceeds 10)
- `_extract_marketplace_data` (line 447): 41 lines (exceeds 40)
- `_save_to_database` (line 547): 75 lines (exceeds 40)
- `add_monitoring_target` (line 623): 60 lines (exceeds 40)
- `get_monitoring_targets` (line 684): 56 lines (exceeds 40)
- `monitor_targets` (line 781): 66 lines (exceeds 40)
- `monitor_targets` (line 781): complexity score 11 (exceeds 10)
- `_save_alert` (line 848): 43 lines (exceeds 40)
- `get_alerts` (line 920): 75 lines (exceeds 40)
- `search_darkweb_content` (line 996): 70 lines (exceeds 40)
- `setup_tor_connection` (line 1068): 46 lines (exceeds 40)

### ./core/database/neo4j/connector.py
- `merge_node` (line 162): 47 lines (exceeds 40)
- `create_relationship` (line 238): 48 lines (exceeds 40)

### ./core/database/supabase/connector.py
- `update` (line 196): 43 lines (exceeds 40)

### ./core/database/utils.py
- `store_entity` (line 103): 74 lines (exceeds 40)
- `get_entity` (line 178): 55 lines (exceeds 40)
- `update_entity` (line 234): 85 lines (exceeds 40)
- `create_relationship` (line 320): 114 lines (exceeds 40)

### ./core/drone/simulation.py
- `create_drone` (line 252): 129 lines (exceeds 40)
- `create_squadron` (line 382): 45 lines (exceeds 40)
- `assign_mission` (line 428): 129 lines (exceeds 40)
- `assign_squadron_formation` (line 558): 122 lines (exceeds 40)
- `assign_squadron_formation` (line 558): complexity score 12 (exceeds 10)
- `update_simulation` (line 681): 130 lines (exceeds 40)
- `export_telemetry` (line 897): 61 lines (exceeds 40)
- `_update_telemetry` (line 959): 65 lines (exceeds 40)
- `_simulate_random_events` (line 1064): 81 lines (exceeds 40)

### ./core/geospatial/base_maps.py
- `create_base_map` (line 42): 57 lines (exceeds 40)
- `add_tile_layers` (line 100): 63 lines (exceeds 40)
- `create_advanced_map` (line 164): 135 lines (exceeds 40)
- `add_legend` (line 300): 88 lines (exceeds 40)

### ./core/geospatial/data_preparation.py
- `prepare_geospatial_data` (line 31): 103 lines (exceeds 40)
- `prepare_geospatial_data` (line 31): complexity score 11 (exceeds 10)
- `convert_to_geodataframe` (line 135): 49 lines (exceeds 40)
- `extract_coordinates` (line 185): 55 lines (exceeds 40)

### ./core/geospatial/plugin_manager.py
- `initialize_plugins` (line 110): 119 lines (exceeds 40)
- `get_plugin_status` (line 230): 44 lines (exceeds 40)

### ./core/geospatial/reporting.py
- `generate_threat_summary` (line 37): 92 lines (exceeds 40)
- `create_threat_time_series` (line 130): 121 lines (exceeds 40)
- `create_threat_time_series` (line 130): complexity score 11 (exceeds 10)
- `create_threat_histogram` (line 252): 65 lines (exceeds 40)
- `generate_geospatial_report` (line 318): 92 lines (exceeds 40)
- `get_report_download_link` (line 444): 43 lines (exceeds 40)
- `display_report_summary` (line 488): 135 lines (exceeds 40)

### ./core/geospatial/threat_analysis.py
- `calculate_threat_score` (line 49): 123 lines (exceeds 40)
- `identify_threat_hotspots` (line 173): 152 lines (exceeds 40)
- `calculate_proximity_risk` (line 326): 108 lines (exceeds 40)

### ./core/geospatial/visualizers/choropleths.py
- `create_choropleth` (line 31): 117 lines (exceeds 40)
- `create_binned_choropleth` (line 149): 174 lines (exceeds 40)
- `create_binned_choropleth` (line 149): complexity score 11 (exceeds 10)
- `get_color` (line 324): 60 lines (exceeds 40)

### ./core/geospatial/visualizers/heatmap.py
- `create_heatmap` (line 34): 86 lines (exceeds 40)
- `render_heatmap` (line 122): 49 lines (exceeds 40)
- `create_threat_heatmap` (line 173): 62 lines (exceeds 40)

### ./core/geospatial/visualizers/markers.py
- `add_markers` (line 32): 120 lines (exceeds 40)
- `add_markers` (line 32): complexity score 14 (exceeds 10)
- `create_marker_clusters` (line 153): 83 lines (exceeds 40)
- `add_boat_markers` (line 237): 64 lines (exceeds 40)

### ./core/geospatial/visualizers/networks.py
- `create_network_graph` (line 32): 289 lines (exceeds 40)
- `create_network_graph` (line 32): complexity score 26 (exceeds 10)

### ./core/gnn/gnn_model.py
- `to_torch_geometric` (line 168): 41 lines (exceeds 40)
- `_extract_task_features` (line 373): 68 lines (exceeds 40)

### ./core/integrations/graph_db/neo4j_connector.py
- `__init__` (line 96): 59 lines (exceeds 40)
- `_connect` (line 160): 77 lines (exceeds 40)
- `session` (line 278): 41 lines (exceeds 40)
- `execute_query` (line 324): 77 lines (exceeds 40)
- `create_nodes` (line 488): 103 lines (exceeds 40)
- `create_relationships` (line 596): 113 lines (exceeds 40)
- `import_dataframe` (line 714): 99 lines (exceeds 40)
- `query_to_dataframe` (line 818): 43 lines (exceeds 40)
- `create_index` (line 866): 73 lines (exceeds 40)
- `create_constraint` (line 944): 71 lines (exceeds 40)
- `distance_query` (line 1046): 69 lines (exceeds 40)
- `shortest_path` (line 1120): 84 lines (exceeds 40)
- `initialize` (line 1258): 57 lines (exceeds 40)

### ./core/integrations/satellite/google_earth_integration.py
- `__init__` (line 104): 57 lines (exceeds 40)
- `_load_styles` (line 166): 91 lines (exceeds 40)
- `_parse_kml_styles` (line 262): 141 lines (exceeds 40)
- `_parse_kml_styles` (line 262): complexity score 17 (exceeds 10)
- `create_kml` (line 408): 46 lines (exceeds 40)
- `add_point` (line 459): 85 lines (exceeds 40)
- `add_linestring` (line 549): 104 lines (exceeds 40)
- `add_linestring` (line 549): complexity score 11 (exceeds 10)
- `add_polygon` (line 658): 128 lines (exceeds 40)
- `add_polygon` (line 658): complexity score 15 (exceeds 10)
- `_apply_style` (line 791): 60 lines (exceeds 40)
- `_apply_style` (line 791): complexity score 11 (exceeds 10)
- `save_kml` (line 856): 68 lines (exceeds 40)
- `load_kml` (line 929): 105 lines (exceeds 40)
- `extract_features` (line 1039): 139 lines (exceeds 40)
- `extract_features` (line 1039): complexity score 14 (exceeds 10)
- `_extract_extended_data` (line 1183): 42 lines (exceeds 40)
- `dataframe_to_kml` (line 1271): 214 lines (exceeds 40)
- `dataframe_to_kml` (line 1271): complexity score 14 (exceeds 10)
- `kml_to_dataframe` (line 1490): 140 lines (exceeds 40)
- `kml_to_dataframe` (line 1490): complexity score 12 (exceeds 10)
- `initialize` (line 1727): 53 lines (exceeds 40)
- `get_capabilities` (line 1807): 41 lines (exceeds 40)

### ./core/interfaces/analyzers.py
- `__init__` (line 23): 46 lines (exceeds 40)

### ./core/mathematics/las_vegas/algorithm.py
- `run` (line 133): 47 lines (exceeds 40)
- `_run_sequential` (line 181): 68 lines (exceeds 40)
- `_run_parallel` (line 250): 142 lines (exceeds 40)
- `_run_parallel` (line 250): complexity score 19 (exceeds 10)
- `worker_func` (line 272): 41 lines (exceeds 40)
- `adaptive_restart` (line 393): 76 lines (exceeds 40)

### ./core/mathematics/monte_carlo/integration.py
- `integrate_uniform` (line 99): 67 lines (exceeds 40)
- `_integrate_uniform_sequential` (line 167): 43 lines (exceeds 40)
- `_integrate_uniform_parallel` (line 211): 88 lines (exceeds 40)
- `integrate_importance` (line 300): 64 lines (exceeds 40)
- `_integrate_importance_sequential` (line 365): 47 lines (exceeds 40)
- `_integrate_importance_parallel` (line 413): 92 lines (exceeds 40)
- `stratified_sampling` (line 506): 88 lines (exceeds 40)
- `_stratified_sampling_sequential` (line 656): 62 lines (exceeds 40)
- `_stratified_sampling_parallel` (line 719): 108 lines (exceeds 40)
- `worker_func` (line 745): 43 lines (exceeds 40)

### ./core/mathematics/monte_carlo/simulation.py
- `plot_histogram` (line 161): 58 lines (exceeds 40)
- `run_simulation` (line 245): 47 lines (exceeds 40)
- `_run_parallel` (line 325): 51 lines (exceeds 40)
- `sensitivity_analysis` (line 377): 52 lines (exceeds 40)
- `plot_sensitivity_analysis` (line 430): 71 lines (exceeds 40)
- `plot_sensitivity_analysis` (line 430): complexity score 14 (exceeds 10)
- `scenario_analysis` (line 503): 46 lines (exceeds 40)

### ./core/mathematics/optimization/genetic_algorithm.py
- `plot_fitness_history` (line 111): 64 lines (exceeds 40)
- `evolve` (line 322): 159 lines (exceeds 40)
- `evolve` (line 322): complexity score 19 (exceeds 10)
- `_evolve_parallel` (line 482): 187 lines (exceeds 40)
- `_evolve_parallel` (line 482): complexity score 21 (exceeds 10)
- `_select_individual` (line 670): 79 lines (exceeds 40)
- `_select_individual` (line 670): complexity score 12 (exceeds 10)

### ./core/mathematics/optimization/particle_swarm.py
- `plot_history` (line 95): 64 lines (exceeds 40)
- `optimize` (line 231): 173 lines (exceeds 40)
- `optimize` (line 231): complexity score 24 (exceeds 10)
- `_optimize_parallel` (line 405): 191 lines (exceeds 40)
- `_optimize_parallel` (line 405): complexity score 18 (exceeds 10)
- `evaluate_particles` (line 443): 46 lines (exceeds 40)
- `_initialize_swarm` (line 597): 48 lines (exceeds 40)
- `_initialize_topology` (line 646): 84 lines (exceeds 40)
- `_initialize_topology` (line 646): complexity score 18 (exceeds 10)
- `_get_neighborhood_best` (line 731): 43 lines (exceeds 40)

### ./core/mathematics/optimization/simulated_annealing.py
- `plot_energy_history` (line 98): 64 lines (exceeds 40)
- `optimize` (line 213): 148 lines (exceeds 40)
- `optimize` (line 213): complexity score 19 (exceeds 10)
- `_optimize_parallel` (line 362): 202 lines (exceeds 40)
- `_optimize_parallel` (line 362): complexity score 20 (exceeds 10)
- `_update_temperature` (line 565): 52 lines (exceeds 40)

### ./core/matroid/base.py
- `optimize_allocation` (line 465): 43 lines (exceeds 40)

### ./core/matroid/spatial_matroid.py
- `find_optimal_coverage` (line 149): 50 lines (exceeds 40)
- `find_optimal_coverage` (line 149): complexity score 11 (exceeds 10)
- `_check_independence` (line 306): 42 lines (exceeds 40)
- `find_temporal_clusters` (line 349): 56 lines (exceeds 40)
- `from_dict` (line 427): 41 lines (exceeds 40)
- `_check_independence` (line 515): 46 lines (exceeds 40)
- `_check_independence` (line 515): complexity score 13 (exceeds 10)

### ./core/mcp_client.py
- `call_llm` (line 154): 79 lines (exceeds 40)
- `_prepare_request` (line 331): 81 lines (exceeds 40)
- `_make_request_with_retries` (line 413): 44 lines (exceeds 40)
- `_extract_content` (line 458): complexity score 14 (exceeds 10)

### ./core/mcp_server.py
- `generate_workflow_results` (line 644): 61 lines (exceeds 40)
- `login_for_access_token` (line 727): 51 lines (exceeds 40)
- `call_llm` (line 863): 138 lines (exceeds 40)
- `call_llm` (line 863): complexity score 14 (exceeds 10)
- `stream_llm` (line 1004): 97 lines (exceeds 40)
- `generate` (line 1035): 61 lines (exceeds 40)
- `execute_tool` (line 1341): 45 lines (exceeds 40)
- `landing_page` (line 1826): 111 lines (exceeds 40)
- `_add_example_data` (line 1959): 147 lines (exceeds 40)

### ./core/media_analysis/analyzer.py
- `extract_metadata` (line 149): 85 lines (exceeds 40)
- `extract_metadata` (line 149): complexity score 17 (exceeds 10)
- `analyze_image` (line 293): 55 lines (exceeds 40)
- `_extract_dominant_colors` (line 349): 53 lines (exceeds 40)
- `analyze_video` (line 477): 66 lines (exceeds 40)
- `analyze_url_media` (line 544): 81 lines (exceeds 40)
- `analyze_url_media` (line 544): complexity score 11 (exceeds 10)

### ./core/periodic_table/element.py
- `from_dict` (line 286): 45 lines (exceeds 40)

### ./core/periodic_table/registry.py
- `_initialize_schema` (line 93): 95 lines (exceeds 40)
- `add_element` (line 190): 44 lines (exceeds 40)
- `get_element` (line 235): 56 lines (exceeds 40)
- `add_relationship` (line 752): 46 lines (exceeds 40)
- `load_from_file` (line 919): 63 lines (exceeds 40)

### ./core/periodic_table/relationships.py
- `get_inverse_type` (line 181): 47 lines (exceeds 40)
- `add_relationship` (line 278): 45 lines (exceeds 40)
- `remove_relationship` (line 324): 41 lines (exceeds 40)
- `get_path` (line 465): 42 lines (exceeds 40)

### ./core/periodic_table/simple_relationships.py
- `add_relationship` (line 127): 62 lines (exceeds 40)
- `get_relationships` (line 220): 51 lines (exceeds 40)
- `get_relationships` (line 220): complexity score 16 (exceeds 10)

### ./core/periodic_table/table.py
- `get_node_card` (line 112): 97 lines (exceeds 40)
- `get_table_data` (line 272): 60 lines (exceeds 40)
- `create_plotly_table` (line 333): 123 lines (exceeds 40)
- `create_network_graph` (line 457): 159 lines (exceeds 40)
- `create_network_graph` (line 457): complexity score 16 (exceeds 10)
- `_force_atlas2_layout` (line 617): 117 lines (exceeds 40)
- `_force_atlas2_layout` (line 617): complexity score 21 (exceeds 10)
- `create_element_detail_plot` (line 755): 107 lines (exceeds 40)

### ./core/periodic_table/task_loader.py
- `load_task_from_json` (line 135): 60 lines (exceeds 40)
- `create_demo_tasks` (line 257): 55 lines (exceeds 40)

### ./core/periodic_table/task_registry.py
- `_initialize_schema` (line 103): 57 lines (exceeds 40)
- `add_task` (line 185): 45 lines (exceeds 40)
- `add_relationship` (line 417): 48 lines (exceeds 40)

### ./core/plugin_loader.py
- `initialize` (line 117): 89 lines (exceeds 40)
- `activate_plugin` (line 207): 83 lines (exceeds 40)
- `get_plugins_by_capability` (line 349): 79 lines (exceeds 40)
- `_has_capability` (line 429): 64 lines (exceeds 40)
- `list_discovered_plugins` (line 494): 48 lines (exceeds 40)
- `deactivate_plugin` (line 543): 63 lines (exceeds 40)

### ./core/plugins/plugin_base.py
- `discover_plugins` (line 354): 134 lines (exceeds 40)
- `activate_plugin` (line 493): 101 lines (exceeds 40)
- `deactivate_plugin` (line 599): 72 lines (exceeds 40)
- `get_plugins_by_type` (line 708): 48 lines (exceeds 40)

### ./core/registry.py
- `register` (line 151): 44 lines (exceeds 40)
- `unregister` (line 196): 51 lines (exceeds 40)
- `get_by_tag` (line 525): 53 lines (exceeds 40)
- `get_by_category` (line 579): 53 lines (exceeds 40)
- `search` (line 633): 65 lines (exceeds 40)
- `get_service` (line 813): 71 lines (exceeds 40)
- `remove_service` (line 914): 65 lines (exceeds 40)
- `initialize` (line 1007): 42 lines (exceeds 40)
- `list_services` (line 1050): 100 lines (exceeds 40)
- `unregister_feature` (line 1237): 42 lines (exceeds 40)
- `search_features` (line 1422): 61 lines (exceeds 40)
- `initialize` (line 1573): 45 lines (exceeds 40)
- `list_features` (line 1619): 68 lines (exceeds 40)

### ./core/security/kali_integrator.py
- `_load_tools_inventory` (line 132): 68 lines (exceeds 40)
- `_build_tools_inventory` (line 201): 60 lines (exceeds 40)
- `_determine_category` (line 291): 66 lines (exceeds 40)
- `_build_category_map` (line 444): 43 lines (exceeds 40)
- `get_tools` (line 488): 77 lines (exceeds 40)
- `get_tool_help` (line 600): 65 lines (exceeds 40)
- `update_inventory` (line 698): 43 lines (exceeds 40)
- `execute_command` (line 742): 91 lines (exceeds 40)
- `parse_command_output` (line 834): 48 lines (exceeds 40)

### ./core/storyteller/real_time_tracker.py
- `__init__` (line 58): 49 lines (exceeds 40)
- `create_live_timeline_visualization` (line 108): 83 lines (exceeds 40)
- `create_live_timeline_visualization` (line 108): complexity score 11 (exceeds 10)
- `_create_elements_dataframe` (line 192): 45 lines (exceeds 40)
- `_create_timeline_visualization` (line 238): 175 lines (exceeds 40)
- `create_workflow_activity_feed` (line 442): 83 lines (exceeds 40)
- `create_workflow_metrics_dashboard` (line 526): 79 lines (exceeds 40)
- `create_workflow_metrics_dashboard` (line 526): complexity score 20 (exceeds 10)

### ./core/storyteller/story_elements.py
- `from_dict` (line 317): 44 lines (exceeds 40)

### ./core/storyteller/workflow_progress.py
- `__init__` (line 76): 46 lines (exceeds 40)
- `save_timeline` (line 196): 43 lines (exceeds 40)
- `list_timelines` (line 244): 57 lines (exceeds 40)
- `display_timeline_visualization` (line 411): 52 lines (exceeds 40)
- `_create_timeline_figure` (line 468): 285 lines (exceeds 40)
- `_create_timeline_figure` (line 468): complexity score 13 (exceeds 10)
- `_display_element_details` (line 758): 112 lines (exceeds 40)
- `_display_element_details` (line 758): complexity score 14 (exceeds 10)
- `display_timeline_summary` (line 875): 149 lines (exceeds 40)
- `display_timeline_summary` (line 875): complexity score 14 (exceeds 10)
- `create_timeline_editor` (line 1029): 197 lines (exceeds 40)
- `create_timeline_editor` (line 1029): complexity score 23 (exceeds 10)

### ./core/triptych/client.py
- `create_sch` (line 144): 42 lines (exceeds 40)
- `create_identity` (line 187): 41 lines (exceeds 40)

### ./core/web_intelligence/media_outlets_processor.py
- `_initialize_database` (line 167): 113 lines (exceeds 40)
- `import_outlets_from_excel` (line 281): 102 lines (exceeds 40)
- `import_outlets_from_excel` (line 281): complexity score 21 (exceeds 10)
- `save_outlet` (line 384): 77 lines (exceeds 40)
- `get_outlet` (line 462): 69 lines (exceeds 40)
- `get_all_outlets` (line 532): 41 lines (exceeds 40)
- `search_outlets` (line 574): 43 lines (exceeds 40)
- `add_monitoring_keyword` (line 618): 42 lines (exceeds 40)
- `get_monitoring_keywords` (line 661): 64 lines (exceeds 40)
- `extract_content_from_url` (line 726): 171 lines (exceeds 40)
- `extract_content_from_url` (line 726): complexity score 34 (exceeds 10)
- `scan_content_for_keywords` (line 946): 89 lines (exceeds 40)
- `scan_content_for_keywords` (line 946): complexity score 11 (exceeds 10)
- `_save_content_match` (line 1064): 45 lines (exceeds 40)
- `get_content_matches` (line 1110): 88 lines (exceeds 40)
- `discover_related_outlets` (line 1199): 79 lines (exceeds 40)
- `batch_monitor_outlets` (line 1279): 71 lines (exceeds 40)
- `export_content_matches` (line 1379): 98 lines (exceeds 40)

### ./core/web_intelligence/news_scraper.py
- `_load_news_sources` (line 146): 75 lines (exceeds 40)
- `_load_news_sources` (line 146): complexity score 18 (exceeds 10)
- `extract_article_content` (line 292): 174 lines (exceeds 40)
- `extract_article_content` (line 292): complexity score 27 (exceeds 10)
- `discover_articles` (line 498): 64 lines (exceeds 40)
- `_is_likely_article` (line 563): 44 lines (exceeds 40)
- `analyze_news_source` (line 642): 69 lines (exceeds 40)

### ./data/sample_threat_intel.py
- `generate_sample_flow_data` (line 13): 301 lines (exceeds 40)
- `generate_sample_iocs` (line 316): 133 lines (exceeds 40)
- `generate_sample_bulletins` (line 451): 100 lines (exceeds 40)

### ./data_sources/airspace_api_source.py
- `get_flights` (line 168): 78 lines (exceeds 40)
- `get_flights` (line 168): complexity score 17 (exceeds 10)
- `get_notams` (line 250): 84 lines (exceeds 40)
- `get_notams` (line 250): complexity score 18 (exceeds 10)
- `get_airspace_info` (line 338): 76 lines (exceeds 40)
- `get_airspace_info` (line 338): complexity score 15 (exceeds 10)
- `get_aviation_weather` (line 418): 80 lines (exceeds 40)
- `get_aviation_weather` (line 418): complexity score 17 (exceeds 10)
- `_get_opensky_flights` (line 504): 80 lines (exceeds 40)
- `_get_simulated_flights` (line 718): 98 lines (exceeds 40)
- `_get_simulated_notams` (line 820): 81 lines (exceeds 40)
- `_get_simulated_airspace` (line 905): 68 lines (exceeds 40)
- `_get_simulated_weather` (line 977): 128 lines (exceeds 40)

### ./data_sources/data_source_integrator.py
- `add_source` (line 83): 41 lines (exceeds 40)
- `get_data` (line 147): 59 lines (exceeds 40)
- `_update_source_health` (line 252): 50 lines (exceeds 40)
- `_extract_content_with_bs4` (line 550): 84 lines (exceeds 40)
- `_extract_content_with_bs4` (line 550): complexity score 14 (exceeds 10)
- `_parse_date` (line 663): 53 lines (exceeds 40)

### ./data_sources/excel_osint_source.py
- `_load_data` (line 46): 95 lines (exceeds 40)
- `_load_data` (line 46): complexity score 18 (exceeds 10)
- `get_data` (line 142): 89 lines (exceeds 40)
- `get_data` (line 142): complexity score 22 (exceeds 10)

### ./data_sources/incident_reporter.py
- `create_incident` (line 266): 62 lines (exceeds 40)
- `get_incidents` (line 341): 51 lines (exceeds 40)
- `get_incidents` (line 341): complexity score 17 (exceeds 10)
- `update_incident` (line 424): 52 lines (exceeds 40)
- `get_incident_trend` (line 539): 64 lines (exceeds 40)
- `generate_report` (line 604): 51 lines (exceeds 40)
- `_generate_summary_report` (line 656): 55 lines (exceeds 40)
- `_generate_detailed_report` (line 712): 42 lines (exceeds 40)
- `_generate_executive_report` (line 755): 77 lines (exceeds 40)
- `_generate_executive_report` (line 755): complexity score 15 (exceeds 10)
- `export_incidents` (line 866): 41 lines (exceeds 40)

### ./data_sources/multi_model_processor.py
- `_extract_entities` (line 130): 109 lines (exceeds 40)
- `_extract_keywords` (line 240): 105 lines (exceeds 40)
- `_classify_incident` (line 346): 123 lines (exceeds 40)
- `_analyze_cyber_threat` (line 470): 122 lines (exceeds 40)
- `_get_content_summary` (line 624): 102 lines (exceeds 40)
- `convert_analysis_to_osint_format` (line 752): 97 lines (exceeds 40)
- `convert_analysis_to_osint_format` (line 752): complexity score 25 (exceeds 10)

### ./data_sources/network_analysis_core.py
- `fit` (line 359): 113 lines (exceeds 40)
- `fit` (line 359): complexity score 22 (exceeds 10)
- `predict_likelihood` (line 479): 41 lines (exceeds 40)
- `most_likely_paths` (line 521): 51 lines (exceeds 40)
- `fit` (line 587): 46 lines (exceeds 40)
- `_extract_sequences` (line 634): 73 lines (exceeds 40)
- `_extract_sequences` (line 634): complexity score 16 (exceeds 10)
- `predict_next_locations` (line 708): 47 lines (exceeds 40)
- `predict_routes` (line 849): 93 lines (exceeds 40)
- `predict_routes` (line 849): complexity score 18 (exceeds 10)
- `load_crime_data` (line 1063): 123 lines (exceeds 40)
- `load_crime_data` (line 1063): complexity score 28 (exceeds 10)
- `_extract_location_id` (line 1187): complexity score 12 (exceeds 10)
- `_extract_location_attributes` (line 1209): complexity score 11 (exceeds 10)
- `_analyze_temporal_patterns` (line 1252): 45 lines (exceeds 40)
- `analyze_trafficking_routes` (line 1298): 91 lines (exceeds 40)
- `analyze_trafficking_routes` (line 1298): complexity score 18 (exceeds 10)
- `detect_criminal_communities` (line 1431): 57 lines (exceeds 40)
- `predict_future_hotspots` (line 1489): 81 lines (exceeds 40)
- `predict_future_hotspots` (line 1489): complexity score 11 (exceeds 10)
- `calculate_risk_scores` (line 1571): 49 lines (exceeds 40)
- `generate_intelligence_report` (line 1621): 55 lines (exceeds 40)
- `load_shipping_data` (line 1687): 172 lines (exceeds 40)
- `load_shipping_data` (line 1687): complexity score 37 (exceeds 10)
- `analyze_shipping_routes` (line 1892): 131 lines (exceeds 40)
- `analyze_shipping_routes` (line 1892): complexity score 19 (exceeds 10)
- `optimize_shipping_network` (line 2024): 251 lines (exceeds 40)
- `optimize_shipping_network` (line 2024): complexity score 36 (exceeds 10)
- `predict_shipping_patterns` (line 2292): 222 lines (exceeds 40)
- `predict_shipping_patterns` (line 2292): complexity score 35 (exceeds 10)
- `generate_shipping_report` (line 2515): 50 lines (exceeds 40)

### ./data_sources/news_monitor.py
- `__init__` (line 40): 55 lines (exceeds 40)
- `initialize_from_excel` (line 96): 50 lines (exceeds 40)
- `initialize_from_excel` (line 96): complexity score 13 (exceeds 10)
- `_extract_incident_details` (line 257): 48 lines (exceeds 40)
- `parse_cyber_threat_indicators` (line 382): 49 lines (exceeds 40)

### ./data_sources/osint_analyzer.py
- `analyze_text` (line 55): 83 lines (exceeds 40)
- `analyze_text` (line 55): complexity score 15 (exceeds 10)
- `analyze_dataframe` (line 139): 74 lines (exceeds 40)
- `analyze_dataframe` (line 139): complexity score 14 (exceeds 10)
- `generate_insights_report` (line 214): 81 lines (exceeds 40)
- `generate_insights_report` (line 214): complexity score 14 (exceeds 10)

### ./data_sources/osint_investigation.py
- `_initialize_plugins` (line 63): 55 lines (exceeds 40)
- `investigate` (line 119): 57 lines (exceeds 40)
- `get_investigation_summary` (line 207): 43 lines (exceeds 40)
- `_run_investigation` (line 251): 57 lines (exceeds 40)

### ./data_sources/plugins/news_api_source.py
- `get_data` (line 47): 73 lines (exceeds 40)
- `_articles_to_dataframe` (line 214): 60 lines (exceeds 40)

### ./data_sources/plugins/social_monitoring_source.py
- `get_data` (line 61): 45 lines (exceeds 40)
- `configure` (line 139): 42 lines (exceeds 40)
- `configure` (line 139): complexity score 13 (exceeds 10)
- `test_connection` (line 182): 61 lines (exceeds 40)
- `_get_twitter_data` (line 244): 115 lines (exceeds 40)
- `_get_reddit_data` (line 360): 98 lines (exceeds 40)

### ./data_sources/shodan_integration.py
- `search_location` (line 45): 52 lines (exceeds 40)
- `get_host_details` (line 98): 47 lines (exceeds 40)
- `create_shodan_visualization` (line 188): 120 lines (exceeds 40)
- `create_shodan_visualization` (line 188): complexity score 14 (exceeds 10)

### ./data_sources/target_analyzer.py
- `analyze_targets_at_risk` (line 198): 131 lines (exceeds 40)
- `analyze_targets_at_risk` (line 198): complexity score 17 (exceeds 10)
- `_analyze_geographic_patterns` (line 366): 251 lines (exceeds 40)
- `_analyze_geographic_patterns` (line 366): complexity score 16 (exceeds 10)
- `_find_targets_near_point` (line 618): 56 lines (exceeds 40)
- `check_geofences` (line 675): 108 lines (exceeds 40)
- `check_geofences` (line 675): complexity score 14 (exceeds 10)
- `identify_latent_threats` (line 784): 330 lines (exceeds 40)
- `identify_latent_threats` (line 784): complexity score 62 (exceeds 10)
- `_collect_all_targets_in_area` (line 1115): 52 lines (exceeds 40)
- `_is_approximately_on_line` (line 1168): 65 lines (exceeds 40)
- `generate_target_analysis_report` (line 1234): 54 lines (exceeds 40)
- `export_target_database` (line 1289): 58 lines (exceeds 40)
- `import_target_database` (line 1348): 112 lines (exceeds 40)
- `import_target_database` (line 1348): complexity score 13 (exceeds 10)

### ./data_sources/traffic_camera_source.py
- `get_traffic_cameras` (line 133): 80 lines (exceeds 40)
- `get_traffic_cameras` (line 133): complexity score 20 (exceeds 10)
- `get_camera_image` (line 217): 64 lines (exceeds 40)
- `get_camera_image` (line 217): complexity score 11 (exceeds 10)
- `_get_nyc_cameras` (line 319): 41 lines (exceeds 40)
- `_get_michigan_cameras` (line 364): 41 lines (exceeds 40)
- `_get_california_cameras` (line 409): 51 lines (exceeds 40)
- `_get_511ny_cameras` (line 464): 46 lines (exceeds 40)
- `_get_nyc_camera_image` (line 538): 41 lines (exceeds 40)
- `_get_michigan_camera_image` (line 583): 41 lines (exceeds 40)
- `_get_simulated_cameras` (line 676): 66 lines (exceeds 40)
- `search_cameras` (line 788): 47 lines (exceeds 40)
- `get_cameras_by_coordinates` (line 839): 49 lines (exceeds 40)

### ./data_sources/web_scraper.py
- `__init__` (line 31): 52 lines (exceeds 40)
- `extract_links_from_html` (line 118): 51 lines (exceeds 40)
- `get_website_text_content` (line 170): 68 lines (exceeds 40)
- `get_data` (line 247): 101 lines (exceeds 40)
- `get_data` (line 247): complexity score 12 (exceeds 10)
- `get_keywords_for_location` (line 353): complexity score 11 (exceeds 10)
- `configure` (line 380): complexity score 11 (exceeds 10)

### ./main.py
- `apply_custom_css` (line 39): 147 lines (exceeds 40)
- `create_threat_map` (line 249): 84 lines (exceeds 40)
- `display_incident_timeline` (line 334): 130 lines (exceeds 40)
- `create_threat_categories_chart` (line 465): 55 lines (exceeds 40)
- `create_attack_trend_chart` (line 521): 127 lines (exceeds 40)
- `display_threat_analysis` (line 649): 87 lines (exceeds 40)

### ./main_dashboard.py
- `render_sidebar` (line 226): 99 lines (exceeds 40)
- `render_sidebar` (line 226): complexity score 12 (exceeds 10)
- `render_dashboard` (line 327): 282 lines (exceeds 40)
- `render_osint_view` (line 611): 119 lines (exceeds 40)
- `render_incidents_view` (line 732): 211 lines (exceeds 40)
- `render_data_sources_view` (line 947): 320 lines (exceeds 40)
- `render_tools_view` (line 1269): 333 lines (exceeds 40)
- `render_tools_view` (line 1269): complexity score 21 (exceeds 10)
- `render_reports_view` (line 1604): 295 lines (exceeds 40)
- `render_reports_view` (line 1604): complexity score 11 (exceeds 10)
- `render_opsec_view` (line 1901): 288 lines (exceeds 40)

### ./pages/advanced_osint_suite.py
- `configure_page` (line 50): 58 lines (exceeds 40)
- `render_web_intelligence_section` (line 209): 53 lines (exceeds 40)
- `display_article_results` (line 267): 73 lines (exceeds 40)
- `display_source_analysis` (line 345): 47 lines (exceeds 40)
- `render_media_analysis_section` (line 397): 128 lines (exceeds 40)
- `render_media_analysis_section` (line 397): complexity score 12 (exceeds 10)
- `display_media_analysis_results` (line 530): 73 lines (exceeds 40)
- `display_media_analysis_results` (line 530): complexity score 11 (exceeds 10)
- `display_image_analysis_results` (line 608): 62 lines (exceeds 40)
- `display_image_analysis_results` (line 608): complexity score 12 (exceeds 10)
- `display_video_analysis_results` (line 675): 80 lines (exceeds 40)
- `render_darkweb_intelligence_section` (line 760): 167 lines (exceeds 40)
- `render_darkweb_intelligence_section` (line 760): complexity score 16 (exceeds 10)

### ./pages/adversary_task_viewer.py
- `render_task_card` (line 330): 281 lines (exceeds 40)
- `render_task_card` (line 330): complexity score 19 (exceeds 10)
- `render_property_comparison` (line 613): 43 lines (exceeds 40)
- `render_relationship_graph` (line 658): 79 lines (exceeds 40)
- `render_relationship_graph` (line 658): complexity score 11 (exceeds 10)
- `main` (line 739): 361 lines (exceeds 40)
- `main` (line 739): complexity score 39 (exceeds 10)

### ./pages/cyberwarfare_tools.py
- `initialize_components` (line 180): 69 lines (exceeds 40)
- `refresh_tools_list` (line 254): 41 lines (exceeds 40)
- `filter_tools` (line 300): 69 lines (exceeds 40)
- `execute_tool_command` (line 374): 72 lines (exceeds 40)
- `render_header` (line 451): 55 lines (exceeds 40)
- `render_sidebar` (line 511): 116 lines (exceeds 40)
- `render_tools_explorer` (line 632): 151 lines (exceeds 40)
- `render_command_center` (line 788): 216 lines (exceeds 40)
- `render_command_center` (line 788): complexity score 12 (exceeds 10)
- `render_tool_scanner` (line 1009): 326 lines (exceeds 40)
- `render_tool_scanner` (line 1009): complexity score 21 (exceeds 10)
- `render_execution_history` (line 1340): 112 lines (exceeds 40)
- `render_page` (line 1457): 50 lines (exceeds 40)

### ./pages/database_integration_demo.py
- `entity_demo` (line 95): 110 lines (exceeds 40)
- `entity_demo` (line 95): complexity score 14 (exceeds 10)
- `main` (line 209): 44 lines (exceeds 40)

### ./pages/drone_operations.py
- `render_drone_operations_dashboard` (line 91): 49 lines (exceeds 40)
- `render_squadron_monitor` (line 144): 145 lines (exceeds 40)
- `render_squadron_monitor` (line 144): complexity score 21 (exceeds 10)
- `render_telemetry_feed` (line 293): 141 lines (exceeds 40)
- `render_telemetry_feed` (line 293): complexity score 17 (exceeds 10)
- `render_mission_planning` (line 438): 426 lines (exceeds 40)
- `render_mission_planning` (line 438): complexity score 56 (exceeds 10)
- `render_airspace_monitoring` (line 903): 94 lines (exceeds 40)

### ./pages/drone_operations/components/airspace_monitor.py
- `render_airspace_monitoring` (line 35): 94 lines (exceeds 40)

### ./pages/drone_operations/components/mission_planning.py
- `render_mission_config_panel` (line 42): 81 lines (exceeds 40)
- `assign_mission_to_drones` (line 162): 73 lines (exceeds 40)
- `assign_mission_to_drones` (line 162): complexity score 12 (exceeds 10)
- `render_mission_map` (line 236): 107 lines (exceeds 40)
- `render_mission_map` (line 236): complexity score 27 (exceeds 10)
- `render_mission_planning` (line 344): 44 lines (exceeds 40)

### ./pages/drone_operations/components/squadron_monitor.py
- `render_squadron_monitor` (line 36): 150 lines (exceeds 40)
- `render_squadron_monitor` (line 36): complexity score 21 (exceeds 10)

### ./pages/drone_operations/components/telemetry_feed.py
- `render_telemetry_feed` (line 32): 141 lines (exceeds 40)
- `render_telemetry_feed` (line 32): complexity score 17 (exceeds 10)

### ./pages/drone_operations/dashboard.py
- `render_drone_operations_dashboard` (line 40): 49 lines (exceeds 40)

### ./pages/drone_operations/utils/mission_patterns.py
- `generate_search_grid_pattern` (line 33): 51 lines (exceeds 40)
- `add_search_grid_to_map` (line 85): 48 lines (exceeds 40)
- `add_direct_attack_to_map` (line 166): 48 lines (exceeds 40)
- `add_orbit_to_map` (line 252): 41 lines (exceeds 40)
- `generate_reconnaissance_path` (line 294): 49 lines (exceeds 40)

### ./pages/enhanced_workflow_storyteller.py
- `configure_page` (line 46): 58 lines (exceeds 40)
- `create_enhanced_demo_timeline` (line 108): 239 lines (exceeds 40)
- `render_enhanced_page` (line 351): 131 lines (exceeds 40)

### ./pages/geospatial_heatmap.py
- `render_page` (line 53): 113 lines (exceeds 40)

### ./pages/geospatial_intelligence.py
- `initialize_plugins` (line 242): 197 lines (exceeds 40)
- `prepare_geospatial_data` (line 488): 103 lines (exceeds 40)
- `prepare_geospatial_data` (line 488): complexity score 11 (exceeds 10)
- `show_geospatial_analysis` (line 596): 2771 lines (exceeds 40)
- `show_geospatial_analysis` (line 596): complexity score 110 (exceeds 10)

### ./pages/kali_tools_explorer.py
- `display_tool_details` (line 82): 46 lines (exceeds 40)
- `create_category_distribution` (line 188): 45 lines (exceeds 40)
- `main` (line 235): 177 lines (exceeds 40)
- `main` (line 235): complexity score 15 (exceeds 10)

### ./pages/media_outlets_monitoring.py
- `configure_page` (line 55): 61 lines (exceeds 40)
- `render_dashboard` (line 175): 111 lines (exceeds 40)
- `render_outlets_management` (line 291): 420 lines (exceeds 40)
- `render_outlets_management` (line 291): complexity score 47 (exceeds 10)
- `render_keywords_monitoring` (line 716): 490 lines (exceeds 40)
- `render_keywords_monitoring` (line 716): complexity score 62 (exceeds 10)
- `render_batch_monitoring` (line 1211): 154 lines (exceeds 40)
- `render_batch_monitoring` (line 1211): complexity score 15 (exceeds 10)

### ./pages/node_card_viewer.py
- `initialize_registry` (line 219): 145 lines (exceeds 40)
- `render_node_card` (line 390): 100 lines (exceeds 40)
- `main` (line 528): 324 lines (exceeds 40)
- `main` (line 528): complexity score 41 (exceeds 10)

### ./pages/optimization_demo.py
- `page_config` (line 92): 50 lines (exceeds 40)
- `get_optimization_problems` (line 166): 41 lines (exceeds 40)
- `visualize_2d_function` (line 253): 121 lines (exceeds 40)
- `simulated_annealing_page` (line 383): 284 lines (exceeds 40)
- `genetic_algorithm_page` (line 676): 326 lines (exceeds 40)
- `genetic_algorithm_page` (line 676): complexity score 14 (exceeds 10)
- `particle_swarm_page` (line 1011): 273 lines (exceeds 40)
- `monte_carlo_page` (line 1293): 865 lines (exceeds 40)
- `monte_carlo_page` (line 1293): complexity score 33 (exceeds 10)
- `portfolio_simulation` (line 1558): 42 lines (exceeds 40)
- `las_vegas_page` (line 2167): 415 lines (exceeds 40)
- `las_vegas_page` (line 2167): complexity score 20 (exceeds 10)
- `main` (line 2605): 49 lines (exceeds 40)

### ./pages/periodic_table_demo.py
- `initialize_registry` (line 119): 146 lines (exceeds 40)
- `main` (line 291): 346 lines (exceeds 40)
- `main` (line 291): complexity score 29 (exceeds 10)
- `create_plotly_table` (line 317): 62 lines (exceeds 40)

### ./pages/simple_node_viewer.py
- `load_sample_nodes` (line 103): 61 lines (exceeds 40)
- `render_node_card` (line 165): 91 lines (exceeds 40)
- `main` (line 257): 137 lines (exceeds 40)
- `main` (line 257): complexity score 22 (exceeds 10)

### ./pages/threat_intel.py
- `main` (line 31): 206 lines (exceeds 40)
- `main` (line 31): complexity score 22 (exceeds 10)

### ./pages/threat_intelligence.py
- `show_api_key_input` (line 169): 51 lines (exceeds 40)
- `load_sample_flow_data` (line 222): 68 lines (exceeds 40)
- `load_and_filter_data` (line 292): 82 lines (exceeds 40)
- `render_ioc_table` (line 384): 80 lines (exceeds 40)
- `render_threat_bulletins` (line 466): 44 lines (exceeds 40)

### ./pages/url_health.py
- `check_url_health` (line 79): 47 lines (exceeds 40)
- `main` (line 251): 384 lines (exceeds 40)
- `main` (line 251): complexity score 27 (exceeds 10)

### ./pages/url_intelligence.py
- `render_url_context_tab` (line 79): 76 lines (exceeds 40)
- `render_geospatial_tab` (line 156): 63 lines (exceeds 40)
- `render_network_tab` (line 220): 87 lines (exceeds 40)
- `render_historical_tab` (line 308): 42 lines (exceeds 40)

### ./pages/workflow_storyteller.py
- `create_demo_timeline` (line 91): 233 lines (exceeds 40)
- `render_page` (line 329): 75 lines (exceeds 40)

### ./processors/geo_resolver.py
- `process_single` (line 130): 45 lines (exceeds 40)
- `_process_url_data` (line 176): 74 lines (exceeds 40)
- `_process_generic_data` (line 251): 76 lines (exceeds 40)
- `_process_generic_data` (line 251): complexity score 11 (exceeds 10)
- `_extract_locations` (line 328): 67 lines (exceeds 40)
- `_geocode` (line 424): 43 lines (exceeds 40)
- `_detect_regions` (line 468): 58 lines (exceeds 40)
- `reverse_geocode` (line 556): 43 lines (exceeds 40)

### ./processors/osint_data_processor.py
- `process_single` (line 112): 48 lines (exceeds 40)
- `_process_dataset` (line 161): 77 lines (exceeds 40)
- `_process_url_with_osint` (line 239): 87 lines (exceeds 40)
- `_process_generic_data` (line 327): 77 lines (exceeds 40)
- `_extract_entities_from_dataframe` (line 405): 65 lines (exceeds 40)
- `_extract_entities_from_dataframe` (line 405): complexity score 12 (exceeds 10)
- `create_entity_from_row` (line 419): 41 lines (exceeds 40)
- `create_entity_from_row` (line 419): complexity score 11 (exceeds 10)
- `_extract_entities_from_text` (line 471): 113 lines (exceeds 40)
- `_generate_connections` (line 585): 84 lines (exceeds 40)
- `_generate_connections` (line 585): complexity score 11 (exceeds 10)
- `_match_entities` (line 670): 74 lines (exceeds 40)
- `_match_entities` (line 670): complexity score 16 (exceeds 10)
- `entity_similarity` (line 685): 46 lines (exceeds 40)
- `entity_similarity` (line 685): complexity score 13 (exceeds 10)
- `get_entity_network` (line 758): 73 lines (exceeds 40)
- `analyze_osint_data` (line 832): 157 lines (exceeds 40)
- `analyze_osint_data` (line 832): complexity score 26 (exceeds 10)

### ./processors/url_context_processor.py
- `process_single` (line 110): 62 lines (exceeds 40)
- `_process_url_data` (line 173): 59 lines (exceeds 40)
- `_generate_text_summary` (line 233): 53 lines (exceeds 40)
- `_generate_text_summary` (line 233): complexity score 11 (exceeds 10)
- `_extract_keywords` (line 287): 43 lines (exceeds 40)
- `_analyze_domain` (line 331): 59 lines (exceeds 40)
- `_analyze_domain` (line 331): complexity score 12 (exceeds 10)
- `_analyze_content` (line 391): 55 lines (exceeds 40)

### ./refactor_analyzer.py
- `analyze_file` (line 56): 56 lines (exceeds 40)
- `scan_directory` (line 113): complexity score 11 (exceeds 10)
- `generate_markdown_report` (line 171): 81 lines (exceeds 40)

### ./scripts/analyze_excel.py
- `analyze_excel_file` (line 34): 74 lines (exceeds 40)

### ./scripts/import_outlets_from_excel.py
- `process_excel_file` (line 51): 65 lines (exceeds 40)
- `configure_monitoring_keywords` (line 121): 65 lines (exceeds 40)
- `discover_related_outlets` (line 191): 41 lines (exceeds 40)
- `main` (line 237): 75 lines (exceeds 40)

### ./utils.py
- `get_theme_settings` (line 49): 46 lines (exceeds 40)
- `create_map` (line 96): 87 lines (exceeds 40)

### ./utils/ctas_headers.py
- `generate_ctas_header` (line 28): 62 lines (exceeds 40)
- `apply_header_to_file` (line 92): 46 lines (exceeds 40)

### ./utils/kali_integrator.py
- `_create_default_tools` (line 240): 92 lines (exceeds 40)
- `_create_default_chains` (line 333): 68 lines (exceeds 40)
- `get_execution_history` (line 475): 47 lines (exceeds 40)
- `execute_tool` (line 589): 69 lines (exceeds 40)
- `run_chain` (line 659): 92 lines (exceeds 40)
- `_build_command` (line 842): 59 lines (exceeds 40)
- `_build_command` (line 842): complexity score 22 (exceeds 10)
- `_generate_simulated_output` (line 902): 128 lines (exceeds 40)

### ./utils/kml_handler.py
- `kml_to_dataframe` (line 23): 51 lines (exceeds 40)
- `dataframe_to_kml` (line 75): 100 lines (exceeds 40)

### ./utils/opsec_manager.py
- `__init__` (line 43): 44 lines (exceeds 40)
- `create_profile` (line 255): 51 lines (exceeds 40)
- `update_profile` (line 307): 67 lines (exceeds 40)
- `update_profile` (line 307): complexity score 14 (exceeds 10)

### ./utils/security_tools_utils.py
- `execute_command_async` (line 45): 65 lines (exceeds 40)
- `execute_command` (line 111): 56 lines (exceeds 40)
- `execute_docker_command` (line 168): 41 lines (exceeds 40)
- `execute_remote_command` (line 210): 45 lines (exceeds 40)
- `download_kali_tool_image` (line 340): 46 lines (exceeds 40)
- `format_command_output` (line 387): 66 lines (exceeds 40)
- `build_command` (line 489): 55 lines (exceeds 40)

### ./utils/url_health_monitor.py
- `check_url_health` (line 71): 71 lines (exceeds 40)
- `create_availability_chart` (line 315): 64 lines (exceeds 40)

### ./visualization/advanced_charts.py
- `create_activity_comparison_chart` (line 25): 54 lines (exceeds 40)
- `create_statistical_summary_chart` (line 81): 77 lines (exceeds 40)
- `create_trend_analysis_chart` (line 160): 122 lines (exceeds 40)

### ./visualization/analytics/ai_gis_integration.py
- `analyze_terrain` (line 192): 45 lines (exceeds 40)
- `detect_patterns` (line 238): 78 lines (exceeds 40)
- `detect_patterns` (line 238): complexity score 15 (exceeds 10)
- `analyze_routes` (line 317): 63 lines (exceeds 40)
- `predict_activity` (line 381): 68 lines (exceeds 40)
- `predict_activity` (line 381): complexity score 11 (exceeds 10)
- `analyze_image` (line 450): 87 lines (exceeds 40)
- `calculate_mathematical_terrain` (line 538): 54 lines (exceeds 40)
- `gis_to_graph` (line 593): 81 lines (exceeds 40)
- `gis_to_graph` (line 593): complexity score 21 (exceeds 10)
- `analyze_graph` (line 675): 61 lines (exceeds 40)
- `export_graph_to_cytoscape` (line 737): 74 lines (exceeds 40)
- `export_to_google_earth` (line 812): 86 lines (exceeds 40)
- `export_to_google_earth` (line 812): complexity score 12 (exceeds 10)
- `_process_with_model` (line 930): 45 lines (exceeds 40)

### ./visualization/gis/geo_processor.py
- `buffer_points` (line 191): 46 lines (exceeds 40)
- `create_hexagons` (line 238): 68 lines (exceeds 40)
- `extract_coordinates` (line 392): 51 lines (exceeds 40)
- `calculate_isochrones` (line 470): 118 lines (exceeds 40)
- `detect_hotspots` (line 589): 182 lines (exceeds 40)
- `detect_hotspots` (line 589): complexity score 14 (exceeds 10)

### ./visualization/gis/geojson_utils.py
- `filter_geojson` (line 136): 74 lines (exceeds 40)
- `filter_geojson` (line 136): complexity score 16 (exceeds 10)
- `add_property` (line 273): 41 lines (exceeds 40)
- `create_buffer` (line 315): 47 lines (exceeds 40)
- `create_grid` (line 363): 128 lines (exceeds 40)
- `create_voronoi` (line 492): 94 lines (exceeds 40)
- `create_voronoi` (line 492): complexity score 12 (exceeds 10)
- `create_heatmap_grid` (line 587): 120 lines (exceeds 40)
- `create_heatmap_grid` (line 587): complexity score 23 (exceeds 10)

### ./visualization/gis/mapbox_integration.py
- `create_threat_map` (line 74): 96 lines (exceeds 40)
- `create_advanced_threat_map` (line 171): 259 lines (exceeds 40)
- `create_advanced_threat_map` (line 171): complexity score 35 (exceeds 10)
- `create_pydeck_map` (line 431): 140 lines (exceeds 40)
- `create_pydeck_map` (line 431): complexity score 11 (exceeds 10)
- `create_3d_terrain_map` (line 572): 97 lines (exceeds 40)
- `create_time_lapse_map` (line 670): 299 lines (exceeds 40)
- `create_time_lapse_map` (line 670): complexity score 18 (exceeds 10)

### ./visualization/gis/postgis_integration.py
- `_connect` (line 100): 54 lines (exceeds 40)
- `store_geodataframe` (line 175): 89 lines (exceeds 40)
- `query_to_geodataframe` (line 265): 79 lines (exceeds 40)
- `spatial_join` (line 345): 41 lines (exceeds 40)
- `distance_matrix` (line 419): 56 lines (exceeds 40)
- `nearest_neighbor_analysis` (line 476): 65 lines (exceeds 40)

### ./visualization/gis/whitebox_tools.py
- `generate_dem_derivatives` (line 100): 100 lines (exceeds 40)
- `calculate_viewshed` (line 201): 61 lines (exceeds 40)
- `extract_watersheds` (line 263): 90 lines (exceeds 40)
- `perform_lidar_analysis` (line 354): 79 lines (exceeds 40)
- `create_visibility_index` (line 434): 44 lines (exceeds 40)
- `perform_cost_distance_analysis` (line 479): 71 lines (exceeds 40)
- `calculate_least_cost_path` (line 551): 61 lines (exceeds 40)
- `calculate_travel_time` (line 613): 74 lines (exceeds 40)
- `detect_terrain_features` (line 688): 81 lines (exceeds 40)

### ./visualization/heatmap.py
- `create_heatmap` (line 24): 85 lines (exceeds 40)
- `create_time_based_heatmap` (line 111): 70 lines (exceeds 40)
- `create_clustered_heatmap` (line 183): 75 lines (exceeds 40)

### ./visualization/osint_visualizer.py
- `create_emotion_radar_chart` (line 26): 46 lines (exceeds 40)
- `create_entity_network` (line 74): 115 lines (exceeds 40)
- `create_entity_network` (line 74): complexity score 12 (exceeds 10)
- `create_emotional_trends_chart` (line 191): 61 lines (exceeds 40)
- `create_sentiment_heatmap` (line 254): 68 lines (exceeds 40)
- `create_key_phrases_wordcloud` (line 324): 90 lines (exceeds 40)
- `create_key_phrases_wordcloud` (line 324): complexity score 12 (exceeds 10)
- `create_osint_dashboard` (line 416): 45 lines (exceeds 40)
- `create_osint_dashboard` (line 416): complexity score 16 (exceeds 10)

### ./visualization/threat_flow_visualization.py
- `plot_threat_flows` (line 50): 286 lines (exceeds 40)
- `plot_threat_flows` (line 50): complexity score 11 (exceeds 10)
- `create_threat_actor_chart` (line 337): 72 lines (exceeds 40)
- `create_target_distribution` (line 410): 68 lines (exceeds 40)
- `render_dashboard` (line 479): 134 lines (exceeds 40)

### ./visualizers/data_loaders.py
- `load_data_sources` (line 41): 48 lines (exceeds 40)
- `load_system_intelligence` (line 93): 84 lines (exceeds 40)
- `handle_file_upload` (line 181): 84 lines (exceeds 40)
- `create_sample_data_mini` (line 269): 147 lines (exceeds 40)

### ./visualizers/data_loaders/file_loader.py
- `handle_file_upload` (line 36): 84 lines (exceeds 40)

### ./visualizers/data_loaders/interface.py
- `load_data_sources` (line 44): 48 lines (exceeds 40)

### ./visualizers/data_loaders/sample_mini_generator.py
- `create_sample_data_mini` (line 37): 147 lines (exceeds 40)

### ./visualizers/data_loaders/system_intelligence.py
- `load_system_intelligence` (line 37): 84 lines (exceeds 40)

### ./visualizers/export_utilities.py
- `configure_exports` (line 41): 69 lines (exceeds 40)
- `_export_data` (line 114): 93 lines (exceeds 40)
- `_convert_to_geojson` (line 211): 71 lines (exceeds 40)
- `_convert_to_kml` (line 286): 100 lines (exceeds 40)
- `create_download_button` (line 390): 45 lines (exceeds 40)

### ./visualizers/export_utilities/export_core.py
- `configure_exports` (line 39): 69 lines (exceeds 40)
- `export_data` (line 112): 88 lines (exceeds 40)
- `create_download_button` (line 204): 45 lines (exceeds 40)

### ./visualizers/export_utilities/format_converters.py
- `convert_to_geojson` (line 161): 71 lines (exceeds 40)
- `convert_to_kml` (line 236): 100 lines (exceeds 40)

### ./visualizers/geospatial_heatmap.py
- `render` (line 95): 44 lines (exceeds 40)
- `generate_sample_data` (line 204): 47 lines (exceeds 40)

### ./visualizers/map_builders/infrastructure_map.py
- `get_sample_infrastructure_data` (line 35): 43 lines (exceeds 40)
- `render_infrastructure_targets` (line 82): 73 lines (exceeds 40)

### ./visualizers/map_builders/trafficking_map.py
- `render_trafficking_routes` (line 77): 57 lines (exceeds 40)

### ./visualizers/map_builders/transport_map.py
- `render_transport_tracking` (line 76): 70 lines (exceeds 40)

### ./visualizers/sample_data_generators.py
- `create_sample_data` (line 40): 68 lines (exceeds 40)
- `_create_cluster_pattern` (line 153): 94 lines (exceeds 40)
- `_create_linear_pattern` (line 251): 97 lines (exceeds 40)
- `_create_grid_pattern` (line 352): 82 lines (exceeds 40)
- `_create_radial_pattern` (line 438): 92 lines (exceeds 40)
- `_create_path_based` (line 534): 119 lines (exceeds 40)
- `_create_city_centers` (line 657): 111 lines (exceeds 40)
- `_create_custom_distribution` (line 772): 109 lines (exceeds 40)
- `generate_custom_sample` (line 885): 57 lines (exceeds 40)

### ./visualizers/sample_data_generators/__init__.py
- `create_sample_data` (line 57): 68 lines (exceeds 40)

### ./visualizers/sample_data_generators/basic_generators.py
- `create_cluster_pattern` (line 80): 94 lines (exceeds 40)
- `create_custom_distribution` (line 178): 109 lines (exceeds 40)
- `generate_custom_sample` (line 291): 57 lines (exceeds 40)

### ./visualizers/sample_data_generators/geographic_generators.py
- `create_path_based` (line 39): 119 lines (exceeds 40)
- `create_city_centers` (line 162): 111 lines (exceeds 40)

### ./visualizers/sample_data_generators/pattern_generators.py
- `create_linear_pattern` (line 39): 97 lines (exceeds 40)
- `create_grid_pattern` (line 140): 82 lines (exceeds 40)
- `create_radial_pattern` (line 226): 92 lines (exceeds 40)

### ./visualizers/url_context_card.py
- `__init__` (line 36): 46 lines (exceeds 40)
- `visualize` (line 100): 73 lines (exceeds 40)
- `_render_context_card` (line 174): 187 lines (exceeds 40)
- `_render_context_card` (line 174): complexity score 19 (exceeds 10)
- `render_export_options` (line 362): 59 lines (exceeds 40)
- `_generate_html_report` (line 422): 260 lines (exceeds 40)
- `_generate_html_report` (line 422): complexity score 16 (exceeds 10)

## Refactoring Recommendations

1. **Break down large files** into smaller, more focused modules
2. **Extract helper functions** from overly long functions
3. **Reduce complexity** by simplifying nested control structures
4. **Apply design patterns** to improve code organization
5. **Consider applying** functional programming techniques to reduce state management complexity
