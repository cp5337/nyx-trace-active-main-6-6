# Cursor Development Task: Rust/WebAssembly Performance Modules for NyxTrace

## Project Context
I'm developing "NyxTrace," an advanced geospatial intelligence platform for tracking convergent threats across physical, cyber, and cartel domains. The platform combines OSINT capabilities with interactive visualization to provide comprehensive threat intelligence.

While the current implementation is in Python, the final version will likely be in Bevy with Rust. To prepare for this transition and optimize performance for computationally intensive tasks, I need high-performance modules written in Rust and compiled to WebAssembly that can be called from the Python application.

## Development Request
Please develop high-performance Rust modules compiled to WebAssembly for the following computationally intensive tasks:

### 1. Graph Analysis Algorithms
- Implement efficient graph algorithms for analyzing large network datasets
- Include centrality measures (betweenness, closeness, eigenvector)
- Add community detection algorithms (Louvain, Leiden, etc.)
- Implement path finding and flow algorithms
- Create shortest path computations for large graphs
- Add temporal graph analysis capabilities

### 2. Geospatial Computation
- Implement geospatial indexing for fast spatial queries
- Create routing algorithms for path optimization
- Add geofencing and point-in-polygon algorithms
- Implement clustering algorithms for geographic data
- Create interpolation methods for spatial data
- Add coordinate transformation utilities

### 3. Text Processing Pipeline
- Implement high-performance text tokenization
- Create efficient named entity recognition
- Add document similarity calculations
- Implement TF-IDF and BM25 algorithms
- Create keyword extraction capabilities
- Add text clustering algorithms

### 4. Data Structure Optimization
- Implement compressed data structures for large datasets
- Create efficient serialization/deserialization
- Add bloom filters and other probabilistic data structures
- Implement priority queues and specialized hash maps
- Create lock-free concurrent data structures
- Add specialized structures for time-series data

## Technical Requirements
- Implement in Rust with WebAssembly compilation
- Create Python bindings for all modules
- Ensure thread safety for concurrent operations
- Implement proper error handling across language boundaries
- Optimize for both memory usage and computational efficiency
- Include comprehensive benchmarks comparing to Python implementations
- Create documentation for both Rust and Python interfaces

## Code Structure
The performance modules should be organized as follows:

```
rust/
├── graph/
│   ├── src/
│   │   ├── lib.rs       # Main library code
│   │   ├── centrality.rs # Centrality algorithms
│   │   ├── community.rs  # Community detection
│   │   ├── paths.rs      # Path algorithms
│   │   └── temporal.rs   # Temporal graph analysis
│   ├── Cargo.toml       # Rust package manifest
│   └── tests/           # Test cases
├── geo/
│   ├── src/
│   │   ├── lib.rs        # Main library code
│   │   ├── indexing.rs    # Spatial indexing
│   │   ├── routing.rs     # Routing algorithms
│   │   ├── clustering.rs  # Spatial clustering
│   │   └── transforms.rs  # Coordinate transformations
│   ├── Cargo.toml        # Rust package manifest
│   └── tests/            # Test cases
├── text/
│   ├── src/
│   │   ├── lib.rs         # Main library code
│   │   ├── tokenization.rs # Text tokenization
│   │   ├── entities.rs     # Entity recognition
│   │   ├── similarity.rs   # Document similarity
│   │   └── keywords.rs     # Keyword extraction
│   ├── Cargo.toml         # Rust package manifest
│   └── tests/             # Test cases
├── data_structures/
│   ├── src/
│   │   ├── lib.rs          # Main library code
│   │   ├── compressed.rs   # Compressed structures
│   │   ├── probabilistic.rs # Probabilistic structures
│   │   ├── concurrent.rs   # Concurrent structures
│   │   └── time_series.rs  # Time series structures
│   ├── Cargo.toml          # Rust package manifest
│   └── tests/              # Test cases
└── python/
    ├── graph.py           # Python bindings for graph module
    ├── geo.py             # Python bindings for geo module
    ├── text.py            # Python bindings for text module
    ├── data_structures.py # Python bindings for data structures
    └── benchmarks/        # Benchmark comparisons
```

## Python Integration
The Rust modules should be callable from Python via WebAssembly or PyO3 bindings. Here's an example of how the Python interface should look:

```python
# Example for graph module
from nyxtrace_wasm import graph

# Create a graph
G = graph.Graph()

# Add nodes and edges
for i in range(1000):
    G.add_node(i, {"type": "entity"})
    
for i in range(999):
    G.add_edge(i, i+1, {"weight": 1.0})

# Calculate centrality
betweenness = graph.centrality.betweenness(G)
top_nodes = sorted(betweenness.items(), key=lambda x: x[1], reverse=True)[:10]
print(f"Top nodes by betweenness centrality: {top_nodes}")

# Detect communities
communities = graph.community.louvain(G)
print(f"Found {len(communities)} communities")

# Find shortest path
path = graph.paths.shortest_path(G, 0, 999)
print(f"Shortest path from 0 to 999: {path}")
```

## Data Format Examples
Here are examples of the data formats that the modules will need to process:

**Graph Data**:
```python
{
    "nodes": [
        {"id": "node1", "type": "person", "attributes": {"name": "John Doe", "age": 30}},
        {"id": "node2", "type": "organization", "attributes": {"name": "ACME Corp"}},
        # Thousands more nodes...
    ],
    "edges": [
        {"source": "node1", "target": "node2", "type": "membership", "weight": 0.8},
        # Thousands more edges...
    ]
}
```

**Geospatial Data**:
```python
{
    "points": [
        {"id": "point1", "lat": 40.7128, "lon": -74.0060, "attributes": {"type": "incident"}},
        # Thousands more points...
    ],
    "polygons": [
        {
            "id": "polygon1",
            "coordinates": [
                [40.7128, -74.0060],
                [40.7129, -74.0065],
                [40.7137, -74.0063],
                [40.7132, -74.0055],
                [40.7128, -74.0060]  # Closing point
            ],
            "attributes": {"type": "region", "name": "Area A"}
        },
        # Hundreds more polygons...
    ],
    "routes": [
        {
            "id": "route1",
            "points": [
                {"lat": 40.7128, "lon": -74.0060},
                {"lat": 40.7140, "lon": -74.0090},
                {"lat": 40.7150, "lon": -74.0100}
            ],
            "attributes": {"type": "movement", "actor": "entity1"}
        },
        # Hundreds more routes...
    ]
}
```

**Text Data**:
```python
{
    "documents": [
        {
            "id": "doc1",
            "text": "Long document text with potentially thousands of words...",
            "metadata": {"source": "news", "date": "2023-05-01T14:30:00Z"}
        },
        # Thousands more documents...
    ],
    "queries": [
        {"id": "query1", "text": "Search query text..."}
    ]
}
```

## Example Implementation
Here's a simplified example of how the Rust implementation for a graph centrality algorithm could look:

```rust
use wasm_bindgen::prelude::*;
use serde::{Serialize, Deserialize};
use std::collections::{HashMap, HashSet, VecDeque};

// Data structures for the graph
#[derive(Serialize, Deserialize)]
pub struct Node {
    id: String,
    node_type: String,
    attributes: HashMap<String, JsValue>,
}

#[derive(Serialize, Deserialize)]
pub struct Edge {
    source: String,
    target: String,
    edge_type: String,
    weight: f64,
    attributes: HashMap<String, JsValue>,
}

#[derive(Serialize, Deserialize)]
pub struct Graph {
    nodes: HashMap<String, Node>,
    edges: Vec<Edge>,
    // Adjacency list for quick access
    adjacency: HashMap<String, Vec<(String, f64)>>,
}

#[wasm_bindgen]
impl Graph {
    #[wasm_bindgen(constructor)]
    pub fn new() -> Self {
        Graph {
            nodes: HashMap::new(),
            edges: Vec::new(),
            adjacency: HashMap::new(),
        }
    }
    
    pub fn add_node(&mut self, id: String, node_type: String, attributes: JsValue) -> bool {
        if self.nodes.contains_key(&id) {
            return false;
        }
        
        let attrs: HashMap<String, JsValue> = match serde_wasm_bindgen::from_value(attributes) {
            Ok(map) => map,
            Err(_) => HashMap::new(),
        };
        
        let node = Node {
            id: id.clone(),
            node_type,
            attributes: attrs,
        };
        
        self.nodes.insert(id, node);
        true
    }
    
    pub fn add_edge(&mut self, source: String, target: String, edge_type: String, weight: f64, attributes: JsValue) -> bool {
        if !self.nodes.contains_key(&source) || !self.nodes.contains_key(&target) {
            return false;
        }
        
        let attrs: HashMap<String, JsValue> = match serde_wasm_bindgen::from_value(attributes) {
            Ok(map) => map,
            Err(_) => HashMap::new(),
        };
        
        let edge = Edge {
            source: source.clone(),
            target: target.clone(),
            edge_type,
            weight,
            attributes: attrs,
        };
        
        self.edges.push(edge);
        
        // Update adjacency list
        self.adjacency
            .entry(source.clone())
            .or_insert_with(Vec::new)
            .push((target.clone(), weight));
        
        // For undirected graphs, add the reverse edge to adjacency
        self.adjacency
            .entry(target)
            .or_insert_with(Vec::new)
            .push((source, weight));
        
        true
    }
    
    pub fn node_count(&self) -> usize {
        self.nodes.len()
    }
    
    pub fn edge_count(&self) -> usize {
        self.edges.len()
    }
}

#[wasm_bindgen]
pub fn calculate_betweenness_centrality(graph_js: JsValue) -> Result<JsValue, JsValue> {
    // Parse input graph
    let graph: Graph = serde_wasm_bindgen::from_value(graph_js)?;
    
    // Store results
    let mut centrality: HashMap<String, f64> = HashMap::new();
    
    // Initialize all nodes with centrality 0
    for node_id in graph.nodes.keys() {
        centrality.insert(node_id.clone(), 0.0);
    }
    
    // For each node as source
    for source in graph.nodes.keys() {
        // BFS to find shortest paths
        let mut queue = VecDeque::new();
        let mut distance: HashMap<String, usize> = HashMap::new();
        let mut paths: HashMap<String, Vec<String>> = HashMap::new();
        let mut predecessors: HashMap<String, Vec<String>> = HashMap::new();
        
        // Initialize
        queue.push_back(source.clone());
        distance.insert(source.clone(), 0);
        paths.insert(source.clone(), vec![]);
        
        // BFS
        while let Some(current) = queue.pop_front() {
            let current_dist = *distance.get(&current).unwrap();
            
            if let Some(neighbors) = graph.adjacency.get(&current) {
                for (neighbor, _) in neighbors {
                    if !distance.contains_key(neighbor) {
                        distance.insert(neighbor.clone(), current_dist + 1);
                        queue.push_back(neighbor.clone());
                        predecessors.entry(neighbor.clone()).or_insert_with(Vec::new).push(current.clone());
                    } else if *distance.get(neighbor).unwrap() == current_dist + 1 {
                        predecessors.entry(neighbor.clone()).or_insert_with(Vec::new).push(current.clone());
                    }
                }
            }
        }
        
        // Dependency accumulation
        let mut dependency: HashMap<String, f64> = HashMap::new();
        let mut processed: HashSet<String> = HashSet::new();
        
        // Process nodes in order of decreasing distance from source
        let mut nodes_by_distance: Vec<(String, usize)> = distance.iter()
            .map(|(k, v)| (k.clone(), *v))
            .collect();
        nodes_by_distance.sort_by(|a, b| b.1.cmp(&a.1));
        
        for (node, _) in nodes_by_distance {
            if node == *source {
                continue;
            }
            
            let mut node_dependency = 0.0;
            let pred = predecessors.get(&node).unwrap_or(&vec![]);
            
            for p in pred {
                let paths_through_p = 1.0 / pred.len() as f64;
                node_dependency += paths_through_p * (1.0 + dependency.get(p).unwrap_or(&0.0));
            }
            
            dependency.insert(node.clone(), node_dependency);
            
            // Add to centrality
            let current_centrality = centrality.get(&node).unwrap_or(&0.0);
            centrality.insert(node, current_centrality + node_dependency);
        }
    }
    
    // Normalize
    let n = graph.nodes.len() as f64;
    if n > 2.0 {
        for (_, value) in centrality.iter_mut() {
            *value = *value / ((n - 1.0) * (n - 2.0));
        }
    }
    
    // Convert to JS object
    Ok(serde_wasm_bindgen::to_value(&centrality)?)
}
```

## Performance Benchmarks
For each module, include benchmarks comparing the Rust/WebAssembly implementation to equivalent Python implementations. For example:

```python
import time
import numpy as np
import networkx as nx
from nyxtrace_wasm import graph

def benchmark_centrality():
    # Generate random graph
    n_nodes = 1000
    n_edges = 5000
    
    # NetworkX implementation
    G_nx = nx.Graph()
    G_nx.add_nodes_from(range(n_nodes))
    edges = [(np.random.randint(0, n_nodes), np.random.randint(0, n_nodes)) for _ in range(n_edges)]
    G_nx.add_edges_from(edges)
    
    start_time = time.time()
    nx_result = nx.betweenness_centrality(G_nx)
    nx_time = time.time() - start_time
    print(f"NetworkX time: {nx_time:.4f}s")
    
    # Rust/WebAssembly implementation
    G_rust = graph.Graph()
    for i in range(n_nodes):
        G_rust.add_node(str(i), "node", {})
    
    for src, dst in edges:
        G_rust.add_edge(str(src), str(dst), "edge", 1.0, {})
    
    start_time = time.time()
    rust_result = graph.centrality.betweenness(G_rust)
    rust_time = time.time() - start_time
    print(f"Rust/WASM time: {rust_time:.4f}s")
    
    speedup = nx_time / rust_time
    print(f"Speedup: {speedup:.2f}x")
    
    # Verify results match (approximately)
    for node in nx_result:
        nx_val = nx_result[node]
        rust_val = rust_result[str(node)]
        assert abs(nx_val - rust_val) < 1e-6, f"Results differ for node {node}: {nx_val} vs {rust_val}"
    
    print("Results verified ✓")

if __name__ == "__main__":
    benchmark_centrality()
```

## Next Steps and Expansion
Once these performance modules are implemented, we'll want to:

1. Integrate them with the NyxTrace Python application
2. Add more algorithms and capabilities based on performance needs
3. Begin the transition to a fully Rust-based implementation using Bevy

Please develop these modules with a focus on performance, correctness, and usability from Python. The implementation should be thoroughly tested and benchmarked to demonstrate the performance improvements over pure Python implementations.