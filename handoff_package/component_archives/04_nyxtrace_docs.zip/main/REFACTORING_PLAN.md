# CTAS Code Refactoring Plan

## Overview

Based on the code analysis, our project has significant technical debt:
- 121 of 227 files exceed the recommended 300-line limit
- 708 functions exceed the recommended 40-line limit
- Total codebase size: 110,446 lines of Python code

This refactoring plan addresses these issues with a phased approach.

## Primary Goals

1. Improve code maintainability and readability
2. Reduce file and function sizes to meet best practices
3. Establish consistent patterns across the codebase
4. Fix SQLite thread safety issues with Streamlit
5. Ensure proper error handling throughout the application

## Phase 1: Critical Infrastructure Improvements

### 1.1 SQLite Thread Safety for Streamlit

The most urgent issue is the SQLite thread safety problem with Streamlit. We'll implement:

- Data caching in `st.session_state` to prevent cross-thread access
- Singleton pattern with thread-local storage for database connections
- Read-only data access pattern for visualization components

**Key Files:**
- `core/periodic_table/registry.py`
- `pages/node_card_viewer.py`
- `pages/periodic_table_demo.py`

### 1.2 Core Module Refactoring

The core periodic table modules need restructuring:

- Split `registry.py` (994 lines) into specialized components:
  - `db_connector.py`: Database connection management
  - `query_manager.py`: SQL query operations
  - `cache_manager.py`: Thread-safe caching layer
  - `registry.py`: Core registry functionality

- Split `table.py` (861 lines) into:
  - `table_core.py`: Base table functionality
  - `table_layout.py`: Visual layout algorithms
  - `table_interactions.py`: User interaction handlers

## Phase 2: Page Component Refactoring

### 2.1 Large Page Decomposition

Largest pages need immediate attention:

- `pages/geospatial_intelligence.py` (3372 lines):
  - Extract map rendering components
  - Create separate analysis modules
  - Move utilities to dedicated files

- `main_dashboard.py` (2229 lines):
  - Extract each dashboard panel to component files
  - Create a component registry system
  - Implement lazy loading pattern

### 2.2 Node Viewer Refactoring

- Create a simplified JSON-based node viewer to replace SQL-dependent version
- Implement clean component architecture with:
  - `components/cards/node_card.py`
  - `components/views/grid_view.py`
  - `components/views/detail_view.py`
  - `components/filters/search_filter.py`

## Phase 3: Systematic Pattern Implementation

### 3.1 Consistent Interface Patterns

Implement consistent patterns across the codebase:

- Data Access Objects (DAO) pattern for all database operations
- Repository pattern for data management
- Service pattern for business logic
- Component pattern for UI elements

### 3.2 Error Handling Strategy

Standardize error handling:

- Create custom exception hierarchy
- Implement consistent try/except patterns
- Add proper logging throughout
- Create user-friendly error messages

## Implementation Strategy

We'll follow these principles during implementation:

1. **Incremental Changes**: Make small, testable changes
2. **Test-Driven**: Add tests before refactoring
3. **Zero Downtime**: Keep the application functional throughout
4. **Documentation**: Update docs with each change

## Metrics for Success

We'll track the following metrics:

1. Percentage of files under 300 lines
2. Percentage of functions under 40 lines
3. Number of SQLite thread errors
4. Application load time
5. Code duplication percentage

## Timeline

- **Week 1**: Infrastructure improvements (Phase 1.1)
- **Week 2**: Core module refactoring (Phase 1.2)
- **Week 3**: Page component refactoring (Phase 2)
- **Week 4**: Pattern implementation (Phase 3)