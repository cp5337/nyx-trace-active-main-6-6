# NyxTrace Repository Structure

## Overview

NyxTrace is a cutting-edge geospatial intelligence platform that functions as a specialized subsystem within the Convergent Threat Analysis System (CTAS v6.5) framework. The platform combines OSINT capabilities with interactive visualization to track hybrid threats across multiple domains.

## Directory Structure

```
NyxTrace
├── collectors/                     # Data collection modules
│   ├── kali_tools_collector.py     # Tools for collecting security data
│   └── url_context_collector.py    # URL information collection
│
├── config/                         # Configuration files
│   └── opsec.json                  # OPSEC configuration
│
├── core/                           # Core system components
│   ├── algorithms/                 # Computational algorithms
│   │   ├── distance_calculator.py  # Distance computation
│   │   ├── geospatial_algorithms.py# Facade for geospatial algorithms
│   │   ├── geospatial_utils.py     # Geospatial utilities
│   │   ├── hexagonal_grid.py       # Hexagonal grid system
│   │   ├── hotspot_analysis.py     # Hotspot detection algorithms
│   │   └── spatial_join.py         # Spatial join operations
│   │
│   ├── gnn/                        # Graph Neural Network components
│   │   └── gnn_model.py            # GNN model implementation
│   │
│   ├── integrations/               # External integrations
│   │   ├── graph_db/               # Graph database connections
│   │   │   └── neo4j_connector.py  # Neo4j connection utilities
│   │   └── satellite/              # Satellite imagery integration
│   │       └── google_earth_integration.py
│   │
│   ├── interfaces/                 # Interface definitions
│   │   ├── analyzers.py            # Analyzer interfaces
│   │   ├── base.py                 # Base interfaces
│   │   ├── collectors.py           # Collector interfaces
│   │   ├── processors.py           # Processor interfaces
│   │   └── visualizers.py          # Visualizer interfaces
│   │
│   ├── matroid/                    # Matroid theory implementation
│   │   ├── base.py                 # Base matroid classes
│   │   └── spatial_matroid.py      # Spatial matroid implementation
│   │
│   ├── mcp_client.py               # MCP client implementation
│   ├── mcp_server.py               # MCP server implementation
│   ├── plugin_loader.py            # Plugin management
│   ├── registry.py                 # Component registry
│   │
│   ├── storyteller/                # Workflow storyteller components
│   │   ├── story_elements.py       # Story element definitions
│   │   └── workflow_progress.py    # Workflow progress tracker
│   │
│   └── triptych/                   # Triptych framework
│       ├── client.py               # Triptych client
│       └── models.py               # Triptych data models
│
├── data/                           # Data storage
│   ├── sample_threat_intel.py      # Sample threat intelligence data
│   └── url_health_history.json     # URL health monitoring history
│
├── data_sources/                   # Data source implementations
│   ├── base_source.py              # Base data source class
│   ├── criminal_network_analyzer.py# Criminal network analysis
│   ├── data_source_integrator.py   # Data source integration
│   ├── excel_osint_source.py       # Excel-based OSINT source
│   ├── incident_reporter.py        # Incident reporting
│   ├── infrastructure_scanner.py   # Infrastructure scanning
│   ├── multi_model_processor.py    # Multi-model processing
│   ├── network_analysis_core.py    # Network analysis core
│   ├── news_api_source.py          # News API data source
│   ├── news_monitor.py             # News monitoring
│   ├── osint_analyzer.py           # OSINT analysis
│   ├── osint_investigation.py      # OSINT investigation tools
│   ├── plugins/                    # Data source plugins
│   │   ├── alienvault_otx_source.py# AlienVault OTX integration
│   │   ├── news_api_source.py      # News API plugin
│   │   └── social_monitoring_source.py # Social media monitoring
│   ├── shodan_integration.py       # Shodan integration
│   ├── source_manager.py           # Source management
│   ├── target_analyzer.py          # Target analysis
│   ├── twitter_source.py           # Twitter data source
│   └── web_scraper.py              # Web scraping utilities
│
├── docs/                           # Documentation
│   └── algorithms/                 # Algorithm documentation
│       └── geospatial_algorithms.md# Geospatial algorithms documentation
│
├── pages/                          # Streamlit pages
│   ├── download.py                 # Download interface
│   ├── geospatial_heatmap.py       # Geospatial heatmap visualization
│   ├── geospatial_intelligence.py  # Geospatial intelligence dashboard
│   ├── kali_tools_explorer.py      # Kali tools explorer
│   ├── kali_tools.py               # Kali tools interface
│   ├── threat_intelligence.py      # Threat intelligence dashboard
│   ├── threat_intel.py             # Threat intel interface
│   ├── url_health_dashboard.py     # URL health dashboard
│   ├── url_health_monitoring.py    # URL health monitoring
│   ├── url_health.py               # URL health interface
│   ├── url_intelligence.py         # URL intelligence dashboard
│   └── workflow_storyteller.py     # Workflow storyteller interface
│
├── processors/                     # Data processing modules
│   ├── geo_resolver.py             # Geographic resolution
│   ├── osint_data_processor.py     # OSINT data processing
│   └── url_context_processor.py    # URL context processing
│
├── prompts/                        # AI prompts and instructions
│   ├── Cursor_Advanced_Visualization_Prompt.md
│   ├── Cursor_Predictive_Analytics_Prompt.md
│   ├── Cursor_Rust_WebAssembly_Prompt.md
│   ├── NyxTrace_Agent_Tasks.md
│   ├── NyxTrace_Continuation_Prompt.md
│   ├── NyxTrace_Cursor_Vercel_Tasks.md
│   ├── Vercel_Collaboration_Infrastructure_Prompt.md
│   ├── Vercel_Deployment_Architecture_Prompt.md
│   └── Vercel_Progressive_Web_App_Prompt.md
│
├── utils/                          # Utility functions
│   ├── ctas_headers.py             # CTAS header utilities
│   ├── ctas_repo_analyzer.py       # Repository analysis
│   ├── kali_integrator.py          # Kali Linux integration
│   ├── kml_handler.py              # KML file handling
│   ├── opsec_manager.py            # OPSEC management
│   ├── security_tools_utils.py     # Security tool utilities
│   └── url_health_monitor.py       # URL health monitoring
│
├── visualization/                  # Visualization components
│   ├── advanced_charts.py          # Advanced chart creation
│   ├── analytics/                  # Analytics visualizations
│   │   └── ai_gis_integration.py   # AI-GIS integration
│   ├── gis/                        # GIS visualizations
│   │   ├── geojson_utils.py        # GeoJSON utilities
│   │   ├── geo_processor.py        # Geographic processing
│   │   ├── mapbox_integration.py   # Mapbox integration
│   │   ├── postgis_integration.py  # PostGIS integration
│   │   └── whitebox_tools.py       # WhiteBox GIS tools
│   ├── heatmap.py                  # Heatmap visualization
│   ├── osint_visualizer.py         # OSINT visualization
│   └── threat_flow_visualization.py# Threat flow visualization
│
├── visualizers/                    # Visualizer implementations
│   ├── geospatial_heatmap.py       # Geospatial heatmap visualizer
│   └── url_context_card.py         # URL context card visualizer
│
├── apply_ctas_headers.py           # Apply CTAS headers to files
├── code_check.py                   # Code quality checking
├── data_handler.py                 # Data handling utilities
├── main_dashboard.py               # Main dashboard interface
├── main.py                         # Main application entry point
├── pyproject.toml                  # Python project configuration
├── README.md                       # Project documentation
├── replit.nix                      # Replit configuration
├── utils.py                        # General utilities
└── uv.lock                         # UV lock file
```

## Key Components

### Core Algorithms and Mathematics (core/algorithms/)
Contains the primary computational algorithms used for geospatial analysis, including:
- Distance calculations
- Hexagonal grid systems
- Hotspot analysis
- Spatial joins

### Matroid Theory Implementation (core/matroid/)
Implements matroid theory concepts for intelligence analysis:
- Base matroid classes
- Spatial matroid implementation

### Data Collection (collectors/)
Modules for collecting data from various sources:
- Kali tools collection
- URL context collection

### Data Sources (data_sources/)
Implementations of various data sources:
- OSINT investigation
- News monitoring
- Criminal network analysis
- Infrastructure scanning
- Social media monitoring

### Visualization (visualization/)
Components for data visualization:
- GIS integration (PostGIS, Mapbox)
- Heatmaps
- Threat flow visualization
- Advanced charts

### Interactive Interfaces (pages/)
Streamlit pages for user interaction:
- Geospatial intelligence dashboard
- Threat intelligence
- URL health monitoring
- Kali tools explorer
- Workflow storyteller

### Workflow Storyteller (core/storyteller/)
New feature for tracking and visualizing operational workflows:
- Story elements
- Workflow progress tracking
- Timeline visualization

## Development Areas for Location Items and Drone Packages

### For Location Items:
- **Core/Algorithms**: Enhance the geospatial algorithms module to handle specialized location types
- **Core/Matroid**: Extend the spatial matroid implementation to accommodate new location item types
- **Visualization/GIS**: Add specialized visualization for location items with custom properties
- **Data Sources**: Implement data sources specifically for location intelligence

### For Drone Packages:
- **Core/Interfaces**: Create new interfaces for drone-specific data collection and processing
- **Collectors**: Develop drone telemetry collectors
- **Visualization**: Implement specialized visualization for drone flight paths, coverage areas, and sensor data
- **Pages**: Create dedicated dashboards for drone fleet management and mission planning

## Suggested Implementation Plan

1. Define the data models for location items and drone packages
2. Extend the existing geospatial algorithms to support the new data types
3. Create specialized collectors for drone telemetry and location data
4. Implement visualization components for the new data types
5. Develop user interfaces for interacting with location items and drone packages
6. Integrate with the existing storyteller functionality to track drone operations