# Cursor Development Task: Predictive Analytics System for NyxTrace

## Project Context
I'm developing "NyxTrace," an advanced geospatial intelligence platform for tracking convergent threats across physical, cyber, and cartel domains. The platform combines OSINT capabilities with interactive visualization to provide comprehensive threat intelligence.

The system follows the "Hunt, Detect, Disrupt, Disable, Dominate" framework derived from FIVE EYES intelligence operations and monitors critical infrastructure across multiple sectors including agriculture/food, chemical, communications, energy, healthcare, and more.

I've already built core modules for incident reporting, OSINT investigation, operational security, data source integration, and security tool integration. Now I need sophisticated predictive analytics capabilities to analyze patterns and forecast potential threats.

## Development Request
Please develop a predictive analytics system for the NyxTrace platform with the following capabilities:

### 1. Bayesian Analysis for Threat Assessment
- Implement Bayesian network models for analyzing threat probabilities
- Create conditional probability calculators for different threat scenarios
- Develop belief propagation algorithms for updating probabilities as new evidence arrives
- Build visualization components for displaying probability distributions
- Implement Bayesian inference for threat attribution
- Create a system for incorporating expert knowledge into priors

### 2. Hidden Markov Models for Movement Pattern Analysis
- Develop HMM implementations for analyzing movement patterns of entities
- Create training algorithms for learning state transition probabilities
- Implement the Viterbi algorithm for finding most likely state sequences
- Build forward-backward algorithms for state probability estimation
- Create visualization components for displaying state transitions and predictions
- Implement sequence prediction for forecasting future movements

### 3. Anomaly Detection System
- Implement multiple anomaly detection algorithms (statistical, clustering-based, etc.)
- Create ensemble methods for combining detection algorithms
- Develop adaptive thresholding for different contexts and threat types
- Build visualization components for displaying anomalies and their significance
- Implement real-time anomaly detection capabilities
- Create feedback mechanisms for improving detection accuracy

### 4. Pattern Recognition across Domains
- Develop algorithms for detecting patterns across cyber, physical, and human domains
- Create feature extraction methods for different data types
- Implement correlation analysis for identifying relationships between events
- Build temporal pattern detection for identifying recurring patterns
- Develop spatial pattern recognition for geographic distributions
- Create visualization components for displaying identified patterns

## Technical Requirements
- Implement in Python with support for integration with the Streamlit dashboard
- Ensure algorithms are efficient enough for interactive use
- Create clear APIs for each component
- Implement proper validation for all models
- Provide uncertainty quantification for predictions
- Enable both batch and incremental processing of data
- Support serialization for trained models

## Code Structure
The predictive analytics components should be organized as follows:

```
analytics/
├── bayesian/
│   ├── network.py      # Bayesian network implementation
│   ├── inference.py    # Inference algorithms
│   ├── learning.py     # Parameter and structure learning
│   └── visualization.py # Visualization for Bayesian models
├── markov/
│   ├── hmm.py          # Hidden Markov Model implementation
│   ├── training.py     # HMM training algorithms
│   ├── inference.py    # State inference algorithms
│   └── visualization.py # Visualization for HMMs
├── anomaly/
│   ├── detectors.py    # Anomaly detection algorithms
│   ├── ensemble.py     # Ensemble methods
│   ├── thresholding.py # Adaptive thresholding
│   └── visualization.py # Visualization for anomalies
├── pattern/
│   ├── extractors.py   # Feature extraction
│   ├── correlation.py  # Correlation analysis
│   ├── temporal.py     # Temporal pattern detection
│   ├── spatial.py      # Spatial pattern detection
│   └── visualization.py # Visualization for patterns
└── utils/
    ├── validation.py   # Model validation utilities
    ├── metrics.py      # Performance metrics
    ├── serialization.py # Model serialization
    └── data_prep.py    # Data preparation utilities
```

## Data Formats
The predictive analytics components should accept standardized data formats:

**Incident Data for Analysis**:
```python
{
    "incidents": [
        {
            "id": "INC-12345",
            "type": "cyber",  # cyber, physical, cartel, hybrid
            "timestamp": "2023-05-01T14:30:00Z",
            "location": {
                "lat": 40.7128,
                "lon": -74.0060,
                "region": "North America",
                "country": "USA",
                "city": "New York"
            },
            "severity": "critical",  # critical, high, medium, low
            "actors": ["actor1", "actor2"],
            "targets": ["target1"],
            "methods": ["method1", "method2"],
            "indicators": [...],  # List of technical indicators
            "related_incidents": ["INC-12344", "INC-12346"],
            "attributes": {...}  # Additional attributes
        },
        # More incidents...
    ],
    "time_range": {
        "start": "2022-05-01T00:00:00Z",
        "end": "2023-05-01T23:59:59Z"
    },
    "filters": {
        "types": ["cyber", "physical"],  # Filter by types
        "severities": ["critical", "high"],  # Filter by severities
        "regions": ["North America"],  # Filter by regions
        # More filters...
    }
}
```

**Entity Movement Data**:
```python
{
    "entity": "entity1",
    "movements": [
        {
            "timestamp": "2023-05-01T14:30:00Z",
            "location": {"lat": 40.7128, "lon": -74.0060, "name": "Location A"},
            "confidence": 0.9,
            "duration": 3600,  # Duration in seconds
            "activity": "meeting",
            "contacts": ["entity2", "entity3"]
        },
        # More movements...
    ],
    "attributes": {
        "type": "person",  # person, vehicle, group
        "affiliation": "organization1",
        "risk_level": "high"
    },
    "time_range": {
        "start": "2023-05-01T00:00:00Z",
        "end": "2023-05-07T23:59:59Z"
    }
}
```

**Pattern Analysis Data**:
```python
{
    "events": [
        {
            "id": "event1",
            "type": "cyber",
            "timestamp": "2023-05-01T14:30:00Z",
            "location": {"lat": 40.7128, "lon": -74.0060},
            "attributes": {...},
            "features": [0.1, 0.2, 0.5, ...],  # Numerical features for analysis
            "categorical_features": {"feature1": "value1", ...}  # Categorical features
        },
        # More events...
    ],
    "relationships": [
        {
            "source": "event1",
            "target": "event2",
            "type": "causation",
            "strength": 0.7,
            "attributes": {...}
        },
        # More relationships...
    ],
    "context": {
        "time_period": "daily",  # hourly, daily, weekly, monthly
        "geographic_scale": "city",  # global, continent, country, region, city
        "domain_focus": "all"  # all, cyber, physical, human
    }
}
```

## Example Implementation
Here's an example implementation of a basic Bayesian analysis component:

```python
import numpy as np
import pandas as pd
import networkx as nx
from pgmpy.models import BayesianNetwork
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination
import plotly.graph_objects as go
import streamlit as st

class ThreatNetworkModel:
    """
    Bayesian Network model for threat analysis
    """
    
    def __init__(self):
        # Define the structure of the Bayesian Network
        self.model = BayesianNetwork([
            ('ThreatActor', 'CyberActivity'),
            ('ThreatActor', 'PhysicalActivity'),
            ('CyberActivity', 'DataBreach'),
            ('PhysicalActivity', 'InfrastructureCompromise'),
            ('DataBreach', 'Impact'),
            ('InfrastructureCompromise', 'Impact')
        ])
        
        # Initialize with default CPDs
        self._initialize_cpds()
        
        # Create inference engine
        self.inference = VariableElimination(self.model)
        
    def _initialize_cpds(self):
        """Initialize conditional probability distributions"""
        # CPD for ThreatActor
        cpd_threat_actor = TabularCPD(
            variable='ThreatActor',
            variable_card=3,  # Low, Medium, High sophistication
            values=[[0.6], [0.3], [0.1]]  # Prior probabilities
        )
        
        # CPD for CyberActivity given ThreatActor
        cpd_cyber = TabularCPD(
            variable='CyberActivity',
            variable_card=2,  # Inactive, Active
            values=[
                [0.9, 0.6, 0.2],  # P(Inactive | ThreatActor)
                [0.1, 0.4, 0.8]   # P(Active | ThreatActor)
            ],
            evidence=['ThreatActor'],
            evidence_card=[3]
        )
        
        # CPD for PhysicalActivity given ThreatActor
        cpd_physical = TabularCPD(
            variable='PhysicalActivity',
            variable_card=2,  # Inactive, Active
            values=[
                [0.95, 0.7, 0.3],  # P(Inactive | ThreatActor)
                [0.05, 0.3, 0.7]   # P(Active | ThreatActor)
            ],
            evidence=['ThreatActor'],
            evidence_card=[3]
        )
        
        # CPD for DataBreach given CyberActivity
        cpd_data_breach = TabularCPD(
            variable='DataBreach',
            variable_card=2,  # No, Yes
            values=[
                [0.99, 0.4],  # P(No | CyberActivity)
                [0.01, 0.6]   # P(Yes | CyberActivity)
            ],
            evidence=['CyberActivity'],
            evidence_card=[2]
        )
        
        # CPD for InfrastructureCompromise given PhysicalActivity
        cpd_infra = TabularCPD(
            variable='InfrastructureCompromise',
            variable_card=2,  # No, Yes
            values=[
                [0.98, 0.3],  # P(No | PhysicalActivity)
                [0.02, 0.7]   # P(Yes | PhysicalActivity)
            ],
            evidence=['PhysicalActivity'],
            evidence_card=[2]
        )
        
        # CPD for Impact given DataBreach and InfrastructureCompromise
        cpd_impact = TabularCPD(
            variable='Impact',
            variable_card=3,  # Low, Medium, High
            values=[
                [0.9, 0.6, 0.1, 0.5],  # P(Low | DataBreach, InfrastructureCompromise)
                [0.09, 0.3, 0.3, 0.3],  # P(Medium | DataBreach, InfrastructureCompromise)
                [0.01, 0.1, 0.6, 0.2]   # P(High | DataBreach, InfrastructureCompromise)
            ],
            evidence=['DataBreach', 'InfrastructureCompromise'],
            evidence_card=[2, 2]
        )
        
        # Add CPDs to the model
        self.model.add_cpds(
            cpd_threat_actor, cpd_cyber, cpd_physical,
            cpd_data_breach, cpd_infra, cpd_impact
        )
        
        # Check if the model is valid
        assert self.model.check_model()
        
    def update_from_incidents(self, incidents):
        """
        Update model parameters based on incident data
        
        Args:
            incidents: List of incident dictionaries
        """
        # This would implement parameter learning from data
        # For this example, we'll just use the default parameters
        pass
        
    def predict_impact(self, evidence=None):
        """
        Predict impact probability distribution given evidence
        
        Args:
            evidence: Dictionary of evidence variables and their values
            
        Returns:
            Probability distribution over impact levels
        """
        if evidence is None:
            evidence = {}
            
        query_result = self.inference.query(variables=['Impact'], evidence=evidence)
        return query_result.values
        
    def visualize_network(self):
        """
        Create a visualization of the Bayesian network
        
        Returns:
            Plotly figure object
        """
        # Create a directed graph from the model
        G = nx.DiGraph()
        
        # Add nodes and edges
        for node in self.model.nodes():
            G.add_node(node)
            
        for edge in self.model.edges():
            G.add_edge(edge[0], edge[1])
            
        # Define node positions using a layout algorithm
        pos = nx.spring_layout(G)
        
        # Create edge trace
        edge_x = []
        edge_y = []
        for edge in G.edges():
            x0, y0 = pos[edge[0]]
            x1, y1 = pos[edge[1]]
            edge_x.extend([x0, x1, None])
            edge_y.extend([y0, y1, None])
            
        edge_trace = go.Scatter(
            x=edge_x, y=edge_y,
            line=dict(width=1, color='#888'),
            hoverinfo='none',
            mode='lines')
            
        # Create node trace
        node_x = []
        node_y = []
        for node in G.nodes():
            x, y = pos[node]
            node_x.append(x)
            node_y.append(y)
            
        node_trace = go.Scatter(
            x=node_x, y=node_y,
            mode='markers+text',
            text=list(G.nodes()),
            textposition='top center',
            marker=dict(
                showscale=False,
                color='#007BFF',
                size=15,
                line=dict(width=2, color='#FFFFFF')
            ),
            hoverinfo='text',
            hovertext=list(G.nodes())
        )
        
        # Create figure
        fig = go.Figure(data=[edge_trace, node_trace],
                        layout=go.Layout(
                            title='Threat Assessment Bayesian Network',
                            titlefont=dict(size=16),
                            showlegend=False,
                            hovermode='closest',
                            margin=dict(b=20, l=5, r=5, t=40),
                            xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                            yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                            paper_bgcolor='rgba(0,0,0,0)',
                            plot_bgcolor='rgba(0,0,0,0)',
                        ))
        
        return fig

# Example Streamlit integration
def display_threat_assessment(incidents_data):
    """Display threat assessment in Streamlit"""
    st.subheader("Bayesian Threat Assessment")
    
    # Create and update model
    model = ThreatNetworkModel()
    model.update_from_incidents(incidents_data.get('incidents', []))
    
    # Display network visualization
    fig = model.visualize_network()
    st.plotly_chart(fig, use_container_width=True)
    
    # Create interface for evidence selection
    st.subheader("Scenario Analysis")
    
    # Example evidence selection
    threat_actor = st.selectbox(
        "Threat Actor Sophistication",
        options=["Unknown", "Low", "Medium", "High"],
        index=0
    )
    
    cyber_activity = st.selectbox(
        "Cyber Activity Detected",
        options=["Unknown", "Inactive", "Active"],
        index=0
    )
    
    physical_activity = st.selectbox(
        "Physical Activity Detected",
        options=["Unknown", "Inactive", "Active"],
        index=0
    )
    
    # Build evidence dictionary
    evidence = {}
    if threat_actor != "Unknown":
        evidence['ThreatActor'] = ["Low", "Medium", "High"].index(threat_actor)
    if cyber_activity != "Unknown":
        evidence['CyberActivity'] = 0 if cyber_activity == "Inactive" else 1
    if physical_activity != "Unknown":
        evidence['PhysicalActivity'] = 0 if physical_activity == "Inactive" else 1
    
    # Predict impact
    impact_probs = model.predict_impact(evidence)
    
    # Display results
    st.subheader("Impact Probability")
    impact_labels = ["Low", "Medium", "High"]
    
    # Create bar chart
    impact_fig = go.Figure(data=[
        go.Bar(
            x=impact_labels,
            y=impact_probs,
            marker_color=['green', 'orange', 'red']
        )
    ])
    
    impact_fig.update_layout(
        title="Predicted Impact Probability",
        xaxis_title="Impact Level",
        yaxis_title="Probability",
        yaxis=dict(range=[0, 1])
    )
    
    st.plotly_chart(impact_fig, use_container_width=True)
```

## Next Steps and Expansion
After implementing the basic predictive analytics components, I'll want to:

1. Integrate with real-time data streams
2. Implement feedback loops for continuous model improvement
3. Add more sophisticated models (deep learning, etc.)
4. Create automated alert mechanisms based on predictions

Please develop these predictive analytics components as modular, reusable elements that can be integrated into the larger NyxTrace platform. Prioritize accuracy, performance, and interpretability in the implementation.