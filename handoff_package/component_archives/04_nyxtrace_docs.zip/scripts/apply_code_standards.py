"""
CTAS Code Standards Application Tool
-----------------------------------
This script applies code standards to Python files across the codebase:
- Formats files using Black with 80-character line limits
- Validates documentation and comments meet standards
- Reports on compliance with code standards
"""

import os
import sys
import ast
import subprocess
import logging
from typing import List, Dict, Any, Tuple, Optional
import re

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("code_standards")

# Constants
MAX_LINE_LENGTH = 80
MAX_MODULE_SIZE = 30
MIN_COMMENT_RATIO = 0.15
EXCLUDED_DIRS = [
    "__pycache__", 
    ".git", 
    ".pythonlibs", 
    ".venv", 
    "venv",
    ".cache",
    ".config",
    ".local",
    ".upm"
]


def count_file_lines(file_path: str) -> int:
    """
    Count the number of lines in a file
    
    Args:
        file_path: Path to the file to analyze
        
    Returns:
        int: Number of lines in the file
    """
    with open(file_path, 'r', encoding='utf-8') as file:
        return len(file.readlines())


def count_comment_lines(source_code: str) -> int:
    """
    Count the number of comment lines in the source code
    
    Args:
        source_code: Source code string
        
    Returns:
        int: Number of comment lines
    """
    lines = source_code.splitlines()
    comment_count = 0
    
    in_multiline = False
    for line in lines:
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
            
        # Check for multiline string/comment start/end
        if re.match(r'^[rufd]?""".*"""$', line, re.IGNORECASE) or re.match(r"^[rufd]?'''.*'''$", line, re.IGNORECASE):
            # One-line docstring
            comment_count += 1
            continue
            
        if re.match(r'^[rufd]?"""', line, re.IGNORECASE) or re.match(r"^[rufd]?'''", line, re.IGNORECASE):
            in_multiline = True
            comment_count += 1
            continue
            
        if in_multiline:
            comment_count += 1
            if re.search(r'"""$', line) or re.search(r"'''$", line):
                in_multiline = False
            continue
            
        # Single line comment
        if line.startswith('#'):
            comment_count += 1
            
    return comment_count


def calculate_comment_ratio(file_path: str) -> float:
    """
    Calculate the ratio of comments to code
    
    Args:
        file_path: Path to the file to analyze
        
    Returns:
        float: Ratio of comments to total non-empty lines
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
            
        # Count non-empty lines
        total_lines = len([l for l in content.splitlines() if l.strip()])
        if total_lines == 0:
            return 0
            
        comment_lines = count_comment_lines(content)
        return comment_lines / total_lines
    except Exception as e:
        logger.error(f"Error calculating comment ratio for {file_path}: {e}")
        return 0


def extract_modules(tree: ast.AST) -> List[Tuple[str, int, int, int]]:
    """
    Extract modules (functions, classes, methods) from AST
    
    Args:
        tree: AST tree of a Python file
        
    Returns:
        List of (name, start_line, end_line, line_count) tuples for each module
    """
    modules = []
    
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            name = node.name
            start_line = node.lineno
            end_line = max(
                getattr(node, 'end_lineno', node.lineno),
                *(getattr(n, 'end_lineno', n.lineno) for n in ast.walk(node) 
                if hasattr(n, 'lineno'))
            )
            line_count = end_line - start_line + 1
            modules.append((name, start_line, end_line, line_count))
            
    return modules


def analyze_module_size(file_path: str) -> Tuple[List[Tuple[str, int]], int]:
    """
    Analyze module sizes in a file and report violations
    
    Args:
        file_path: Path to the file to analyze
        
    Returns:
        Tuple containing:
            - List of (module_name, line_count) tuples for oversize modules
            - Number of modules exceeding max size
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            tree = ast.parse(file.read(), filename=file_path)
            
        modules = extract_modules(tree)
        oversize_modules = [(name, count) for name, _, _, count in modules 
                          if count > MAX_MODULE_SIZE]
                          
        return oversize_modules, len(oversize_modules)
    except Exception as e:
        logger.error(f"Error analyzing module size for {file_path}: {e}")
        return [], 0


def apply_black_formatting(file_path: str) -> Tuple[bool, str]:
    """
    Apply Black formatter to a file
    
    Args:
        file_path: Path to the file to format
        
    Returns:
        Tuple of (success, message)
    """
    try:
        result = subprocess.run(
            ["black", "--line-length", str(MAX_LINE_LENGTH), file_path],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            return True, "Formatting successful"
        else:
            return False, f"Black error: {result.stderr}"
    except Exception as e:
        return False, f"Failed to run Black: {str(e)}"


def analyze_file(file_path: str) -> Dict[str, Any]:
    """
    Analyze a file for compliance with code standards
    
    Args:
        file_path: Path to the file to analyze
        
    Returns:
        Dictionary with analysis results
    """
    result = {
        "file_path": file_path,
        "format_success": False,
        "format_message": "",
        "comment_ratio": 0,
        "meets_comment_standard": False,
        "oversize_modules": [],
        "module_violations": 0
    }
    
    # Apply Black formatting
    result["format_success"], result["format_message"] = apply_black_formatting(file_path)
    
    # Check comment density
    result["comment_ratio"] = calculate_comment_ratio(file_path)
    result["meets_comment_standard"] = result["comment_ratio"] >= MIN_COMMENT_RATIO
    
    # Check module sizes
    result["oversize_modules"], result["module_violations"] = analyze_module_size(file_path)
    
    return result


def scan_directory(path: str = '.', extensions: List[str] = None) -> List[Dict[str, Any]]:
    """
    Scan a directory for Python files to analyze
    
    Args:
        path: Directory path to scan
        extensions: File extensions to include
        
    Returns:
        List of analysis results for each file
    """
    if extensions is None:
        extensions = ['.py']
        
    results = []
    
    for root, dirs, files in os.walk(path):
        # Skip excluded directories
        dirs[:] = [d for d in dirs if d not in EXCLUDED_DIRS]
        
        for file in files:
            if any(file.endswith(ext) for ext in extensions):
                file_path = os.path.join(root, file)
                logger.info(f"Analyzing {file_path}")
                result = analyze_file(file_path)
                results.append(result)
                
    return results


def generate_report(results: List[Dict[str, Any]]) -> str:
    """
    Generate a report of the analysis results
    
    Args:
        results: List of file analysis results
        
    Returns:
        String containing the report
    """
    format_successes = sum(1 for r in results if r["format_success"])
    comment_standard_met = sum(1 for r in results if r["meets_comment_standard"])
    modules_violation_files = sum(1 for r in results if r["module_violations"] > 0)
    total_module_violations = sum(r["module_violations"] for r in results)
    
    report = f"""
# Code Standards Compliance Report

## Summary
- **Files processed**: {len(results)}
- **Black formatting successful**: {format_successes} ({format_successes/len(results)*100:.1f}%)
- **Comment standard met**: {comment_standard_met} ({comment_standard_met/len(results)*100:.1f}%)
- **Files with oversize modules**: {modules_violation_files} ({modules_violation_files/len(results)*100:.1f}%)
- **Total module size violations**: {total_module_violations}

## Files Needing Attention

### Low Comment Density
Files with comment ratio below {MIN_COMMENT_RATIO*100:.1f}%:
"""
    
    # List files with low comment density
    low_comment_files = sorted(
        [r for r in results if not r["meets_comment_standard"]], 
        key=lambda x: x["comment_ratio"]
    )
    
    for result in low_comment_files[:20]:  # Show top 20
        report += f"- {result['file_path']}: {result['comment_ratio']*100:.1f}%\n"
    
    if len(low_comment_files) > 20:
        report += f"- ... and {len(low_comment_files) - 20} more files\n"
    
    # List files with module size violations
    report += "\n### Module Size Violations\n"
    report += "Files with functions/classes exceeding the maximum size:\n"
    
    module_violation_files = sorted(
        [r for r in results if r["module_violations"] > 0],
        key=lambda x: x["module_violations"],
        reverse=True
    )
    
    for result in module_violation_files[:20]:  # Show top 20
        report += f"- {result['file_path']}: {result['module_violations']} violations\n"
        for module_name, size in result["oversize_modules"][:3]:
            report += f"  - {module_name}: {size} lines\n"
        if len(result["oversize_modules"]) > 3:
            report += f"  - ... and {len(result['oversize_modules']) - 3} more\n"
    
    if len(module_violation_files) > 20:
        report += f"- ... and {len(module_violation_files) - 20} more files\n"
        
    return report


def main():
    """Main entry point for the script"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Apply code standards to Python files"
    )
    parser.add_argument(
        "--path", 
        default=".", 
        help="Directory path to scan (default: current directory)"
    )
    parser.add_argument(
        "--report", 
        default="code_standards_report.md",
        help="Output file for the report (default: code_standards_report.md)"
    )
    
    args = parser.parse_args()
    
    logger.info(f"Scanning directory: {args.path}")
    results = scan_directory(args.path)
    
    report = generate_report(results)
    
    with open(args.report, 'w', encoding='utf-8') as f:
        f.write(report)
        
    logger.info(f"Report generated: {args.report}")
    
    # Print summary to console
    format_successes = sum(1 for r in results if r["format_success"])
    comment_standard_met = sum(1 for r in results if r["meets_comment_standard"])
    modules_violation_files = sum(1 for r in results if r["module_violations"] > 0)
    
    print(f"\nSummary:")
    print(f"- Files processed: {len(results)}")
    print(f"- Black formatting successful: {format_successes} ({format_successes/len(results)*100:.1f}%)")
    print(f"- Comment standard met: {comment_standard_met} ({comment_standard_met/len(results)*100:.1f}%)")
    print(f"- Files with oversize modules: {modules_violation_files} ({modules_violation_files/len(results)*100:.1f}%)")


if __name__ == "__main__":
    main()